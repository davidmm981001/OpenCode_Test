# Project Context

## Project
David test 28

## User Stories
## 1. Eliminar un usuario registrando observaciones y actualizando el estado BANCS asociado
Módulo: Administración de Usuarios

Como responsable de administración de usuarios, necesito eliminar un usuario de forma controlada, dejando constancia de observaciones y asegurando que la relación con BANCS quede en un estado consistente. La implementación se observa en SSITP007.cbl, específicamente en VALIDA-ELIMINA, donde primero se exige observación, luego se marca P015-TIPO='E', se procesa el requerimiento principal y, si existen datos BANCS, se actualiza T95BAN04 con EST_PROCESO='TE' mediante MODIFICA-ESTADO-BANCS. Después se ejecuta ELIMINA-OBSERVACION sobre T95OBS04 y se graba el log. Aunque existe el párrafo ELIMINA-USR sobre T95BAN04, en el flujo principal de eliminación usado aquí no se borra el vínculo BANCS, sino que se modifica su estado. Por tanto, la migración debe respetar esta intención: eliminación funcional del usuario administrado con conservación de trazas y transición del estado BANCS. La interfaz moderna debe sustituir la tecla PF5 por una acción de eliminar con confirmación modal, mostrando claramente el impacto. También debe impedir la eliminación si faltan observaciones, ya que esa regla está explícitamente codificada y además responde a un requisito de auditoría presente en mapas y logs.

Actor: Usuario

Flujo funcional:
1. El usuario abre el detalle de un usuario existente.
2. Selecciona la acción de eliminar.
3. El sistema solicita confirmación y exige registrar observaciones de la eliminación.
4. El usuario confirma la operación con una observación válida.
5. El sistema elimina el usuario en la fuente principal según el procesamiento del requerimiento.
6. Si existe relación BANCS informada, el sistema actualiza su estado a equivalente de terminado ('TE') y conserva trazabilidad.
7. El sistema elimina la observación operativa almacenada en la fuente correspondiente a T95OBS04.
8. El sistema registra la auditoría de la operación y actualiza el listado visible sin el usuario eliminado o con su estado resultante, según corresponda al diseño final de datos.

Pantallas / superficies: Mapa BMS: SSI0701 (SSIM007.bms); Programa origen: SSITP007.cbl (VALIDA-ELIMINA, MODIFICA-ESTADO-BANCS, ELIMINA-OBSERVACION, WRITELOG); Ruta React propuesta: /seguridad/usuarios/:userId

Reglas de negocio:
- Para eliminar es obligatorio ingresar observaciones.
- El tipo de operación de eliminación es 'E'.
- Si existen datos BANCS informados, T95BAN04 se actualiza con EST_PROCESO='TE'.
- En la eliminación se ejecuta borrado de observación en T95OBS04 por COD_USUARIO.
- El flujo principal de eliminación incluye escritura de log.
- Si falta observación, el origen muestra 'Ingrese Observaciones'.

Notas técnicas:
La operación debe exponerse como acción REST protegida y transaccional. Dado que el origen combina eliminación funcional del usuario principal y cambio de estado en BANCS, la migración debe documentar claramente si el borrado en PostgreSQL será físico o lógico para la entidad principal; el código analizado muestra PROCESA-REQUERIMIENTO hacia PRG016, pero no expone directamente el SQL del usuario principal. Por trazabilidad, se recomienda auditoría persistente y confirmación modal en React. confianza: media
Criterios:
  1. Dado que el usuario está visualizando el detalle de 'USR00001', cuando pulsa 'Eliminar', entonces la aplicación muestra un modal de confirmación que exige observaciones antes de continuar.
  2. Dado que el campo observaciones está vacío, cuando el usuario confirma la eliminación, entonces el sistema rechaza la operación e informa que debe ingresar observaciones.
  3. Dado que la eliminación fue confirmada con observación válida, cuando el sistema completa la operación, entonces el usuario eliminado deja de aparecer en el listado actualizado sin recarga manual completa de la página.
  4. Dado que el usuario eliminado tenía relación BANCS registrada, cuando finaliza la operación, entonces la fuente equivalente a BANCS refleja el estado de proceso 'TE' asociado al usuario.
  5. Dado que existía una observación operativa previa del usuario, cuando se completa la eliminación, entonces esa observación deja de estar disponible en la fuente equivalente a T95OBS04.
  6. Dado que el backend procesa la eliminación, cuando el frontend recibe la respuesta de negocio correspondiente, entonces el cuerpo JSON expone solo los campos de negocio acordados para confirmar el resultado de la operación.

---

## 2. Modificar un usuario existente preservando consistencia con BANCS y observaciones
Módulo: Administración de Usuarios

Como usuario responsable de seguridad, necesito modificar un usuario existente para mantener actualizados sus datos de negocio, su perfil, su empresa/centro y su relación operativa con BANCS, sin perder trazabilidad del estado anterior. La evidencia está en SSITP007.cbl, en VALIDA-MODIFICA, donde se almacenan valores previos en LOG-PERS, LOG-CENTRO y LOG-AUTORIZA para el registro de auditoría, y luego se ejecutan las mismas validaciones de VALIDA-CAMPOS antes de llamar a PROCESA-REQUERIMIENTO, CONSULTA-BANCS, MODIFICA-USR y MODIFICA-OBSER. El flujo incluye reglas específicas: si el usuario ya existe en BANCS y el estado es 'TE', se pasa a 'TC'; si no se informan usuario/terminal BANCS pero sí existían previamente, se conservan o se reflejan según la lógica implementada; y si el update en T95BAN04 devuelve SQLCODE 100, el origen intenta insertar mediante INGRESA-USR. La historia de migración debe centrarse en la edición de un solo usuario, mostrando el estado actual, permitiendo cambios controlados y actualizando tanto la información principal como observaciones y relación BANCS. Debe conservarse la actualización visible inmediata en la SPA y la validación de reglas de negocio ya observadas, evitando cualquier interpretación de edición masiva o workflow adicional no evidenciado.

Actor: Usuario

Flujo funcional:
1. El usuario abre el detalle de un usuario existente.
2. El sistema carga los datos actuales del registro y su información relacionada.
3. El usuario modifica los campos permitidos como nombre, empresa, centro, cargo, perfil, autorizador, oficina Swift, observaciones y datos BANCS.
4. El sistema valida nuevamente reglas obligatorias y catálogos asociados.
5. El sistema actualiza el registro principal del usuario.
6. El sistema actualiza la observación y la información BANCS aplicando la lógica de existencia previa y estado de proceso.
7. El sistema registra la operación de modificación con referencia al estado anterior relevante.
8. Tras guardar, la interfaz actualiza el detalle y cualquier listado asociado sin recarga manual completa.

Pantallas / superficies: Mapa BMS: SSI0701 (SSIM007.bms); Programa origen: SSITP007.cbl (VALIDA-MODIFICA, MODIFICA-USR, MODIFICA-OBSER, CONSULTA-BANCS); Ruta React propuesta: /seguridad/usuarios/:userId; Endpoint Spring propuesto por migración funcional: PUT /api/seguridad/usuarios/{userId}

Reglas de negocio:
- En modificación se conservan valores previos de perfil, centro y autorizador para auditoría.
- Se aplican las mismas validaciones de campos obligatorios que en el alta.
- Si oficina Swift se informa, debe ser 'MSQUTODO'.
- Si existe relación BANCS previa con estado 'TE', la modificación la ajusta a 'TC'.
- Si UPDATE de T95BAN04 no encuentra registro (SQLCODE 100), el origen intenta insertar por INGRESA-USR.
- Si ocurre duplicidad en T95BAN04, el origen informa 'Usuario Bancs Duplicado'.
- La observación del usuario se actualiza en T95OBS04; si no existe, se inserta.

Notas técnicas:
Conviene modelar la modificación como un caso de uso transaccional en Spring que actualice usuario principal, observación y vínculo BANCS con manejo centralizado de excepciones. La lógica fallback de UPDATE luego INSERT observada en COBOL puede implementarse explícitamente como upsert controlado, cuidando unicidad e idempotencia en PostgreSQL. React Query debe invalidar la caché del detalle y del listado tras la modificación exitosa. confianza: alta
Criterios:
  1. Dado que existe el usuario 'USR00001', cuando el usuario modifica su nombre y guarda, entonces el detalle muestra el nuevo nombre persistido sin recarga manual completa de la página.
  2. Dado que el usuario modifica el perfil a uno inexistente en la fuente equivalente a T01GRE20, cuando intenta guardar, entonces el sistema rechaza la modificación e informa que el perfil no está definido.
  3. Dado que el usuario deja vacías las observaciones durante la modificación, cuando intenta guardar, entonces el sistema muestra un error asociado al campo observaciones.
  4. Dado que el usuario informa un usuario BANCS ya asociado de forma duplicada según la restricción del sistema, cuando intenta guardar, entonces el sistema informa 'Usuario Bancs Duplicado' o su equivalente funcional.
  5. Dado que el usuario tenía un detalle abierto y la modificación fue exitosa, cuando retorna al listado filtrado, entonces la fila correspondiente refleja los datos persistidos en PostgreSQL sin recarga manual completa.
  6. Dado que el backend devuelve la representación del usuario modificado, cuando el frontend recibe el recurso JSON, entonces el cuerpo expone solo los campos de negocio acordados para el usuario actualizado.

---

## 3. Registrar un nuevo usuario con validación de perfil, empresa, centro y datos BANCS
Módulo: Administración de Usuarios

Como administrador o usuario autorizado del módulo de seguridad, necesito crear un nuevo usuario con todas las validaciones obligatorias para asegurar que el registro quede consistente con los catálogos y con la integración BANCS. Esta necesidad está implementada en SSITP007.cbl mediante VALIDA-INGRESO y la rutina VALIDA-CAMPOS, además de INGRESA-USR, MODIFICA-OBSER y las comprobaciones sobre T95PAR02, T01GRE20, T06TC005, T06TC007 y T95BAN04. El origen exige usuario, nombre, observaciones, perfil, empresa y centro; valida que la oficina Swift, si se informa, sea exactamente 'MSQUTODO'; verifica que el perfil exista en T95PAR02 con COD_PARAMETRO='GR' y también en T01GRE20; exige coherencia entre usuario BANCS y terminal BANCS; y, si ambos datos BANCS existen, inserta en T95BAN04 con EST_PROCESO='TC'. Además, para altas inicializa ciertos campos de logon en cero o espacios. La migración debe convertir este comportamiento en un formulario React con validación inmediata y verificación backend definitiva, manteniendo la integridad de negocio y una experiencia más clara que el mapa 3270. La historia no debe asumir alta de contraseña porque el programa analizado no la ejecuta dentro del flujo de alta del usuario principal.

Actor: Usuario

Flujo funcional:
1. El usuario abre el formulario de alta.
2. Ingresa usuario, nombre, cédula si aplica, empresa, centro, cargo, perfil, indicador de autorizador, oficina Swift, observaciones y datos BANCS cuando correspondan.
3. El sistema valida campos obligatorios y reglas de consistencia antes de guardar.
4. El sistema verifica existencia del perfil en catálogos, existencia de empresa y centro, y coherencia de datos BANCS.
5. Si las validaciones son correctas, el sistema crea el usuario principal.
6. Si se informaron usuario BANCS y terminal BANCS, el sistema registra además la relación en la fuente equivalente a T95BAN04 con estado de proceso de alta.
7. El sistema registra o actualiza la observación del usuario.
8. Tras el alta exitosa, la vista refleja el estado persistido y muestra mensaje de confirmación.

Pantallas / superficies: Mapa BMS: SSI0701 (SSIM007.bms); Programa origen: SSITP007.cbl (VALIDA-INGRESO, VALIDA-CAMPOS, INGRESA-USR, MODIFICA-OBSER); Ruta React propuesta: /seguridad/usuarios/nuevo; Endpoint Spring propuesto por migración funcional: POST /api/seguridad/usuarios

Reglas de negocio:
- Usuario es obligatorio.
- Nombre es obligatorio.
- Observaciones son obligatorias.
- Perfil es obligatorio.
- Si se informa oficina Swift, solo se acepta 'MSQUTODO'.
- El perfil debe existir en T95PAR02 con COD_PARAMETRO='GR'.
- El perfil debe existir también en T01GRE20.
- La empresa debe existir en T06TC005.
- El centro debe existir en T06TC007 para la empresa indicada.
- Si se informa usuario BANCS, debe informarse también terminal BANCS.
- Si se informa terminal BANCS, debe informarse también usuario BANCS.
- Si se informan ambos datos BANCS, se inserta registro en T95BAN04 con EST_PROCESO='TC'.
- En alta se inicializan fechas y horas de logon en cero y otros campos de signon en blanco.

Notas técnicas:
Migración recomendada: formulario React con Zod/Yup y backend Spring con Bean Validation + validadores de negocio en servicio. La lógica de alta no debe distribuirse entre frontend y backend; el backend debe ser la fuente final de reglas. SQL embebido de comprobación COUNT(*) se migra a repositorios específicos con existsBy... en Spring Data. Las observaciones de T95OBS04 deben persistirse dentro de la misma transacción de negocio cuando aplique. La integración BANCS observada en T95BAN04 no aparece como API externa sino como tabla local/relacional en el código analizado. confianza: alta
Criterios:
  1. Dado que el usuario está en el formulario de alta, cuando deja vacío el campo usuario y pulsa guardar, entonces la interfaz muestra un error asociado al campo usuario.
  2. Dado que el usuario informa oficina Swift 'ABC', cuando intenta guardar, entonces la interfaz muestra que el único valor permitido es 'MSQUTODO'.
  3. Dado que el perfil informado no existe en la fuente equivalente a T95PAR02 con parámetro 'GR', cuando se intenta guardar, entonces el sistema rechaza el alta e informa que el perfil no está definido.
  4. Dado que la empresa '9999' no existe en la fuente equivalente a T06TC005, cuando se intenta guardar, entonces el sistema rechaza el alta e informa que la empresa no está definida.
  5. Dado que el usuario informa usuario BANCS '12345678' y deja vacía la terminal BANCS, cuando intenta guardar, entonces el sistema rechaza el alta e informa que debe ingresar la terminal BANCS.
  6. Dado un alta exitosa de usuario, cuando el sistema persiste la información, entonces el detalle o listado refleja el nuevo registro almacenado en PostgreSQL sin requerir recarga manual completa de página.

---

## 4. Validar y mostrar información descriptiva de perfil, empresa y centro en formularios de usuario
Módulo: Administración de Usuarios

Como usuario del módulo de seguridad, necesito que el formulario me muestre las descripciones asociadas al perfil, a la empresa y al centro para confirmar que estoy trabajando con códigos correctos y reducir errores de digitación. Esta necesidad está soportada por SSITP007.cbl en los párrafos GETRECU, GETCENTRO y GETEMPRESA, que consultan respectivamente T95PAR02, T06TC007 y T06TC005 para poblar W-DETALLE y luego mostrar los textos en M15DPVMO, M15DCENO y M15DEMPO del mapa SSIM007.bms. Además, las validaciones de VALIDA-CAMPOS no solo consultan existencia, sino que devuelven mensajes explícitos cuando el perfil, la empresa o el centro no están definidos. La migración debe trasladar este comportamiento a ayudas contextuales en el formulario React, idealmente con resolución automática de descripciones al ingresar el código o seleccionar el valor, manteniendo la verificación definitiva en backend. Esta historia no introduce nuevos catálogos ni autocompletados no evidenciados; se limita a reflejar la evidencia de que el sistema ya expone descripciones y utiliza esos catálogos como parte del flujo de alta, modificación y consulta individual.

Actor: Usuario

Flujo funcional:
1. El usuario abre el formulario de alta, edición o consulta individual.
2. Ingresa o visualiza el código de perfil.
3. El sistema resuelve y muestra la descripción del perfil si existe.
4. El usuario ingresa o visualiza el código de empresa y de centro.
5. El sistema resuelve y muestra los nombres descriptivos de empresa y centro.
6. Si algún código no existe en su catálogo correspondiente, el sistema muestra el mensaje de validación y no confirma la operación.
7. Las descripciones visibles se actualizan cuando cambian los códigos asociados.

Pantallas / superficies: Mapa BMS: SSI0701 (SSIM007.bms); Programa origen: SSITP007.cbl (GETRECU, GETCENTRO, GETEMPRESA, VALIDA-CAMPOS); Componente React propuesto: UserForm

Reglas de negocio:
- La descripción del perfil proviene de T95PAR02 con COD_PARAMETRO='GR'.
- Si el perfil no existe en T95PAR02, el origen informa 'Perfil NO definido en T95PAR02'.
- Si el perfil no existe en T01GRE20, el origen informa 'Perfil RE no definido en T01GRE20'.
- Si la empresa no existe en T06TC005, el origen informa 'Empresa no definida T06TC005'.
- Si el centro no existe en T06TC007 para la empresa indicada, el origen informa 'Centro no definido T06TC007'.
- El mapa muestra campos descriptivos separados para perfil, empresa y centro.

Notas técnicas:
Esta historia puede resolverse con endpoints de catálogos o con resolución incluida en el endpoint de detalle, siempre sin inventar catálogos no evidenciados. En React, los textos descriptivos se muestran en campos de solo lectura sincronizados con el código digitado. En PostgreSQL conviene indexar códigos de perfil, empresa y centro por ser usados en validaciones frecuentes. confianza: alta
Criterios:
  1. Dado que el usuario informa el perfil 'PERF0001' existente, cuando el sistema valida el formulario, entonces se muestra la descripción correspondiente del perfil junto al código ingresado.
  2. Dado que el usuario informa un perfil inexistente, cuando intenta guardar, entonces el sistema informa que el perfil no está definido y no persiste cambios.
  3. Dado que el usuario informa la empresa '0001' existente, cuando el sistema resuelve el código, entonces se muestra el nombre descriptivo de la empresa en el formulario.
  4. Dado que el usuario informa centro '0002' para la empresa '0001' y ambos existen relacionados, cuando se valida el formulario, entonces se muestra el nombre descriptivo del centro.
  5. Dado que el usuario cambia el código de empresa o centro en pantalla, cuando termina la validación de ese campo, entonces la descripción visible se actualiza sin recarga manual completa de la página.
  6. Dado que el frontend consume la resolución de códigos, cuando recibe el recurso JSON asociado, entonces el cuerpo expone solo los campos de negocio acordados para código y descripción de perfil, empresa y centro.

---

## 5. Consultar el detalle completo de un usuario con datos de perfil, empresa, centro y observaciones
Módulo: Administración de Usuarios

Como usuario del módulo de seguridad, necesito consultar el detalle completo de un usuario para validar su identificación, su perfil, la empresa y centro asociados, el contexto de BANCS y la observación registrada antes de decidir una acción administrativa. La evidencia principal está en SSITP007.cbl, especialmente en VALIDA-ENTER, PROCESA-REQUERIMIENTO, GETRECU, GETCENTRO, GETEMPRESA, GETOBSER, CONSULTA-USR y CONSULTA-BANCS, así como en el mapa SSIM007.bms. El programa obliga a ingresar el usuario, invoca PRG016 para consultar el registro principal y luego enriquece la pantalla con descripciones de perfil desde T95PAR02, nombre de centro desde T06TC007, nombre de empresa desde T06TC005, observación desde T95OBS04 y datos BANCS desde T95BAN04. La historia de migración debe preservar esa consulta enriquecida, sin replicar el envío/recepción de mapa ni la COMMAREA CICS, sino exponiendo un detalle único y consistente en la SPA. También debe reflejar los metadatos mostrados en el origen: fecha y hora de actualización, usuario modificador, terminal, último signon e indicador de autorizador. Si el usuario no se ingresa o no existe, la aplicación debe informar el resultado con mensajes equivalentes a los del origen y no mostrar datos inconsistentes.

Actor: Usuario

Flujo funcional:
1. El usuario accede al formulario de administración individual.
2. Ingresa o selecciona un código de usuario para consultar.
3. El sistema valida que el identificador de usuario haya sido informado.
4. El sistema consulta el registro principal del usuario y recupera su detalle funcional.
5. El sistema enriquece el detalle con descripción de perfil, nombre de empresa, nombre de centro, observación y datos BANCS si existen.
6. El sistema muestra el formulario completo con campos editables y campos solo lectura según el origen.
7. Si el usuario no existe o la consulta falla, el sistema informa el mensaje correspondiente y no deja datos parciales inconsistentes en pantalla.

Pantallas / superficies: Mapa BMS: SSI0701 (SSIM007.bms); Programa origen: SSITP007.cbl; Ruta React propuesta: /seguridad/usuarios/:userId; Endpoint Spring propuesto por migración funcional: GET /api/seguridad/usuarios/{userId}

Reglas de negocio:
- El usuario es obligatorio para consultar; mensaje origen: 'Ingrese usuario' o 'Ingrese Usuario'.
- La consulta principal se canaliza por PROCESA-REQUERIMIENTO hacia PRG016.
- La descripción del perfil se obtiene desde T95PAR02 con COD_PARAMETRO='GR'.
- El nombre del centro se obtiene desde T06TC007 usando empresa y centro.
- El nombre de la empresa se obtiene desde T06TC005 usando código de empresa.
- La observación se obtiene desde T95OBS04 por COD_USUARIO.
- Los datos BANCS se obtienen desde T95BAN04 por USR_SIGLO21.
- Si CONSULTA-USR no encuentra registro en BAN04, el origen informa 'User no existe en BAN04'.

Notas técnicas:
Patrón origen: pantalla BMS enriquecida por múltiples consultas SQL y LINK a PRG016. En la migración conviene un endpoint de detalle agregado que componga la información de usuario principal y catálogos relacionados. Campos COBOL PIC X y numéricos deben mapearse a String, Integer o BigDecimal según corresponda; por ejemplo TERM_NO NUMBER(5) a Integer, fechas char a LocalDate/String según normalización disponible. Los atributos BMS PROT/UNPROT se traducen a inputs readOnly/editables en React. confianza: alta
Criterios:
  1. Dado que el usuario abre el detalle de 'USR00001', cuando la consulta finaliza correctamente, entonces la pantalla muestra usuario, nombre, perfil, empresa, centro, cargo, autorizador, oficina swift y observaciones.
  2. Dado que no se informó un código de usuario, cuando el usuario intenta consultar el detalle, entonces la interfaz muestra el mensaje 'Ingrese usuario' o su equivalente definido para la migración.
  3. Dado que el usuario consultado tiene perfil existente en parámetros, cuando se carga el detalle, entonces se muestra también la descripción del perfil obtenida desde la fuente equivalente a T95PAR02.
  4. Dado que el usuario consultado tiene empresa y centro válidos, cuando se carga el detalle, entonces se muestran los nombres descriptivos de empresa y centro junto a sus códigos.
  5. Dado que existe una observación registrada para el usuario, cuando se carga el detalle, entonces el campo de observaciones muestra el último texto persistido.
  6. Dado que el backend entrega el detalle del usuario, cuando el frontend recibe el recurso JSON, entonces el cuerpo expone solo los campos de negocio acordados para el detalle enriquecido.

---

## 6. Seleccionar un usuario del listado y abrir su detalle para consulta o edición
Módulo: Consulta General de Usuarios

Como usuario del área de seguridad, necesito seleccionar un registro desde la consulta general y abrir su detalle para revisar o continuar con una modificación, manteniendo la transición funcional entre el listado y la administración individual del usuario. La trazabilidad es directa a SSITP002.cbl, particularmente en TECLA-PF4 y TECLA-PF2. PF2 realiza un XCTL a SSITP007 con P015-COMMAREA='0' para iniciar alta, mientras PF4 valida la selección P02SELI entre 1 y 14, toma la clave SSI02-CLAVE(I) y transfiere el control a SSITP007 con P015-COMMAREA='2' y P015-SIGLO21 informado. También existe el flujo RECIBE-SSITP002 en SSITP007.cbl, que interpreta la COMMAREA para precargar datos del usuario consultado. En la aplicación React, esta interacción debe sustituirse por acciones de tabla como 'Nuevo usuario' y 'Editar', eliminando la necesidad de ingresar un índice numérico de selección pero respetando el mismo propósito. La historia cubre la selección de fila, apertura del detalle con datos precargados, control de selección inválida equivalente a 'Seleccion Errada', y conservación del contexto de navegación para retornar al listado. No se debe asumir edición masiva ni selección múltiple, ya que el origen claramente trabaja sobre una sola fila seleccionada.

Actor: Usuario

Flujo funcional:
1. El usuario ejecuta una consulta y visualiza resultados en el listado.
2. El usuario elige crear un nuevo usuario o editar uno existente desde acciones visibles en la interfaz.
3. Si elige crear, el sistema navega al formulario de administración en modo alta con campos vacíos.
4. Si elige editar una fila válida, el sistema navega al detalle del usuario seleccionado con datos precargados.
5. El sistema conserva el identificador del usuario seleccionado para recuperar su información completa.
6. Si el usuario intenta editar sin una fila válida seleccionada, el sistema informa que la selección es incorrecta.
7. Desde el detalle, el usuario puede regresar al listado manteniendo los filtros previos cuando aplique.

Pantallas / superficies: Programa origen: SSITP002.cbl (TECLA-PF2, TECLA-PF4) y SSITP007.cbl (RECIBE-SSITP002); Mapas BMS: SSI0201, SSI0701; Rutas React propuestas: /seguridad/usuarios, /seguridad/usuarios/nuevo, /seguridad/usuarios/:userId

Reglas de negocio:
- PF2 en el origen inicia alta de usuario invocando SSITP007 con P015-COMMAREA='0'.
- PF4 en el origen inicia edición si P02SELI está entre 1 y 14 y la clave seleccionada no está en blanco.
- Si la selección es inválida, el origen muestra 'Seleccion Errada'.
- La clave transferida al detalle es P015-SIGLO21.
- El flujo de precarga del detalle está implementado en RECIBE-SSITP002 de SSITP007.

Notas técnicas:
La COMMAREA usada entre SSITP002 y SSITP007 debe migrarse a navegación SPA con parámetro de ruta o estado de navegación. PF2/PF4 se traducen a botones 'Nuevo' y 'Editar'. El detalle no debe depender de estado implícito de pantalla como en CICS; debe recuperar datos mediante endpoint de detalle o caché de React Query. Arquitectura sugerida: lista y detalle desacoplados con rutas hijas y breadcrumbs. confianza: alta
Criterios:
  1. Dado que el usuario visualiza el listado de usuarios, cuando pulsa la acción 'Nuevo usuario', entonces la aplicación navega a /seguridad/usuarios/nuevo y presenta el formulario vacío.
  2. Dado que el listado contiene una fila con usuario 'USR00001', cuando el usuario pulsa la acción 'Editar' sobre esa fila, entonces la aplicación navega a /seguridad/usuarios/USR00001 y muestra el detalle precargado.
  3. Dado que no existe una fila válida seleccionada para editar, cuando el usuario intenta abrir el detalle desde una acción contextual no disponible, entonces la interfaz informa que la selección es incorrecta y no navega.
  4. Dado que el detalle fue abierto desde el listado filtrado por empresa '0001', cuando el usuario regresa al listado, entonces los filtros y la página visibles se conservan sin recarga manual completa.
  5. Dado que el frontend consulta el detalle del usuario, cuando recibe el recurso JSON, entonces el cuerpo expone solo los campos de negocio acordados para la administración individual del usuario.
  6. Dado que el usuario abrió el detalle de un registro existente, cuando la pantalla termina de cargar, entonces se muestran el identificador de usuario y los datos de negocio leídos desde la persistencia.

---

## 7. Consultar usuarios por empresa, centro, usuario, perfil o nombre con paginación
Módulo: Consulta General de Usuarios

Como usuario operativo del módulo de seguridad, necesito consultar usuarios usando distintos criterios para localizar rápidamente registros en la tabla de usuarios y decidir si debo revisar o editar un detalle. Esta necesidad está claramente implementada en SSITP002.cbl, descrito como 'CONSULTA GENERAL DE USUARIOS TABLA T95USU03', y en el mapa SSIM002.bms. El programa soporta búsqueda por empresa, centro, usuario, perfil y nombre a través de cursores SQL separados: CEMPRESA, CCENTRO, CCODIGO, CPERFIL y CNOMBRE, todos sobre M2D.T95USU03. También aplica un comportamiento de paginación manual por desplazamiento de registros usando WS-PAGINAR, W-CONTADOR y un máximo visible de 14 filas en P02DETA OCCURS 14. En la aplicación modernizada, esta intención debe trasladarse a una grilla React con filtros explícitos y paginación backend, manteniendo los mismos criterios observados y el límite visual equivalente. No debe inventarse búsqueda combinada avanzada porque el origen evalúa un único criterio efectivo según prioridad de campos. La historia cubre captura de filtros, ejecución de la búsqueda, presentación del listado resumido con usuario, nombre, perfil, empresa, centro, dominio, nodo y autorización, y mensajes equivalentes a 'Ingrese Criterio Consulta', 'Existen mas Datos' y 'No existen mas Datos', pero con UX web sobria y accesible.

Actor: Usuario

Flujo funcional:
1. El usuario accede a la consulta general de usuarios.
2. El sistema muestra filtros equivalentes a empresa, centro, usuario, perfil, nombre y un área de resultados.
3. El usuario ingresa uno de los criterios disponibles y solicita la búsqueda.
4. El sistema determina el criterio aplicado según la prioridad observada en SSITP002: empresa, centro, usuario, perfil y luego nombre.
5. El sistema consulta la fuente de usuarios y presenta hasta 14 resultados por página con los campos resumidos del listado.
6. El usuario navega entre páginas para ver más resultados o retroceder.
7. Si no ingresa ningún criterio, el sistema informa que debe ingresar un criterio de consulta.
8. Si no existen más datos para el criterio seleccionado, el sistema lo informa en la interfaz.

Pantallas / superficies: Mapa BMS: SSI0201 (SSIM002.bms); Programa origen: SSITP002.cbl; Ruta React propuesta: /seguridad/usuarios; Endpoint Spring propuesto por migración funcional: GET /api/seguridad/usuarios

Reglas de negocio:
- La tabla origen consultada es M2D.T95USU03.
- Los criterios evidenciados son empresa, centro, usuario, perfil y nombre.
- El programa aplica prioridad secuencial del criterio: empresa, centro, usuario, perfil, nombre.
- Si no se ingresa ningún criterio, se muestra 'Ingrese Criterio Consulta'.
- El listado visible en origen contiene 14 renglones (P02DETA OCCURS 14).
- Para usuario y perfil, los espacios se transforman en '%' para búsquedas tipo LIKE.
- Para nombre, los espacios se transforman en '%' para búsquedas tipo LIKE.
- Mensajes origen: 'Existen mas Datos', 'No existen mas Datos', 'Error grave tabla USUARIOS', 'Error open cursor ...'.

Notas técnicas:
Migración de cursores FETCH de COBOL/CICS a paginación REST con parámetros query. Los cinco cursores SQL del origen deben convertirse en consultas parametrizadas en Spring Data/JPA o consultas SQL específicas en repositorio. La paginación manual por WS-PAGINAR se reemplaza por page/size conservando un tamaño por defecto de 14 para equivalencia funcional con SSI0201. La pantalla BMS con OCCURS 14 se transforma en tabla React responsive con selección por fila. Dado que el origen prioriza un solo criterio, conviene validar en frontend y backend que solo se aplique el primer criterio informado o definirlo explícitamente en contrato. confianza: alta
Criterios:
  1. Dado que el usuario accede a /seguridad/usuarios, cuando la pantalla termina de cargar, entonces visualiza filtros para empresa, centro, usuario, perfil y nombre junto con una tabla de resultados vacía o inicial.
  2. Dado que no se ingresó empresa, centro, usuario, perfil ni nombre, cuando el usuario ejecuta la búsqueda, entonces la interfaz muestra el mensaje 'Ingrese Criterio Consulta'.
  3. Dado que el usuario ingresa empresa '0001', cuando ejecuta la búsqueda, entonces la tabla muestra únicamente usuarios cuyo código de empresa es '0001'.
  4. Dado que el usuario ingresa nombre 'ANA', cuando ejecuta la búsqueda, entonces la tabla muestra registros cuyo nombre coincide según patrón de búsqueda equivalente al LIKE del programa SSITP002.
  5. Dado que existen más de 14 usuarios para el criterio consultado, cuando el usuario avanza a la siguiente página, entonces la tabla reemplaza los renglones visibles por el siguiente conjunto sin recargar manualmente toda la página.
  6. Dado que el backend responde a la consulta de usuarios, cuando el frontend recibe el recurso JSON, entonces el cuerpo expone solo los campos de negocio acordados para usuario, nombre, perfil, empresa, centro, dominio, nodo y autoriza.

---

## 8. Acceder al módulo de seguridad desde un menú principal moderno
Módulo: Navegación de Seguridad

Como usuario del módulo de seguridad, necesito ingresar a las funciones disponibles desde una navegación visual y no mediante códigos numéricos, para reducir errores de operación y hacer la aplicación más usable sin perder la intención funcional del programa legacy. La evidencia principal está en PRG000 de SSIM000.cbl y el mapa SSIM000.bms, donde el menú principal expone opciones numeradas y redirige mediante EXEC CICS XCTL a programas como SSITP002 para administración de usuarios. En la migración, la equivalencia funcional no debe replicar el patrón 3270 de ingresar un número en M1OPCIOI, sino transformarlo en un dashboard o sidebar con opciones visibles, manteniendo la misma jerarquía de acceso al módulo de seguridad. El alcance de esta historia cubre la presentación del menú principal, la visualización del contexto de sesión equivalente a USERID, terminal y fecha/hora mostrados en el mapa, y la navegación hacia la consulta general de usuarios. Cuando el código origen informa teclas inválidas u opción no válida, la versión web deberá reflejarlo como estados de interacción y deshabilitar accesos no implementados, sin inventar nuevas opciones. Esta historia sirve como puerta de entrada coherente para el resto de funcionalidades detectadas en los programas COBOL y mapas BMS analizados.

Actor: Usuario

Flujo funcional:
1. El usuario autenticado accede al módulo de seguridad.
2. El sistema muestra un menú principal con opciones visibles equivalentes a las del mapa PRG00M1, incluyendo acceso a Administración de Usuarios.
3. El sistema presenta contexto de sesión visible con usuario autenticado, aplicación y fecha/hora actuales, tomando como referencia los datos mostrados en SSIM000.cbl.
4. El usuario selecciona la opción de Administración de Usuarios desde un botón, card o elemento del menú.
5. El sistema navega a la pantalla de consulta general de usuarios equivalente a SSITP002.
6. Si una opción del menú no forma parte del alcance migrado actual, el sistema la muestra como no disponible sin permitir navegación errónea.
7. Si la sesión no es válida o no existe usuario autenticado, el sistema impide el acceso al módulo.

Pantallas / superficies: Mapa BMS: PRG00M1 (SSIM000.bms); Programa origen: PRG000 (SSIM000.cbl); Ruta React propuesta: /seguridad; Ruta React propuesta: /seguridad/usuarios

Reglas de negocio:
- El menú principal del módulo de seguridad expone opciones numeradas en el origen, pero la migración debe conservar la intención funcional y no el mecanismo de captura numérica.
- La opción 1 del menú legacy redirige a SSITP002.
- Si el valor ingresado en M1OPCIOI no es numérico, el origen muestra 'Ingrese un valor numerico'.
- Si la opción no está entre 1 y 10, el origen muestra 'Opcion invalida'.
- Si no existe USERID en CICS, el programa finaliza sin continuar.
- CLEAR en el origen termina el flujo y retorna.

Notas técnicas:
Tecnología origen detectada: COBOL/CICS con mapas BMS y navegación por XCTL. Patrón legado PRG000 + PRG00M1 debe migrarse a React Router con navegación declarativa y a Spring Security para exponer datos de sesión. EXEC CICS ASSIGN USERID/APPLID se mapea funcionalmente a claims de autenticación y/o endpoint de sesión. El menú numérico se sustituye por componentes React accesibles con cards o sidebar. No hay evidencia de API REST existente en el input; por tanto, la navegación moderna es propuesta de migración y no reutilización directa. Arquitectura sugerida: frontend React con rutas protegidas y backend Spring para contexto de sesión. confianza: alta
Criterios:
  1. Dado un usuario autenticado con acceso al módulo de seguridad, cuando ingresa a la ruta /seguridad, entonces visualiza un menú corporativo con la opción Administración de Usuarios disponible sin necesidad de ingresar códigos numéricos.
  2. Dado que el menú principal fue cargado, cuando se renderiza la cabecera, entonces se muestran el identificador del usuario autenticado, la fecha y la hora actuales en pantalla.
  3. Dado que el usuario se encuentra en /seguridad, cuando selecciona Administración de Usuarios, entonces la aplicación navega a /seguridad/usuarios y muestra la vista de consulta general.
  4. Dado que existe una opción de menú fuera del alcance migrado actual, cuando el usuario la visualiza, entonces el sistema la presenta como no disponible o deshabilitada sin redirigir a una pantalla inexistente.
  5. Dado un usuario sin sesión válida, cuando intenta acceder a /seguridad, entonces la aplicación bloquea el acceso y redirige al flujo de autenticación configurado.
  6. Dado que el frontend consume el contexto de sesión, cuando recibe el recurso JSON correspondiente, entonces el cuerpo expone solo los campos de negocio acordados para usuario, aplicación, fecha y hora.

---

## 9. Registrar auditoría de altas, modificaciones y eliminaciones de usuarios
Módulo: Administración de Usuarios

Como área de control o seguridad, necesito que cada operación administrativa sobre usuarios quede auditada con suficiente detalle para reconstruir quién realizó la acción, sobre qué usuario y con qué datos relevantes. La trazabilidad es directa al párrafo WRITELOG de SSITP007.cbl, que construye R-T95LOG01 y llama a PRG008. El código identifica la transacción 'T95USU03' y registra operaciones 'INGRESO', 'MODIFICACION' o 'ELIMINACION'. También concatena en T95LOG01-MENSAJERIA el usuario, nombre, perfil, centro, autorizador, valores anteriores en caso de modificación y las observaciones capturadas en M15SOLICI, separadas por ';'. Además completa información de terminal, usuario modificador y mensaje de respuesta. Esta historia debe migrar ese comportamiento a una auditoría moderna persistida y consultable, sin reproducir el formato posicional exacto pero sí preservando el contenido sustancial y la trazabilidad. Es especialmente importante porque el propio mapa SSIM007 documenta ampliaciones del campo observaciones para auditoría. La historia cubre la generación del evento auditado en altas, modificaciones y eliminaciones, la persistencia del detalle clave y la relación con el usuario autenticado que ejecutó la acción.

Actor: Usuario

Flujo funcional:
1. El usuario ejecuta una alta, modificación o eliminación de usuario.
2. El sistema procesa la operación de negocio principal.
3. El sistema construye un registro de auditoría con tipo de operación, usuario afectado y observaciones.
4. Si la operación es modificación, el sistema incluye también los valores previos relevantes de perfil, centro y autorizador observados en el origen.
5. El sistema almacena el registro auditado con fecha/hora, usuario ejecutor y terminal o su equivalente de sesión.
6. El sistema mantiene disponible esta información para pruebas automatizadas y revisión operativa futura.

Pantallas / superficies: Programa origen: SSITP007.cbl (WRITELOG); Integración origen: PRG008; N/A para UI directa

Reglas de negocio:
- Se auditan las operaciones de tipo I, M y E.
- La transacción registrada en el origen es 'T95USU03'.
- Las operaciones se registran como 'INGRESO', 'MODIFICACION' o 'ELIMINACION'.
- En modificación se registran además perfil, centro y autorizador anteriores.
- Las observaciones del formulario forman parte del mensaje auditado.
- Si falla la escritura de log, el origen informa 'Error XXX PRG008 (Write Log)' o 'Err XXX Link PRG008 Write Log'.

Notas técnicas:
El LINK a PRG008 debe migrarse a un servicio de auditoría backend interno, idealmente desacoplado en la capa de aplicación o dominio. La estructura posicional T95LOG01-MENSAJERIA puede mapearse a columnas explícitas en PostgreSQL más un campo detalle serializado para evitar pérdida de información. Se recomienda correlation ID en logs estructurados JSON y tabla de auditoría persistente. Dado que el input no incluye el contrato de PRG008, la implementación exacta del sink de auditoría es una propuesta de migración basada en evidencia parcial. confianza: media
Criterios:
  1. Dado que un usuario crea un nuevo registro de usuario, cuando la operación finaliza exitosamente, entonces existe un registro de auditoría con la operación 'INGRESO' asociado al usuario afectado.
  2. Dado que un usuario modifica el perfil, centro o autorizador de un usuario existente, cuando la operación finaliza exitosamente, entonces el registro de auditoría conserva los valores anteriores relevantes además de los nuevos.
  3. Dado que un usuario elimina un registro con observaciones, cuando la operación finaliza exitosamente, entonces la auditoría almacena la operación 'ELIMINACION' y el texto de observaciones ingresado.
  4. Dado que el backend genera la auditoría, cuando se consulta el recurso JSON de auditoría correspondiente en pruebas automatizadas, entonces el cuerpo expone solo los campos de negocio acordados para operación, usuario afectado, ejecutor, fecha y detalle.
  5. Dado que una alta o modificación fue exitosa, cuando el detalle del usuario se vuelve a consultar, entonces los metadatos visibles de última actualización reflejan el usuario ejecutor y el momento persistido.
  6. Dado que ocurre un fallo en la persistencia del log de auditoría, cuando el backend responde al flujo afectado según la política definida, entonces el resultado observable informa el problema con un mensaje legible y consistente.

---

## 10. Preparar la solución migrada para ejecución local con Docker Compose, tests y puertos no estándar
Módulo: Infraestructura y Migración

Como equipo de desarrollo y migración, necesitamos una base de ejecución local reproducible para validar la modernización del módulo de seguridad sin depender del entorno CICS original. Esta historia se justifica por el contexto completo del código analizado: el sistema fuente es un conjunto COBOL/CICS con mapas BMS, SQL embebido y programas enlazados como SSITP002, SSITP007, PRG000, PRG016 y PRG008. Para migrarlo al stack objetivo indicado, hace falta una solución operable en React, Spring Boot y PostgreSQL que permita probar los flujos de consulta general, detalle, alta, modificación, eliminación y auditoría. El valor de negocio es reducir incertidumbre de migración y habilitar validaciones tempranas sobre equivalencias funcionales. El alcance incluye Docker Compose para frontend, backend y base de datos; scripts unificados run.sh y run.ps1; configuración por variables de entorno con puertos no estándar; ejecución automática de tests; CORS resuelto para desarrollo; health checks y documentación mínima de arranque. Aunque esta historia no deriva de una pantalla legacy específica, sí está anclada al hecho de que el sistema origen es transaccional, dependiente de CICS y no ejecutable de forma nativa en el stack destino, por lo que la infraestructura de migración es una necesidad directa del esfuerzo evidenciado.

Actor: Usuario

Flujo funcional:
1. El desarrollador clona el proyecto migrado en su entorno local.
2. Ejecuta el script ./run.sh o .\run.ps1.
3. El script verifica prerrequisitos, puertos disponibles y dependencias necesarias.
4. El script instala dependencias backend y frontend, ejecuta pruebas y construye las imágenes.
5. Docker Compose levanta PostgreSQL, backend Spring y frontend React.
6. El sistema valida health checks y conectividad entre servicios.
7. El desarrollador accede a las URLs publicadas y verifica que la aplicación esté operativa sin conflictos de CORS.

Pantallas / superficies: N/A

Reglas de negocio:
- La solución destino debe ejecutarse con puertos no estándar para evitar conflictos locales.
- Deben existir scripts run.sh y run.ps1 para arranque unificado.
- La configuración debe resolverse por variables de entorno.
- Los tests deben ejecutarse automáticamente antes o durante el proceso de levantamiento con reporte de resultado.
- Deben levantarse como mínimo PostgreSQL, backend Spring y frontend React.
- La aplicación debe quedar accesible en puertos configurados y sin errores de CORS en desarrollo.

Notas técnicas:
Tecnología origen identificada: COBOL/CICS con BMS y SQL embebido. Se propone migración a React 18 + TypeScript, Spring Boot 3 sobre Java 17 y PostgreSQL 15 con Docker Compose. Puertos sugeridos: frontend 3001, backend 8081, base de datos 5433. CORS explícito en backend permitiendo http://localhost:3001 y proxy de desarrollo en frontend. Flyway o Liquibase para versionado de esquema. Esta historia materializa la plataforma de convivencia y validación del comportamiento migrado. confianza: alta
Criterios:
  1. Dado que se despliega la aplicación en entorno local, cuando se ejecuta el script ./run.sh (Linux/Mac) o .\run.ps1 (Windows), entonces Docker Compose levanta PostgreSQL, backend Spring y frontend React, todos los tests se ejecutan exitosamente, las dependencias se instalan automáticamente, no hay errores de CORS, y la aplicación está accesible en los puertos configurados sin conflictos.
  2. Dado que los puertos 3001, 8081 o 5433 están ocupados, cuando se ejecuta el script de arranque, entonces el sistema informa el conflicto antes de iniciar los servicios.
  3. Dado que el backend Spring inicia correctamente, cuando se consulta el endpoint de health check configurado, entonces la verificación devuelve un estado saludable observable por automatización.
  4. Dado que PostgreSQL fue levantado por Docker Compose, cuando el backend inicia sus migraciones versionadas, entonces el esquema requerido para usuarios, observaciones, catálogos y auditoría queda disponible sin intervención manual.
  5. Dado que el frontend React está levantado, cuando el usuario abre la URL local configurada, entonces puede navegar al módulo de seguridad sin errores de comunicación con el backend en desarrollo.
  6. Dado que el proyecto publica información de arranque, cuando finaliza la ejecución del script, entonces se muestran en consola las URLs de acceso, los puertos configurados y las instrucciones para detener o inspeccionar logs.

## OpenSpec Change
cmnnd5h3x0000kor8xlbud90b