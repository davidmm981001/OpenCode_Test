## 1. Setup

- [ ] 1.1 Confirm the scope and keep the OpenSpec/OpenCode boundary intact.
- [ ] 1.2 Create the backend/frontend scaffold, root scripts, and project documentation required to run locally.
- [ ] 1.3 Install or pin the requested dependencies for backend and frontend.

## 2. Backend foundation

- [ ] 2.1 Implement Spring Boot bootstrap, global error handling, security, JWT, refresh tokens, and logout.
- [ ] 2.2 Implement the domain data model, Flyway migrations, seed data, and persistence repositories.
- [ ] 2.3 Implement the security menu, catalog lookups, users, BANCS, and audit REST APIs.

## 3. Frontend foundation

- [ ] 3.1 Implement Vite + React shell, routing, auth context, and protected navigation.
- [ ] 3.2 Implement the security dashboard, user consultation, user detail, user form, catalog hints, BANCS panel, and audit panel.

## 4. Validation

- [ ] 4.1 Add integration/component tests for the critical backend and frontend flows.
- [ ] 4.2 Validate the build, run, and local execution scripts end to end.
