# COBOL Test Apr3

## Purpose
This repository is a generated project driven by OpenSpec and OpenCode.

## Working rules
- Treat "openspec/config.yaml", "openspec/specs/project-scope/spec.md", and "openspec/changes/cmnj2ouee0000lwirpkonoky0" as the source of truth for scope.
- Read the full user stories before making changes.
- Use OpenSpec artifacts to plan the work before coding.
- Create the missing app scaffold, dependencies, scripts, and build files when the implementation needs them.
- Install dependencies from inside the project when the implementation needs them.
- Keep the result runnable and verify it before finishing.
- Prefer focused changes that satisfy the stories end to end.

## User stories
## 1. Visualizar el menú principal de seguridad y navegar a las opciones permitidas para el operador
Módulo: seguridad-menu

Como operador del modulo de seguridad necesito entrar a una pantalla inicial clara que me muestre las opciones disponibles y me permita navegar a cada funcion del dominio sin depender de comandos de terminal. La evidencia funcional proviene del mapa de menu y del programa principal que carga fecha, hora, identificador de usuario, aplicacion y terminal, valida la opcion ingresada y redirige a diferentes programas segun el valor seleccionado. En el codigo fuente se observa que las opciones visibles son 1 a 9, aunque la validacion acepta 10; para evitar exponer una funcion sin destino definido, la aplicacion moderna debe presentar solo las opciones implementadas con decision explicita documentada: se mostraran 1 a 9 y cualquier intento manual de invocar 10 devolvera error de validacion. La historia incluye el comportamiento de inicio de sesion contextual, mensajes de error por tecla no valida o seleccion fuera de rango, y salida segura cuando el usuario cancela la operacion. El frontend debe reemplazar la antigua pantalla por un dashboard React con tarjetas o lista accesible, mientras el backend expone un recurso de navegacion que devuelve las opciones habilitadas para el usuario autenticado. La vista debe mostrar fecha y hora del servidor, usuario autenticado y nombre del modulo, manteniendo una experiencia corporativa simple y lista para produccion.

Actor: Operador de seguridad

Flujo funcional:
1. El usuario autenticado entra a /app/seguridad y el frontend solicita GET /api/v1/seguridad/menu.
2. El backend devuelve usuario, aplicacion, terminal logica, fechaHoraServidor y el catalogo de opciones 1..9 habilitadas.
3. El usuario selecciona una opcion valida y el frontend navega a la ruta correspondiente del modulo.
4. Si el usuario intenta acceder sin autenticacion, el guard de ruta redirige a /login.
5. Si el frontend envia una opcion fuera del rango permitido, el backend responde 400 con mensaje 'Opcion invalida'.
6. Si el usuario cierra sesion o usa la accion salir, se limpian credenciales en memoria y vuelve a /login.

Pantallas / superficies: Rutas React: /login, /app/seguridad. Componentes: SecurityDashboard, MenuOptionCard, AppHeader, ProtectedRoute. Endpoints Spring: GET /api/v1/seguridad/menu, POST /auth/logout.

Reglas de negocio:
- El usuario debe estar autenticado para consultar el menu.
- Si no existe identidad de usuario, no se entrega contenido y se fuerza salida segura.
- Solo se exponen opciones 1 a 9 porque son las unicas con destino funcional evidenciado.
- La entrada de opcion debe ser numerica.
- Una opcion fuera del conjunto permitido devuelve error de validacion.
- La accion de cancelar o limpiar no debe ejecutar navegacion a otra funcionalidad.
- El menu debe mostrar fecha, hora, usuario y aplicacion en cada carga.
- Teclas o acciones no soportadas deben mapearse a mensaje de error controlado.

Notas técnicas:
Aplicar ARQUITECTURA, AUTH MASTER, UI/UX RULES y TECHNICAL QUALITY - DEFINITION OF DONE. Endpoint API: GET /api/v1/seguridad/menu. Response 200: { usuario: string, aplicacion: string, terminal: string, fechaHoraServidor: string(ISO8601), opciones: [{ codigo: number, titulo: string, ruta: string, habilitada: boolean }] }. Error 401: { timestamp, status, code:'UNAUTHORIZED', message, path }. Endpoint adicional POST /auth/logout sin body, response 200 { message:string }. Tabla DB: no requiere nueva tabla para menu; si se desea parametrizacion usar t00men01-menu_opciones con columnas menu_id uuid PK, menu_codigo smallint NOT NULL UNIQUE, menu_titulo varchar(120) NOT NULL, menu_ruta varchar(160) NOT NULL, menu_habilitada boolean NOT NULL default true. Auth/Authz: JWT requerido, roles ROLE_ADMIN o ROLE_OPERADOR. Error mapping: opcion invalida->400 INVALID_MENU_OPTION; no autenticado->401; acceso denegado->403. Flyway reference: V1__create_t00men01_menu_opciones.sql si se parametriza menu, o documentar menu estatico sin migracion. Estructura de paquetes sugerida: com.coboltest.seguridadmenu.{domain,application,infrastructure,api}. Limites transaccionales: solo lectura, @Transactional(readOnly=true). Estrategia de cache/estado: React Query staleTime 5 min para menu; invalidar al login/logout. DEPENDENCIAS MAVEN REQUERIDAS: org.springframework.boot:spring-boot-starter-parent:3.2.5, org.springframework.boot:spring-boot-starter-web:3.2.5, org.springframework.boot:spring-boot-starter-data-jpa:3.2.5, org.springframework.boot:spring-boot-starter-security:3.2.5, org.springframework.boot:spring-boot-starter-validation:3.2.5, org.springframework.boot:spring-boot-starter-actuator:3.2.5, org.springdoc:springdoc-openapi-starter-webmvc-ui:2.3.0, io.jsonwebtoken:jjwt-api:0.12.5, io.jsonwebtoken:jjwt-impl:0.12.5, io.jsonwebtoken:jjwt-jackson:0.12.5, org.postgresql:postgresql:42.7.3, org.flywaydb:flyway-core:9.22.3, org.flywaydb:flyway-database-postgresql:10.10.0, org.projectlombok:lombok:1.18.32, com.fasterxml.jackson.core:jackson-databind:2.15.4, org.springframework.boot:spring-boot-devtools:3.2.5, org.springframework.boot:spring-boot-starter-test:3.2.5, org.springframework.security:spring-security-test:6.2.4, com.h2database:h2:2.2.224. DEPENDENCIAS NPM REQUERIDAS: react:18.2.0, react-dom:18.2.0, react-router-dom:^6.22.3, @tanstack/react-query:^5.24.8, axios:^1.7.2, zod:^3.22.4, react-hook-form:^7.50.1, @hookform/resolvers:^3.3.4, tailwindcss:^3.4.3, autoprefixer:^10.4.19, postcss:^8.4.38, sonner:^1.4.41, lucide-react:^0.344.0, clsx:^2.1.1, date-fns:^3.6.0, typescript:^5.4.5, vite:^5.2.10, @vitejs/plugin-react:^4.2.1, @types/react:^18.2.66, @types/react-dom:^18.2.22, eslint:^8.57.0, prettier:^3.2.5, eslint-config-prettier:^9.1.0, @testing-library/react:^14.2.2, @testing-library/jest-dom:^6.4.2, @testing-library/user-event:^14.5.2, vitest:^1.5.0, jsdom:^24.0.0, @vitest/coverage-v8:^1.5.0, playwright:^1.43.1. confianza: alta
Criterios:
  1. Dado un usuario autenticado con rol ROLE_OPERADOR, cuando llama al endpoint GET /api/v1/seguridad/menu, entonces recibe HTTP 200 y un body JSON con exactamente los campos usuario, aplicacion, terminal, fechaHoraServidor y opciones, donde opciones es un arreglo de objetos con codigo:number, titulo:string, ruta:string, habilitada:boolean.
  2. Dado un usuario autenticado, cuando abre la ruta /app/seguridad, entonces la SPA muestra las 9 opciones del modulo y al hacer clic en 'Administracion de Usuarios' navega a /app/usuarios/consulta sin recarga manual.
  3. Dado que el frontend intenta consultar GET /api/v1/seguridad/menu sin token JWT valido, cuando el backend procesa la solicitud, entonces devuelve HTTP 401 con body {timestamp,status,code,message,path}.
  4. Dado que se envia una opcion manual con codigo 10 a un endpoint de validacion de navegacion, cuando el backend la recibe, entonces devuelve HTTP 400 con code INVALID_MENU_OPTION y message 'Opcion invalida'.
  5. Dado que el usuario ejecuta la accion de logout desde el header, cuando POST /auth/logout responde 200, entonces React Query invalida la cache del menu, elimina el contexto autenticado y redirige a /login.
  6. Dado que se reenvia la misma peticion GET /api/v1/seguridad/menu con el mismo JWT vigente, cuando el backend la recibe por segunda vez, entonces no genera duplicados ni efectos secundarios y devuelve el mismo estado HTTP 200 con datos coherentes.
  7. Dado que el usuario intenta acceder a /app/seguridad con el token expirado, cuando el guard de rutas detecta HTTP 401 del backend, entonces muestra una notificacion de sesion expirada y redirige a /login.

---

## 2. Consultar usuarios por empresa, centro, usuario, perfil o nombre con paginación funcional para analistas de seguridad
Módulo: usuarios-consulta

Como analista de seguridad necesito una consulta general de usuarios que me permita filtrar por distintos criterios y revisar resultados paginados para localizar rapidamente registros operativos. La funcionalidad se extrae del mapa de consulta general y del programa que define busquedas por empresa, centro, usuario, perfil y nombre, usando cursores separados y una grilla de 14 filas por pagina. El comportamiento observado prioriza el primer criterio informado en un orden estricto: empresa, luego centro, luego usuario, luego perfil y finalmente nombre; si no se ingresa ninguno se informa que falta criterio de consulta. Tambien se detecta logica de paginacion por desplazamiento con contador de registros y la accion PF7, que en la implementacion original recalcula el offset hacia atras mediante un valor acumulado; en la version moderna se normaliza a paginacion page/size manteniendo el resultado de negocio: obtener bloques de hasta 14 registros y avisar si existen mas datos o si se llego al inicio o final del conjunto. La pantalla React debe mostrar filtros, tabla de resultados, selector por fila y mensajes de estado. El backend debe devolver solo los campos realmente expuestos en la consulta: usuario, nombre, perfil, empresa, centro, dominio, nodo y flag de autorizador. Esta historia incluye la seleccion de una fila para ir al detalle editable y el acceso directo para crear un nuevo usuario.

Actor: Analista de seguridad

Flujo funcional:
1. El usuario abre /app/usuarios/consulta y el frontend carga la pantalla vacia con filtros y tabla.
2. El usuario ingresa un unico criterio o varios; el frontend envia GET /api/v1/usuarios con los filtros.
3. El backend aplica prioridad de criterio: empresa > centro > usuario > perfil > nombre y devuelve hasta 14 resultados con metadatos de pagina.
4. El usuario revisa la tabla, navega a pagina siguiente o anterior y el listado se actualiza sin recargar la SPA.
5. Si no se envio ningun criterio util, el backend responde 400 con mensaje 'Ingrese Criterio Consulta'.
6. Si ocurre un error de base de datos en la consulta, el backend responde 500 y la UI muestra mensaje corporativo de error.
7. Si el usuario selecciona una fila valida, navega al detalle del usuario correspondiente.
8. Si intenta editar una fila inexistente o fuera de rango visible, la UI muestra 'Seleccion Errada'.

Pantallas / superficies: Rutas React: /app/usuarios/consulta, /app/usuarios/nuevo, /app/usuarios/:usrSiglo21. Componentes: UsuarioSearchPage, UsuarioFiltersForm, UsuarioTable, PaginationBar. Endpoints Spring: GET /api/v1/usuarios, GET /api/v1/usuarios/{usrSiglo21}.

Reglas de negocio:
- Debe existir al menos un criterio de consulta no vacio.
- La prioridad de busqueda es: empresa, centro, usuario, perfil, nombre.
- Los campos usuario y perfil admiten comodin de sufijo al completar espacios no informados.
- El campo nombre admite comodines sobre espacios restantes.
- El tamano maximo por pagina es 14 para reflejar el comportamiento funcional observado; el backend puede aceptar size pero no mayor a 14 en esta pantalla.
- Si el desplazamiento solicitado va antes del inicio, se retorna la primera pagina y mensaje 'Inicio de los datos'.
- Si hay mas resultados que los visibles, se informa 'Existen mas Datos'.
- Si no hay mas resultados, se informa 'No existen mas Datos'.
- Los resultados muestran usuario, nombre recortado a 30 caracteres visibles, perfil, empresa, centro, dominio, nodo y autorizador.
- La seleccion para editar solo es valida sobre filas realmente retornadas.

Notas técnicas:
Endpoint API: GET /api/v1/usuarios?empresa=string(4,opt)&centro=string(4,opt)&usuario=string(8,opt)&perfil=string(8,opt)&nombre=string(40,opt)&page=int default 0&size=int default 14 max 14. Response 200: { content:[{ usrSiglo21:string, usrNombre:string, usrPers:string, usrEmpresa:string, usrCentro:string, usrDominio:string, usrNodo:string, usrAutoriza:string }], totalElements:number, totalPages:number, size:number, number:number, first:boolean, last:boolean, message:string }. Response 400: { timestamp,status,code:'QUERY_CRITERIA_REQUIRED'|'INVALID_PAGINATION',message,details,path }. Tabla DB: t95usu03-usuarios con columnas usr_siglo21_codigo varchar(8) PK, usr_nombre_completo varchar(40) NOT NULL, usr_status char(1) NOT NULL, usr_cid varchar(10) NOT NULL, usr_offset_bancs varchar(8) NOT NULL, usr_cargo varchar(15) NOT NULL, usr_empresa_codigo varchar(4) NOT NULL, usr_centro_codigo varchar(4) NOT NULL, usr_pers_codigo varchar(8) NOT NULL, usr_dominio_codigo varchar(4) NOT NULL, usr_nodo_codigo varchar(4) NOT NULL, usr_autoriza char(1) NOT NULL, usr_updfch char(8) NOT NULL, usr_updtime char(6) NOT NULL, usr_updusr varchar(8) NOT NULL, usr_updterm varchar(4) NOT NULL, usr_fchlogon char(8) NOT NULL, usr_timelogon char(6) NOT NULL, usr_token varchar(8) NOT NULL, usr_historia varchar(80) NOT NULL, usr_fchnewpass char(8) NOT NULL, usr_fchcambio char(8) NOT NULL. Constraints: PK usr_siglo21_codigo; FK usr_empresa_codigo->t06tc005-empresas.emp_codigo, FK (usr_empresa_codigo,usr_centro_codigo)->t06tc007-centros(emp_codigo,cen_codigo), FK usr_pers_codigo->t95par02-parametros.par_grupo_usuario; indices: btree por empresa, centro, perfil; gin_trgm_ops en nombre. Auth/Authz: JWT requerido, ROLE_ADMIN o ROLE_OPERADOR. Error mapping: sin criterio->400 QUERY_CRITERIA_REQUIRED; fila no encontrada->404 USER_NOT_FOUND; error SQL->500 USERS_QUERY_ERROR. Flyway reference: V2__create_t95usu03_usuarios.sql y V3__create_catalogos_empresas_centros_perfiles.sql. Estructura de paquetes sugerida: com.coboltest.usuariosconsulta.{domain,application,infrastructure,api}. Limites transaccionales: @Transactional(readOnly=true) en servicio de consulta. Estrategia de cache/estado: React Query key ['usuarios', filtros, page, size], keepPreviousData true, invalidacion al crear/editar/eliminar. DEPENDENCIAS MAVEN REQUERIDAS: org.springframework.boot:spring-boot-starter-parent:3.2.5, org.springframework.boot:spring-boot-starter-web:3.2.5, org.springframework.boot:spring-boot-starter-data-jpa:3.2.5, org.springframework.boot:spring-boot-starter-security:3.2.5, org.springframework.boot:spring-boot-starter-validation:3.2.5, org.springframework.boot:spring-boot-starter-actuator:3.2.5, org.springdoc:springdoc-openapi-starter-webmvc-ui:2.3.0, org.postgresql:postgresql:42.7.3, org.flywaydb:flyway-core:9.22.3, org.flywaydb:flyway-database-postgresql:10.10.0, io.jsonwebtoken:jjwt-api:0.12.5, io.jsonwebtoken:jjwt-impl:0.12.5, io.jsonwebtoken:jjwt-jackson:0.12.5, org.projectlombok:lombok:1.18.32, org.springframework.boot:spring-boot-devtools:3.2.5, org.springframework.boot:spring-boot-starter-test:3.2.5, org.springframework.security:spring-security-test:6.2.4, com.h2database:h2:2.2.224. DEPENDENCIAS NPM REQUERIDAS: react:18.2.0, react-dom:18.2.0, react-router-dom:^6.22.3, @tanstack/react-query:^5.24.8, axios:^1.7.2, zod:^3.22.4, react-hook-form:^7.50.1, @hookform/resolvers:^3.3.4, tailwindcss:^3.4.3, autoprefixer:^10.4.19, postcss:^8.4.38, sonner:^1.4.41, lucide-react:^0.344.0, clsx:^2.1.1, date-fns:^3.6.0, typescript:^5.4.5, vite:^5.2.10, @vitejs/plugin-react:^4.2.1, @types/react:^18.2.66, @types/react-dom:^18.2.22, eslint:^8.57.0, prettier:^3.2.5, eslint-config-prettier:^9.1.0, @testing-library/react:^14.2.2, @testing-library/jest-dom:^6.4.2, @testing-library/user-event:^14.5.2, vitest:^1.5.0, jsdom:^24.0.0, @vitest/coverage-v8:^1.5.0, playwright:^1.43.1. confianza: alta
Criterios:
  1. Dado un usuario autenticado, cuando llama al endpoint GET /api/v1/usuarios?empresa=1001&page=0&size=14, entonces recibe HTTP 200 con content de hasta 14 registros y cada item contiene exactamente los campos usrSiglo21, usrNombre, usrPers, usrEmpresa, usrCentro, usrDominio, usrNodo y usrAutoriza con tipos string.
  2. Dado que se informan simultaneamente empresa=1001 y usuario=SMELO001, cuando el backend procesa la consulta, entonces aplica prioridad por empresa y devuelve los usuarios de la empresa 1001 segun la regla funcional observada.
  3. Dado que el frontend llama al endpoint GET /api/v1/usuarios sin empresa, centro, usuario, perfil ni nombre, cuando la peticion es valida sintacticamente pero no funcionalmente, entonces devuelve HTTP 400 con body {timestamp,status,code,message,details,path} y code QUERY_CRITERIA_REQUIRED.
  4. Dado que existen 20 usuarios para el perfil PERF0001, cuando se consulta GET /api/v1/usuarios?perfil=PERF0001&page=0&size=14, entonces el mensaje funcional indica 'Existen mas Datos' y totalElements es 20.
  5. Dado que el usuario navega de page=0 a page=1 en /app/usuarios/consulta, cuando la segunda respuesta llega exitosamente, entonces la tabla React actualiza su contenido persistido sin recarga manual y conserva filtros activos mediante invalidacion o cambio de query key.
  6. Dado que se reenvia la misma peticion GET /api/v1/usuarios?nombre=JUAN%25&page=0&size=14 con el mismo identificador unico de consulta en cabecera X-Request-Id, cuando el backend la recibe por segunda vez, entonces no genera duplicados y devuelve el mismo estado HTTP 200 con datos coherentes.
  7. Dado que se ejecutan las migraciones Flyway, cuando se verifica la tabla t95usu03-usuarios, entonces existen las columnas usr_siglo21_codigo, usr_nombre_completo, usr_status, usr_cid, usr_offset_bancs, usr_cargo, usr_empresa_codigo, usr_centro_codigo, usr_pers_codigo, usr_dominio_codigo, usr_nodo_codigo, usr_autoriza, usr_updfch, usr_updtime, usr_updusr, usr_updterm, usr_fchlogon, usr_timelogon, usr_token, usr_historia, usr_fchnewpass y usr_fchcambio con tipos PostgreSQL definidos, constraint de primary key en usr_siglo21_codigo, y foreign keys a t06tc005-empresas, t06tc007-centros y t95par02-parametros segun DDL en V2__create_t95usu03_usuarios.sql.
  8. Dado que el usuario selecciona una fila no visible en la tabla, cuando intenta abrir edicion, entonces la interfaz muestra 'Seleccion Errada' y no navega al detalle.

---

## 3. Consultar el detalle completo de un usuario con datos operativos, observaciones y metadatos de actualización
Módulo: usuarios-administracion

Como administrador de seguridad necesito abrir el detalle completo de un usuario para consultar su informacion principal, su perfil, empresa, centro, datos de dominio y nodo, observaciones, fechas de ultima actualizacion y ultimo acceso. Esta necesidad surge del formulario de administracion que primero valida el identificador, luego consulta el registro principal y posteriormente resuelve descripciones adicionales de perfil, empresa y centro, asi como observaciones y datos complementarios de BANCS si existen. En el codigo se observa que la consulta por Enter carga numerosos campos en pantalla: usuario, usuario bancs, terminal bancs, nombres, cedula, empresa, centro, cargo, perfil, dominio, nodo, autorizador, oficina swift, observaciones, ultima actualizacion, ultimo signon e IP/terminal del ultimo acceso. La historia separa la lectura detallada de las operaciones de mutacion para facilitar una API limpia y reutilizable. El backend debe componer una respuesta agregada desde varias tablas sin exponer estructuras internas ni campos tecnicos irrelevantes. El frontend debe mostrar la informacion en un formulario de solo lectura inicial, con posibilidad de pasar a modo edicion desde acciones explicitas. Si el usuario no existe, si falta el identificador o si alguna referencia catalogada no puede resolverse, la pantalla debe seguir operativa mostrando mensajes de negocio equivalentes a los observados en la fuente, sin bloquear toda la consulta.

Actor: Administrador de seguridad

Flujo funcional:
1. El administrador navega a /app/usuarios/:usrSiglo21 o selecciona una fila desde la consulta general.
2. El frontend invoca GET /api/v1/usuarios/{usrSiglo21}.
3. El backend valida que el identificador exista y consulta el usuario principal, observaciones, descripcion de perfil, nombre de empresa, nombre de centro y datos BANCS si existen.
4. La UI renderiza todos los campos en una pantalla de detalle con acciones Consultar, Editar, Eliminar y Volver.
5. Si el identificador viene vacio o invalido, el backend devuelve 400 y la UI posiciona foco en el campo de usuario.
6. Si el usuario no existe, el backend devuelve 404 y la pantalla muestra mensaje funcional sin romper la navegacion.
7. Si faltan datos de tablas de catalogo, el backend devuelve el detalle principal pero informa textos de ausencia para perfil, empresa o centro.

Pantallas / superficies: Rutas React: /app/usuarios/:usrSiglo21. Componentes: UsuarioDetailPage, UsuarioDetailForm, DetailField, AuditInfoPanel. Endpoints Spring: GET /api/v1/usuarios/{usrSiglo21}, GET /api/v1/usuarios/{usrSiglo21}/observacion, GET /api/v1/usuarios/{usrSiglo21}/bancs (opcional interno o agregado).

Reglas de negocio:
- El codigo de usuario es obligatorio para consultar detalle.
- Si el usuario no existe se informa error funcional controlado.
- El detalle debe incluir datos de auditoria de actualizacion y de ultimo acceso si existen.
- El perfil debe resolverse a descripcion usando parametro GR; si no existe, mostrar mensaje equivalente a ausencia en tabla de parametros.
- La empresa debe resolverse por codigo; si no existe, mostrar mensaje equivalente a ausencia en tabla de empresas.
- El centro debe resolverse por empresa+centro; si no existe, mostrar mensaje equivalente a ausencia en tabla de centros.
- La observacion es opcional; si no existe registro asociado, se muestra vacia.
- Los datos BANCS son opcionales; si no existe registro asociado, no es error fatal del detalle.
- El indicador autorizador solo admite 0 o 1.

Notas técnicas:
Endpoint API: GET /api/v1/usuarios/{usrSiglo21}. Path param usrSiglo21 string(8,req). Response 200: { usrSiglo21:string, usrBancs:string|null, termBancs:number|null, usrNombre:string, usrCid:string, usrEmpresa:string, usrEmpresaNombre:string, usrCentro:string, usrCentroNombre:string, usrCargo:string, usrPers:string, usrPersDescripcion:string, usrDominio:string, usrNodo:string, usrAutoriza:number, usrOficinaSwift:string|null, observacion:string|null, updFecha:string, updHora:string, updUsuario:string, updTerminal:string, ultimoLogonFecha:string, ultimoLogonHora:string, ultimoLogonIp:string|null, status:string }. Error 400: INVALID_USER_CODE. Error 404: USER_NOT_FOUND. Tabla DB: t95obs04-observaciones_usuario con columnas obs_usuario_codigo varchar(8) PK FK->t95usu03-usuarios.usr_siglo21_codigo, obs_usuario_modificacion varchar(8) NOT NULL, obs_fecha_ultima timestamp NOT NULL default current_timestamp, obs_comentario varchar(100) NOT NULL. Tabla apoyo t95ban04-usuarios_bancs con PK bancs_usuario_codigo varchar(8). Auth/Authz: JWT requerido, ROLE_ADMIN o ROLE_OPERADOR. Error mapping: user code vacio->400; usuario inexistente->404; error catalogo parcial->200 con strings descriptivos; error inesperado->500. Flyway reference: V4__create_t95obs04_observaciones_usuario.sql y V5__create_t95ban04_usuarios_bancs.sql. Estructura de paquetes sugerida: com.coboltest.usuariosadministracion.{domain,application,infrastructure,api}. Limites transaccionales: @Transactional(readOnly=true) sobre la carga agregada para evitar inconsistencias de lectura. Estrategia de cache/estado: React Query key ['usuario-detalle', usrSiglo21]; invalidar al editar, eliminar u observar cambios BANCS. DEPENDENCIAS MAVEN REQUERIDAS: org.springframework.boot:spring-boot-starter-parent:3.2.5, org.springframework.boot:spring-boot-starter-web:3.2.5, org.springframework.boot:spring-boot-starter-data-jpa:3.2.5, org.springframework.boot:spring-boot-starter-security:3.2.5, org.springframework.boot:spring-boot-starter-validation:3.2.5, org.springframework.boot:spring-boot-starter-actuator:3.2.5, org.springdoc:springdoc-openapi-starter-webmvc-ui:2.3.0, org.postgresql:postgresql:42.7.3, org.flywaydb:flyway-core:9.22.3, org.flywaydb:flyway-database-postgresql:10.10.0, io.jsonwebtoken:jjwt-api:0.12.5, io.jsonwebtoken:jjwt-impl:0.12.5, io.jsonwebtoken:jjwt-jackson:0.12.5, org.projectlombok:lombok:1.18.32, org.springframework.boot:spring-boot-starter-test:3.2.5, org.springframework.security:spring-security-test:6.2.4, com.h2database:h2:2.2.224. DEPENDENCIAS NPM REQUERIDAS: react:18.2.0, react-dom:18.2.0, react-router-dom:^6.22.3, @tanstack/react-query:^5.24.8, axios:^1.7.2, zod:^3.22.4, react-hook-form:^7.50.1, @hookform/resolvers:^3.3.4, tailwindcss:^3.4.3, autoprefixer:^10.4.19, postcss:^8.4.38, sonner:^1.4.41, lucide-react:^0.344.0, clsx:^2.1.1, date-fns:^3.6.0, typescript:^5.4.5, vite:^5.2.10, @vitejs/plugin-react:^4.2.1, @types/react:^18.2.66, @types/react-dom:^18.2.22, eslint:^8.57.0, prettier:^3.2.5, eslint-config-prettier:^9.1.0, @testing-library/react:^14.2.2, @testing-library/jest-dom:^6.4.2, @testing-library/user-event:^14.5.2, vitest:^1.5.0, jsdom:^24.0.0, @vitest/coverage-v8:^1.5.0, playwright:^1.43.1. confianza: alta
Criterios:
  1. Dado un usuario existente con codigo USR00001, cuando el frontend llama al endpoint GET /api/v1/usuarios/USR00001, entonces el cuerpo JSON de respuesta contiene exactamente los campos usrSiglo21, usrBancs, termBancs, usrNombre, usrCid, usrEmpresa, usrEmpresaNombre, usrCentro, usrCentroNombre, usrCargo, usrPers, usrPersDescripcion, usrDominio, usrNodo, usrAutoriza, usrOficinaSwift, observacion, updFecha, updHora, updUsuario, updTerminal, ultimoLogonFecha, ultimoLogonHora, ultimoLogonIp y status con los tipos acordados.
  2. Dado un codigo de usuario vacio, cuando se llama GET /api/v1/usuarios/%20, entonces el backend devuelve HTTP 400 con body {timestamp,status,code,message,details,path} y code INVALID_USER_CODE.
  3. Dado un codigo de usuario inexistente USR99999, cuando el backend procesa GET /api/v1/usuarios/USR99999, entonces devuelve HTTP 404 con code USER_NOT_FOUND.
  4. Dado que el usuario abre /app/usuarios/USR00001 y luego ejecuta una modificacion exitosa sobre ese mismo registro, cuando React Query invalida la key ['usuario-detalle','USR00001'], entonces el detalle visible refleja el estado persistido sin recarga manual.
  5. Dado que no existe observacion asociada al usuario USR00002, cuando se consulta su detalle, entonces el campo observacion se devuelve como null o cadena vacia y el resto del detalle se entrega en HTTP 200.
  6. Dado que se reenvia la misma peticion GET /api/v1/usuarios/USR00001 con el mismo identificador unico, cuando el backend la recibe por segunda vez, entonces no genera duplicados y devuelve el mismo estado HTTP 200 con datos coherentes.
  7. Dado que se ejecutan las migraciones Flyway, cuando se verifica la tabla t95obs04-observaciones_usuario, entonces existen las columnas obs_usuario_codigo, obs_usuario_modificacion, obs_fecha_ultima y obs_comentario con tipos varchar, timestamp y varchar, constraint de primary key en obs_usuario_codigo, y foreign keys a t95usu03-usuarios segun DDL en V4__create_t95obs04_observaciones_usuario.sql.

---

## 4. Crear un usuario de seguridad con validaciones completas de perfil, empresa, centro, observaciones y metadatos
Módulo: usuarios-administracion

Como administrador de seguridad necesito registrar un nuevo usuario en el sistema con todos los datos obligatorios y con validaciones estrictas antes de persistirlo. La fuente funcional muestra una secuencia clara: se arma un registro de entrada, se validan datos obligatorios, se comprueba la existencia de perfil, empresa y centro en tablas de catalogo, se normalizan campos opcionales como cedula, cargo y fechas de logon, se procesa la alta principal y luego se actualiza o inserta la observacion asociada. Tambien se evidencia que la observacion es obligatoria para altas, que la oficina swift solo acepta un valor especifico cuando se informa, que el autorizador solo puede ser 0 o 1 y que los campos BANCS tienen dependencia mutua. La implementacion moderna debe encapsular todo en una transaccion de aplicacion y devolver una respuesta agregada lista para repintar la vista. El formulario React debe admitir modo nuevo con validacion Zod y mensajes en linea, accesibilidad por teclado y toasts de resultado. El backend debe generar la metadata de actualizacion usando el usuario autenticado y la terminal logica de la solicitud. Si alguna validacion falla, no se debe crear ni el usuario ni la observacion. Si la persistencia principal es exitosa pero la observacion falla, toda la transaccion se revierte para mantener consistencia.

Actor: Administrador de seguridad

Flujo funcional:
1. El administrador abre /app/usuarios/nuevo y completa usuario, nombre, empresa, centro, perfil, observaciones y demas datos.
2. El frontend valida formato y envia POST /api/v1/usuarios.
3. El backend valida obligatorios, reglas de dominio, existencia de catalogos y coherencia de campos BANCS.
4. Si todo es valido, crea el usuario principal, registra o actualiza la observacion, y opcionalmente crea integracion BANCS si se informo usuario y terminal.
5. Devuelve 201 con el detalle persistido y la UI navega al detalle del nuevo usuario.
6. Si falta un campo obligatorio o existe una referencia invalida, devuelve 400 con detalle campo a campo.
7. Si el usuario ya existe, devuelve 409 sin alterar la base.
8. Si una suboperacion falla dentro de la transaccion, devuelve 500 y no quedan registros parciales.

Pantallas / superficies: Rutas React: /app/usuarios/nuevo, /app/usuarios/:usrSiglo21. Componentes: UsuarioFormPage, UsuarioForm, CatalogLookupHint. Endpoints Spring: POST /api/v1/usuarios.

Reglas de negocio:
- Usuario es obligatorio.
- Nombre es obligatorio.
- Observaciones son obligatorias.
- Perfil es obligatorio y debe existir en parametros con codigo GR.
- Perfil tambien debe tener definicion de recursos en tabla de recursos.
- Empresa es obligatoria y debe existir.
- Centro es obligatorio, numerico/alfanumerico de 4 posiciones y debe existir para la empresa indicada.
- Si se informa oficina swift, el unico valor permitido es MSQUTODO.
- Cedula puede venir vacia; se normaliza a cero o nulo tecnico segun modelo moderno.
- Cargo puede venir vacio; se persiste como cadena vacia.
- Autorizador solo admite 0 o 1; cualquier otro valor se interpreta como 0 en la logica original, pero la API moderna debe rechazar valores fuera de rango con 400 para evitar ambiguedad.
- Si se informa usuario BANCS, tambien debe informarse terminal BANCS.
- Si se informa terminal BANCS, tambien debe informarse usuario BANCS.
- En altas se inicializan fechas y horas de ultimo logon en cero o nulas funcionales.
- No deben quedar registros parciales si falla usuario, observacion o integracion BANCS.

Notas técnicas:
Endpoint API: POST /api/v1/usuarios. Request schema: { usrSiglo21:string(8,req), usrNombre:string(43,req), usrCid:string(10,opt), usrEmpresa:string(4,req), usrCentro:string(4,req), usrCargo:string(18,opt), usrPers:string(8,req), usrDominio:string(4,opt), usrNodo:string(4,opt), usrAutoriza:number(0|1,req), usrOficinaSwift:string(opt), observacion:string(1..100,req), usrBancs:string(8,opt), termBancs:number(opt) }. Response 201: { id:string(uuid), usrSiglo21:string, usrNombre:string, usrEmpresa:string, usrCentro:string, usrPers:string, usrAutoriza:number, observacion:string, usrBancs:string|null, termBancs:number|null, updFecha:string, updHora:string, updUsuario:string, updTerminal:string, message:string }. Response error 400: { timestamp,status,code,message,details:[{field,message}],path }. Response error 409: USER_ALREADY_EXISTS | BANCS_USER_DUPLICATE. Tabla DB principal: t95usu03-usuarios definida en V2. Tabla observaciones: t95obs04-observaciones_usuario definida en V4. Tabla opcional BANCS: t95ban04-usuarios_bancs con columnas bancs_usuario_codigo varchar(8) PK FK->t95usu03-usuarios, bancs_usuario_externo varchar(8) NOT NULL UNIQUE, bancs_nombre varchar(60) NOT NULL, bancs_branch_codigo varchar(4) NOT NULL, bancs_terminal_numero integer NOT NULL, bancs_empresa_codigo varchar(4) NOT NULL, bancs_estado_proceso varchar(2) NOT NULL, bancs_observacion varchar(80) NOT NULL, bancs_fecha_ult_cambio timestamp NOT NULL default current_timestamp, bancs_usuario_ult_cambio varchar(8) NOT NULL. Auth/Authz: JWT requerido, solo ROLE_ADMIN. Error mapping: validacion campo->400; referencias faltantes->400 PROFILE_NOT_FOUND/PROFILE_RESOURCE_NOT_FOUND/COMPANY_NOT_FOUND/CENTER_NOT_FOUND; duplicado usuario->409 USER_ALREADY_EXISTS; duplicado usuario BANCS->409 BANCS_USER_DUPLICATE; fallo transaccional->500 USER_CREATE_ERROR. Flyway reference: V2__create_t95usu03_usuarios.sql, V4__create_t95obs04_observaciones_usuario.sql, V5__create_t95ban04_usuarios_bancs.sql. Estructura de paquetes sugerida: com.coboltest.usuariosadministracion.{domain,application,infrastructure,api}. Limites transaccionales: @Transactional isolation READ_COMMITTED sobre createUserWithObservationAndOptionalBancs. Estrategia de cache/estado: invalidar ['usuarios'] y precargar ['usuario-detalle', usrSiglo21] tras 201; optimistic update no recomendado por alta cantidad de reglas. DEPENDENCIAS MAVEN REQUERIDAS: org.springframework.boot:spring-boot-starter-parent:3.2.5, org.springframework.boot:spring-boot-starter-web:3.2.5, org.springframework.boot:spring-boot-starter-data-jpa:3.2.5, org.springframework.boot:spring-boot-starter-security:3.2.5, org.springframework.boot:spring-boot-starter-validation:3.2.5, org.springframework.boot:spring-boot-starter-actuator:3.2.5, org.springdoc:springdoc-openapi-starter-webmvc-ui:2.3.0, org.postgresql:postgresql:42.7.3, org.flywaydb:flyway-core:9.22.3, org.flywaydb:flyway-database-postgresql:10.10.0, io.jsonwebtoken:jjwt-api:0.12.5, io.jsonwebtoken:jjwt-impl:0.12.5, io.jsonwebtoken:jjwt-jackson:0.12.5, org.projectlombok:lombok:1.18.32, org.springframework.boot:spring-boot-devtools:3.2.5, org.springframework.boot:spring-boot-starter-test:3.2.5, org.springframework.security:spring-security-test:6.2.4, com.h2database:h2:2.2.224. DEPENDENCIAS NPM REQUERIDAS: react:18.2.0, react-dom:18.2.0, react-router-dom:^6.22.3, @tanstack/react-query:^5.24.8, axios:^1.7.2, zod:^3.22.4, react-hook-form:^7.50.1, @hookform/resolvers:^3.3.4, tailwindcss:^3.4.3, autoprefixer:^10.4.19, postcss:^8.4.38, sonner:^1.4.41, lucide-react:^0.344.0, clsx:^2.1.1, date-fns:^3.6.0, typescript:^5.4.5, vite:^5.2.10, @vitejs/plugin-react:^4.2.1, @types/react:^18.2.66, @types/react-dom:^18.2.22, eslint:^8.57.0, prettier:^3.2.5, eslint-config-prettier:^9.1.0, @testing-library/react:^14.2.2, @testing-library/jest-dom:^6.4.2, @testing-library/user-event:^14.5.2, vitest:^1.5.0, jsdom:^24.0.0, @vitest/coverage-v8:^1.5.0, playwright:^1.43.1. confianza: alta
Criterios:
  1. Dado que el frontend llama al endpoint POST /api/v1/usuarios, cuando la peticion es valida, entonces el cuerpo JSON de respuesta contiene exactamente los campos id, usrSiglo21, usrNombre, usrEmpresa, usrCentro, usrPers, usrAutoriza, observacion, usrBancs, termBancs, updFecha, updHora, updUsuario, updTerminal y message con tipos string, number o null segun corresponda, y en caso de error de validacion devuelve HTTP 400 con body {timestamp,status,code,message,details,path}.
  2. Dado un payload con usrSiglo21='USR10001', usrNombre='ANA PEREZ', usrEmpresa='1001', usrCentro='0001', usrPers='PERF0001', usrAutoriza=1 y observacion='Alta inicial aprobada', cuando POST /api/v1/usuarios es procesado, entonces devuelve HTTP 201 y el detalle del nuevo usuario queda persistido.
  3. Dado un payload sin observacion, cuando se procesa el alta, entonces el backend devuelve HTTP 400 con detalle del campo observacion y no crea registros en t95usu03-usuarios ni en t95obs04-observaciones_usuario.
  4. Dado un payload con usrOficinaSwift='OTROVALOR', cuando se intenta crear el usuario, entonces el backend devuelve HTTP 400 con mensaje 'Of.Swift: MSQUTODO'.
  5. Dado un payload con usrBancs='12345678' y termBancs ausente, cuando se valida la solicitud, entonces el backend devuelve HTTP 400 con mensaje 'Ingrese Terminal BANCS.'.
  6. Dado un payload con termBancs=12345 y usrBancs ausente, cuando se valida la solicitud, entonces el backend devuelve HTTP 400 con mensaje 'Ingrese Usuario BANCS.'.
  7. Dado que el usuario USR10001 ya existe, cuando se reenvia la misma peticion POST /api/v1/usuarios con el mismo identificador unico Idempotency-Key: alta-USR10001, entonces el backend no genera duplicados y devuelve HTTP 200 o 201 coherente con el recurso existente.
  8. Dado que la creacion fue exitosa desde /app/usuarios/nuevo, cuando el backend responde 201, entonces la SPA invalida la cache del listado, navega al detalle del usuario creado y el estado persistido se refleja sin recarga manual.

---

## 5. Modificar un usuario existente preservando reglas de negocio, sincronización complementaria y observaciones
Módulo: usuarios-administracion

Como administrador de seguridad necesito actualizar un usuario existente para corregir perfil, centro, datos descriptivos, autorizacion y datos complementarios sin perder trazabilidad. La logica fuente evidencia que antes de modificar se conservan valores previos de perfil, centro y autorizador para auditoria, luego se ejecutan las mismas validaciones que en el alta, se procesa la actualizacion del registro principal y posteriormente se actualizan observaciones y, cuando aplica, la informacion BANCS. Tambien se observan varios casos limite: si ya existe registro BANCS se reutiliza su estado, si su estado es TE se cambia a TC al modificar, si la pantalla viene sin usuario o terminal BANCS pero existe registro previo, se conserva el dato existente y se limpian campos visuales; y si cambia el usuario BANCS hacia otro valor, debe validarse duplicidad. La version moderna debe ofrecer una API PUT idempotente con control de concurrencia optimista opcional por updatedAt o version, manteniendo la semantica de negocio detectada. El frontend debe iniciar en modo consulta y pasar a edicion mediante accion explicita, mostrando solo errores relevantes por campo. La operacion debe ser transaccional: si falla la actualizacion principal o la observacion o la sincronizacion BANCS, no debe quedar el usuario en un estado mixto. Al finalizar, el detalle y el listado deben reflejar el cambio sin recarga manual.

Actor: Administrador de seguridad

Flujo funcional:
1. El administrador abre un usuario existente y pulsa Editar.
2. El frontend carga el formulario con el detalle actual y envia PUT /api/v1/usuarios/{usrSiglo21} al guardar.
3. El backend valida reglas de negocio, existencia de referencias y coherencia con estado previo.
4. Actualiza el usuario principal, actualiza o inserta observacion y resuelve la sincronizacion BANCS segun los datos enviados y los existentes.
5. Devuelve 200 con el detalle actualizado; la UI repinta detalle y refresca el listado.
6. Si el usuario no existe, devuelve 404.
7. Si hay duplicidad en usuario BANCS o referencias invalidas, devuelve 409 o 400 respectivamente.
8. Si hay error transaccional, devuelve 500 y revierte todos los cambios.

Pantallas / superficies: Rutas React: /app/usuarios/:usrSiglo21. Componentes: UsuarioDetailPage, UsuarioEditForm, ConfirmSaveDialog. Endpoints Spring: PUT /api/v1/usuarios/{usrSiglo21}.

Reglas de negocio:
- Solo se puede modificar un usuario existente.
- Se aplican las mismas validaciones obligatorias del alta para nombre, observacion, perfil, empresa y centro.
- Si oficina swift se informa, solo se acepta MSQUTODO.
- Autorizador solo admite 0 o 1.
- Si hay datos BANCS nuevos, usuario y terminal son mutuamente obligatorios.
- Si existe registro BANCS previo con estado TE y se modifica el usuario, el estado pasa a TC.
- Si no se informan nuevos datos BANCS pero existe registro previo, se conserva el dato persistido para integracion.
- Si se informa un usuario BANCS diferente al existente, debe validarse duplicidad unica.
- La observacion debe actualizarse; si no existe registro previo, debe insertarse.
- Deben guardarse metadatos de actualizacion con usuario y terminal autenticados.
- No deben quedar cambios parciales entre usuario principal, observacion y BANCS.

Notas técnicas:
Endpoint API: PUT /api/v1/usuarios/{usrSiglo21}. Path param usrSiglo21 string(8,req). Request schema igual a POST con campos editables y opcional version:number o ifMatch:string. Response 200: { usrSiglo21:string, usrNombre:string, usrEmpresa:string, usrCentro:string, usrPers:string, usrAutoriza:number, observacion:string, usrBancs:string|null, termBancs:number|null, bancsEstadoProceso:string|null, updFecha:string, updHora:string, updUsuario:string, updTerminal:string, message:string }. Error 404 USER_NOT_FOUND. Error 409 BANCS_USER_DUPLICATE | CONCURRENT_MODIFICATION. Tabla DB: t95usu03-usuarios, t95obs04-observaciones_usuario, t95ban04-usuarios_bancs. Añadir columna usr_version bigint not null default 0 en V6__alter_t95usu03_add_version.sql para bloqueo optimista moderno. Auth/Authz: JWT requerido, solo ROLE_ADMIN. Error mapping: usuario inexistente->404; validacion dominio->400; duplicado BANCS->409; conflicto de version->409; error DB->500. Flyway reference: V6__alter_t95usu03_add_version.sql. Estructura de paquetes sugerida: com.coboltest.usuariosadministracion.{domain,application,infrastructure,api}. Limites transaccionales: @Transactional isolation READ_COMMITTED, actualizacion agregada atomica. Estrategia de cache/estado: invalidar ['usuarios'] y ['usuario-detalle', usrSiglo21] tras 200; actualizar cache local del detalle con respuesta del PUT. DEPENDENCIAS MAVEN REQUERIDAS: org.springframework.boot:spring-boot-starter-parent:3.2.5, org.springframework.boot:spring-boot-starter-web:3.2.5, org.springframework.boot:spring-boot-starter-data-jpa:3.2.5, org.springframework.boot:spring-boot-starter-security:3.2.5, org.springframework.boot:spring-boot-starter-validation:3.2.5, org.springframework.boot:spring-boot-starter-actuator:3.2.5, org.springdoc:springdoc-openapi-starter-webmvc-ui:2.3.0, org.postgresql:postgresql:42.7.3, org.flywaydb:flyway-core:9.22.3, org.flywaydb:flyway-database-postgresql:10.10.0, io.jsonwebtoken:jjwt-api:0.12.5, io.jsonwebtoken:jjwt-impl:0.12.5, io.jsonwebtoken:jjwt-jackson:0.12.5, org.projectlombok:lombok:1.18.32, org.springframework.boot:spring-boot-starter-test:3.2.5, org.springframework.security:spring-security-test:6.2.4, com.h2database:h2:2.2.224. DEPENDENCIAS NPM REQUERIDAS: react:18.2.0, react-dom:18.2.0, react-router-dom:^6.22.3, @tanstack/react-query:^5.24.8, axios:^1.7.2, zod:^3.22.4, react-hook-form:^7.50.1, @hookform/resolvers:^3.3.4, tailwindcss:^3.4.3, autoprefixer:^10.4.19, postcss:^8.4.38, sonner:^1.4.41, lucide-react:^0.344.0, clsx:^2.1.1, date-fns:^3.6.0, typescript:^5.4.5, vite:^5.2.10, @vitejs/plugin-react:^4.2.1, @types/react:^18.2.66, @types/react-dom:^18.2.22, eslint:^8.57.0, prettier:^3.2.5, eslint-config-prettier:^9.1.0, @testing-library/react:^14.2.2, @testing-library/jest-dom:^6.4.2, @testing-library/user-event:^14.5.2, vitest:^1.5.0, jsdom:^24.0.0, @vitest/coverage-v8:^1.5.0, playwright:^1.43.1. confianza: media
Criterios:
  1. Dado que el frontend llama al endpoint PUT /api/v1/usuarios/USR10001, cuando la peticion es valida, entonces el cuerpo JSON de respuesta contiene exactamente los campos usrSiglo21, usrNombre, usrEmpresa, usrCentro, usrPers, usrAutoriza, observacion, usrBancs, termBancs, bancsEstadoProceso, updFecha, updHora, updUsuario, updTerminal y message con tipos acordados, y en caso de error de validacion devuelve HTTP 400 con body {timestamp,status,code,message,details,path}.
  2. Dado un usuario existente USR10001 con perfil PERF0001, cuando se modifica a PERF0002 y centro 0002 mediante PUT /api/v1/usuarios/USR10001, entonces devuelve HTTP 200 y el detalle persistido refleja PERF0002 y centro 0002.
  3. Dado un usuario inexistente USR99999, cuando se llama PUT /api/v1/usuarios/USR99999, entonces el backend devuelve HTTP 404 con code USER_NOT_FOUND.
  4. Dado que existe un registro BANCS previo con estado proceso 'TE' para USR10001, cuando se modifica el usuario con datos BANCS validos, entonces la respuesta incluye bancsEstadoProceso='TC'.
  5. Dado que la modificacion es exitosa desde /app/usuarios/USR10001, cuando la mutation concluye, entonces la SPA invalida las caches del listado y del detalle y ambos reflejan el estado persistido sin recarga manual.
  6. Dado que se reenvia la misma peticion PUT /api/v1/usuarios/USR10001 con el mismo identificador unico Idempotency-Key: mod-USR10001-v1, cuando el backend la recibe por segunda vez, entonces no genera duplicados y devuelve el mismo estado HTTP 200 con datos coherentes.
  7. Dado que dos administradores editan el mismo usuario y el segundo envia una version desactualizada, cuando el backend compara usr_version, entonces devuelve HTTP 409 con code CONCURRENT_MODIFICATION.
  8. Dado que se ejecutan las migraciones Flyway, cuando se verifica la tabla t95usu03-usuarios, entonces existe la columna usr_version con tipo bigint not null default 0 segun DDL en V6__alter_t95usu03_add_version.sql.

---

## 6. Eliminar un usuario de seguridad y limpiar su observación asociada con manejo del estado complementario
Módulo: usuarios-administracion

Como administrador de seguridad necesito eliminar un usuario de seguridad de forma controlada para retirar accesos que ya no deben existir, asegurando que quede evidencia y que los datos complementarios se manejen de acuerdo con las reglas observadas. En el codigo fuente la eliminacion exige usuario valido y observacion obligatoria, luego procesa la baja principal, y si el usuario tiene identificador BANCS informado actualiza el estado del registro complementario a TE con la observacion registrada; finalmente elimina la observacion asociada y escribe auditoria. La semantica funcional no borra necesariamente el registro BANCS fisicamente en todos los casos, sino que primero marca el estado de proceso y limpia los campos visibles de la pantalla. La implementacion moderna debe modelar esta conducta como una baja transaccional del usuario principal con cleanup de observaciones y tratamiento complementario de BANCS. Para mantener trazabilidad y evitar inconsistencia, si falla la actualizacion del estado BANCS o la eliminacion de la observacion, debe revertirse toda la operacion o devolver el error segun el punto de fallo. El frontend debe solicitar confirmacion explicita y motivo de baja, y al completarse exitosamente debe volver al listado actualizado. Si el usuario no existe o falta la observacion, la API debe rechazar la operacion con mensajes claros.

Actor: Administrador de seguridad

Flujo funcional:
1. El administrador abre el detalle de un usuario y pulsa Eliminar.
2. La UI solicita confirmacion y observacion obligatoria.
3. El frontend envia DELETE /api/v1/usuarios/{usrSiglo21} con body JSON que contiene la observacion de baja.
4. El backend valida existencia del usuario y observacion informada.
5. Si existe integracion BANCS informada, actualiza su estado a TE y guarda la observacion.
6. El backend elimina el usuario principal y la observacion asociada en una transaccion.
7. Devuelve 200 con mensaje de eliminacion; la UI vuelve al listado y refresca datos.
8. Si falta observacion o el usuario no existe, devuelve 400 o 404.
9. Si alguna operacion interna falla, devuelve 500 y no deja datos parciales.

Pantallas / superficies: Rutas React: /app/usuarios/:usrSiglo21, /app/usuarios/consulta. Componentes: DeleteUserDialog, UsuarioDetailPage, UsuarioTable. Endpoints Spring: DELETE /api/v1/usuarios/{usrSiglo21}.

Reglas de negocio:
- La observacion es obligatoria para eliminar.
- Solo se puede eliminar un usuario existente.
- Si el usuario tiene datos BANCS informados, el estado complementario debe pasar a TE antes de completar la baja.
- La observacion debe propagarse al registro BANCS cuando se actualiza su estado.
- Debe eliminarse la observacion asociada del usuario principal.
- La operacion debe registrar auditoria.
- Tras la eliminacion exitosa, el usuario no debe aparecer en nuevas consultas.
- La eliminacion debe ser idempotente a nivel de API si se reenvia con la misma clave de idempotencia: no recrea ni duplica efectos; si el recurso ya no existe puede responder 200 con estado final o 404 consistente segun estrategia documentada. Se adopta 200 con resultado alreadyDeleted cuando se reenvia con la misma Idempotency-Key.

Notas técnicas:
Endpoint API: DELETE /api/v1/usuarios/{usrSiglo21}. Path param usrSiglo21 string(8,req). Request body: { observacion:string(1..100,req) }. Response 200: { usrSiglo21:string, deleted:boolean, alreadyDeleted:boolean, bancsEstadoProceso:string|null, message:string }. Error 400: OBSERVATION_REQUIRED. Error 404: USER_NOT_FOUND. Tabla DB: t95usu03-usuarios, t95obs04-observaciones_usuario, t95ban04-usuarios_bancs. Auth/Authz: JWT requerido, solo ROLE_ADMIN. Error mapping: observacion vacia->400; usuario inexistente->404; error update BANCS->500 BANCS_STATE_UPDATE_ERROR; error delete observation->500 OBSERVATION_DELETE_ERROR. Flyway reference: sin nuevas tablas; reutiliza V2, V4 y V5. Estructura de paquetes sugerida: com.coboltest.usuariosadministracion.{domain,application,infrastructure,api}. Limites transaccionales: @Transactional isolation READ_COMMITTED; secuencia update BANCS -> delete user -> delete observation -> audit, con rollback total en excepcion. Estrategia de cache/estado: invalidar ['usuarios'] y remover ['usuario-detalle', usrSiglo21] tras 200; redirigir al listado. DEPENDENCIAS MAVEN REQUERIDAS: org.springframework.boot:spring-boot-starter-parent:3.2.5, org.springframework.boot:spring-boot-starter-web:3.2.5, org.springframework.boot:spring-boot-starter-data-jpa:3.2.5, org.springframework.boot:spring-boot-starter-security:3.2.5, org.springframework.boot:spring-boot-starter-validation:3.2.5, org.springframework.boot:spring-boot-starter-actuator:3.2.5, org.springdoc:springdoc-openapi-starter-webmvc-ui:2.3.0, org.postgresql:postgresql:42.7.3, org.flywaydb:flyway-core:9.22.3, org.flywaydb:flyway-database-postgresql:10.10.0, io.jsonwebtoken:jjwt-api:0.12.5, io.jsonwebtoken:jjwt-impl:0.12.5, io.jsonwebtoken:jjwt-jackson:0.12.5, org.projectlombok:lombok:1.18.32, org.springframework.boot:spring-boot-starter-test:3.2.5, org.springframework.security:spring-security-test:6.2.4, com.h2database:h2:2.2.224. DEPENDENCIAS NPM REQUERIDAS: react:18.2.0, react-dom:18.2.0, react-router-dom:^6.22.3, @tanstack/react-query:^5.24.8, axios:^1.7.2, zod:^3.22.4, react-hook-form:^7.50.1, @hookform/resolvers:^3.3.4, tailwindcss:^3.4.3, autoprefixer:^10.4.19, postcss:^8.4.38, sonner:^1.4.41, lucide-react:^0.344.0, clsx:^2.1.1, date-fns:^3.6.0, typescript:^5.4.5, vite:^5.2.10, @vitejs/plugin-react:^4.2.1, @types/react:^18.2.66, @types/react-dom:^18.2.22, eslint:^8.57.0, prettier:^3.2.5, eslint-config-prettier:^9.1.0, @testing-library/react:^14.2.2, @testing-library/jest-dom:^6.4.2, @testing-library/user-event:^14.5.2, vitest:^1.5.0, jsdom:^24.0.0, @vitest/coverage-v8:^1.5.0, playwright:^1.43.1. confianza: alta
Criterios:
  1. Dado que el frontend llama al endpoint DELETE /api/v1/usuarios/USR10001, cuando la peticion es valida, entonces el cuerpo JSON de respuesta contiene exactamente los campos usrSiglo21, deleted, alreadyDeleted, bancsEstadoProceso y message con tipos string, boolean y string|null, y en caso de error de validacion devuelve HTTP 400 con body {timestamp,status,code,message,details,path}.
  2. Dado un usuario existente USR10001 y observacion='Baja por salida de la organizacion', cuando se ejecuta DELETE /api/v1/usuarios/USR10001, entonces devuelve HTTP 200 con deleted=true.
  3. Dado un intento de eliminacion sin observacion, cuando se procesa DELETE /api/v1/usuarios/USR10001, entonces el backend devuelve HTTP 400 con code OBSERVATION_REQUIRED.
  4. Dado un usuario inexistente USR99999, cuando se solicita DELETE /api/v1/usuarios/USR99999 con observacion valida, entonces devuelve HTTP 404 con code USER_NOT_FOUND.
  5. Dado que el usuario USR10001 tiene registro en t95ban04-usuarios_bancs, cuando se elimina correctamente, entonces la respuesta informa bancsEstadoProceso='TE' y el registro complementario conserva la observacion de baja.
  6. Dado que la eliminacion es exitosa desde /app/usuarios/USR10001, cuando la mutation responde 200, entonces la SPA invalida el listado, remueve el detalle en cache y el usuario ya no aparece sin recarga manual en /app/usuarios/consulta.
  7. Dado que se reenvia la misma peticion DELETE /api/v1/usuarios/USR10001 con la misma Idempotency-Key, cuando el backend la recibe por segunda vez, entonces no genera duplicados y devuelve el mismo estado HTTP 200 con alreadyDeleted=true y datos coherentes.

---

## 7. Resolver y validar catálogos de perfil, empresa, centro y observaciones para soportar formularios y mensajes de negocio
Módulo: catalogos-validacion

Como administrador de seguridad necesito que el sistema valide y resuelva de forma consistente los catálogos relacionados con usuarios para prevenir errores de captura y ofrecer descripciones legibles. Esta historia sintetiza funcionalidad transversal extraida de varias rutinas: validacion de perfil en tabla de parametros con codigo GR, validacion de recursos del perfil en tabla de recursos, consulta del nombre de empresa y del nombre de centro, lectura de observacion asociada, y fallback con mensajes cuando la referencia no existe o hay error de tabla. Aunque en el sistema original estas validaciones estan embebidas en el flujo del formulario, en la version moderna conviene exponer endpoints de apoyo reutilizables para autocompletado, validacion asincrona y resolucion de descripciones visibles. Esto permite que la interfaz muestre inmediatamente el nombre de la empresa, el centro y la descripcion del perfil mientras el usuario digita, reduciendo errores antes del submit. La historia no agrega nueva capacidad de negocio; solo externaliza y normaliza la logica ya evidenciada. Deben mantenerse mensajes equivalentes a los existentes: perfil no definido, error en tabla de parametros, empresa no definida y centro no definido. Tambien debe existir acceso a la observacion actual del usuario para poblar formularios de edicion. La solucion debe contemplar consultas de solo lectura y alto reuso desde las historias de alta, modificacion y detalle.

Actor: Administrador de seguridad

Flujo funcional:
1. El usuario escribe un perfil, empresa o centro en el formulario de alta o edicion.
2. El frontend dispara consultas ligeras de validacion/resolucion al backend.
3. El backend consulta las tablas de catalogo y devuelve descripcion y estado de validez.
4. La UI muestra la descripcion resuelta junto al campo y habilita o bloquea el guardado segun el resultado.
5. Si la referencia no existe, muestra el mensaje funcional correspondiente.
6. Si el usuario abre un detalle o edicion, el frontend consulta la observacion actual para precargarla.
7. Si hay error interno de consulta, se informa un error de catalogo controlado.

Pantallas / superficies: Rutas React: /app/usuarios/nuevo, /app/usuarios/:usrSiglo21. Componentes: CatalogLookupHint, UsuarioForm. Endpoints Spring: GET /api/v1/catalogos/perfiles/{codigo}, GET /api/v1/catalogos/empresas/{codigo}, GET /api/v1/catalogos/empresas/{empresa}/centros/{centro}, GET /api/v1/usuarios/{usrSiglo21}/observacion.

Reglas de negocio:
- El perfil se considera valido solo si existe parametro GR en catalogo de perfiles.
- El perfil debe ademas existir en la tabla de recursos/permisos para ser utilizable.
- La empresa debe existir para ser valida.
- El centro debe existir dentro de la empresa indicada.
- La observacion de usuario es opcional en lectura y puede no existir.
- Los mensajes de ausencia deben ser explicitos y equivalentes al negocio existente.
- Los endpoints son de solo lectura y no deben modificar estado.
- El usuario debe estar autenticado para consultar catalogos funcionales.

Notas técnicas:
Endpoint API 1: GET /api/v1/catalogos/perfiles/{codigo} -> 200 { codigo:string, descripcion:string|null, existeParametro:boolean, existeRecurso:boolean, valido:boolean, message:string }. Endpoint API 2: GET /api/v1/catalogos/empresas/{codigo} -> 200 { codigo:string, nombre:string|null, valido:boolean, message:string }. Endpoint API 3: GET /api/v1/catalogos/empresas/{empresa}/centros/{centro} -> 200 { empresa:string, centro:string, nombre:string|null, valido:boolean, message:string }. Endpoint API 4: GET /api/v1/usuarios/{usrSiglo21}/observacion -> 200 { usrSiglo21:string, observacion:string|null }. Error 404 solo para recurso sintacticamente correcto sin entidad y cuando el frontend requiere distincion; para validacion de campo preferir 200 con valido=false. Tablas DB: t95par02-parametros con columnas par_grupo_usuario varchar(12), par_codigo_parametro varchar(4), par_descripcion varchar(100), PK compuesta (par_grupo_usuario, par_codigo_parametro); t01gre20-recursos_grupo con columnas gre_grupo_usuario varchar(8), gre_recurso_codigo varchar(12), gre_acceso numeric(4,0), gre_usuario_mod varchar(8), gre_modificacion_ts timestamp, PK compuesta (gre_grupo_usuario, gre_recurso_codigo); t06tc005-empresas con emp_codigo varchar(4) PK, emp_nombre varchar(40) NOT NULL; t06tc007-centros con PK compuesta (cen_empresa_codigo varchar(4), cen_centro_codigo varchar(4)), cen_nombre varchar(40) NOT NULL; t95obs04-observaciones_usuario definida en V4. Auth/Authz: JWT requerido, ROLE_ADMIN o ROLE_OPERADOR. Error mapping: perfil no definido->200 valido=false message 'Perfil NO definido en T95PAR02'; recursos no definidos->200 valido=false message 'Perfil RE no definido en T01GRE20'; empresa ausente->200 valido=false message 'Empresa no definida T06TC005'; centro ausente->200 valido=false message 'Centro no definido T06TC007'; error SQL->500 CATALOG_QUERY_ERROR. Flyway reference: V3__create_catalogos_empresas_centros_perfiles.sql y V4__create_t95obs04_observaciones_usuario.sql. Estructura de paquetes sugerida: com.coboltest.catalogosvalidacion.{domain,application,infrastructure,api}. Limites transaccionales: @Transactional(readOnly=true). Estrategia de cache/estado: React Query staleTime 10 min para catalogos; observacion staleTime 30 s e invalidacion al editar usuario. DEPENDENCIAS MAVEN REQUERIDAS: org.springframework.boot:spring-boot-starter-parent:3.2.5, org.springframework.boot:spring-boot-starter-web:3.2.5, org.springframework.boot:spring-boot-starter-data-jpa:3.2.5, org.springframework.boot:spring-boot-starter-security:3.2.5, org.springframework.boot:spring-boot-starter-validation:3.2.5, org.springframework.boot:spring-boot-starter-actuator:3.2.5, org.springdoc:springdoc-openapi-starter-webmvc-ui:2.3.0, org.postgresql:postgresql:42.7.3, org.flywaydb:flyway-core:9.22.3, org.flywaydb:flyway-database-postgresql:10.10.0, io.jsonwebtoken:jjwt-api:0.12.5, io.jsonwebtoken:jjwt-impl:0.12.5, io.jsonwebtoken:jjwt-jackson:0.12.5, org.projectlombok:lombok:1.18.32, org.springframework.boot:spring-boot-starter-test:3.2.5, org.springframework.security:spring-security-test:6.2.4, com.h2database:h2:2.2.224. DEPENDENCIAS NPM REQUERIDAS: react:18.2.0, react-dom:18.2.0, react-router-dom:^6.22.3, @tanstack/react-query:^5.24.8, axios:^1.7.2, zod:^3.22.4, react-hook-form:^7.50.1, @hookform/resolvers:^3.3.4, tailwindcss:^3.4.3, autoprefixer:^10.4.19, postcss:^8.4.38, sonner:^1.4.41, lucide-react:^0.344.0, clsx:^2.1.1, date-fns:^3.6.0, typescript:^5.4.5, vite:^5.2.10, @vitejs/plugin-react:^4.2.1, @types/react:^18.2.66, @types/react-dom:^18.2.22, eslint:^8.57.0, prettier:^3.2.5, eslint-config-prettier:^9.1.0, @testing-library/react:^14.2.2, @testing-library/jest-dom:^6.4.2, @testing-library/user-event:^14.5.2, vitest:^1.5.0, jsdom:^24.0.0, @vitest/coverage-v8:^1.5.0, playwright:^1.43.1. confianza: alta
Criterios:
  1. Dado que el frontend llama al endpoint GET /api/v1/catalogos/perfiles/PERF0001, cuando la peticion es valida, entonces el cuerpo JSON de respuesta contiene exactamente los campos codigo, descripcion, existeParametro, existeRecurso, valido y message con tipos string, string|null y boolean, y en caso de error de validacion devuelve HTTP 400 con body {timestamp,status,code,message,details,path}.
  2. Dado un perfil inexistente PERF9999, cuando se consulta GET /api/v1/catalogos/perfiles/PERF9999, entonces responde HTTP 200 con valido=false y message 'Perfil NO definido en T95PAR02'.
  3. Dado una empresa inexistente 9999, cuando se consulta GET /api/v1/catalogos/empresas/9999, entonces responde HTTP 200 con valido=false y message 'Empresa no definida T06TC005'.
  4. Dado empresa='1001' y centro='0099' no asociado, cuando se llama GET /api/v1/catalogos/empresas/1001/centros/0099, entonces responde HTTP 200 con valido=false y message 'Centro no definido T06TC007'.
  5. Dado que el usuario edita USR10001 y se guarda una nueva observacion, cuando la operacion concluye exitosamente, entonces React Query invalida la key ['usuario-observacion','USR10001'] y la UI refleja el nuevo texto sin recarga manual.
  6. Dado que se ejecutan las migraciones Flyway, cuando se verifica la tabla t95par02-parametros, entonces existen las columnas par_grupo_usuario, par_codigo_parametro y par_descripcion con tipos varchar, constraint de primary key compuesta en (par_grupo_usuario, par_codigo_parametro), y referencias a catalogos segun DDL en V3__create_catalogos_empresas_centros_perfiles.sql.
  7. Dado que se reenvia la misma peticion GET /api/v1/catalogos/empresas/1001 con el mismo identificador unico, cuando el backend la recibe por segunda vez, entonces no genera duplicados y devuelve el mismo estado HTTP 200 con datos coherentes.

---

## 8. Gestionar la integración complementaria BANCS del usuario con consulta, alta, modificación y cambio de estado
Módulo: integracion-bancs

Como administrador de seguridad necesito que el sistema gestione de forma consistente los datos complementarios BANCS asociados al usuario, ya que forman parte del mantenimiento funcional observado en el código. La fuente muestra consultas específicas sobre una tabla complementaria con usuario BANCS, terminal, empresa, nombre, observación y estado de proceso; también permite insertar, modificar y cambiar solo el estado según el ciclo de vida del usuario. Se detectan reglas importantes: no se debe operar si faltan usuario principal, usuario BANCS o terminal; un SQLCODE -1 se interpreta como usuario BANCS duplicado; la consulta de inexistencia no es un error fatal en todos los flujos; y los estados utilizados incluyen al menos TC y TE. La implementación moderna debe tratar esta integración como subrecurso interno del usuario, de manera que pueda consultarse de forma aislada y también ser usada transaccionalmente por las altas, modificaciones y bajas del usuario principal. La API debe conservar mensajes claros y distinguir ausencia de registro complementario frente a error técnico. El frontend mostrará una sección plegable “Datos BANCS” dentro del detalle del usuario, con validaciones relacionadas y estado visible. Esta historia no inventa nuevos procesos externos; solo moderniza la persistencia y lectura de la información complementaria ya presente en el comportamiento funcional.

Actor: Administrador de seguridad

Flujo funcional:
1. El administrador abre el detalle del usuario y expande la seccion Datos BANCS.
2. El frontend consulta GET /api/v1/usuarios/{usrSiglo21}/bancs.
3. Si existe informacion, el backend devuelve usuario BANCS, terminal, empresa, observacion y estado.
4. En alta o modificacion del usuario principal, el backend inserta o actualiza este subregistro cuando vienen ambos datos obligatorios.
5. En eliminacion del usuario principal, el backend cambia el estado del subregistro a TE y actualiza observacion.
6. Si el usuario BANCS ya esta asociado a otro usuario, el backend devuelve 409.
7. Si no existe subregistro para el usuario consultado, devuelve 404 o 200 null segun endpoint de lectura; para esta historia se adopta 404 para consulta directa y null embebido en detalle agregado.
8. Si faltan datos mutuamente obligatorios, devuelve 400.

Pantallas / superficies: Rutas React: /app/usuarios/:usrSiglo21. Componentes: BancsSection, UsuarioEditForm. Endpoints Spring: GET /api/v1/usuarios/{usrSiglo21}/bancs, PUT /api/v1/usuarios/{usrSiglo21}/bancs/estado.

Reglas de negocio:
- Usuario principal es obligatorio para consultar o modificar BANCS.
- Usuario BANCS y terminal BANCS son mutuamente obligatorios para alta o modificacion.
- Si faltan valores criticos, no se inserta ni actualiza el subregistro.
- El usuario BANCS debe ser unico; duplicados provocan conflicto.
- La inexistencia del subregistro en consulta directa debe distinguirse de un error técnico.
- En alta o modificacion normal el estado esperado es TC.
- En eliminacion del usuario principal el estado se cambia a TE.
- La observacion del proceso puede almacenarse en el subregistro.
- La empresa del subregistro debe corresponder a la empresa del usuario principal.

Notas técnicas:
Endpoint API 1: GET /api/v1/usuarios/{usrSiglo21}/bancs. Response 200: { usrSiglo21:string, usrBancs:string, usrNombre:string, branchNo:string, termNo:number, codEmpresa:string, estProceso:string, observacion:string, fechaUltCambio:string, usrUltCambio:string }. Error 404: BANCS_RECORD_NOT_FOUND. Endpoint API 2: PUT /api/v1/usuarios/{usrSiglo21}/bancs/estado. Request { estProceso:string(2,req), observacion:string(1..80,req) }. Response 200 { usrSiglo21:string, estProceso:string, observacion:string, updated:boolean }. Tabla DB: t95ban04-usuarios_bancs con columnas bancs_usuario_codigo varchar(8) PK, bancs_usuario_externo varchar(8) NOT NULL UNIQUE, bancs_nombre varchar(60) NOT NULL, bancs_branch_codigo varchar(4) NOT NULL, bancs_terminal_numero integer NOT NULL, bancs_empresa_codigo varchar(4) NOT NULL, bancs_estado_proceso varchar(2) NOT NULL, bancs_observacion varchar(80) NOT NULL, bancs_fecha_ult_cambio timestamp NOT NULL default current_timestamp, bancs_usuario_ult_cambio varchar(8) NOT NULL. Auth/Authz: JWT requerido, solo ROLE_ADMIN. Error mapping: faltan datos BANCS->400 BANCS_DATA_INCOMPLETE; duplicado usuario BANCS->409 BANCS_USER_DUPLICATE; no existe subregistro->404 BANCS_RECORD_NOT_FOUND; error SQL->500 BANCS_ERROR. Flyway reference: V5__create_t95ban04_usuarios_bancs.sql. Estructura de paquetes sugerida: com.coboltest.integracionbancs.{domain,application,infrastructure,api}. Limites transaccionales: operaciones de escritura ejecutadas dentro de las transacciones de usuario principal; endpoint de cambio de estado con @Transactional propio. Estrategia de cache/estado: key ['usuario-bancs', usrSiglo21]; invalidar tras alta, edicion, eliminacion o cambio de estado. DEPENDENCIAS MAVEN REQUERIDAS: org.springframework.boot:spring-boot-starter-parent:3.2.5, org.springframework.boot:spring-boot-starter-web:3.2.5, org.springframework.boot:spring-boot-starter-data-jpa:3.2.5, org.springframework.boot:spring-boot-starter-security:3.2.5, org.springframework.boot:spring-boot-starter-validation:3.2.5, org.springframework.boot:spring-boot-starter-actuator:3.2.5, org.springdoc:springdoc-openapi-starter-webmvc-ui:2.3.0, org.postgresql:postgresql:42.7.3, org.flywaydb:flyway-core:9.22.3, org.flywaydb:flyway-database-postgresql:10.10.0, io.jsonwebtoken:jjwt-api:0.12.5, io.jsonwebtoken:jjwt-impl:0.12.5, io.jsonwebtoken:jjwt-jackson:0.12.5, org.projectlombok:lombok:1.18.32, org.springframework.boot:spring-boot-starter-test:3.2.5, org.springframework.security:spring-security-test:6.2.4, com.h2database:h2:2.2.224. DEPENDENCIAS NPM REQUERIDAS: react:18.2.0, react-dom:18.2.0, react-router-dom:^6.22.3, @tanstack/react-query:^5.24.8, axios:^1.7.2, zod:^3.22.4, react-hook-form:^7.50.1, @hookform/resolvers:^3.3.4, tailwindcss:^3.4.3, autoprefixer:^10.4.19, postcss:^8.4.38, sonner:^1.4.41, lucide-react:^0.344.0, clsx:^2.1.1, date-fns:^3.6.0, typescript:^5.4.5, vite:^5.2.10, @vitejs/plugin-react:^4.2.1, @types/react:^18.2.66, @types/react-dom:^18.2.22, eslint:^8.57.0, prettier:^3.2.5, eslint-config-prettier:^9.1.0, @testing-library/react:^14.2.2, @testing-library/jest-dom:^6.4.2, @testing-library/user-event:^14.5.2, vitest:^1.5.0, jsdom:^24.0.0, @vitest/coverage-v8:^1.5.0, playwright:^1.43.1. confianza: alta
Criterios:
  1. Dado que el frontend llama al endpoint GET /api/v1/usuarios/USR10001/bancs, cuando la peticion es valida, entonces el cuerpo JSON de respuesta contiene exactamente los campos usrSiglo21, usrBancs, usrNombre, branchNo, termNo, codEmpresa, estProceso, observacion, fechaUltCambio y usrUltCambio con tipos string y number, y en caso de error de validacion devuelve HTTP 400 con body {timestamp,status,code,message,details,path}.
  2. Dado un usuario con subregistro BANCS existente, cuando se consulta GET /api/v1/usuarios/USR10001/bancs, entonces devuelve HTTP 200 con estProceso='TC' o el valor persistido.
  3. Dado un usuario sin subregistro BANCS, cuando se consulta GET /api/v1/usuarios/USR10002/bancs, entonces devuelve HTTP 404 con code BANCS_RECORD_NOT_FOUND.
  4. Dado un cambio de estado valido con observacion='Baja definitiva', cuando se llama PUT /api/v1/usuarios/USR10001/bancs/estado con estProceso='TE', entonces devuelve HTTP 200 con updated=true y estProceso='TE'.
  5. Dado un intento de alta o edicion con usrBancs='12345678' y termNo ausente, cuando el backend valida la operacion de usuario principal, entonces devuelve HTTP 400 con code BANCS_DATA_INCOMPLETE.
  6. Dado un usuario BANCS ya asociado a otro usuario, cuando se intenta guardar ese mismo usrBancs para USR10003, entonces el backend devuelve HTTP 409 con code BANCS_USER_DUPLICATE.
  7. Dado que la actualizacion BANCS fue exitosa desde la seccion plegable del detalle, cuando React Query invalida la key ['usuario-bancs','USR10001'], entonces la tarjeta de Datos BANCS refleja el estado persistido sin recarga manual.
  8. Dado que se ejecutan las migraciones Flyway, cuando se verifica la tabla t95ban04-usuarios_bancs, entonces existen las columnas bancs_usuario_codigo, bancs_usuario_externo, bancs_nombre, bancs_branch_codigo, bancs_terminal_numero, bancs_empresa_codigo, bancs_estado_proceso, bancs_observacion, bancs_fecha_ult_cambio y bancs_usuario_ult_cambio con tipos PostgreSQL, constraint de primary key en bancs_usuario_codigo, y foreign keys a t95usu03-usuarios segun DDL en V5__create_t95ban04_usuarios_bancs.sql.

---

## 9. Registrar auditoría funcional de altas, modificaciones y eliminaciones de usuarios para cumplimiento y trazabilidad
Módulo: auditoria-operacion

Como responsable de control necesito que cada alta, modificación y eliminación de usuarios deje un rastro auditable con datos previos y actuales relevantes, motivo y resultado operativo. Esta necesidad se basa directamente en la rutina de escritura de log observada en el código, donde se construye un registro con transacción T95USU03, operación INGRESO, MODIFICACION o ELIMINACION, mensajería delimitada por ';', observación y respuesta final. Para modificaciones, además se incluyen valores previos de perfil, centro y autorizador; para otras operaciones se enmascaran esos espacios con asteriscos. La modernización debe persistir este log en PostgreSQL y exponerlo mediante consulta de auditoría para soporte y revisiones internas. La historia no altera el flujo principal de negocio, pero exige que las mutaciones de usuarios llamen al servicio de auditoría dentro de la misma transacción lógica o inmediatamente después con garantías de consistencia. La estructura del mensaje debe ser legible y mantener la semántica del formato original, aunque almacenada en campos separados además de una cadena consolidada para búsquedas. El frontend debe permitir consultar la bitácora del usuario desde su detalle. Si la escritura de auditoría falla, la API principal debe responder error para no perder trazabilidad, ya que en la fuente se trata como un problema funcional relevante.

Actor: Responsable de control

Flujo funcional:
1. Un administrador crea, modifica o elimina un usuario.
2. El backend ejecuta la operacion funcional y arma el registro de auditoria con operacion, mensaje consolidado, observacion y resultado.
3. Guarda el log en base de datos con fecha, hora, terminal y usuario ejecutor.
4. El frontend puede consultar la bitacora del usuario desde el detalle mediante GET /api/v1/auditoria/usuarios/{usrSiglo21}.
5. Si la auditoria se guarda correctamente, la operacion principal finaliza con exito.
6. Si la auditoria falla, la operacion principal devuelve 500 y revierte la transaccion o reporta fallo consistente.
7. Si no hay eventos para un usuario, la API devuelve lista vacia.

Pantallas / superficies: Rutas React: /app/usuarios/:usrSiglo21/auditoria o panel dentro de /app/usuarios/:usrSiglo21. Componentes: UsuarioAuditPanel, AuditTimeline. Endpoints Spring: GET /api/v1/auditoria/usuarios/{usrSiglo21}.

Reglas de negocio:
- Debe auditarse cada alta, modificacion y eliminacion de usuarios.
- El codigo de transaccion funcional es T95USU03.
- Las operaciones validas son INGRESO, MODIFICACION y ELIMINACION.
- El mensaje de auditoria debe incluir usuario, nombre, perfil, centro, autorizador, observacion y respuesta separados por ';'.
- En modificacion deben almacenarse tambien los valores previos de perfil, centro y autorizador.
- En otras operaciones, los valores previos se enmascaran con asteriscos.
- Si falla la escritura de auditoria, la operacion de negocio no se considera completa.
- La consulta de auditoria debe estar protegida por autenticacion.

Notas técnicas:
Endpoint API: GET /api/v1/auditoria/usuarios/{usrSiglo21}?page=0&size=20. Response 200: { content:[{ id:uuid, transaccion:string, operacion:string, usrSiglo21:string, nombre:string, perfilActual:string, centroActual:string, autorizadorActual:number, perfilPrevio:string|null, centroPrevio:string|null, autorizadorPrevio:number|null, observacion:string, respuesta:string, mensajeria:string, usuarioModificador:string, terminal:string, fechaHora:string }], totalElements:number, totalPages:number, size:number, number:number, first:boolean, last:boolean }. Tabla DB: t95log01-auditoria_usuarios con columnas log_id uuid PK, log_transaccion varchar(8) NOT NULL, log_operacion varchar(12) NOT NULL, log_usr_siglo21 varchar(8) NOT NULL, log_nombre varchar(40) NOT NULL, log_perfil_actual varchar(8) NOT NULL, log_centro_actual varchar(4) NOT NULL, log_autorizador_actual smallint NOT NULL, log_perfil_previo varchar(8), log_centro_previo varchar(4), log_autorizador_previo smallint, log_observacion varchar(100) NOT NULL, log_respuesta varchar(100) NOT NULL, log_mensajeria varchar(255) NOT NULL, log_terminal varchar(10) NOT NULL, log_usuario_mod varchar(20) NOT NULL, log_fecha_hora timestamp NOT NULL default current_timestamp. Indices: idx_log_usr_siglo21_fecha on (log_usr_siglo21, log_fecha_hora desc). Auth/Authz: JWT requerido, ROLE_ADMIN o ROLE_OPERADOR para lectura, solo servicios internos para escritura. Error mapping: falla de auditoria->500 AUDIT_WRITE_ERROR; usuario sin eventos->200 lista vacia. Flyway reference: V7__create_t95log01_auditoria_usuarios.sql. Estructura de paquetes sugerida: com.coboltest.auditoriaoperacion.{domain,application,infrastructure,api}. Limites transaccionales: escritura llamada desde el mismo boundary transaccional de create/update/delete. Estrategia de cache/estado: key ['auditoria-usuario', usrSiglo21, page]; invalidar tras mutaciones exitosas. DEPENDENCIAS MAVEN REQUERIDAS: org.springframework.boot:spring-boot-starter-parent:3.2.5, org.springframework.boot:spring-boot-starter-web:3.2.5, org.springframework.boot:spring-boot-starter-data-jpa:3.2.5, org.springframework.boot:spring-boot-starter-security:3.2.5, org.springframework.boot:spring-boot-starter-validation:3.2.5, org.springframework.boot:spring-boot-starter-actuator:3.2.5, org.springdoc:springdoc-openapi-starter-webmvc-ui:2.3.0, org.postgresql:postgresql:42.7.3, org.flywaydb:flyway-core:9.22.3, org.flywaydb:flyway-database-postgresql:10.10.0, io.jsonwebtoken:jjwt-api:0.12.5, io.jsonwebtoken:jjwt-impl:0.12.5, io.jsonwebtoken:jjwt-jackson:0.12.5, org.projectlombok:lombok:1.18.32, org.springframework.boot:spring-boot-starter-test:3.2.5, org.springframework.security:spring-security-test:6.2.4, com.h2database:h2:2.2.224. DEPENDENCIAS NPM REQUERIDAS: react:18.2.0, react-dom:18.2.0, react-router-dom:^6.22.3, @tanstack/react-query:^5.24.8, axios:^1.7.2, zod:^3.22.4, react-hook-form:^7.50.1, @hookform/resolvers:^3.3.4, tailwindcss:^3.4.3, autoprefixer:^10.4.19, postcss:^8.4.38, sonner:^1.4.41, lucide-react:^0.344.0, clsx:^2.1.1, date-fns:^3.6.0, typescript:^5.4.5, vite:^5.2.10, @vitejs/plugin-react:^4.2.1, @types/react:^18.2.66, @types/react-dom:^18.2.22, eslint:^8.57.0, prettier:^3.2.5, eslint-config-prettier:^9.1.0, @testing-library/react:^14.2.2, @testing-library/jest-dom:^6.4.2, @testing-library/user-event:^14.5.2, vitest:^1.5.0, jsdom:^24.0.0, @vitest/coverage-v8:^1.5.0, playwright:^1.43.1. confianza: alta
Criterios:
  1. Dado que se ejecuta una alta de usuario exitosa, cuando la transaccion finaliza, entonces se inserta un registro en t95log01-auditoria_usuarios con log_transaccion='T95USU03' y log_operacion='INGRESO'.
  2. Dado que se ejecuta una modificacion de usuario con cambio de perfil de PERF0001 a PERF0002 y centro de 0001 a 0002, cuando se guarda la auditoria, entonces el registro contiene perfilActual='PERF0002', centroActual='0002', perfilPrevio='PERF0001' y centroPrevio='0001'.
  3. Dado que el frontend llama al endpoint GET /api/v1/auditoria/usuarios/USR10001, cuando la peticion es valida, entonces el cuerpo JSON de respuesta contiene exactamente los campos content, totalElements, totalPages, size, number, first y last, y cada item de content contiene id, transaccion, operacion, usrSiglo21, nombre, perfilActual, centroActual, autorizadorActual, perfilPrevio, centroPrevio, autorizadorPrevio, observacion, respuesta, mensajeria, usuarioModificador, terminal y fechaHora.
  4. Dado que una mutacion de usuario fue exitosa y luego se abre el panel de auditoria en la misma SPA, cuando React Query invalida la key ['auditoria-usuario','USR10001',0], entonces el nuevo evento aparece sin recarga manual.
  5. Dado que no existen eventos para USR99999, cuando se consulta GET /api/v1/auditoria/usuarios/USR99999?page=0&size=20, entonces devuelve HTTP 200 con content=[] y totalElements=0.
  6. Dado que se reenvia la misma consulta GET /api/v1/auditoria/usuarios/USR10001?page=0&size=20 con el mismo identificador unico, cuando el backend la recibe por segunda vez, entonces no genera duplicados y devuelve el mismo estado HTTP 200 con datos coherentes.
  7. Dado que se ejecutan las migraciones Flyway, cuando se verifica la tabla t95log01-auditoria_usuarios, entonces existen las columnas log_id, log_transaccion, log_operacion, log_usr_siglo21, log_nombre, log_perfil_actual, log_centro_actual, log_autorizador_actual, log_perfil_previo, log_centro_previo, log_autorizador_previo, log_observacion, log_respuesta, log_mensajeria, log_terminal, log_usuario_mod y log_fecha_hora con tipos PostgreSQL, constraint de primary key en log_id, y el indice idx_log_usr_siglo21_fecha segun DDL en V7__create_t95log01_auditoria_usuarios.sql.

---

## 10. Autenticar usuarios, preparar el entorno local completo y documentar la ejecución productiva del módulo de seguridad
Módulo: auth-infra

Como equipo de desarrollo y QA necesito una base de autenticación y una orquestación local completa para ejecutar el sistema de seguridad de punta a punta con un solo comando, incluyendo backend, frontend, base de datos, migraciones, pruebas y documentación operativa. Esta historia es obligatoria porque toda la funcionalidad extraída del código depende de identidad de usuario, terminal lógica, control de acceso y una ejecución local estable. Debe implementarse autenticación JWT con roles ROLE_ADMIN y ROLE_OPERADOR, endpoints de login/refresh/logout, guards en React, interceptor Axios y manejo de expiración sin almacenar el token en localStorage. Además, debe proveerse .env.example, README.md, DOCS.md, scripts run.sh/run.ps1 y stop.sh/stop.ps1 exactamente alineados con la directiva de puertos dinámicos, descarga completa de dependencias, chequeos de peso de artefactos, arranque de PostgreSQL nativo, Flyway, health checks, ejecución de tests y mantenimiento de procesos en background mostrando logs. Esta historia también cubre el empaquetado completo de dependencias Maven y npm, configuración OpenAPI, perfiles Spring y estructura de proyecto /backend y /frontend. Sin esta base, las historias funcionales no son ejecutables; por eso debe implementarse primero y servir como columna vertebral del sistema listo para producción local.

Actor: Equipo de desarrollo y operador autenticado

Flujo funcional:
1. El desarrollador copia .env.example a .env y completa secretos requeridos.
2. Ejecuta ./run.sh o .\run.ps1 desde la raiz del proyecto.
3. El script verifica java, node, npm y psql; instala faltantes si es posible usando SUDO_AUTH.
4. Descarga dependencias, compila backend, instala frontend y valida tamanos minimos.
5. Detecta puertos libres, configura PostgreSQL local, aplica Flyway y seed.
6. Inicia backend, espera /actuator/health=UP, inicia frontend y verifica HTTP 200.
7. Ejecuta mvn test y npx vitest run.
8. Mantiene ambos procesos corriendo, muestra URLs, PIDs y logs.
9. El usuario final navega a /login, se autentica y accede al modulo de seguridad segun su rol.
10. Si falla cualquier prerequisito, dependencia, health check o test, el script corta con mensaje claro y codigo de salida no cero.

Pantallas / superficies: Rutas React: /login, /app/seguridad, /app/usuarios/consulta, /swagger-ui/index.html. Componentes: LoginPage, ProtectedRoute, AuthProvider. Endpoints Spring: POST /auth/login, POST /auth/refresh, POST /auth/logout, GET /actuator/health, GET /v3/api-docs, GET /swagger-ui/index.html.

Reglas de negocio:
- JWT es obligatorio para /api/v1/**.
- Login y refresh son publicos; el resto requiere autenticacion.
- Roles permitidos: ROLE_ADMIN y ROLE_OPERADOR.
- El token de acceso expira en 1 hora y debe poder refrescarse.
- El token nunca se almacena en localStorage ni en la URL.
- .env.example debe incluir variables de DB, JWT, CORS, puertos y SUDO_AUTH.
- Los scripts deben instalar dependencias faltantes o fallar claramente.
- Los puertos base son 8081 backend, 3001 frontend y 5433 db, pero deben moverse automaticamente si estan ocupados.
- No se permite uso de contenedores.
- Deben ejecutarse migraciones y seed antes de iniciar la app.
- El script debe dejar la aplicacion corriendo mostrando logs y PIDs.
- stop.sh/stop.ps1 debe detener procesos usando archivos .pids.
- README.md y DOCS.md son obligatorios.

Notas técnicas:
Aplicar AUTH MASTER, ENV VARS MASTER, DEPENDENCIES MASTER - BACKEND pom.xml, DEPENDENCIES MASTER - FRONTEND package.json, TEST STRATEGY MASTER y TECHNICAL QUALITY - DEFINITION OF DONE. Endpoint API login: POST /auth/login request { username:string(req), password:string(req) } response 200 { accessToken:string, refreshToken:string, tokenType:string, expiresIn:number, user:{ username:string, roles:string[] } }. Endpoint refresh: POST /auth/refresh request { refreshToken:string(req) } response 200 igual login. Endpoint logout: POST /auth/logout request opcional vacio response 200 { message:string }. Error body comun: { timestamp,status,code,message,details,path }. Tabla DB auth: t99aut01-refresh_tokens con columnas rtk_id uuid PK, rtk_usuario varchar(8) NOT NULL, rtk_token varchar(255) NOT NULL UNIQUE, rtk_expiracion timestamp NOT NULL, rtk_revocado boolean NOT NULL default false, rtk_creado_en timestamp NOT NULL default current_timestamp. Seed: V999__seed_datos_iniciales.sql con empresas, centros, perfiles y usuarios demo admin/operator. Auth/Authz: Spring Security stateless con JWT access token y refresh token; CSRF disabled para API; rate limiting basico con bucket4j o filtro propio si se incluye dependencia adicional. Estructura de paquetes sugerida: com.coboltest.authinfra.{domain,application,infrastructure,api}. Flyway reference: V8__create_t99aut01_refresh_tokens.sql, V999__seed_datos_iniciales.sql. Limites transaccionales: login/logout/refresh @Transactional; resto segun modulo. Estrategia de cache/estado: AuthContext en memoria + React Query para perfil actual; invalidar todas las queries protegidas al logout. Scripts obligatorios: run.sh, run.ps1, stop.sh, stop.ps1 funcionales con bloques de verificacion de prerequisitos, descarga de dependencias, find_free_port, arranque postgres, build, health checks, tests, resumen y tail -f. Archivos obligatorios: /backend/pom.xml completo, /frontend/package.json completo, /.env.example, /README.md, /DOCS.md, /.gitignore. DEPENDENCIAS MAVEN REQUERIDAS: org.springframework.boot:spring-boot-starter-parent:3.2.5, org.springframework.boot:spring-boot-starter-web:3.2.5, org.springframework.boot:spring-boot-starter-data-jpa:3.2.5, org.springframework.boot:spring-boot-starter-security:3.2.5, org.springframework.boot:spring-boot-starter-validation:3.2.5, org.springframework.boot:spring-boot-starter-actuator:3.2.5, org.postgresql:postgresql:42.7.3, org.flywaydb:flyway-core:9.22.3, org.flywaydb:flyway-database-postgresql:10.10.0, io.jsonwebtoken:jjwt-api:0.12.5, io.jsonwebtoken:jjwt-impl:0.12.5, io.jsonwebtoken:jjwt-jackson:0.12.5, org.springdoc:springdoc-openapi-starter-webmvc-ui:2.3.0, org.projectlombok:lombok:1.18.32, org.springframework.boot:spring-boot-devtools:3.2.5, org.springframework.boot:spring-boot-starter-test:3.2.5, org.springframework.security:spring-security-test:6.2.4, com.h2database:h2:2.2.224, com.fasterxml.jackson.core:jackson-databind:2.15.4. Build plugins: org.springframework.boot:spring-boot-maven-plugin:3.2.5, org.flywaydb:flyway-maven-plugin:9.22.3. DEPENDENCIAS NPM REQUERIDAS: react:18.2.0, react-dom:18.2.0, react-router-dom:^6.22.3, @tanstack/react-query:^5.24.8, axios:^1.7.2, zod:^3.22.4, react-hook-form:^7.50.1, @hookform/resolvers:^3.3.4, tailwindcss:^3.4.3, autoprefixer:^10.4.19, postcss:^8.4.38, sonner:^1.4.41, lucide-react:^0.344.0, clsx:^2.1.1, date-fns:^3.6.0, typescript:^5.4.5, vite:^5.2.10, @vitejs/plugin-react:^4.2.1, @types/react:^18.2.66, @types/react-dom:^18.2.22, eslint:^8.57.0, prettier:^3.2.5, eslint-config-prettier:^9.1.0, @testing-library/react:^14.2.2, @testing-library/jest-dom:^6.4.2, @testing-library/user-event:^14.5.2, vitest:^1.5.0, jsdom:^24.0.0, @vitest/coverage-v8:^1.5.0, playwright:^1.43.1. confianza: alta
Criterios:
  1. Dado que se ejecuta el script ./run.sh o .\run.ps1 en entorno local sin Docker: (1) se descargan e instalan automaticamente TODAS las dependencias, librerias y paquetes necesarios desde repositorios oficiales (mvn clean install, npm install, drivers DB, etc.), (2) se verifica que el JAR del backend pesa mas de 30MB y que node_modules contiene mas de 50 paquetes, (3) se detectan puertos 8081, 3001, 5433 y si estan en uso se asignan automaticamente puertos nuevos y consecutivos que NO tengan ningun proceso escuchando, (4) se aplica migracion y seed de DB nativa, (5) se inician backend y frontend vinculados estrictamente a estos puertos nuevos, (6) se espera health check de backend (GET /actuator/health = UP) y respuesta HTTP 200 del frontend, (7) se ejecutan pruebas de integracion y E2E apuntando a las URLs dinamicas generadas, (8) tras validacion exitosa, la aplicacion SE MANTIENE CORRIENDO en background sin cerrar la terminal, (9) se muestran PIDs, puertos asignados, estado de salud y URLs finales accesibles incluyendo Swagger UI.
  2. Dado que se ejecuta mvn dependency:tree en /backend, entonces se listan al menos spring-boot-starter-web, spring-boot-starter-data-jpa, spring-boot-starter-security, spring-boot-starter-validation, postgresql, flyway-core, jjwt-api, springdoc-openapi-starter-webmvc-ui, y el JAR empaquetado pesa minimo 40MB. Dado que se ejecuta ls node_modules en /frontend, entonces existen react, react-dom, react-router-dom, @tanstack/react-query, axios, zod, vite, typescript, tailwindcss y al menos 15 dependencias directas mas.
  3. Dado un usuario demo admin con credenciales validas, cuando el frontend llama al endpoint POST /auth/login, entonces la peticion valida devuelve HTTP 200 y el cuerpo JSON de respuesta contiene exactamente los campos accessToken, refreshToken, tokenType, expiresIn y user con tipos string, number y objeto, y en caso de error de validacion devuelve HTTP 400 con body {timestamp,status,code,message,details,path}.
  4. Dado un access token expirado y un refresh token vigente, cuando el frontend llama POST /auth/refresh, entonces recibe HTTP 200 con un nuevo accessToken y mantiene la sesion sin recarga completa de la aplicacion.
  5. Dado un usuario sin autenticacion, cuando intenta acceder a /app/usuarios/consulta, entonces ProtectedRoute lo redirige a /login y no renderiza contenido protegido.
  6. Dado que se ejecutan las migraciones Flyway, cuando se verifica la tabla t99aut01-refresh_tokens, entonces existen las columnas rtk_id, rtk_usuario, rtk_token, rtk_expiracion, rtk_revocado y rtk_creado_en con tipos PostgreSQL, constraint de primary key en rtk_id, y unique en rtk_token segun DDL en V8__create_t99aut01_refresh_tokens.sql.
  7. Dado que se reenvia la misma peticion POST /auth/logout con el mismo refresh token revocado, cuando el backend la recibe por segunda vez, entonces no genera duplicados y devuelve el mismo estado HTTP 200 con datos coherentes.
  8. Dado que existe README.md y DOCS.md generados, cuando un desarrollador nuevo sigue los pasos documentados desde una maquina limpia, entonces puede ejecutar la aplicacion completa con un solo comando, entender la arquitectura hexagonal, las migraciones, JWT, testing y troubleshooting.
