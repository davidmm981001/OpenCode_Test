create table if not exists auth_users (
  id uuid primary key,
  username varchar(40) not null unique,
  password_hash varchar(100) not null,
  roles_csv varchar(120) not null,
  terminal varchar(10) not null
);
