create table if not exists companies (
  id uuid primary key,
  code varchar(4) not null unique,
  name varchar(40) not null
);

create table if not exists centers (
  id uuid primary key,
  company_code varchar(4) not null,
  center_code varchar(4) not null,
  name varchar(40) not null,
  constraint uk_centers_company_center unique (company_code, center_code),
  constraint fk_centers_company foreign key (company_code) references companies(code)
);

create table if not exists parameters (
  id uuid primary key,
  group_code varchar(12) not null,
  parameter_code varchar(8) not null,
  description varchar(100) not null,
  constraint uk_parameters_group_code unique (group_code, parameter_code)
);

create table if not exists resources (
  id uuid primary key,
  group_code varchar(8) not null,
  resource_code varchar(12) not null,
  access_level integer not null,
  updated_at timestamp not null,
  constraint uk_resources_group_code unique (group_code, resource_code)
);
