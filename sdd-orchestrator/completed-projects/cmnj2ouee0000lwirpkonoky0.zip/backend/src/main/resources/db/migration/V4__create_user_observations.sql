create table if not exists user_observations (
  id uuid primary key,
  user_code varchar(8) not null unique,
  modification_user varchar(8) not null,
  last_change timestamp not null,
  comment varchar(100) not null,
  constraint fk_user_observations_user foreign key (user_code) references security_users(code)
);
