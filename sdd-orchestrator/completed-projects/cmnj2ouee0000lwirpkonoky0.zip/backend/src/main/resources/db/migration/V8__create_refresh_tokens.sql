create table if not exists refresh_tokens (
  id uuid primary key,
  username varchar(40) not null,
  token varchar(255) not null unique,
  expiration timestamp not null,
  revoked boolean not null default false,
  created_at timestamp not null default current_timestamp
);
