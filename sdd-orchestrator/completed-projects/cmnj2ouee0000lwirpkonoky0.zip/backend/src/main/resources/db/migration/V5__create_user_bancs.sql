create table if not exists user_bancs (
  id uuid primary key,
  user_code varchar(8) not null unique,
  external_user varchar(8) not null unique,
  name varchar(60) not null,
  branch_no varchar(4) not null,
  terminal_no integer not null,
  company_code varchar(4) not null,
  status varchar(2) not null,
  observation varchar(80) not null,
  last_change timestamp not null,
  updated_by varchar(8) not null,
  constraint fk_user_bancs_user foreign key (user_code) references security_users(code)
);
