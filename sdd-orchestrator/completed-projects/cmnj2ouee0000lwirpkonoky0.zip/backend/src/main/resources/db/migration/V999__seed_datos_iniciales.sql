insert into companies (id, code, name) values
  (random_uuid(), '1001', 'EMPRESA UNO'),
  (random_uuid(), '1002', 'EMPRESA DOS');

insert into centers (id, company_code, center_code, name) values
  (random_uuid(), '1001', '0001', 'CENTRO UNO'),
  (random_uuid(), '1001', '0002', 'CENTRO DOS'),
  (random_uuid(), '1002', '0001', 'CENTRO TRES');

insert into parameters (id, group_code, parameter_code, description) values
  (random_uuid(), 'GR', 'PERF0001', 'Perfil Operador'),
  (random_uuid(), 'GR', 'PERF0002', 'Perfil Administrador');

insert into resources (id, group_code, resource_code, access_level, updated_at) values
  (random_uuid(), 'GR', 'PERF0001', 1, current_timestamp),
  (random_uuid(), 'GR', 'PERF0002', 1, current_timestamp);

insert into menu_options (id, code, title, route, enabled) values
  (random_uuid(), 1, 'Consulta de Usuarios', '/app/usuarios/consulta', true),
  (random_uuid(), 2, 'Nuevo Usuario', '/app/usuarios/nuevo', true),
  (random_uuid(), 3, 'Detalle de Usuario', '/app/usuarios/USR00001', true),
  (random_uuid(), 4, 'Auditoría de Usuario', '/app/usuarios/USR00001/auditoria', true),
  (random_uuid(), 5, 'Datos BANCS', '/app/usuarios/USR00001/bancs', true),
  (random_uuid(), 6, 'Catálogos', '/app/catalogos', true),
  (random_uuid(), 7, 'Menú Seguridad', '/app/seguridad', true),
  (random_uuid(), 8, 'Recargar Sesión', '/app/seguridad', true),
  (random_uuid(), 9, 'Salir', '/login', true);

insert into security_users (id, code, name, status, cid, offset_bancs, cargo, company_code, center_code, profile_code, domain_code, node_code, autoriza, updated_date, updated_time, updated_user, updated_terminal, logon_date, logon_time, logon_ip, office_swift, created_at, version) values
  (random_uuid(), 'USR00001', 'ANA PEREZ', 'A', '1234567890', '', 'ANALISTA', '1001', '0001', 'PERF0001', 'D001', 'N001', 1, '20260403', '120000', 'USR00001', 'TERM1', '20260403', '120000', '127.0.0.1', 'MSQUTODO', current_timestamp, 0),
  (random_uuid(), 'USR00002', 'JUAN MARTINEZ', 'A', '9876543210', '', 'OPERADOR', '1001', '0002', 'PERF0001', 'D001', 'N002', 0, '20260403', '120000', 'USR00001', 'TERM1', '20260403', '120000', '127.0.0.1', null, current_timestamp, 0),
  (random_uuid(), 'USR10001', 'ANA PEREZ', 'A', '1234567890', '', 'ANALISTA', '1001', '0001', 'PERF0001', 'D001', 'N001', 1, '20260403', '120000', 'USR00001', 'TERM1', '20260403', '120000', '127.0.0.1', 'MSQUTODO', current_timestamp, 0);

insert into user_observations (id, user_code, modification_user, last_change, comment) values
  (random_uuid(), 'USR00001', 'USR00001', current_timestamp, 'Observación inicial'),
  (random_uuid(), 'USR10001', 'USR00001', current_timestamp, 'Alta inicial aprobada');

insert into user_bancs (id, user_code, external_user, name, branch_no, terminal_no, company_code, status, observation, last_change, updated_by) values
  (random_uuid(), 'USR10001', '12345678', 'BANCS ANA', '1001', 1234, '1001', 'TC', 'Observación BANCS', current_timestamp, 'USR00001');

insert into user_audits (id, transaction_code, operation, user_code, name, current_profile, current_center, current_autoriza, previous_profile, previous_center, previous_autoriza, observation, response, mensajeria, terminal, modified_by, created_at) values
  (random_uuid(), 'T95USU03', 'INGRESO', 'USR10001', 'ANA PEREZ', 'PERF0001', '0001', 1, null, null, null, 'Alta inicial aprobada', 'Usuario creado', 'USR10001;ANA PEREZ;PERF0001;0001;1;*;*;*;Alta inicial aprobada;Usuario creado', 'TERM1', 'USR00001', current_timestamp);

insert into auth_users (id, username, password_hash, roles_csv, terminal) values
  (random_uuid(), 'admin', '{noop}Admin123!', 'ROLE_ADMIN', 'TERM1'),
  (random_uuid(), 'operador', '{noop}Operador123!', 'ROLE_OPERADOR', 'TERM1');
