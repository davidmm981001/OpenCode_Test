create table if not exists menu_options (
  id uuid primary key,
  code integer not null unique,
  title varchar(120) not null,
  route varchar(160) not null,
  enabled boolean not null
);
