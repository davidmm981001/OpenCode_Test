package com.coboltest.persistence.repo;

import com.coboltest.persistence.entity.ParameterEntity;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParameterRepository extends JpaRepository<ParameterEntity, UUID> {
  Optional<ParameterEntity> findByGroupCodeAndParameterCode(String groupCode, String parameterCode);
}
