package com.coboltest.usuariosconsulta.api.dto;

import java.util.List;

public record UserSearchResponse(
    List<UserSummaryResponse> content,
    long totalElements,
    int totalPages,
    int size,
    int number,
    boolean first,
    boolean last,
    String message) {}
