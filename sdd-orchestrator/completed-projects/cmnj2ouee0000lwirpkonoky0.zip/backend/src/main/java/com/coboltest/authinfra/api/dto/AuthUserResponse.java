package com.coboltest.authinfra.api.dto;

import java.util.List;

public record AuthUserResponse(String username, List<String> roles) {}
