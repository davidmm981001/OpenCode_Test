package com.coboltest.persistence.repo;

import com.coboltest.persistence.entity.MenuOptionEntity;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MenuOptionRepository extends JpaRepository<MenuOptionEntity, UUID> {
  List<MenuOptionEntity> findAllByEnabledTrueOrderByCodeAsc();
}
