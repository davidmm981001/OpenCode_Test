package com.coboltest.usuariosadministracion.api.dto;

public record UserDeleteResponse(String usrSiglo21, boolean deleted, boolean alreadyDeleted, String bancsEstadoProceso, String message) {}
