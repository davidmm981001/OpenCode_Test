package com.coboltest.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.util.UUID;

@Entity
@Table(name = "companies")
public class CompanyEntity {
  @Id
  public UUID id;

  @Column(nullable = false, unique = true, length = 4)
  public String code;

  @Column(nullable = false, length = 40)
  public String name;

  protected CompanyEntity() {}
}
