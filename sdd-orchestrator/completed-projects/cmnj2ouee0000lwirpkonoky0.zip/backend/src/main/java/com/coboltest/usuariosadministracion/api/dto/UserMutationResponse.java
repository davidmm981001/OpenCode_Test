package com.coboltest.usuariosadministracion.api.dto;

public record UserMutationResponse(
    String usrSiglo21,
    String usrNombre,
    String usrEmpresa,
    String usrCentro,
    String usrPers,
    Integer usrAutoriza,
    String observacion,
    String usrBancs,
    Integer termBancs,
    String bancsEstadoProceso,
    String updFecha,
    String updHora,
    String updUsuario,
    String updTerminal,
    String message) {}
