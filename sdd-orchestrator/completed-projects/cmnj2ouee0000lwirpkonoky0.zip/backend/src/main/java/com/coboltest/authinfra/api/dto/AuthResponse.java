package com.coboltest.authinfra.api.dto;

public record AuthResponse(String accessToken, String refreshToken, String tokenType, long expiresIn, AuthUserResponse user) {}
