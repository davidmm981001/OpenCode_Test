package com.coboltest.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "refresh_tokens")
public class RefreshTokenEntity {
  @Id
  public UUID id;

  @Column(nullable = false, length = 40)
  public String username;

  @Column(nullable = false, unique = true, length = 255)
  public String token;

  @Column(nullable = false)
  public Instant expiration;

  @Column(nullable = false)
  public boolean revoked;

  @Column(nullable = false)
  public Instant createdAt;

  public RefreshTokenEntity() {}
}
