package com.coboltest.seguridadmenu.api.dto;

public record MenuOptionResponse(Integer codigo, String titulo, String ruta, boolean habilitada) {}
