package com.coboltest.usuariosadministracion.service;

import com.coboltest.catalogosvalidacion.api.dto.ObservationLookupResponse;
import com.coboltest.common.api.ApiPageResponse;
import com.coboltest.common.exception.ConflictException;
import com.coboltest.common.exception.ResourceNotFoundException;
import com.coboltest.common.exception.ValidationException;
import com.coboltest.common.security.CurrentUserService;
import com.coboltest.persistence.entity.AuditEntity;
import com.coboltest.persistence.entity.BancsEntity;
import com.coboltest.persistence.entity.SecurityUserEntity;
import com.coboltest.persistence.entity.UserObservationEntity;
import com.coboltest.persistence.repo.AuditRepository;
import com.coboltest.persistence.repo.BancsRepository;
import com.coboltest.persistence.repo.CenterRepository;
import com.coboltest.persistence.repo.CompanyRepository;
import com.coboltest.persistence.repo.ParameterRepository;
import com.coboltest.persistence.repo.ResourceRepository;
import com.coboltest.persistence.repo.SecurityUserRepository;
import com.coboltest.persistence.repo.UserObservationRepository;
import com.coboltest.usuariosadministracion.api.dto.BancsDetailResponse;
import com.coboltest.usuariosadministracion.api.dto.BancsStateResponse;
import com.coboltest.usuariosadministracion.api.dto.UserCreateResponse;
import com.coboltest.usuariosadministracion.api.dto.UserDeleteResponse;
import com.coboltest.usuariosadministracion.api.dto.UserDetailResponse;
import com.coboltest.usuariosadministracion.api.dto.UserMutationResponse;
import com.coboltest.usuariosconsulta.api.dto.UserSummaryResponse;
import com.coboltest.usuariosadministracion.api.dto.UserUpsertRequest;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserAdministrationService {
  private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyyMMdd");
  private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HHmmss");
  private static final Map<String, Object> IDEMPOTENCY_CACHE = new ConcurrentHashMap<>();

  private final SecurityUserRepository userRepository;
  private final UserObservationRepository observationRepository;
  private final BancsRepository bancsRepository;
  private final AuditRepository auditRepository;
  private final CompanyRepository companyRepository;
  private final CenterRepository centerRepository;
  private final ParameterRepository parameterRepository;
  private final ResourceRepository resourceRepository;
  private final CurrentUserService currentUserService;

  public UserAdministrationService(
      SecurityUserRepository userRepository,
      UserObservationRepository observationRepository,
      BancsRepository bancsRepository,
      AuditRepository auditRepository,
      CompanyRepository companyRepository,
      CenterRepository centerRepository,
      ParameterRepository parameterRepository,
      ResourceRepository resourceRepository,
      CurrentUserService currentUserService) {
    this.userRepository = userRepository;
    this.observationRepository = observationRepository;
    this.bancsRepository = bancsRepository;
    this.auditRepository = auditRepository;
    this.companyRepository = companyRepository;
    this.centerRepository = centerRepository;
    this.parameterRepository = parameterRepository;
    this.resourceRepository = resourceRepository;
    this.currentUserService = currentUserService;
  }

  @Transactional(readOnly = true)
  public ApiPageResponse<UserSummaryResponse> search(String empresa, String centro, String usuario, String perfil, String nombre, int page, int size) {
    if (size > 14 || size < 1 || page < 0) {
      throw new ValidationException("INVALID_PAGINATION", "Paginación inválida", List.of("size máximo 14", "page no negativo"));
    }
    List<SecurityUserEntity> all = userRepository.findAll();
    List<SecurityUserEntity> filtered;
    String message;
    if (notBlank(empresa)) {
      filtered = all.stream().filter(user -> user.companyCode.equalsIgnoreCase(empresa)).toList();
    } else if (notBlank(centro)) {
      filtered = all.stream().filter(user -> user.centerCode.equalsIgnoreCase(centro)).toList();
    } else if (notBlank(usuario)) {
      filtered = all.stream().filter(user -> user.code.toUpperCase(Locale.ROOT).startsWith(usuario.toUpperCase(Locale.ROOT))).toList();
    } else if (notBlank(perfil)) {
      filtered = all.stream().filter(user -> user.profileCode.toUpperCase(Locale.ROOT).startsWith(perfil.toUpperCase(Locale.ROOT))).toList();
    } else if (notBlank(nombre)) {
      filtered = all.stream().filter(user -> user.name.toUpperCase(Locale.ROOT).contains(nombre.toUpperCase(Locale.ROOT))).toList();
    } else {
      throw new ValidationException("QUERY_CRITERIA_REQUIRED", "Ingrese Criterio Consulta", List.of("Debe informar empresa, centro, usuario, perfil o nombre"));
    }
    filtered = filtered.stream().sorted(Comparator.comparing(user -> user.code)).toList();
    int totalElements = filtered.size();
    int totalPages = totalElements == 0 ? 0 : (int) Math.ceil(totalElements / (double) size);
    int from = Math.min(page * size, totalElements);
    int to = Math.min(from + size, totalElements);
    if (page > 0 && from >= totalElements) {
      from = 0;
      to = Math.min(size, totalElements);
      page = 0;
      message = "Inicio de los datos";
    } else if (to < totalElements) {
      message = "Existen mas Datos";
    } else {
      message = "No existen mas Datos";
    }
    List<UserSummaryResponse> content = filtered.subList(from, to).stream().map(this::toSummary).toList();
    return new ApiPageResponse<>(content, totalElements, totalPages, size, page, page == 0, to >= totalElements, message);
  }

  @Transactional(readOnly = true)
  public UserDetailResponse detail(String userCode) {
    if (!notBlank(userCode)) {
      throw new ValidationException("INVALID_USER_CODE", "Código de usuario inválido", List.of("El código es obligatorio"));
    }
    SecurityUserEntity user = userRepository.findByCode(userCode).orElseThrow(() -> new ResourceNotFoundException("USER_NOT_FOUND", "Usuario no encontrado"));
    return buildDetail(user);
  }

  @Transactional(readOnly = true)
  public ObservationLookupResponse observation(String userCode) {
    return new ObservationLookupResponse(userCode, observationRepository.findByUserCode(userCode).map(o -> o.comment).orElse(null));
  }

  @Transactional
  public UserCreateResponse create(UserUpsertRequest request, String idempotencyKey) {
    if (idempotencyKey != null && IDEMPOTENCY_CACHE.containsKey("POST:/api/v1/usuarios:" + idempotencyKey)) {
      return (UserCreateResponse) IDEMPOTENCY_CACHE.get("POST:/api/v1/usuarios:" + idempotencyKey);
    }
    validateUpsert(request, true);
    if (userRepository.findByCode(request.usrSiglo21()).isPresent()) {
      if (idempotencyKey != null) {
        return createExistingResponse(request.usrSiglo21());
      }
      throw new ConflictException("USER_ALREADY_EXISTS", "El usuario ya existe");
    }
    SecurityUserEntity entity = mapEntity(request);
    entity.id = UUID.randomUUID();
    entity.status = "A";
    entity.createdAt = Instant.now();
    entity.version = 0L;
    populateUpdateMetadata(entity, true);
    try {
      userRepository.save(entity);
      saveObservation(entity.code, request.observacion());
      saveBancsIfPresent(entity, request, true);
      audit(entity.code, request.usrNombre(), request.usrPers(), request.usrCentro(), request.usrAutoriza(), null, null, null, "INGRESO", request.observacion(), "Usuario creado");
      UserCreateResponse response = new UserCreateResponse(entity.id, entity.code, entity.name, entity.companyCode, entity.centerCode, entity.profileCode, entity.autoriza, request.observacion(), request.usrBancs(), request.termBancs(), entity.updatedDate, entity.updatedTime, entity.updatedUser, entity.updatedTerminal, "Usuario creado correctamente");
      if (idempotencyKey != null) {
        IDEMPOTENCY_CACHE.put("POST:/api/v1/usuarios:" + idempotencyKey, response);
      }
      return response;
    } catch (DataIntegrityViolationException ex) {
      throw new ConflictException("USER_CREATE_ERROR", "No fue posible crear el usuario");
    }
  }

  @Transactional
  public UserMutationResponse update(String userCode, UserUpsertRequest request, String idempotencyKey) {
    String cacheKey = "PUT:/api/v1/usuarios/" + userCode + ":" + idempotencyKey;
    if (idempotencyKey != null && IDEMPOTENCY_CACHE.containsKey(cacheKey)) {
      return (UserMutationResponse) IDEMPOTENCY_CACHE.get(cacheKey);
    }
    validateUpsert(request, false);
    SecurityUserEntity entity = userRepository.findByCode(userCode).orElseThrow(() -> new ResourceNotFoundException("USER_NOT_FOUND", "Usuario no encontrado"));
    if (request.version() != null && !Objects.equals(request.version(), entity.version)) {
      throw new ConflictException("CONCURRENT_MODIFICATION", "La versión del registro no coincide");
    }
    SecurityUserEntity previous = copy(entity);
    if (request.usrBancs() != null && !request.usrBancs().isBlank()) {
      bancsRepository.findByExternalUser(request.usrBancs()).ifPresent(existing -> {
        if (!existing.userCode.equals(entity.code)) {
          throw new ConflictException("BANCS_USER_DUPLICATE", "Usuario BANCS duplicado");
        }
      });
    }
    entity.name = request.usrNombre();
    entity.cid = defaultString(request.usrCid());
    entity.companyCode = request.usrEmpresa();
    entity.centerCode = request.usrCentro();
    entity.cargo = defaultString(request.usrCargo());
    entity.profileCode = request.usrPers();
    entity.domainCode = defaultString(request.usrDominio());
    entity.nodeCode = defaultString(request.usrNodo());
    entity.autoriza = request.usrAutoriza();
    entity.officeSwift = defaultString(request.usrOficinaSwift());
    populateUpdateMetadata(entity, false);
    entity.version = entity.version + 1;
    try {
      userRepository.save(entity);
      upsertObservation(entity.code, request.observacion());
      BancsEntity bancs = saveBancsIfPresent(entity, request, false);
      audit(entity.code, entity.name, entity.profileCode, entity.centerCode, entity.autoriza, previous.profileCode, previous.centerCode, previous.autoriza, "MODIFICACION", request.observacion(), "Usuario modificado");
      UserMutationResponse response = new UserMutationResponse(entity.code, entity.name, entity.companyCode, entity.centerCode, entity.profileCode, entity.autoriza, request.observacion(), bancs == null ? null : bancs.externalUser, bancs == null ? null : bancs.terminalNo, bancs == null ? null : bancs.status, entity.updatedDate, entity.updatedTime, entity.updatedUser, entity.updatedTerminal, "Usuario modificado correctamente");
      if (idempotencyKey != null) {
        IDEMPOTENCY_CACHE.put(cacheKey, response);
      }
      return response;
    } catch (DataIntegrityViolationException ex) {
      throw new ConflictException("BANCS_USER_DUPLICATE", "No fue posible modificar el usuario");
    }
  }

  @Transactional
  public UserDeleteResponse delete(String userCode, String observation, String idempotencyKey) {
    String cacheKey = "DELETE:/api/v1/usuarios/" + userCode + ":" + idempotencyKey;
    if (idempotencyKey != null && IDEMPOTENCY_CACHE.containsKey(cacheKey)) {
      return (UserDeleteResponse) IDEMPOTENCY_CACHE.get(cacheKey);
    }
    if (!notBlank(observation)) {
      throw new ValidationException("OBSERVATION_REQUIRED", "Observación obligatoria", List.of("Debe informar observación"));
    }
    SecurityUserEntity entity = userRepository.findByCode(userCode).orElseThrow(() -> new ResourceNotFoundException("USER_NOT_FOUND", "Usuario no encontrado"));
    BancsEntity bancs = bancsRepository.findByUserCode(userCode).orElse(null);
    if (bancs != null) {
      bancs.status = "TE";
      bancs.observation = observation;
      bancs.updatedBy = currentUserService.usernameOrDefault();
      bancs.lastChange = Instant.now();
      bancsRepository.save(bancs);
    }
    observationRepository.findByUserCode(userCode).ifPresent(obs -> observationRepository.delete(obs));
    userRepository.delete(entity);
    audit(entity.code, entity.name, entity.profileCode, entity.centerCode, entity.autoriza, null, null, null, "ELIMINACION", observation, "Usuario eliminado");
    UserDeleteResponse response = new UserDeleteResponse(userCode, true, false, bancs == null ? null : bancs.status, "Usuario eliminado");
    if (idempotencyKey != null) {
      IDEMPOTENCY_CACHE.put(cacheKey, response);
    }
    return response;
  }

  @Transactional(readOnly = true)
  public BancsDetailResponse bancs(String userCode) {
    SecurityUserEntity user = userRepository.findByCode(userCode).orElseThrow(() -> new ResourceNotFoundException("USER_NOT_FOUND", "Usuario no encontrado"));
    BancsEntity bancs = bancsRepository.findByUserCode(userCode).orElseThrow(() -> new ResourceNotFoundException("BANCS_RECORD_NOT_FOUND", "No existe información BANCS"));
    return new BancsDetailResponse(user.code, bancs.externalUser, user.name, bancs.branchNo, bancs.terminalNo, bancs.companyCode, bancs.status, bancs.observation, bancs.lastChange.toString(), bancs.updatedBy);
  }

  @Transactional
  public BancsStateResponse updateBancsState(String userCode, String estado, String observation) {
    BancsEntity bancs = bancsRepository.findByUserCode(userCode).orElseThrow(() -> new ResourceNotFoundException("BANCS_RECORD_NOT_FOUND", "No existe información BANCS"));
    bancs.status = estado;
    bancs.observation = observation;
    bancs.lastChange = Instant.now();
    bancs.updatedBy = currentUserService.usernameOrDefault();
    bancsRepository.save(bancs);
    return new BancsStateResponse(userCode, estado, observation, true);
  }

  @Transactional(readOnly = true)
  public ApiPageResponse<com.coboltest.auditoriaoperacion.api.dto.AuditEntryResponse> audit(String userCode, int page, int size) {
    var pageable = PageRequest.of(page, size);
    var pageData = auditRepository.findByUserCodeOrderByCreatedAtDesc(userCode, pageable);
    var content = pageData.getContent().stream().map(a -> new com.coboltest.auditoriaoperacion.api.dto.AuditEntryResponse(a.id, a.transactionCode, a.operation, a.userCode, a.name, a.currentProfile, a.currentCenter, a.currentAutoriza, a.previousProfile, a.previousCenter, a.previousAutoriza, a.observation, a.response, a.mensajeria, a.modifiedBy, a.terminal, a.createdAt.toString())).toList();
    return new ApiPageResponse<>(content, pageData.getTotalElements(), pageData.getTotalPages(), size, page, page == 0, pageData.isLast(), pageData.getTotalElements() == 0 ? "" : "");
  }

  private void validateUpsert(UserUpsertRequest request, boolean creating) {
    List<String> details = new ArrayList<>();
    if (!notBlank(request.usrSiglo21()) || request.usrSiglo21().length() > 8) details.add("usrSiglo21");
    if (!notBlank(request.usrNombre())) details.add("usrNombre");
    if (!notBlank(request.usrEmpresa())) details.add("usrEmpresa");
    if (!notBlank(request.usrCentro())) details.add("usrCentro");
    if (!notBlank(request.usrPers())) details.add("usrPers");
    if (request.usrAutoriza() == null || (request.usrAutoriza() != 0 && request.usrAutoriza() != 1)) details.add("usrAutoriza");
    if (!notBlank(request.observacion())) details.add("observacion");
    if (!details.isEmpty()) throw new ValidationException("VALIDATION_ERROR", "Validación fallida", details);
    if (notBlank(request.usrOficinaSwift()) && !"MSQUTODO".equalsIgnoreCase(request.usrOficinaSwift())) {
      throw new ValidationException("INVALID_OFFICE_SWIFT", "Of.Swift: MSQUTODO", List.of("usrOficinaSwift"));
    }
    if ((notBlank(request.usrBancs()) && request.termBancs() == null) || (!notBlank(request.usrBancs()) && request.termBancs() != null)) {
      throw new ValidationException("BANCS_DATA_INCOMPLETE", notBlank(request.usrBancs()) ? "Ingrese Terminal BANCS." : "Ingrese Usuario BANCS.", List.of("usrBancs", "termBancs"));
    }
    if (companyRepository.findByCode(request.usrEmpresa()).isEmpty()) {
      throw new ValidationException("COMPANY_NOT_FOUND", "Empresa no definida T06TC005", List.of("usrEmpresa"));
    }
    if (centerRepository.findByCompanyCodeAndCenterCode(request.usrEmpresa(), request.usrCentro()).isEmpty()) {
      throw new ValidationException("CENTER_NOT_FOUND", "Centro no definido T06TC007", List.of("usrCentro"));
    }
    var profile = parameterRepository.findByGroupCodeAndParameterCode("GR", request.usrPers());
    if (profile.isEmpty()) {
      throw new ValidationException("PROFILE_NOT_FOUND", "Perfil NO definido en T95PAR02", List.of("usrPers"));
    }
    if (resourceRepository.findByGroupCodeAndResourceCode("GR", request.usrPers()).isEmpty()) {
      throw new ValidationException("PROFILE_RESOURCE_NOT_FOUND", "Perfil RE no definido en T01GRE20", List.of("usrPers"));
    }
  }

  private SecurityUserEntity mapEntity(UserUpsertRequest request) {
    SecurityUserEntity entity = new SecurityUserEntity();
    entity.code = request.usrSiglo21();
    entity.name = request.usrNombre();
    entity.cid = defaultString(request.usrCid());
    entity.companyCode = request.usrEmpresa();
    entity.centerCode = request.usrCentro();
    entity.cargo = defaultString(request.usrCargo());
    entity.profileCode = request.usrPers();
    entity.domainCode = defaultString(request.usrDominio());
    entity.nodeCode = defaultString(request.usrNodo());
    entity.autoriza = request.usrAutoriza();
    entity.officeSwift = defaultString(request.usrOficinaSwift());
    return entity;
  }

  private void populateUpdateMetadata(SecurityUserEntity entity, boolean creating) {
    var current = currentUserService.currentUser().orElseThrow(() -> new ValidationException("UNAUTHORIZED", "Usuario no autenticado", List.of("Debe iniciar sesión")));
    LocalDateTime now = LocalDateTime.now();
    entity.updatedDate = now.format(DATE);
    entity.updatedTime = now.format(TIME);
    entity.updatedUser = current.username();
    entity.updatedTerminal = current.terminal();
    if (creating) {
      entity.logonDate = "00000000";
      entity.logonTime = "000000";
      entity.logonIp = null;
    }
  }

  private void saveObservation(String userCode, String observation) {
    UserObservationEntity entity = new UserObservationEntity();
    entity.id = UUID.randomUUID();
    entity.userCode = userCode;
    entity.modificationUser = currentUserService.usernameOrDefault();
    entity.lastChange = Instant.now();
    entity.comment = observation;
    observationRepository.save(entity);
  }

  private void upsertObservation(String userCode, String observation) {
    UserObservationEntity entity = observationRepository.findByUserCode(userCode).orElseGet(UserObservationEntity::new);
    if (entity.id == null) entity.id = UUID.randomUUID();
    entity.userCode = userCode;
    entity.modificationUser = currentUserService.usernameOrDefault();
    entity.lastChange = Instant.now();
    entity.comment = observation;
    observationRepository.save(entity);
  }

  private BancsEntity saveBancsIfPresent(SecurityUserEntity entity, UserUpsertRequest request, boolean creating) {
    if (!notBlank(request.usrBancs())) {
      return null;
    }
    BancsEntity bancs = bancsRepository.findByUserCode(entity.code).orElseGet(BancsEntity::new);
    if (bancs.id == null) bancs.id = UUID.randomUUID();
    bancs.userCode = entity.code;
    bancs.externalUser = request.usrBancs();
    bancs.name = entity.name;
    bancs.branchNo = request.usrEmpresa();
    bancs.terminalNo = request.termBancs();
    bancs.companyCode = entity.companyCode;
    bancs.status = creating ? "TC" : "TC";
    bancs.observation = request.observacion();
    bancs.lastChange = Instant.now();
    bancs.updatedBy = currentUserService.usernameOrDefault();
    return bancsRepository.save(bancs);
  }

  private void audit(String userCode, String name, String profile, String center, Integer autoriza, String prevProfile, String prevCenter, Integer prevAutoriza, String operation, String observation, String response) {
    AuditEntity audit = new AuditEntity();
    audit.id = UUID.randomUUID();
    audit.transactionCode = "T95USU03";
    audit.operation = operation;
    audit.userCode = userCode;
    audit.name = name;
    audit.currentProfile = profile;
    audit.currentCenter = center;
    audit.currentAutoriza = autoriza;
    audit.previousProfile = prevProfile;
    audit.previousCenter = prevCenter;
    audit.previousAutoriza = prevAutoriza;
    audit.observation = observation;
    audit.response = response;
    audit.mensajeria = String.join(";", userCode, name, profile, center, String.valueOf(autoriza), String.valueOf(prevProfile), String.valueOf(prevCenter), String.valueOf(prevAutoriza), observation, response);
    audit.terminal = currentUserService.currentUser().map(u -> u.terminal()).orElse("WEB");
    audit.modifiedBy = currentUserService.usernameOrDefault();
    audit.createdAt = Instant.now();
    auditRepository.save(audit);
  }

  private UserCreateResponse createExistingResponse(String userCode) {
    SecurityUserEntity user = userRepository.findByCode(userCode).orElseThrow(() -> new ResourceNotFoundException("USER_NOT_FOUND", "Usuario no encontrado"));
    UserObservationEntity observation = observationRepository.findByUserCode(userCode).orElse(null);
    return new UserCreateResponse(user.id, user.code, user.name, user.companyCode, user.centerCode, user.profileCode, user.autoriza, observation == null ? null : observation.comment, null, null, user.updatedDate, user.updatedTime, user.updatedUser, user.updatedTerminal, "Usuario existente");
  }

  private UserSummaryResponse toSummary(SecurityUserEntity user) {
    return new UserSummaryResponse(user.code, trim30(user.name), user.profileCode, user.companyCode, user.centerCode, user.domainCode, user.nodeCode, String.valueOf(user.autoriza));
  }

  private UserDetailResponse buildDetail(SecurityUserEntity user) {
    var company = companyRepository.findByCode(user.companyCode).map(c -> c.name).orElse("Empresa no definida T06TC005");
    var center = centerRepository.findByCompanyCodeAndCenterCode(user.companyCode, user.centerCode).map(c -> c.name).orElse("Centro no definido T06TC007");
    var profile = parameterRepository.findByGroupCodeAndParameterCode("GR", user.profileCode).map(p -> p.description).orElse("Perfil NO definido en T95PAR02");
    var observation = observationRepository.findByUserCode(user.code).map(o -> o.comment).orElse(null);
    var bancs = bancsRepository.findByUserCode(user.code).orElse(null);
    return new UserDetailResponse(user.code, bancs == null ? null : bancs.externalUser, bancs == null ? null : bancs.terminalNo, user.name, user.cid, user.companyCode, company, user.centerCode, center, user.cargo, user.profileCode, profile, user.domainCode, user.nodeCode, user.autoriza, user.officeSwift, observation, user.updatedDate, user.updatedTime, user.updatedUser, user.updatedTerminal, user.logonDate, user.logonTime, user.logonIp, user.status);
  }

  private SecurityUserEntity copy(SecurityUserEntity user) {
    SecurityUserEntity copy = new SecurityUserEntity();
    copy.id = user.id;
    copy.code = user.code;
    copy.name = user.name;
    copy.status = user.status;
    copy.cid = user.cid;
    copy.offsetBancs = user.offsetBancs;
    copy.cargo = user.cargo;
    copy.companyCode = user.companyCode;
    copy.centerCode = user.centerCode;
    copy.profileCode = user.profileCode;
    copy.domainCode = user.domainCode;
    copy.nodeCode = user.nodeCode;
    copy.autoriza = user.autoriza;
    copy.updatedDate = user.updatedDate;
    copy.updatedTime = user.updatedTime;
    copy.updatedUser = user.updatedUser;
    copy.updatedTerminal = user.updatedTerminal;
    copy.logonDate = user.logonDate;
    copy.logonTime = user.logonTime;
    copy.logonIp = user.logonIp;
    copy.officeSwift = user.officeSwift;
    copy.version = user.version;
    return copy;
  }

  private String defaultString(String value) {
    return value == null ? "" : value;
  }

  private boolean notBlank(String value) {
    return value != null && !value.isBlank();
  }

  private String trim30(String value) {
    if (value == null) return null;
    return value.length() <= 30 ? value : value.substring(0, 30);
  }
}
