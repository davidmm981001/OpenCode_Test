package com.coboltest.common.security;

import com.coboltest.common.api.ApiErrorResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.time.OffsetDateTime;
import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;

public class RestAccessDeniedHandler implements AccessDeniedHandler {
  private final ObjectMapper objectMapper = new ObjectMapper().findAndRegisterModules();

  @Override
  public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) {
    response.setStatus(403);
    response.setContentType(MediaType.APPLICATION_JSON_VALUE);
    try {
      objectMapper.writeValue(
          response.getOutputStream(),
          new ApiErrorResponse(OffsetDateTime.now(), 403, "FORBIDDEN", "Access denied", List.of(), request.getRequestURI()));
    } catch (Exception ignored) {
    }
  }
}
