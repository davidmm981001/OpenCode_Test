package com.coboltest.catalogosvalidacion.api;

import com.coboltest.catalogosvalidacion.api.dto.CenterLookupResponse;
import com.coboltest.catalogosvalidacion.api.dto.CompanyLookupResponse;
import com.coboltest.catalogosvalidacion.api.dto.ObservationLookupResponse;
import com.coboltest.catalogosvalidacion.api.dto.ProfileLookupResponse;
import com.coboltest.catalogosvalidacion.service.CatalogService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/catalogos")
public class CatalogController {
  private final CatalogService service;

  public CatalogController(CatalogService service) {
    this.service = service;
  }

  @Operation(summary = "Consulta de perfil")
  @GetMapping("/perfiles/{codigo}")
  public ProfileLookupResponse profile(@PathVariable String codigo) {
    return service.profile(codigo);
  }

  @Operation(summary = "Consulta de empresa")
  @GetMapping("/empresas/{codigo}")
  public CompanyLookupResponse company(@PathVariable String codigo) {
    return service.company(codigo);
  }

  @Operation(summary = "Consulta de centro")
  @GetMapping("/empresas/{empresa}/centros/{centro}")
  public CenterLookupResponse center(@PathVariable String empresa, @PathVariable String centro) {
    return service.center(empresa, centro);
  }
}
