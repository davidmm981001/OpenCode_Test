package com.coboltest.common.api;

import java.util.List;

public record ApiPageResponse<T>(
    List<T> content,
    long totalElements,
    int totalPages,
    int size,
    int number,
    boolean first,
    boolean last,
    String message) {}
