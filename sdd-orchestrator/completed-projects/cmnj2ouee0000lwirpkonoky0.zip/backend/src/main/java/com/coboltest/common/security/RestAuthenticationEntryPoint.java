package com.coboltest.common.security;

import com.coboltest.common.api.ApiErrorResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.time.OffsetDateTime;
import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;

public class RestAuthenticationEntryPoint implements AuthenticationEntryPoint {
  private final ObjectMapper objectMapper = new ObjectMapper().findAndRegisterModules();

  @Override
  public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) {
    response.setStatus(401);
    response.setContentType(MediaType.APPLICATION_JSON_VALUE);
    try {
      objectMapper.writeValue(
          response.getOutputStream(),
          new ApiErrorResponse(OffsetDateTime.now(), 401, "UNAUTHORIZED", "Authentication required", List.of(), request.getRequestURI()));
    } catch (Exception ignored) {
    }
  }
}
