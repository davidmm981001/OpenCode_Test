package com.coboltest.persistence.repo;

import com.coboltest.persistence.entity.UserObservationEntity;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserObservationRepository extends JpaRepository<UserObservationEntity, UUID> {
  Optional<UserObservationEntity> findByUserCode(String userCode);
}
