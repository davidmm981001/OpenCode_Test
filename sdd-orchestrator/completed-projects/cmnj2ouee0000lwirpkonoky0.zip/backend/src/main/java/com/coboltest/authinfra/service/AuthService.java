package com.coboltest.authinfra.service;

import com.coboltest.authinfra.api.dto.AuthResponse;
import com.coboltest.authinfra.api.dto.AuthUserResponse;
import com.coboltest.common.exception.ConflictException;
import com.coboltest.common.exception.ResourceNotFoundException;
import com.coboltest.common.exception.UnauthorizedException;
import com.coboltest.common.security.JwtService;
import com.coboltest.persistence.entity.RefreshTokenEntity;
import com.coboltest.persistence.repo.AuthUserRepository;
import com.coboltest.persistence.repo.RefreshTokenRepository;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {
  private final AuthUserRepository authUserRepository;
  private final RefreshTokenRepository refreshTokenRepository;
  private final PasswordEncoder passwordEncoder;
  private final JwtService jwtService;

  public AuthService(AuthUserRepository authUserRepository, RefreshTokenRepository refreshTokenRepository, PasswordEncoder passwordEncoder, JwtService jwtService) {
    this.authUserRepository = authUserRepository;
    this.refreshTokenRepository = refreshTokenRepository;
    this.passwordEncoder = passwordEncoder;
    this.jwtService = jwtService;
  }

  @Transactional
  public AuthResponse login(String username, String password) {
    var authUser = authUserRepository.findByUsername(username).orElseThrow(() -> new ResourceNotFoundException("USER_NOT_FOUND", "Usuario no encontrado"));
    if (!passwordEncoder.matches(password, authUser.passwordHash)) {
      throw new UnauthorizedException("INVALID_CREDENTIALS", "Credenciales invalidas");
    }
    return issueTokens(authUser.username, authUser.rolesCsv, authUser.terminal);
  }

  @Transactional
  public AuthResponse refresh(String refreshToken) {
    var token = refreshTokenRepository.findByToken(refreshToken).orElseThrow(() -> new ResourceNotFoundException("INVALID_REFRESH_TOKEN", "Refresh token invalido"));
    if (token.revoked || token.expiration.isBefore(Instant.now())) {
      throw new UnauthorizedException("INVALID_REFRESH_TOKEN", "Refresh token invalido");
    }
    token.revoked = true;
    refreshTokenRepository.save(token);
    var authUser = authUserRepository.findByUsername(token.username).orElseThrow(() -> new ResourceNotFoundException("USER_NOT_FOUND", "Usuario no encontrado"));
    return issueTokens(authUser.username, authUser.rolesCsv, authUser.terminal);
  }

  @Transactional
  public String logout(String refreshToken, String username) {
    if (refreshToken != null && !refreshToken.isBlank()) {
      refreshTokenRepository.findByToken(refreshToken).ifPresent(token -> {
        token.revoked = true;
        refreshTokenRepository.save(token);
      });
    } else {
      refreshTokenRepository.findByUsernameAndRevokedFalse(username).forEach(token -> {
        token.revoked = true;
        refreshTokenRepository.save(token);
      });
    }
    return "Sesión cerrada correctamente";
  }

  private AuthResponse issueTokens(String username, String rolesCsv, String terminal) {
    List<String> roles = List.of(rolesCsv.split(","));
    String accessToken = jwtService.createAccessToken(username, roles, terminal);
    String refreshToken = UUID.randomUUID() + "." + UUID.randomUUID();
    RefreshTokenEntity entity = new RefreshTokenEntity();
    entity.id = UUID.randomUUID();
    entity.username = username;
    entity.token = refreshToken;
    entity.expiration = Instant.now().plus(7, ChronoUnit.DAYS);
    entity.revoked = false;
    entity.createdAt = Instant.now();
    refreshTokenRepository.save(entity);
    return new AuthResponse(accessToken, refreshToken, "Bearer", 3600, new AuthUserResponse(username, roles));
  }
}
