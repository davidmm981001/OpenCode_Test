package com.coboltest.catalogosvalidacion.api.dto;

public record ObservationLookupResponse(String usrSiglo21, String observacion) {}
