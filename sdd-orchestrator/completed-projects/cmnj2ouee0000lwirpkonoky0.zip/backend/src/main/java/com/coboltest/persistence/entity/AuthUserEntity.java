package com.coboltest.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.util.UUID;

@Entity
@Table(name = "auth_users")
public class AuthUserEntity {
  @Id
  public UUID id;

  @Column(nullable = false, unique = true, length = 40)
  public String username;

  @Column(nullable = false, length = 100)
  public String passwordHash;

  @Column(nullable = false, length = 120)
  public String rolesCsv;

  @Column(nullable = false, length = 10)
  public String terminal;

  protected AuthUserEntity() {}
}
