package com.coboltest.auditoriaoperacion.api;

import com.coboltest.auditoriaoperacion.api.dto.AuditEntryResponse;
import com.coboltest.common.api.ApiPageResponse;
import com.coboltest.usuariosadministracion.service.UserAdministrationService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/auditoria")
public class AuditController {
  private final UserAdministrationService service;

  public AuditController(UserAdministrationService service) {
    this.service = service;
  }

  @Operation(summary = "Consulta auditoría por usuario")
  @GetMapping("/usuarios/{usrSiglo21}")
  public ApiPageResponse<AuditEntryResponse> audit(@PathVariable String usrSiglo21, @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "20") int size) {
    return service.audit(usrSiglo21, page, size);
  }
}
