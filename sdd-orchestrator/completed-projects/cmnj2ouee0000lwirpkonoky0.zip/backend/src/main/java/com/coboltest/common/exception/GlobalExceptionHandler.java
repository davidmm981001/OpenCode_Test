package com.coboltest.common.exception;

import com.coboltest.common.api.ApiErrorResponse;
import jakarta.servlet.http.HttpServletRequest;
import java.time.OffsetDateTime;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

  @ExceptionHandler(ValidationException.class)
  public ResponseEntity<ApiErrorResponse> handleValidation(ValidationException ex, HttpServletRequest request) {
    return ResponseEntity.status(ex.getStatus()).body(body(ex.getStatus(), ex.getCode(), ex.getMessage(), request.getRequestURI(), ex.getDetails()));
  }

  @ExceptionHandler(ResourceNotFoundException.class)
  public ResponseEntity<ApiErrorResponse> handleNotFound(ResourceNotFoundException ex, HttpServletRequest request) {
    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body(404, ex.getCode(), ex.getMessage(), request.getRequestURI(), List.of()));
  }

  @ExceptionHandler(UnauthorizedException.class)
  public ResponseEntity<ApiErrorResponse> handleUnauthorized(UnauthorizedException ex, HttpServletRequest request) {
    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(body(401, ex.getCode(), ex.getMessage(), request.getRequestURI(), List.of()));
  }

  @ExceptionHandler(ConflictException.class)
  public ResponseEntity<ApiErrorResponse> handleConflict(ConflictException ex, HttpServletRequest request) {
    return ResponseEntity.status(HttpStatus.CONFLICT).body(body(409, ex.getCode(), ex.getMessage(), request.getRequestURI(), List.of()));
  }

  @ExceptionHandler({BindException.class, MethodArgumentNotValidException.class, IllegalArgumentException.class})
  public ResponseEntity<ApiErrorResponse> handleBadRequest(Exception ex, HttpServletRequest request) {
    return ResponseEntity.badRequest().body(body(400, "BAD_REQUEST", ex.getMessage(), request.getRequestURI(), List.of()));
  }

  @ExceptionHandler({AuthenticationException.class, AccessDeniedException.class})
  public ResponseEntity<ApiErrorResponse> handleSecurity(Exception ex, HttpServletRequest request) {
    int status = ex instanceof AuthenticationException ? 401 : 403;
    String code = status == 401 ? "UNAUTHORIZED" : "FORBIDDEN";
    return ResponseEntity.status(status).body(body(status, code, ex.getMessage(), request.getRequestURI(), List.of()));
  }

  @ExceptionHandler(Exception.class)
  public ResponseEntity<ApiErrorResponse> handleGeneric(Exception ex, HttpServletRequest request) {
    return ResponseEntity.status(500).body(body(500, "INTERNAL_ERROR", ex.getMessage(), request.getRequestURI(), List.of()));
  }

  private ApiErrorResponse body(int status, String code, String message, String path, List<String> details) {
    return new ApiErrorResponse(OffsetDateTime.now(), status, code, message, details, path);
  }
}
