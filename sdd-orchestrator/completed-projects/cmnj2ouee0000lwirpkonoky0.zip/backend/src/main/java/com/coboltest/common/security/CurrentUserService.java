package com.coboltest.common.security;

import java.util.Optional;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
public class CurrentUserService {

  public Optional<CurrentUser> currentUser() {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    if (authentication == null || !authentication.isAuthenticated()) {
      return Optional.empty();
    }
    Object principal = authentication.getPrincipal();
    if (principal instanceof String username && !"anonymousUser".equals(username)) {
      String terminal = "WEB";
      if (authentication.getDetails() instanceof java.util.Map<?, ?> details && details.get("terminal") != null) {
        terminal = String.valueOf(details.get("terminal"));
      }
      return Optional.of(new CurrentUser(username, terminal, "COBOL TEST APR3"));
    }
    return Optional.empty();
  }

  public String usernameOrDefault() {
    return currentUser().map(CurrentUser::username).orElse("system");
  }
}
