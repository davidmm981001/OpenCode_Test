package com.coboltest.common.exception;

import java.util.List;

public class ValidationException extends BusinessException {
  private final List<String> details;

  public ValidationException(String code, String message, List<String> details) {
    super(code, 400, message);
    this.details = details;
  }

  public List<String> getDetails() {
    return details;
  }
}
