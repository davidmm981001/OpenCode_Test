package com.coboltest.usuariosconsulta.api.dto;

public record UserSummaryResponse(String usrSiglo21, String usrNombre, String usrPers, String usrEmpresa, String usrCentro, String usrDominio, String usrNodo, String usrAutoriza) {}
