package com.coboltest.persistence.repo;

import com.coboltest.persistence.entity.BancsEntity;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BancsRepository extends JpaRepository<BancsEntity, UUID> {
  Optional<BancsEntity> findByUserCode(String userCode);

  Optional<BancsEntity> findByExternalUser(String externalUser);
}
