package com.coboltest.authinfra.service;

import com.coboltest.persistence.repo.AuthUserRepository;
import java.util.Arrays;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {
  private final AuthUserRepository repository;

  public CustomUserDetailsService(AuthUserRepository repository) {
    this.repository = repository;
  }

  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    var authUser = repository.findByUsername(username).orElseThrow(() -> new UsernameNotFoundException(username));
    return User.withUsername(authUser.username)
        .password(authUser.passwordHash)
        .authorities(Arrays.stream(authUser.rolesCsv.split(",")).map(SimpleGrantedAuthority::new).toList())
        .build();
  }
}
