package com.coboltest.persistence.repo;

import com.coboltest.persistence.entity.SecurityUserEntity;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SecurityUserRepository extends JpaRepository<SecurityUserEntity, UUID> {
  Optional<SecurityUserEntity> findByCode(String code);
}
