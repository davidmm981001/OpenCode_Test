package com.coboltest.seguridadmenu.service;

import com.coboltest.common.exception.ValidationException;
import com.coboltest.common.security.CurrentUserService;
import com.coboltest.persistence.repo.MenuOptionRepository;
import com.coboltest.seguridadmenu.api.dto.MenuOptionResponse;
import com.coboltest.seguridadmenu.api.dto.MenuValidationResponse;
import com.coboltest.seguridadmenu.api.dto.SecurityMenuResponse;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class SecurityMenuService {
  private final MenuOptionRepository menuOptionRepository;
  private final CurrentUserService currentUserService;

  public SecurityMenuService(MenuOptionRepository menuOptionRepository, CurrentUserService currentUserService) {
    this.menuOptionRepository = menuOptionRepository;
    this.currentUserService = currentUserService;
  }

  @Transactional(readOnly = true)
  public SecurityMenuResponse menu() {
    var currentUser = currentUserService.currentUser().orElseThrow(() -> new ValidationException("UNAUTHORIZED", "Usuario no autenticado", List.of("Debe iniciar sesión")));
    List<MenuOptionResponse> options = menuOptionRepository.findAllByEnabledTrueOrderByCodeAsc().stream()
        .map(option -> new MenuOptionResponse(option.code, option.title, option.route, option.enabled))
        .toList();
    return new SecurityMenuResponse(currentUser.username(), "COBOL TEST APR3", currentUser.terminal(), OffsetDateTime.now().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME), options);
  }

  @Transactional(readOnly = true)
  public MenuValidationResponse validateOption(Integer code) {
    if (code == null || code < 1 || code > 9) {
      throw new ValidationException("INVALID_MENU_OPTION", "Opcion invalida", List.of("Solo se permiten opciones 1 a 9"));
    }
    return new MenuValidationResponse("Opcion valida");
  }
}
