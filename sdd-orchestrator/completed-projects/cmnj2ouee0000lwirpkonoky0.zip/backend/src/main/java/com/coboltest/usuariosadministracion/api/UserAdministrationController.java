package com.coboltest.usuariosadministracion.api;

import com.coboltest.catalogosvalidacion.api.dto.ObservationLookupResponse;
import com.coboltest.common.api.ApiPageResponse;
import com.coboltest.usuariosadministracion.api.dto.BancsDetailResponse;
import com.coboltest.usuariosadministracion.api.dto.BancsStateRequest;
import com.coboltest.usuariosadministracion.api.dto.BancsStateResponse;
import com.coboltest.usuariosadministracion.api.dto.UserCreateResponse;
import com.coboltest.usuariosadministracion.api.dto.UserDeleteRequest;
import com.coboltest.usuariosadministracion.api.dto.UserDeleteResponse;
import com.coboltest.usuariosadministracion.api.dto.UserDetailResponse;
import com.coboltest.usuariosadministracion.api.dto.UserMutationResponse;
import com.coboltest.usuariosconsulta.api.dto.UserSummaryResponse;
import com.coboltest.usuariosadministracion.api.dto.UserUpsertRequest;
import com.coboltest.usuariosadministracion.service.UserAdministrationService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/usuarios")
public class UserAdministrationController {
  private final UserAdministrationService service;

  public UserAdministrationController(UserAdministrationService service) {
    this.service = service;
  }

  @Operation(summary = "Consulta general de usuarios")
  @GetMapping
  public ApiPageResponse<UserSummaryResponse> search(
      @RequestParam(required = false) String empresa,
      @RequestParam(required = false) String centro,
      @RequestParam(required = false) String usuario,
      @RequestParam(required = false) String perfil,
      @RequestParam(required = false) String nombre,
      @RequestParam(defaultValue = "0") int page,
      @RequestParam(defaultValue = "14") int size) {
    return service.search(empresa, centro, usuario, perfil, nombre, page, size);
  }

  @Operation(summary = "Detalle de usuario")
  @GetMapping("/{usrSiglo21}")
  public UserDetailResponse detail(@PathVariable String usrSiglo21) {
    return service.detail(usrSiglo21);
  }

  @Operation(summary = "Crear usuario")
  @PostMapping
  public ResponseEntity<UserCreateResponse> create(@Valid @RequestBody UserUpsertRequest request, @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey) {
    return ResponseEntity.status(201).body(service.create(request, idempotencyKey));
  }

  @Operation(summary = "Actualizar usuario")
  @PutMapping("/{usrSiglo21}")
  public UserMutationResponse update(@PathVariable String usrSiglo21, @Valid @RequestBody UserUpsertRequest request, @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey) {
    return service.update(usrSiglo21, request, idempotencyKey);
  }

  @Operation(summary = "Eliminar usuario")
  @DeleteMapping("/{usrSiglo21}")
  public UserDeleteResponse delete(@PathVariable String usrSiglo21, @Valid @RequestBody UserDeleteRequest request, @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey) {
    return service.delete(usrSiglo21, request.observacion(), idempotencyKey);
  }

  @Operation(summary = "Observación de usuario")
  @GetMapping("/{usrSiglo21}/observacion")
  public ObservationLookupResponse observation(@PathVariable String usrSiglo21) {
    return service.observation(usrSiglo21);
  }

  @Operation(summary = "Consulta BANCS de usuario")
  @GetMapping("/{usrSiglo21}/bancs")
  public BancsDetailResponse bancs(@PathVariable String usrSiglo21) {
    return service.bancs(usrSiglo21);
  }

  @Operation(summary = "Actualizar estado BANCS")
  @PutMapping("/{usrSiglo21}/bancs/estado")
  public BancsStateResponse bancsState(@PathVariable String usrSiglo21, @Valid @RequestBody BancsStateRequest request) {
    return service.updateBancsState(usrSiglo21, request.estProceso(), request.observacion());
  }
}
