package com.coboltest.usuariosadministracion.api.dto;

import java.util.UUID;

public record UserCreateResponse(
    UUID id,
    String usrSiglo21,
    String usrNombre,
    String usrEmpresa,
    String usrCentro,
    String usrPers,
    Integer usrAutoriza,
    String observacion,
    String usrBancs,
    Integer termBancs,
    String updFecha,
    String updHora,
    String updUsuario,
    String updTerminal,
    String message) {}
