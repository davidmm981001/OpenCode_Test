package com.coboltest.common.security;

public record CurrentUser(String username, String terminal, String application) {}
