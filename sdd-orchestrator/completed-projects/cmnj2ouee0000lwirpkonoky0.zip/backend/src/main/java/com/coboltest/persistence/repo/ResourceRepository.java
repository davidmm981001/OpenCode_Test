package com.coboltest.persistence.repo;

import com.coboltest.persistence.entity.ResourceEntity;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResourceRepository extends JpaRepository<ResourceEntity, UUID> {
  Optional<ResourceEntity> findByGroupCodeAndResourceCode(String groupCode, String resourceCode);
}
