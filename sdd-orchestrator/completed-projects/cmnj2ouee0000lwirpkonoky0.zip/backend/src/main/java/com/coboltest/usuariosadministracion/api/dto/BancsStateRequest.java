package com.coboltest.usuariosadministracion.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record BancsStateRequest(@NotBlank @Size(min = 2, max = 2) String estProceso, @NotBlank @Size(min = 1, max = 80) String observacion) {}
