package com.coboltest.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.util.UUID;

@Entity
@Table(name = "menu_options")
public class MenuOptionEntity {
  @Id
  public UUID id;

  @Column(nullable = false, unique = true)
  public Integer code;

  @Column(nullable = false, length = 120)
  public String title;

  @Column(nullable = false, length = 160)
  public String route;

  @Column(nullable = false)
  public boolean enabled;

  protected MenuOptionEntity() {}
}
