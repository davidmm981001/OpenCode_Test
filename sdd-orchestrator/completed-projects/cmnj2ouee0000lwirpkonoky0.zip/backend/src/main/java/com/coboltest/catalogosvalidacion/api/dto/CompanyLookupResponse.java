package com.coboltest.catalogosvalidacion.api.dto;

public record CompanyLookupResponse(String codigo, String nombre, boolean valido, String message) {}
