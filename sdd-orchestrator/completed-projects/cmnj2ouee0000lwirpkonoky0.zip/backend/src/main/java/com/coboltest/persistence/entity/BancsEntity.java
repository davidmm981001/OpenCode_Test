package com.coboltest.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(
    name = "user_bancs",
    uniqueConstraints = {
      @UniqueConstraint(columnNames = {"userCode"}),
      @UniqueConstraint(columnNames = {"externalUser"})
    })
public class BancsEntity {
  @Id
  public UUID id;

  @Column(nullable = false, unique = true, length = 8)
  public String userCode;

  @Column(nullable = false, unique = true, length = 8)
  public String externalUser;

  @Column(nullable = false, length = 60)
  public String name;

  @Column(nullable = false, length = 4)
  public String branchNo;

  @Column(nullable = false)
  public Integer terminalNo;

  @Column(nullable = false, length = 4)
  public String companyCode;

  @Column(nullable = false, length = 2)
  public String status;

  @Column(nullable = false, length = 80)
  public String observation;

  @Column(nullable = false)
  public Instant lastChange;

  @Column(nullable = false, length = 8)
  public String updatedBy;

  public BancsEntity() {}
}
