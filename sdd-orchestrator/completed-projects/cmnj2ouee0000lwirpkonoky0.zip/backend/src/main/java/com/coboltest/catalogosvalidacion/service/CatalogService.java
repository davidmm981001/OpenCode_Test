package com.coboltest.catalogosvalidacion.service;

import com.coboltest.catalogosvalidacion.api.dto.CenterLookupResponse;
import com.coboltest.catalogosvalidacion.api.dto.CompanyLookupResponse;
import com.coboltest.catalogosvalidacion.api.dto.ObservationLookupResponse;
import com.coboltest.catalogosvalidacion.api.dto.ProfileLookupResponse;
import com.coboltest.persistence.repo.CenterRepository;
import com.coboltest.persistence.repo.CompanyRepository;
import com.coboltest.persistence.repo.ParameterRepository;
import com.coboltest.persistence.repo.ResourceRepository;
import com.coboltest.persistence.repo.UserObservationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CatalogService {
  private final ParameterRepository parameterRepository;
  private final ResourceRepository resourceRepository;
  private final CompanyRepository companyRepository;
  private final CenterRepository centerRepository;
  private final UserObservationRepository userObservationRepository;

  public CatalogService(ParameterRepository parameterRepository, ResourceRepository resourceRepository, CompanyRepository companyRepository, CenterRepository centerRepository, UserObservationRepository userObservationRepository) {
    this.parameterRepository = parameterRepository;
    this.resourceRepository = resourceRepository;
    this.companyRepository = companyRepository;
    this.centerRepository = centerRepository;
    this.userObservationRepository = userObservationRepository;
  }

  @Transactional(readOnly = true)
  public ProfileLookupResponse profile(String code) {
    var parameter = parameterRepository.findByGroupCodeAndParameterCode("GR", code);
    var resource = resourceRepository.findByGroupCodeAndResourceCode("GR", code);
    boolean existsParameter = parameter.isPresent();
    boolean existsResource = resource.isPresent();
    String description = existsParameter ? parameter.get().description : null;
    String message = !existsParameter ? "Perfil NO definido en T95PAR02" : (!existsResource ? "Perfil RE no definido en T01GRE20" : "Perfil válido");
    return new ProfileLookupResponse(code, description, existsParameter, existsResource, existsParameter && existsResource, message);
  }

  @Transactional(readOnly = true)
  public CompanyLookupResponse company(String code) {
    return companyRepository.findByCode(code)
        .map(company -> new CompanyLookupResponse(code, company.name, true, "Empresa válida"))
        .orElseGet(() -> new CompanyLookupResponse(code, null, false, "Empresa no definida T06TC005"));
  }

  @Transactional(readOnly = true)
  public CenterLookupResponse center(String companyCode, String centerCode) {
    return centerRepository.findByCompanyCodeAndCenterCode(companyCode, centerCode)
        .map(center -> new CenterLookupResponse(companyCode, centerCode, center.name, true, "Centro válido"))
        .orElseGet(() -> new CenterLookupResponse(companyCode, centerCode, null, false, "Centro no definido T06TC007"));
  }

  @Transactional(readOnly = true)
  public ObservationLookupResponse observation(String userCode) {
    return userObservationRepository.findByUserCode(userCode)
        .map(observation -> new ObservationLookupResponse(userCode, observation.comment))
        .orElseGet(() -> new ObservationLookupResponse(userCode, null));
  }
}
