package com.coboltest.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.util.UUID;

@Entity
@Table(name = "centers", uniqueConstraints = @UniqueConstraint(columnNames = {"companyCode", "centerCode"}))
public class CenterEntity {
  @jakarta.persistence.Id
  public UUID id;

  @Column(nullable = false, length = 4)
  public String companyCode;

  @Column(nullable = false, length = 4)
  public String centerCode;

  @Column(nullable = false, length = 40)
  public String name;

  protected CenterEntity() {}
}
