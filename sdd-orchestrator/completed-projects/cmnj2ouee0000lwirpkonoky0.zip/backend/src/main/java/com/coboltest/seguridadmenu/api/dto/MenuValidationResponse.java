package com.coboltest.seguridadmenu.api.dto;

public record MenuValidationResponse(String message) {}
