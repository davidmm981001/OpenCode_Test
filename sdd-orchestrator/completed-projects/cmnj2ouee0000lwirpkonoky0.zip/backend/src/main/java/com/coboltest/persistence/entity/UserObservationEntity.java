package com.coboltest.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "user_observations")
public class UserObservationEntity {
  @Id
  public UUID id;

  @Column(nullable = false, unique = true, length = 8)
  public String userCode;

  @Column(nullable = false, length = 8)
  public String modificationUser;

  @Column(nullable = false)
  public Instant lastChange;

  @Column(nullable = false, length = 100)
  public String comment;

  public UserObservationEntity() {}
}
