package com.coboltest.authinfra.api;

import com.coboltest.authinfra.api.dto.AuthResponse;
import com.coboltest.authinfra.api.dto.LoginRequest;
import com.coboltest.authinfra.api.dto.LogoutRequest;
import com.coboltest.authinfra.api.dto.LogoutResponse;
import com.coboltest.authinfra.api.dto.RefreshRequest;
import com.coboltest.authinfra.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class AuthController {
  private final AuthService authService;

  public AuthController(AuthService authService) {
    this.authService = authService;
  }

  @Operation(summary = "Login de usuario")
  @PostMapping("/login")
  public AuthResponse login(@Valid @RequestBody LoginRequest request) {
    return authService.login(request.username(), request.password());
  }

  @Operation(summary = "Refresh de sesión")
  @PostMapping("/refresh")
  public AuthResponse refresh(@Valid @RequestBody RefreshRequest request) {
    return authService.refresh(request.refreshToken());
  }

  @Operation(summary = "Logout")
  @PostMapping("/logout")
  public ResponseEntity<LogoutResponse> logout(@RequestBody(required = false) LogoutRequest request, Authentication authentication) {
    String username = authentication != null ? String.valueOf(authentication.getPrincipal()) : "system";
    String message = authService.logout(request == null ? null : request.refreshToken(), username);
    return ResponseEntity.ok(new LogoutResponse(message));
  }
}
