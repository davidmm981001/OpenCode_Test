package com.coboltest.catalogosvalidacion.api.dto;

public record CenterLookupResponse(String empresa, String centro, String nombre, boolean valido, String message) {}
