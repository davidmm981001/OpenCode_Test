package com.coboltest.usuariosadministracion.api.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record UserUpsertRequest(
    @NotBlank @Size(min = 1, max = 8) String usrSiglo21,
    @NotBlank @Size(min = 1, max = 43) String usrNombre,
    @Size(max = 10) String usrCid,
    @NotBlank @Size(min = 4, max = 4) String usrEmpresa,
    @NotBlank @Size(min = 4, max = 4) String usrCentro,
    @Size(max = 18) String usrCargo,
    @NotBlank @Size(min = 1, max = 8) String usrPers,
    @Size(max = 4) String usrDominio,
    @Size(max = 4) String usrNodo,
    @NotNull @Min(0) @Max(1) Integer usrAutoriza,
    @Size(max = 20) String usrOficinaSwift,
    @NotBlank @Size(min = 1, max = 100) String observacion,
    @Size(max = 8) String usrBancs,
    Integer termBancs,
    Long version,
    String ifMatch) {}
