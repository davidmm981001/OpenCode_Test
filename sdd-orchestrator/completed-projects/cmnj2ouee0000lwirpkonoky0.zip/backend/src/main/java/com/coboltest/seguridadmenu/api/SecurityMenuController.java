package com.coboltest.seguridadmenu.api;

import com.coboltest.seguridadmenu.api.dto.MenuValidationRequest;
import com.coboltest.seguridadmenu.api.dto.MenuValidationResponse;
import com.coboltest.seguridadmenu.api.dto.SecurityMenuResponse;
import com.coboltest.seguridadmenu.service.SecurityMenuService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/seguridad/menu")
public class SecurityMenuController {
  private final SecurityMenuService service;

  public SecurityMenuController(SecurityMenuService service) {
    this.service = service;
  }

  @Operation(summary = "Obtiene el menú de seguridad")
  @GetMapping
  public SecurityMenuResponse menu() {
    return service.menu();
  }

  @Operation(summary = "Valida una opción de navegación")
  @PostMapping("/validar")
  public MenuValidationResponse validate(@Valid @RequestBody MenuValidationRequest request) {
    return service.validateOption(request.codigo());
  }
}
