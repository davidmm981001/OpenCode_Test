package com.coboltest.persistence.repo;

import com.coboltest.persistence.entity.AuditEntity;
import java.util.List;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditRepository extends JpaRepository<AuditEntity, UUID> {
  Page<AuditEntity> findByUserCodeOrderByCreatedAtDesc(String userCode, Pageable pageable);

  List<AuditEntity> findByUserCodeOrderByCreatedAtDesc(String userCode);
}
