package com.coboltest.authinfra.api.dto;

public record LogoutRequest(String refreshToken) {}
