package com.coboltest.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "resources", uniqueConstraints = @UniqueConstraint(columnNames = {"groupCode", "resourceCode"}))
public class ResourceEntity {
  @jakarta.persistence.Id
  public UUID id;

  @Column(nullable = false, length = 8)
  public String groupCode;

  @Column(nullable = false, length = 12)
  public String resourceCode;

  @Column(nullable = false)
  public Integer accessLevel;

  @Column(nullable = false)
  public Instant updatedAt;

  protected ResourceEntity() {}
}
