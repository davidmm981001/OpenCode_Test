package com.coboltest.persistence.repo;

import com.coboltest.persistence.entity.RefreshTokenEntity;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RefreshTokenRepository extends JpaRepository<RefreshTokenEntity, UUID> {
  Optional<RefreshTokenEntity> findByToken(String token);

  List<RefreshTokenEntity> findByUsernameAndRevokedFalse(String username);
}
