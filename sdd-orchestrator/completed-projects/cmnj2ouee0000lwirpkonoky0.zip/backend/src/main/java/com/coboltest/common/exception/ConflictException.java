package com.coboltest.common.exception;

public class ConflictException extends BusinessException {
  public ConflictException(String code, String message) {
    super(code, 409, message);
  }
}
