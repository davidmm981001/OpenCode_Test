package com.coboltest.common.exception;

public class UnauthorizedException extends BusinessException {
  public UnauthorizedException(String code, String message) {
    super(code, 401, message);
  }
}
