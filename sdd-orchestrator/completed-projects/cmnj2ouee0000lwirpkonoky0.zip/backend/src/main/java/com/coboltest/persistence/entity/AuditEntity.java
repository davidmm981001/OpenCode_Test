package com.coboltest.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "user_audits")
public class AuditEntity {
  @Id
  public UUID id;

  @Column(nullable = false, length = 8)
  public String transactionCode;

  @Column(nullable = false, length = 12)
  public String operation;

  @Column(nullable = false, length = 8)
  public String userCode;

  @Column(nullable = false, length = 40)
  public String name;

  @Column(nullable = false, length = 8)
  public String currentProfile;

  @Column(nullable = false, length = 4)
  public String currentCenter;

  @Column(nullable = false)
  public Integer currentAutoriza;

  @Column(length = 8)
  public String previousProfile;

  @Column(length = 4)
  public String previousCenter;

  @Column
  public Integer previousAutoriza;

  @Column(nullable = false, length = 100)
  public String observation;

  @Column(nullable = false, length = 100)
  public String response;

  @Column(nullable = false, length = 255)
  public String mensajeria;

  @Column(nullable = false, length = 10)
  public String terminal;

  @Column(nullable = false, length = 20)
  public String modifiedBy;

  @Column(nullable = false)
  public Instant createdAt;

  public AuditEntity() {}
}
