package com.coboltest.authinfra.api.dto;

public record LogoutResponse(String message) {}
