package com.coboltest.usuariosadministracion.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record UserDeleteRequest(@NotBlank @Size(min = 1, max = 100) String observacion) {}
