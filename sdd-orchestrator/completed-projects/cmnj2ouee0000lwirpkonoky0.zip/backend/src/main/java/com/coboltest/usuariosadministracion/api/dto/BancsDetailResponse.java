package com.coboltest.usuariosadministracion.api.dto;

public record BancsDetailResponse(
    String usrSiglo21,
    String usrBancs,
    String usrNombre,
    String branchNo,
    Integer termNo,
    String codEmpresa,
    String estProceso,
    String observacion,
    String fechaUltCambio,
    String usrUltCambio) {}
