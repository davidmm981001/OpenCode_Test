package com.coboltest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CobolTestApr3Application {

  public static void main(String[] args) {
    SpringApplication.run(CobolTestApr3Application.class, args);
  }
}
