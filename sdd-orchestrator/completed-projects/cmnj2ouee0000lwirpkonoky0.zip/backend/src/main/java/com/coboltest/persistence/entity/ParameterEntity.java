package com.coboltest.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.util.UUID;

@Entity
@Table(name = "parameters", uniqueConstraints = @UniqueConstraint(columnNames = {"groupCode", "parameterCode"}))
public class ParameterEntity {
  @jakarta.persistence.Id
  public UUID id;

  @Column(nullable = false, length = 12)
  public String groupCode;

  @Column(nullable = false, length = 8)
  public String parameterCode;

  @Column(nullable = false, length = 100)
  public String description;

  protected ParameterEntity() {}
}
