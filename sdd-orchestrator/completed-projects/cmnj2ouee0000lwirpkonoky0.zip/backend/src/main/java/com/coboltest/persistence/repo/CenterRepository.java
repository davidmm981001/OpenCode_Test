package com.coboltest.persistence.repo;

import com.coboltest.persistence.entity.CenterEntity;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CenterRepository extends JpaRepository<CenterEntity, UUID> {
  Optional<CenterEntity> findByCompanyCodeAndCenterCode(String companyCode, String centerCode);

  List<CenterEntity> findByCompanyCode(String companyCode);
}
