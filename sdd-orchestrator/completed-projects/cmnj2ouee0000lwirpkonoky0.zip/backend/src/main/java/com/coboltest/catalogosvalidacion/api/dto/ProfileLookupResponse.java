package com.coboltest.catalogosvalidacion.api.dto;

public record ProfileLookupResponse(String codigo, String descripcion, boolean existeParametro, boolean existeRecurso, boolean valido, String message) {}
