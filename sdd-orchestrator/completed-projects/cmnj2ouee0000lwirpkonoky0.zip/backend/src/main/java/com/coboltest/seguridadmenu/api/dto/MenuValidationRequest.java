package com.coboltest.seguridadmenu.api.dto;

import jakarta.validation.constraints.NotNull;

public record MenuValidationRequest(@NotNull Integer codigo) {}
