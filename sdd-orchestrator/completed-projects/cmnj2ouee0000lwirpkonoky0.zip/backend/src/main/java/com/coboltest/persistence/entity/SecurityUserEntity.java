package com.coboltest.persistence.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "security_users")
public class SecurityUserEntity {
  @Id
  public UUID id;

  @Column(nullable = false, unique = true, length = 8)
  public String code;

  @Column(nullable = false, length = 43)
  public String name;

  @Column(nullable = false, length = 1)
  public String status;

  @Column(nullable = false, length = 10)
  public String cid;

  @Column(nullable = false, length = 8)
  public String offsetBancs;

  @Column(nullable = false, length = 18)
  public String cargo;

  @Column(nullable = false, length = 4)
  public String companyCode;

  @Column(nullable = false, length = 4)
  public String centerCode;

  @Column(nullable = false, length = 8)
  public String profileCode;

  @Column(nullable = false, length = 4)
  public String domainCode;

  @Column(nullable = false, length = 4)
  public String nodeCode;

  @Column(nullable = false)
  public Integer autoriza;

  @Column(nullable = false, length = 8)
  public String updatedDate;

  @Column(nullable = false, length = 6)
  public String updatedTime;

  @Column(nullable = false, length = 8)
  public String updatedUser;

  @Column(nullable = false, length = 10)
  public String updatedTerminal;

  @Column(nullable = false, length = 8)
  public String logonDate;

  @Column(nullable = false, length = 6)
  public String logonTime;

  @Column(length = 40)
  public String logonIp;

  @Column(length = 20)
  public String officeSwift;

  @Column(nullable = false)
  @jakarta.persistence.Version
  public long version;

  @Column(nullable = false)
  public Instant createdAt;

  public SecurityUserEntity() {}
}
