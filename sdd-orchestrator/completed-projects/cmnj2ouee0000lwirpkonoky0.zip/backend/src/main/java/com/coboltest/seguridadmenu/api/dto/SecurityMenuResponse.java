package com.coboltest.seguridadmenu.api.dto;

import java.util.List;

public record SecurityMenuResponse(String usuario, String aplicacion, String terminal, String fechaHoraServidor, List<MenuOptionResponse> opciones) {}
