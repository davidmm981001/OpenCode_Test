package com.coboltest.auditoriaoperacion.api.dto;

import java.util.UUID;

public record AuditEntryResponse(
    UUID id,
    String transaccion,
    String operacion,
    String usrSiglo21,
    String nombre,
    String perfilActual,
    String centroActual,
    Integer autorizadorActual,
    String perfilPrevio,
    String centroPrevio,
    Integer autorizadorPrevio,
    String observacion,
    String respuesta,
    String mensajeria,
    String usuarioModificador,
    String terminal,
    String fechaHora) {}
