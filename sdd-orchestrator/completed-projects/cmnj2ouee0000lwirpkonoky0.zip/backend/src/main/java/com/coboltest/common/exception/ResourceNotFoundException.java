package com.coboltest.common.exception;

public class ResourceNotFoundException extends BusinessException {
  public ResourceNotFoundException(String code, String message) {
    super(code, 404, message);
  }
}
