package com.coboltest.usuariosadministracion.api.dto;

public record BancsStateResponse(String usrSiglo21, String estProceso, String observacion, boolean updated) {}
