package com.coboltest;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class ApiFlowsIntegrationTest {

  @Autowired MockMvc mockMvc;
  @Autowired ObjectMapper objectMapper;

  @Test
  @DisplayName("Login and security menu are accessible with seeded admin user")
  void loginAndReadSecurityMenu_shouldReturnExpectedPayload() throws Exception {
    String loginJson = mockMvc.perform(post("/auth/login")
            .contentType(MediaType.APPLICATION_JSON)
            .content("{\"username\":\"admin\",\"password\":\"Admin123!\"}"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.accessToken").isNotEmpty())
        .andExpect(jsonPath("$.refreshToken").isNotEmpty())
        .andExpect(jsonPath("$.user.username").value("admin"))
        .andReturn()
        .getResponse()
        .getContentAsString();

    JsonNode login = objectMapper.readTree(loginJson);
    String token = login.get("accessToken").asText();

    mockMvc.perform(get("/api/v1/seguridad/menu").header("Authorization", "Bearer " + token))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.usuario").value("admin"))
        .andExpect(jsonPath("$.aplicacion").value("COBOL TEST APR3"))
        .andExpect(jsonPath("$.opciones.length()").value(9));
  }

  @Test
  @DisplayName("User search requires a functional criterion")
  void searchUsers_withoutCriteria_shouldFailValidation() throws Exception {
    String token = loginToken();

    mockMvc.perform(get("/api/v1/usuarios").header("Authorization", "Bearer " + token))
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("QUERY_CRITERIA_REQUIRED"))
        .andExpect(jsonPath("$.message").value("Ingrese Criterio Consulta"));
  }

  @Test
  @DisplayName("User search supports seeded data and pagination")
  void searchUsers_byCompany_shouldReturnSeededUsers() throws Exception {
    String token = loginToken();

    mockMvc.perform(get("/api/v1/usuarios")
            .header("Authorization", "Bearer " + token)
            .param("empresa", "1001")
            .param("page", "0")
            .param("size", "14"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.content.length()").value(3))
        .andExpect(jsonPath("$.content[0].usrSiglo21").value("USR00001"))
        .andExpect(jsonPath("$.message").exists());
  }

  @Test
  @DisplayName("Catalog validation resolves seeded and missing catalog entries")
  void catalogValidation_shouldExposeLookupMessages() throws Exception {
    String token = loginToken();

    mockMvc.perform(get("/api/v1/catalogos/perfiles/PERF0001").header("Authorization", "Bearer " + token))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.valido").value(true))
        .andExpect(jsonPath("$.descripcion").value("Perfil Operador"));

    mockMvc.perform(get("/api/v1/catalogos/empresas/9999").header("Authorization", "Bearer " + token))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.valido").value(false))
        .andExpect(jsonPath("$.message").value("Empresa no definida T06TC005"));
  }

  private String loginToken() throws Exception {
    String response = mockMvc.perform(post("/auth/login")
            .contentType(MediaType.APPLICATION_JSON)
            .content("{\"username\":\"admin\",\"password\":\"Admin123!\"}"))
        .andExpect(status().isOk())
        .andReturn()
        .getResponse()
        .getContentAsString();
    return objectMapper.readTree(response).get("accessToken").asText();
  }
}
