import axios from 'axios';
import { clearAuthState, getAuthState, setAuthState } from './auth-store';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8081',
  withCredentials: false,
});

api.interceptors.request.use((config) => {
  const auth = getAuthState();
  if (auth.accessToken) {
    config.headers = config.headers ?? {};
    config.headers.Authorization = `Bearer ${auth.accessToken}`;
  }
  return config;
});

let refreshing: Promise<void> | null = null;

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original = error.config;
    if (error.response?.status === 401 && !original?._retry) {
      const auth = getAuthState();
      if (auth.refreshToken) {
        original._retry = true;
        refreshing ??= api
          .post('/auth/refresh', { refreshToken: auth.refreshToken })
          .then((response) => {
            setAuthState({
              accessToken: response.data.accessToken,
              refreshToken: response.data.refreshToken,
              user: response.data.user,
            });
          })
          .finally(() => {
            refreshing = null;
          });
        await refreshing;
        original.headers = original.headers ?? {};
        original.headers.Authorization = `Bearer ${getAuthState().accessToken}`;
        return api(original);
      }
      clearAuthState();
    }
    return Promise.reject(error);
  },
);

export { api };
