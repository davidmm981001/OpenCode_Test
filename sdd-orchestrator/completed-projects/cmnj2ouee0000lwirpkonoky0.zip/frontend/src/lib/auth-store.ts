export type AuthUser = {
  username: string;
  roles: string[];
};

type AuthState = {
  accessToken: string | null;
  refreshToken: string | null;
  user: AuthUser | null;
};

let state: AuthState = {
  accessToken: null,
  refreshToken: null,
  user: null,
};

const listeners = new Set<() => void>();

export function getAuthState() {
  return state;
}

export function setAuthState(next: AuthState) {
  state = next;
  listeners.forEach((listener) => listener());
}

export function clearAuthState() {
  state = { accessToken: null, refreshToken: null, user: null };
  listeners.forEach((listener) => listener());
}

export function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}
