import { createContext, PropsWithChildren, useContext, useEffect, useMemo, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { api } from '../lib/http';
import { AuthUser, clearAuthState, getAuthState, setAuthState, subscribe } from '../lib/auth-store';

type AuthContextValue = {
  user: AuthUser | null;
  isAuthenticated: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: PropsWithChildren) {
  const queryClient = useQueryClient();
  const [user, setUser] = useState<AuthUser | null>(getAuthState().user);

  useEffect(() => subscribe(() => setUser(getAuthState().user)), []);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      isAuthenticated: Boolean(user),
      login: async (username: string, password: string) => {
        const response = await api.post('/auth/login', { username, password });
        setAuthState({
          accessToken: response.data.accessToken,
          refreshToken: response.data.refreshToken,
          user: response.data.user,
        });
      },
      logout: async () => {
        const auth = getAuthState();
        await api.post('/auth/logout', auth.refreshToken ? { refreshToken: auth.refreshToken } : undefined).catch(() => undefined);
        clearAuthState();
        queryClient.clear();
      },
    }),
    [queryClient, user],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('AuthProvider missing');
  return context;
}
