import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, describe, expect, it } from 'vitest';
import { App } from './App';
import { AuthProvider } from './context/AuthContext';
import { clearAuthState } from './lib/auth-store';

describe('App routing', () => {
  afterEach(() => {
    clearAuthState();
  });

  it('redirects unauthenticated users to the login page', () => {
    const queryClient = new QueryClient();

    render(
      <QueryClientProvider client={queryClient}>
        <MemoryRouter initialEntries={['/app/seguridad']}>
          <AuthProvider>
            <App />
          </AuthProvider>
        </MemoryRouter>
      </QueryClientProvider>,
    );

    expect(screen.getByRole('heading', { name: 'Ingresar' })).toBeInTheDocument();
  });
});
