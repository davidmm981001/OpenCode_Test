import { Navigate, Route, Routes } from 'react-router-dom';
import { ProtectedRoute } from './components/ProtectedRoute';
import { LoginPage } from './pages/LoginPage';
import { SecurityDashboard } from './pages/SecurityDashboard';
import { UserSearchPage } from './pages/UserSearchPage';
import { UserFormPage } from './pages/UserFormPage';
import { UserDetailPage } from './pages/UserDetailPage';
import { CatalogPage } from './pages/CatalogPage';
import { AuditPage } from './pages/AuditPage';
import { BancsPage } from './pages/BancsPage';

export function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route element={<ProtectedRoute />}>
        <Route path="/app/seguridad" element={<SecurityDashboard />} />
        <Route path="/app/usuarios/consulta" element={<UserSearchPage />} />
        <Route path="/app/usuarios/nuevo" element={<UserFormPage mode="new" />} />
        <Route path="/app/usuarios/:usrSiglo21" element={<UserDetailPage />} />
        <Route path="/app/usuarios/:usrSiglo21/auditoria" element={<AuditPage />} />
        <Route path="/app/usuarios/:usrSiglo21/bancs" element={<BancsPage />} />
        <Route path="/app/catalogos" element={<CatalogPage />} />
      </Route>
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}
