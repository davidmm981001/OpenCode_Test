import { useQuery } from '@tanstack/react-query';
import { useParams } from 'react-router-dom';
import { api } from '../lib/http';
import { AppHeader } from '../components/AppHeader';

export function AuditPage() {
  const { usrSiglo21 = '' } = useParams();
  const { data } = useQuery({
    queryKey: ['auditoria-usuario', usrSiglo21, 0],
    queryFn: async () => (await api.get(`/api/v1/auditoria/usuarios/${usrSiglo21}`, { params: { page: 0, size: 20 } })).data,
    enabled: Boolean(usrSiglo21),
  });

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader title={`Auditoría ${usrSiglo21}`} />
      <main className="mx-auto max-w-5xl p-6">
        <div className="rounded-xl bg-white p-6 shadow-sm">
          {(data?.content ?? []).map((entry: any) => (
            <div key={entry.id} className="border-b py-3">
              <div className="font-medium">{entry.operacion}</div>
              <div className="text-sm text-slate-500">{entry.mensajeria}</div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
