import { useQuery } from '@tanstack/react-query';
import { useParams } from 'react-router-dom';
import { api } from '../lib/http';
import { AppHeader } from '../components/AppHeader';

export function BancsPage() {
  const { usrSiglo21 = '' } = useParams();
  const { data } = useQuery({
    queryKey: ['usuario-bancs', usrSiglo21],
    queryFn: async () => (await api.get(`/api/v1/usuarios/${usrSiglo21}/bancs`)).data,
    enabled: Boolean(usrSiglo21),
  });

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader title={`BANCS ${usrSiglo21}`} />
      <main className="mx-auto max-w-4xl p-6">
        <pre className="rounded-xl bg-white p-6 shadow-sm text-sm">{JSON.stringify(data ?? {}, null, 2)}</pre>
      </main>
    </div>
  );
}
