import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/http';
import { AppHeader } from '../components/AppHeader';

type UserSummary = { usrSiglo21: string; usrNombre: string; usrPers: string; usrEmpresa: string; usrCentro: string; usrDominio: string; usrNodo: string; usrAutoriza: string };
type UserSearchResponse = { content: UserSummary[]; totalElements: number; totalPages: number; size: number; number: number; first: boolean; last: boolean; message: string };

export function UserSearchPage() {
  const [empresa, setEmpresa] = useState('1001');
  const [usuario, setUsuario] = useState('');
  const [perfil, setPerfil] = useState('');
  const [nombre, setNombre] = useState('');
  const [page, setPage] = useState(0);
  const navigate = useNavigate();

  const filters = useMemo(() => ({ empresa, usuario, perfil, nombre, page, size: 14 }), [empresa, usuario, perfil, nombre, page]);
  const query = useQuery({
    queryKey: ['usuarios', filters],
    queryFn: async () => (await api.get<UserSearchResponse>('/api/v1/usuarios', { params: filters })).data,
    placeholderData: (previous) => previous,
    staleTime: 5 * 60 * 1000,
  });

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader title="Consulta de Usuarios" />
      <main className="mx-auto max-w-6xl p-6">
        <section className="rounded-xl bg-white p-6 shadow-sm">
          <div className="grid gap-4 md:grid-cols-5">
            <Input label="Empresa" value={empresa} onChange={setEmpresa} />
            <Input label="Usuario" value={usuario} onChange={setUsuario} />
            <Input label="Perfil" value={perfil} onChange={setPerfil} />
            <Input label="Nombre" value={nombre} onChange={setNombre} />
            <button className="rounded bg-cyan-500 px-4 py-2 font-medium text-slate-900" onClick={() => setPage(0)}>Buscar</button>
          </div>
        </section>

        <section className="mt-6 overflow-hidden rounded-xl bg-white shadow-sm">
          <table className="min-w-full text-left text-sm">
            <thead className="bg-slate-100 text-slate-600">
              <tr>
                <th className="p-3">Usuario</th><th className="p-3">Nombre</th><th className="p-3">Perfil</th><th className="p-3">Empresa</th><th className="p-3">Centro</th><th className="p-3">Dominio</th><th className="p-3">Nodo</th><th className="p-3">Aut.</th>
              </tr>
            </thead>
            <tbody>
              {query.data?.content?.map((row) => (
                <tr key={row.usrSiglo21} className="border-t hover:bg-slate-50" onClick={() => navigate(`/app/usuarios/${row.usrSiglo21}`)}>
                  <td className="p-3 font-medium">{row.usrSiglo21}</td><td className="p-3">{row.usrNombre}</td><td className="p-3">{row.usrPers}</td><td className="p-3">{row.usrEmpresa}</td><td className="p-3">{row.usrCentro}</td><td className="p-3">{row.usrDominio}</td><td className="p-3">{row.usrNodo}</td><td className="p-3">{row.usrAutoriza}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <div className="mt-4 flex items-center justify-between">
          <button className="rounded border px-4 py-2" disabled={page === 0} onClick={() => setPage((value) => Math.max(0, value - 1))}>Anterior</button>
          <div>{query.data?.message ?? ''}</div>
          <button className="rounded border px-4 py-2" disabled={Boolean(query.data?.last)} onClick={() => setPage((value) => value + 1)}>Siguiente</button>
        </div>
      </main>
    </div>
  );
}

function Input({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return (
    <label className="block text-sm font-medium text-slate-700">
      {label}
      <input className="mt-2 w-full rounded border px-3 py-2" value={value} onChange={(event) => onChange(event.target.value)} />
    </label>
  );
}
