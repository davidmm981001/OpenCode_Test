import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/http';
import { AppHeader } from '../components/AppHeader';
import { MenuOptionCard, MenuOption } from '../components/MenuOptionCard';

type SecurityMenuResponse = {
  usuario: string;
  aplicacion: string;
  terminal: string;
  fechaHoraServidor: string;
  opciones: MenuOption[];
};

export function SecurityDashboard() {
  const { data } = useQuery({
    queryKey: ['security-menu'],
    queryFn: async () => (await api.get<SecurityMenuResponse>('/api/v1/seguridad/menu')).data,
    staleTime: 5 * 60 * 1000,
  });

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader title="Módulo de Seguridad" />
      <main className="mx-auto max-w-6xl p-6">
        <section className="rounded-xl bg-white p-6 shadow-sm">
          <div className="grid gap-4 md:grid-cols-4">
            <Info label="Usuario" value={data?.usuario ?? '-'} />
            <Info label="Aplicación" value={data?.aplicacion ?? '-'} />
            <Info label="Terminal" value={data?.terminal ?? '-'} />
            <Info label="Fecha/hora" value={data?.fechaHoraServidor ?? '-'} />
          </div>
        </section>
        <section className="mt-6 grid gap-4 md:grid-cols-3">
          {data?.opciones?.map((option) => <MenuOptionCard key={option.codigo} option={option} />)}
        </section>
      </main>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-xs uppercase tracking-[0.2em] text-slate-500">{label}</div>
      <div className="mt-1 text-base font-medium text-slate-900">{value}</div>
    </div>
  );
}
