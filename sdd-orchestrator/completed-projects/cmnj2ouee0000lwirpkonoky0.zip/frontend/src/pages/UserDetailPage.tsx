import { useQuery } from '@tanstack/react-query';
import { useParams } from 'react-router-dom';
import { api } from '../lib/http';
import { AppHeader } from '../components/AppHeader';

export function UserDetailPage() {
  const params = useParams();
  const userCode = params.usrSiglo21 ?? '';
  const { data } = useQuery({
    queryKey: ['usuario-detalle', userCode],
    queryFn: async () => (await api.get(`/api/v1/usuarios/${userCode}`)).data,
    enabled: Boolean(userCode),
  });

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader title={`Detalle ${userCode}`} />
      <main className="mx-auto max-w-5xl p-6">
        <section className="grid gap-4 rounded-xl bg-white p-6 shadow-sm md:grid-cols-2">
          {data ? Object.entries(data).map(([key, value]) => <Field key={key} label={key} value={String(value ?? '')} />) : <p>Cargando...</p>}
        </section>
      </main>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-xs uppercase tracking-[0.2em] text-slate-500">{label}</div>
      <div className="mt-1 text-sm text-slate-900">{value}</div>
    </div>
  );
}
