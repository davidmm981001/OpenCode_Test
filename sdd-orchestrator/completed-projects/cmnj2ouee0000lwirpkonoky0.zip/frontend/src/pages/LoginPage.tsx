import { FormEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export function LoginPage() {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('Admin123!');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    try {
      setError('');
      await login(username, password);
      navigate('/app/seguridad', { replace: true });
    } catch (e) {
      setError('No se pudo iniciar sesión');
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-100 px-4">
      <form onSubmit={onSubmit} className="w-full max-w-md rounded-2xl bg-white p-8 shadow-lg">
        <h1 className="text-3xl font-semibold text-slate-900">Ingresar</h1>
        <p className="mt-2 text-sm text-slate-500">Acceso al módulo de seguridad</p>
        <label className="mt-6 block text-sm font-medium text-slate-700">
          Usuario
          <input className="mt-2 w-full rounded border px-3 py-2" value={username} onChange={(event) => setUsername(event.target.value)} />
        </label>
        <label className="mt-4 block text-sm font-medium text-slate-700">
          Contraseña
          <input type="password" className="mt-2 w-full rounded border px-3 py-2" value={password} onChange={(event) => setPassword(event.target.value)} />
        </label>
        {error ? <p className="mt-4 text-sm text-red-600">{error}</p> : null}
        <button className="mt-6 w-full rounded bg-cyan-500 px-4 py-2 font-semibold text-slate-900">Entrar</button>
      </form>
    </main>
  );
}
