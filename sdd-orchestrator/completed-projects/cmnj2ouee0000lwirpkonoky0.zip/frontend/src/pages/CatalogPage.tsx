import { AppHeader } from '../components/AppHeader';

export function CatalogPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader title="Catálogos" />
      <main className="mx-auto max-w-4xl p-6">
        <div className="rounded-xl bg-white p-6 shadow-sm">Pantalla de catálogos</div>
      </main>
    </div>
  );
}
