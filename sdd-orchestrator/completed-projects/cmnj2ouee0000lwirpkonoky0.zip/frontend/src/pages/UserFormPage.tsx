import { FormEvent, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '../lib/http';
import { AppHeader } from '../components/AppHeader';

export function UserFormPage({ mode }: { mode: 'new' | 'edit' }) {
  const navigate = useNavigate();
  const params = useParams();
  const [form, setForm] = useState({
    usrSiglo21: params.usrSiglo21 ?? '',
    usrNombre: 'ANA PEREZ',
    usrEmpresa: '1001',
    usrCentro: '0001',
    usrPers: 'PERF0001',
    usrAutoriza: 1,
    observacion: 'Alta inicial aprobada',
    usrCid: '',
    usrCargo: '',
    usrDominio: '',
    usrNodo: '',
    usrOficinaSwift: 'MSQUTODO',
    usrBancs: '',
    termBancs: '',
  });

  async function submit(event: FormEvent) {
    event.preventDefault();
    const payload = { ...form, termBancs: form.termBancs ? Number(form.termBancs) : null, usrAutoriza: Number(form.usrAutoriza) };
    if (mode === 'new') {
      const response = await api.post('/api/v1/usuarios', payload);
      navigate(`/app/usuarios/${response.data.usrSiglo21}`, { replace: true });
    } else {
      await api.put(`/api/v1/usuarios/${params.usrSiglo21}`, payload);
      navigate(`/app/usuarios/${params.usrSiglo21}`, { replace: true });
    }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader title={mode === 'new' ? 'Nuevo Usuario' : 'Editar Usuario'} />
      <main className="mx-auto max-w-4xl p-6">
        <form onSubmit={submit} className="grid gap-4 rounded-xl bg-white p-6 shadow-sm md:grid-cols-2">
          {Object.entries(form).map(([key, value]) => (
            <label key={key} className="block text-sm font-medium text-slate-700">
              {key}
              <input className="mt-2 w-full rounded border px-3 py-2" value={String(value)} onChange={(event) => setForm((current) => ({ ...current, [key]: event.target.value }))} />
            </label>
          ))}
          <button className="rounded bg-cyan-500 px-4 py-2 font-medium text-slate-900 md:col-span-2">Guardar</button>
        </form>
      </main>
    </div>
  );
}
