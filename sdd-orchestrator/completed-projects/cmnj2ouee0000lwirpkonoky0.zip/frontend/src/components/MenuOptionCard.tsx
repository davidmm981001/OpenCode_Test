import { Link } from 'react-router-dom';

export type MenuOption = {
  codigo: number;
  titulo: string;
  ruta: string;
  habilitada: boolean;
};

export function MenuOptionCard({ option }: { option: MenuOption }) {
  return (
    <Link
      to={option.ruta}
      className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm transition hover:border-cyan-400 hover:shadow-md"
    >
      <div className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">Opción {option.codigo}</div>
      <div className="mt-2 text-lg font-medium text-slate-900">{option.titulo}</div>
      <div className="mt-1 text-sm text-slate-500">{option.ruta}</div>
    </Link>
  );
}
