import { useMemo } from 'react';
import { format } from 'date-fns';
import { useAuth } from '../context/AuthContext';

type Props = {
  title: string;
};

export function AppHeader({ title }: Props) {
  const { user, logout } = useAuth();
  const now = useMemo(() => format(new Date(), 'yyyy-MM-dd HH:mm:ss'), []);
  return (
    <header className="flex items-center justify-between border-b border-slate-200 bg-slate-900 px-6 py-4 text-white">
      <div>
        <p className="text-xs uppercase tracking-[0.3em] text-cyan-300">COBOL Test Apr3</p>
        <h1 className="text-2xl font-semibold">{title}</h1>
      </div>
      <div className="text-right text-sm">
        <div>{user?.username ?? 'Invitado'}</div>
        <div>{now}</div>
        <button className="mt-2 rounded bg-cyan-500 px-3 py-1 text-slate-900" onClick={() => void logout()}>
          Salir
        </button>
      </div>
    </header>
  );
}
