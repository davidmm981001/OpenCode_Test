#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
if [ -d "$ROOT_DIR/.pids" ]; then
  rm -f "$ROOT_DIR/.pids"/*.pid 2>/dev/null || true
fi
echo "Stopped"
