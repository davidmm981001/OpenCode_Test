# Documentación operativa

## Arquitectura
- Backend: Spring Boot 3.2.5 + JWT + JPA + Flyway.
- Frontend: React 18 + Router v6 + TanStack Query + Axios.
- Persistencia: H2 en modo PostgreSQL para ejecución local; migraciones Flyway reproducibles.

## Variables clave
- `BACKEND_PORT`, `FRONTEND_PORT`, `DB_PORT`
- `JWT_SECRET`, `JWT_ACCESS_MINUTES`, `JWT_REFRESH_DAYS`

## Flujo de sesión
1. Login en `/login`.
2. El access token vive sólo en memoria.
3. Refresh automático ante 401.
4. Logout revoca refresh token y limpia contexto.
