#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$ROOT_DIR/.pids"

BACKEND_PORT="${BACKEND_PORT:-8081}"
FRONTEND_PORT="${FRONTEND_PORT:-3001}"
DB_PORT="${DB_PORT:-5433}"

find_free_port() {
  local port="$1"
  while ss -ltn "sport = :$port" >/dev/null 2>&1; do
    port=$((port + 1))
  done
  printf '%s' "$port"
}

BACKEND_PORT="$(find_free_port "$BACKEND_PORT")"
FRONTEND_PORT="$(find_free_port "$FRONTEND_PORT")"

echo "Backend: $BACKEND_PORT"
echo "Frontend: $FRONTEND_PORT"

(cd "$ROOT_DIR/backend" && mvn -q -DskipTests package)
(cd "$ROOT_DIR/frontend" && npm install && npm run build)

echo "Build complete"
