# COBOL Test Apr3

Aplicación full-stack de seguridad modernizada desde OpenSpec.

## Requisitos
- Java 21
- Node.js 20+
- Maven 3.9+

## Ejecución local
1. Copia `.env.example` a `.env`.
2. Ajusta variables si quieres cambiar puertos o secretos.
3. Ejecuta `./run.sh`.

## Estructura
- `backend/`: API Spring Boot.
- `frontend/`: SPA React + Vite.
- `openspec/`: artefactos de alcance.

## Credenciales demo
- admin / Admin123!
- operador / Operador123!
