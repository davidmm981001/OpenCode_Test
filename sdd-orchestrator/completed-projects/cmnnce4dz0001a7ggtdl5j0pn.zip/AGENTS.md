# COBOL NEW PROJ2

## Purpose
This repository is a generated project driven by OpenSpec and OpenCode.

## Working rules
- Treat "openspec/config.yaml", "openspec/specs/project-scope/spec.md", and "openspec/changes/cmnnce4dz0001a7ggtdl5j0pn" as the source of truth for scope.
- Read the full user stories before making changes.
- Use OpenSpec artifacts to plan the work before coding.
- Create the missing app scaffold, dependencies, scripts, and build files when the implementation needs them.
- Install dependencies from inside the project when the implementation needs them.
- Keep the result runnable and verify it before finishing.
- Prefer focused changes that satisfy the stories end to end.

## User stories
## 1. Paginar resultados de la consulta general de usuarios
sourceRunId: b783ee91-1896-4c86-98b7-b9049a644dd3-1775066446394
Módulo: Consulta General de Usuarios

Como usuario del módulo de seguridad, necesito avanzar y retroceder sobre los resultados de búsqueda para revisar más registros sin perder el contexto del criterio aplicado. Esta historia se fundamenta en SSITP002.cbl, donde el programa maneja paginación con WS-PAGINAR, WS-ATRAS, el campo P02NREI/P02NREO y la tecla PF7 para volver hacia páginas anteriores. El código llena hasta 14 filas visibles del mapa SSI0201 y utiliza mensajes como “Existen mas Datos”, “No existen mas Datos” e “Inicio de los datos”. Aunque el diseño legacy depende de cursores abiertos y fetch secuencial con contador, la migración debe conservar el comportamiento de negocio: desplazarse por lotes de resultados y comunicar claramente si quedan más registros o si ya se llegó al inicio o fin. Esta historia no cubre los filtros en sí, sino la continuidad de navegación sobre los resultados ya obtenidos o recalculados en backend. El valor entregado es facilitar trabajo operativo sobre catálogos de usuarios extensos, eliminando la dependencia de teclas PF y reemplazándola por controles estándar de tabla o paginador accesible, manteniendo trazabilidad a TECLA-PF7, EMPRESA-FETCH, CENTRO-FETCH, CONSUL-FETCH, PERFIL-FETCH y NOMBRE-FETCH.

Actor: Usuario

Flujo funcional:
1. El usuario ejecuta una búsqueda con alguno de los criterios disponibles.
2. El sistema muestra la primera página de resultados.
3. El usuario navega a la siguiente página mediante controles visuales.
4. El sistema recupera y muestra el siguiente bloque de registros.
5. El usuario puede volver a una página anterior.
6. Si se intenta retroceder desde el inicio, el sistema informa que está al inicio de los datos.
7. Si no existen más registros al avanzar, el sistema informa que no existen más datos.

Pantallas / superficies: Legacy: SSI0201 / SSIM002.bms con PF7; React: /seguridad/usuarios con tabla paginada; Backend: recurso paginado de consulta de usuarios

Reglas de negocio:
- El listado visible legado maneja 14 filas por iteración de pantalla.
- PF7 en SSITP002 activa WS-ATRAS='S' y recalcula la posición.
- Al retroceder antes del inicio se muestra 'Inicio de los datos'.
- Cuando hay más datos se informa 'Existen mas Datos'.
- Cuando no hay más datos se informa 'No existen mas Datos'.

Notas técnicas:
Equivalencia funcional recomendada: fetch de cursor y contador en COBOL -> paginación por página en Spring con parámetros page y size, o keyset si el volumen lo exige; PF7 -> botón 'Anterior'; indicador P02NRE -> contador/offset visible o total de resultados. React Query debe mantener caché por combinación de filtros y página para evitar recargas completas. Mantener tamaño de página por defecto en 14 si se desea equivalencia visual inicial. Confianza: alta
Criterios:
  1. Dado una búsqueda con más de 14 resultados, cuando el usuario abre la primera página, entonces la grilla muestra el primer bloque de registros y habilita navegar a la siguiente página.
  2. Dado una búsqueda con múltiples páginas, cuando el usuario selecciona la página siguiente, entonces se muestran los registros siguientes para el mismo criterio de búsqueda.
  3. Dado una búsqueda con múltiples páginas, cuando el usuario vuelve a la página anterior, entonces la SPA actualiza la grilla con el bloque previo sin requerir recarga manual completa de página.
  4. Dado que el usuario se encuentra en la primera página, cuando intenta retroceder nuevamente, entonces el sistema muestra el mensaje 'Inicio de los datos'.
  5. Dado que el usuario se encuentra en la última página disponible, cuando intenta avanzar, entonces el sistema muestra el mensaje 'No existen mas Datos'.
  6. Dado que existen resultados adicionales después de la página actual, cuando la consulta devuelve un bloque parcial con continuidad, entonces el sistema muestra una indicación equivalente a 'Existen mas Datos'.

---

## 2. Consultar usuarios por empresa, centro, usuario, perfil o nombre
sourceRunId: b783ee91-1896-4c86-98b7-b9049a644dd3-1775066446394
Módulo: Consulta General de Usuarios

Como usuario del módulo de seguridad, necesito buscar usuarios por distintos criterios para localizar rápidamente registros de la tabla de usuarios y revisar resultados resumidos antes de editar o crear. Esta historia se basa directamente en SSITP002.cbl, descrito como “CONSULTA GENERAL DE USUARIOS TABLA T95USU03”, y en el mapa SSIM002.bms, que expone campos de búsqueda por empresa, centro, usuario, perfil, nombre, además de un contador de registros y una lista de 14 filas. El programa legacy decide dinámicamente el tipo de consulta en TECLA-ENTER según el primer criterio informado y ejecuta cursores SQL específicos: CEMPRESA, CCENTRO, CCODIGO, CPERFIL y CNOMBRE sobre M2D.T95USU03. En la modernización no se deben replicar cursores CICS ni paginación por desplazamiento manual, pero sí la intención funcional: una pantalla de consulta general con filtros claros, tabla paginada y mensajes de resultado equivalentes a “Ingrese Criterio Consulta”, “Existen mas Datos” o “No existen mas Datos”. El valor de negocio es centralizar la localización de usuarios y servir como punto de entrada al detalle o alta, respetando los criterios reales presentes en el código y sin inventar búsquedas no evidenciadas.

Actor: Usuario

Flujo funcional:
1. El usuario accede a la consulta general de usuarios.
2. El sistema muestra filtros por empresa, centro, usuario, perfil y nombre.
3. El usuario informa uno de los criterios de búsqueda y ejecuta la consulta.
4. El sistema determina el criterio aplicable y consulta la tabla de usuarios.
5. El sistema muestra una grilla con usuario, nombre, perfil, empresa, centro, dominio, nodo y autorizador.
6. Si no se informó criterio, el sistema muestra un mensaje solicitando ingresar criterio de consulta.
7. Si hay más resultados que los visibles, el sistema habilita paginación.
8. Si no hay más datos, el sistema informa el fin del resultado.

Pantallas / superficies: Legacy: SSI0201 / SSIM002.bms; React: /seguridad/usuarios; Backend: recurso de consulta sobre T95USU03

Reglas de negocio:
- Los criterios de consulta evidenciados son empresa, centro, usuario, perfil y nombre en TECLA-ENTER de SSITP002.
- Si no se ingresa ningún criterio, debe mostrarse 'Ingrese Criterio Consulta'.
- La grilla resume USR_SIGLO21, USR_NOMBRE, USR_PERS, USR_EMPRESA, USR_CENTRO, USR_NODO, USR_DOMINIO y USR_AUTORIZA.
- Para usuario y perfil se utilizan patrones tipo LIKE; para nombre también LIKE con comodines sobre espacios.
- En el legado se muestran hasta 14 filas por página lógica.

Notas técnicas:
Origen COBOL/CICS con SQL embebido y cursores por criterio. Equivalencia funcional: múltiples DECLARE CURSOR -> endpoint REST de búsqueda con parámetros opcionales y prioridad de criterio alineada con TECLA-ENTER; FETCH secuencial y contador -> paginación Spring Data Pageable con page/size, idealmente size inicial 14 para preservar volumetría visual. React debe usar formulario de filtros y tabla responsive. PostgreSQL requiere índices en usr_siglo21, usr_empresa, usr_centro, usr_pers y potencialmente búsqueda por nombre según volumen. Confianza: alta
Criterios:
  1. Dado que el usuario abre la consulta general, cuando no informa empresa, centro, usuario, perfil ni nombre y ejecuta la búsqueda, entonces el sistema muestra el mensaje 'Ingrese Criterio Consulta'.
  2. Dado que el usuario informa empresa '0001', cuando ejecuta la búsqueda, entonces la grilla muestra únicamente registros cuya empresa corresponde a '0001'.
  3. Dado que el usuario informa centro '0101' y no informa otro criterio aplicable, cuando ejecuta la búsqueda, entonces la grilla muestra únicamente registros cuyo centro corresponde a '0101'.
  4. Dado que el usuario informa el patrón de usuario 'SME%', cuando ejecuta la búsqueda, entonces la grilla muestra registros cuyo código de usuario coincide con ese patrón.
  5. Dado que el usuario informa el nombre 'JUAN%', cuando ejecuta la búsqueda, entonces la grilla muestra registros cuyo nombre coincide con ese patrón de búsqueda.
  6. Dado un conjunto de resultados mayor al tamaño de página configurado, cuando el usuario avanza o retrocede entre páginas, entonces la SPA actualiza la grilla con los datos persistidos sin requerir recarga manual completa de página.
  7. Dado que el backend devuelve resultados de consulta, cuando el frontend consume el recurso, entonces el cuerpo JSON expone solo los campos de negocio usuario, nombre, perfil, empresa, centro, dominio, nodo y autorizador.

---

## 3. Acceder al módulo de seguridad desde un menú principal navegable
sourceRunId: b783ee91-1896-4c86-98b7-b9049a644dd3-1775066446394
Módulo: Navegación de Seguridad

Como usuario del módulo de seguridad, necesito ingresar a las funciones disponibles desde una navegación moderna y comprensible, para sustituir el menú legacy basado en ingreso de opción numérica. La evidencia proviene de PRG000 en SSIM000.cbl y del mapa SSIM000.bms, donde el menú principal presenta opciones numeradas y dirige por XCTL a distintos programas, incluyendo la opción 1 hacia SSITP002 para administración de usuarios y la opción 9 hacia SSITP009. En la migración no debe replicarse la captura de códigos numéricos, sino preservar la intención funcional: ofrecer acceso al módulo de Seguridad Tecnológica y a sus subfunciones con jerarquía clara. La historia cubre la pantalla inicial, la visualización del usuario autenticado, aplicación, terminal equivalente contextual y fecha/hora de sesión, tal como el programa legacy muestra USERID, APPLID, TERMID y mensajes de error para opción inválida o no numérica. El valor entregado es reducir fricción operativa y dejar preparada una shell de navegación corporativa en React, con rutas explícitas y control de acceso en backend, manteniendo trazabilidad a la lógica de validación de 100-INICIO y 300-XCTL de PRG000.

Actor: Usuario

Flujo funcional:
1. El usuario autenticado ingresa al módulo de Seguridad.
2. El sistema muestra un dashboard o sidebar con las funciones disponibles del menú principal legado.
3. El usuario selecciona visualmente una opción, sin ingresar códigos numéricos.
4. Si selecciona Administración de Usuarios, el sistema navega a la consulta general de usuarios.
5. Si la opción no está habilitada para su perfil, el sistema informa que no tiene acceso.
6. Si ocurre un error de carga de navegación, el sistema muestra un mensaje legible y conserva el contexto de sesión.

Pantallas / superficies: Legacy: PRG00M1 / SSIM000.bms; React: /seguridad, /seguridad/usuarios; Backend: endpoint de sesión/autorización según autenticación del sistema migrado

Reglas de negocio:
- El menú legacy valida que la opción ingresada sea numérica y esté entre 1 y 10 en 100-INICIO de PRG000.
- La opción 1 dirige a SSITP002 según 300-XCTL de SSIM000.cbl.
- Deben mostrarse datos de contexto de sesión equivalentes a USERID, APPLID, terminal, fecha y hora.
- Si no existe usuario asignado en contexto, el programa legacy finaliza; en la migración debe bloquearse el acceso a la navegación autenticada.

Notas técnicas:
Tecnología origen detectada: COBOL/CICS con mapas BMS y navegación por EXEC CICS XCTL. Equivalencia funcional: menú numérico de PRG000 -> layout React con sidebar/topbar y React Router; EXEC CICS ASSIGN USERID/APPLID -> extracción de identidad desde JWT o sesión Spring Security; mensajes fijos M1MSG1/M1MSG2 -> alertas inline o toast accesibles. Se recomienda backend Spring Boot con endpoint de perfil/autorización y frontend React con rutas protegidas. Confianza: alta
Criterios:
  1. Dado un usuario autenticado con acceso al módulo de seguridad, cuando abre la ruta /seguridad, entonces visualiza un menú corporativo con la opción Administración de Usuarios sin necesidad de ingresar códigos numéricos.
  2. Dado un usuario autenticado, cuando el sistema carga la navegación principal, entonces se muestran en pantalla su identificador de usuario y el contexto de sesión equivalente al que PRG000 exponía con USERID, APPLID, terminal, fecha y hora.
  3. Dado un usuario con permiso sobre Administración de Usuarios, cuando selecciona esa opción desde la navegación, entonces la SPA navega a /seguridad/usuarios sin recargar completamente la página.
  4. Dado un usuario sin permiso sobre una opción del menú, cuando intenta acceder a la ruta correspondiente, entonces el sistema muestra un mensaje de acceso restringido y no presenta la funcionalidad protegida.
  5. Dado un valor de opción inválido en el menú legacy, cuando se migra la experiencia a React, entonces la interfaz evita esa entrada libre y solo permite acciones mediante elementos navegables visibles.
  6. Dado que el backend expone el recurso de navegación o sesión, cuando el frontend consulta ese recurso, entonces el cuerpo JSON devuelve únicamente los campos de negocio necesarios para identidad y opciones habilitadas del usuario.

---

## 4. Registrar auditoría operativa de altas, modificaciones y eliminaciones de usuarios
sourceRunId: b783ee91-1896-4c86-98b7-b9049a644dd3-1775066446394
Módulo: Administración de Usuarios

Como responsable operativo del módulo de seguridad, necesito que cada alta, modificación y eliminación de usuario deje un rastro auditable con información de contexto para control y soporte. Esta historia se ancla a WRITELOG en SSITP007.cbl y a la estructura R-T95LOG01 declarada en el mismo programa. El legacy construye un registro con número de puesto, transacción, operación, fecha de ingreso, terminal, usuario modificador, mensajería y observación, y lo envía al programa PRG008. La transacción usada para usuarios es T95USU03, con operaciones INGRESO, MODIFICACION/MODIFICACI y ELIMINACION. Además concatena en un solo campo datos del usuario afectado, nombre, perfil, centro, autorizador, valores anteriores para modificaciones, observación y respuesta funcional. La migración debe preservar este objetivo de negocio pero mejorar su forma: la auditoría debe ser estructurada, consultable y consistente con las operaciones del backend Spring, incluyendo correlation ID y usuario autenticado. El valor entregado es trazabilidad fuerte para un dominio de seguridad tecnológica, especialmente en escenarios de investigación operativa o soporte post-incidente.

Actor: Usuario

Flujo funcional:
1. El usuario ejecuta un alta, modificación o eliminación de usuario.
2. El sistema completa la operación de negocio.
3. El sistema arma un registro de auditoría con el tipo de operación, usuario afectado, usuario que ejecuta, terminal o contexto de sesión, observación y resultado.
4. El sistema persiste la auditoría.
5. Si la persistencia de auditoría falla, el sistema deja evidencia técnica para soporte y comunica el problema según severidad definida.
6. La auditoría queda disponible para revisión posterior por mecanismos operativos del sistema.

Pantallas / superficies: N/A en UI específica; evidencia legacy: WRITELOG en SSITP007.cbl y programa PRG008; Backend: servicio de auditoría sobre tabla equivalente a T95LOG01

Reglas de negocio:
- Las operaciones auditadas en SSITP007 son I, M y E.
- Para estas operaciones se usa la transacción 'T95USU03'.
- Los nombres funcionales de operación son INGRESO, MODIFICACION y ELIMINACION.
- La observación funcional del operador forma parte de la auditoría.
- En modificación se incluyen valores previos de perfil, centro y autorizador.
- El legado informa errores específicos cuando falla PRG008 o el link hacia PRG008.

Notas técnicas:
Migrar PRG008/WRITELOG a un AuditService en Spring Boot. En lugar de texto delimitado por ';', almacenar columnas estructuradas más un resumen legible. Incluir logging JSON con correlation ID y, si aplica, tabla audit_log. React no necesita una pantalla dedicada si el input no la evidencia, pero debe enviar la observación de negocio requerida por el backend. Confianza: alta
Criterios:
  1. Dado un alta de usuario exitosa, cuando la operación finaliza, entonces existe un registro de auditoría con operación 'INGRESO' y el código del usuario afectado.
  2. Dado una modificación de usuario exitosa, cuando la operación finaliza, entonces existe un registro de auditoría con operación 'MODIFICACION', el usuario afectado y la observación funcional ingresada.
  3. Dado una eliminación de usuario exitosa, cuando la operación finaliza, entonces existe un registro de auditoría con operación 'ELIMINACION' y el código del usuario afectado.
  4. Dado una modificación con cambio de perfil, centro o autorizador, cuando se consulta la auditoría resultante, entonces se observan los valores anteriores y nuevos de esos campos relevantes.
  5. Dado un error durante la persistencia de auditoría, cuando el sistema procesa la operación, entonces queda un registro técnico trazable para soporte con identificación correlacionable de la solicitud.
  6. Dado que el backend expone recursos de auditoría relacionados con usuarios si el proyecto los habilita, cuando se consulta un registro de auditoría, entonces el cuerpo JSON expone solo los campos de negocio de la operación auditada.

---

## 5. Gestionar observaciones de usuario como parte de la trazabilidad funcional
sourceRunId: b783ee91-1896-4c86-98b7-b9049a644dd3-1775066446394
Módulo: Administración de Usuarios

Como usuario del módulo de seguridad, necesito consultar, crear, actualizar y eliminar observaciones funcionales asociadas a un usuario, porque forman parte explícita del proceso administrativo y de auditoría. La evidencia está en los párrafos GETOBSER, INSERTA-OBSER, MODIFICA-OBSER y ELIMINA-OBSERVACION de SSITP007.cbl, todos operando sobre la tabla M2D.T95OBS04. El comportamiento observado es claro: al consultar un usuario se intenta recuperar CMP_OBSERVACION; al ingresar o modificar un usuario se actualiza la observación y, si el update no encuentra registro, se inserta; al eliminar, se borra la observación asociada. Además, SSIM007.bms muestra el campo M15SOLIC con longitud 50, y el encabezado del mapa documenta explícitamente que este campo fue ampliado para auditoría. El valor de negocio de esta historia es separar conceptualmente la observación como dato funcional obligatorio en ciertos flujos, sin perder la integración con alta, modificación y baja. En la solución objetivo puede presentarse dentro del formulario de usuario, pero debe tener ciclo de vida persistente y trazable como entidad dependiente del usuario.

Actor: Usuario

Flujo funcional:
1. El usuario consulta el detalle de un usuario.
2. El sistema recupera la observación asociada si existe.
3. En alta o modificación, el usuario ingresa o actualiza la observación.
4. El sistema intenta actualizar la observación existente.
5. Si no existe un registro previo, el sistema crea uno nuevo.
6. En eliminación del usuario, el sistema elimina la observación asociada.
7. El sistema refleja el estado final de la observación en pantalla.

Pantallas / superficies: Legacy: campo M15SOLIC en SSI0701; Backend: operaciones sobre T95OBS04; React: sección Observaciones dentro del detalle de usuario

Reglas de negocio:
- La observación se almacena en T95OBS04 por COD_USUARIO.
- GETOBSER devuelve espacios si no existe observación o si ocurre SQLCODE 100.
- MODIFICA-OBSER intenta UPDATE y, si no encuentra registro, ejecuta INSERTA-OBSER.
- ELIMINA-OBSERVACION elimina por COD_USUARIO.
- En alta, modificación y eliminación la observación se usa también para auditoría funcional.

Notas técnicas:
Patrón legacy tipo upsert manual: UPDATE y si falla por no encontrado, INSERT. En Spring/PostgreSQL puede implementarse con lógica de servicio o UPSERT nativo según convención del proyecto. El frontend debe mostrar la observación como campo de texto accesible, con contador visual si se define límite alineado al mapa BMS. Confianza: alta
Criterios:
  1. Dado un usuario con observación registrada en T95OBS04, cuando se consulta su detalle, entonces el campo Observaciones muestra el texto persistido.
  2. Dado un usuario sin observación previa, cuando se guarda una observación nueva desde el formulario, entonces el detalle posterior muestra la observación recién persistida sin requerir recarga manual completa de página.
  3. Dado un usuario con observación previa, cuando el operador modifica ese texto y guarda, entonces el sistema muestra el nuevo contenido persistido en el detalle.
  4. Dado un usuario con observación existente, cuando el operador elimina el usuario y la operación finaliza correctamente, entonces la observación deja de recuperarse para ese código de usuario.
  5. Dado un usuario sin observación previa, cuando el sistema intenta actualizar la observación durante una modificación, entonces crea un nuevo registro de observación asociado al usuario.
  6. Dado que el backend expone la observación asociada al usuario, cuando el frontend consume ese recurso dentro del detalle, entonces el cuerpo JSON expone solo los campos de negocio usuario y observacion.

---

## 6. Eliminar un usuario registrando observación y tratamiento del estado BANCS
sourceRunId: b783ee91-1896-4c86-98b7-b9049a644dd3-1775066446394
Módulo: Administración de Usuarios

Como usuario del módulo de seguridad, necesito eliminar un usuario de forma controlada, dejando observación y ajustando su relación BANCS cuando corresponda. La evidencia está en VALIDA-ELIMINA de SSITP007.cbl. El flujo legacy primero valida datos básicos, exige observación obligatoria, fija el tipo 'E', ejecuta el procesamiento principal de eliminación y, si existe usuario BANCS informado, marca en T95BAN04 el EST_PROCESO='TE' con la observación antes de limpiar los campos de salida de usuario y terminal BANCS. Después elimina el registro de observaciones en T95OBS04 y escribe log de operación ELIMINACION en T95LOG01. Aunque el código incluye también un párrafo ELIMINA-USR para T95BAN04, en el flujo principal la operación observada prioriza el cambio de estado BANCS y la eliminación de observaciones. La migración debe conservar esa intención exacta: la baja del usuario principal debe dejar trazabilidad y tratar el vínculo BANCS según la lógica del legado, sin inventar una cascada física distinta. El valor de negocio es asegurar una baja auditada y reversible a nivel de integración, minimizando inconsistencias con sistemas relacionados.

Actor: Usuario

Flujo funcional:
1. El usuario abre el detalle de un usuario existente.
2. Selecciona la acción de eliminar.
3. El sistema solicita confirmación y observación obligatoria.
4. El sistema ejecuta la eliminación del usuario principal según el procesamiento de negocio.
5. Si el usuario tiene datos BANCS informados, el sistema actualiza su estado BANCS a 'TE' con la observación.
6. El sistema elimina la observación almacenada del usuario en la tabla de observaciones.
7. El sistema registra la auditoría de eliminación.
8. El sistema informa el resultado final al operador.

Pantallas / superficies: Legacy: SSI0701 PF5 / SSITP007.cbl; React: /seguridad/usuarios/:usuario con modal de confirmación; Backend: baja de usuario, actualización T95BAN04, eliminación T95OBS04, auditoría T95LOG01

Reglas de negocio:
- Para eliminar, las observaciones son obligatorias: 'Ingrese Observaciones'.
- El tipo de operación de negocio es 'E'.
- Si existe usuario BANCS informado, T95BAN04 debe actualizar EST_PROCESO a 'TE' y guardar observación.
- Después de la eliminación se ejecuta ELIMINA-OBSERVACION sobre T95OBS04.
- La auditoría registra operación 'ELIMINACION' con transacción T95USU03.

Notas técnicas:
Acción crítica: en React debe usarse modal de confirmación con impacto explícito. En Spring se recomienda transacción para baja principal, actualización de estado BANCS y eliminación de observación, manteniendo consistencia. El patrón PF5-ELIMINA se reemplaza por botón Eliminar con confirmación. Dado que el código no evidencia claramente borrado físico de T95USU03 en este programa sino delegación a PRG016, describir la baja como eliminación de negocio del usuario principal según servicio migrado. Confianza: media
Criterios:
  1. Dado un usuario existente, cuando el operador pulsa Eliminar, entonces el sistema muestra un modal de confirmación que exige observación antes de confirmar la acción.
  2. Dado un intento de eliminación sin observación, cuando el operador confirma la acción, entonces el sistema muestra el mensaje 'Ingrese Observaciones'.
  3. Dado un usuario con relación BANCS informada, cuando la eliminación se confirma exitosamente, entonces el estado BANCS persistido para ese usuario queda en 'TE' con la observación registrada.
  4. Dado un usuario con observación almacenada en T95OBS04, cuando la eliminación finaliza exitosamente, entonces la observación asociada deja de estar disponible en la consulta de detalle del usuario eliminado.
  5. Dado una eliminación exitosa desde la vista de detalle o listado, cuando la SPA actualiza la información, entonces el listado o detalle refleja el estado persistido en PostgreSQL sin requerir recarga manual completa de página.
  6. Dado que el backend devuelve el resultado de la eliminación, cuando el frontend procesa la respuesta, entonces el cuerpo JSON expone solo los campos de negocio necesarios para identificar el usuario afectado y el resultado funcional.

---

## 7. Modificar un usuario preservando auditoría de cambios y observaciones
sourceRunId: b783ee91-1896-4c86-98b7-b9049a644dd3-1775066446394
Módulo: Administración de Usuarios

Como usuario del módulo de seguridad, necesito modificar datos de un usuario existente y conservar trazabilidad de lo cambiado para mantener control administrativo. La evidencia está en VALIDA-MODIFICA y WRITELOG de SSITP007.cbl. Antes de modificar, el programa guarda valores previos de perfil, centro y autorizador en LOG-PERS, LOG-CENTRO y LOG-AUTORIZA. Luego ejecuta las mismas validaciones de negocio del alta, procesa la modificación principal, actualiza observaciones en T95OBS04, resuelve el caso BANCS según exista o no registro previo en T95BAN04 y finalmente escribe un log en T95LOG01 vía PRG008 con transacción T95USU03 y operación MODIFICACION. El mensaje de auditoría concatena usuario, nombre, perfil nuevo, centro nuevo, autorizador nuevo, además de valores anteriores cuando el tipo es modificación. Esta historia entrega valor crítico para un dominio de seguridad: no solo persistir el cambio, sino dejar rastro utilizable de quién cambió qué y con qué observación funcional. La modernización debe convertir esa trazabilidad en auditoría estructurada y consultable, no en una simple réplica del string legacy.

Actor: Usuario

Flujo funcional:
1. El usuario abre el detalle de un usuario existente.
2. Modifica los campos permitidos y registra observaciones.
3. El sistema valida los datos con las mismas reglas del alta aplicables a modificación.
4. El sistema persiste los cambios del usuario.
5. El sistema actualiza o inserta la observación asociada.
6. El sistema registra la auditoría de modificación con valores relevantes anteriores y nuevos.
7. El sistema devuelve el detalle actualizado al usuario.

Pantallas / superficies: Legacy: SSI0701 PF4 / SSITP007.cbl; Backend: actualización de usuario, observación y auditoría T95LOG01; React: /seguridad/usuarios/:usuario/editar

Reglas de negocio:
- La modificación reutiliza las validaciones de VALIDA-CAMPOS.
- Debe conservarse observación funcional informada por el operador.
- En modificación se registran valores previos de perfil, centro y autorizador en la auditoría según WRITELOG.
- La transacción de auditoría usada es 'T95USU03' y la operación es 'MODIFICACION'/'MODIFICACI' en el armado legacy.
- Si falla la escritura del log vía PRG008, el legado informa error específico de log.

Notas técnicas:
Equivalencia funcional: WRITELOG con string delimitado por ';' y LINK a PRG008 -> auditoría estructurada en Spring, persistida en tabla de auditoría con columnas normalizadas y/o evento de dominio. Mantener además mensaje legible para soporte. React debe reflejar el resultado persistido tras guardar usando invalidación selectiva de React Query. Confianza: alta
Criterios:
  1. Dado un usuario existente con perfil 'PERF001' y centro '0001', cuando el operador modifica su perfil a 'PERF002' y su centro a '0002' con observación informada, entonces el detalle posterior muestra los nuevos valores persistidos sin requerir recarga manual completa de página.
  2. Dado una modificación con observación vacía, cuando el operador intenta guardar y la regla de negocio exige observación, entonces el sistema muestra el mensaje 'Ingrese Observaciones'.
  3. Dado una modificación exitosa, cuando se consulta la auditoría del usuario, entonces existe un registro que identifica la operación de modificación, el usuario afectado y la observación funcional ingresada.
  4. Dado una modificación exitosa con cambio de perfil, centro o autorizador, cuando se revisa la auditoría, entonces se observan tanto los valores anteriores como los nuevos para esos datos relevantes.
  5. Dado un error de negocio durante la modificación del usuario, cuando la persistencia no se completa, entonces el formulario mantiene los datos editados y muestra un mensaje legible para corrección.
  6. Dado que el backend devuelve el resultado de la modificación, cuando el frontend consume la respuesta, entonces el cuerpo JSON expone solo los campos de negocio actualizados y el mensaje funcional asociado.

---

## 8. Registrar y validar la relación BANCS asociada al usuario
sourceRunId: b783ee91-1896-4c86-98b7-b9049a644dd3-1775066446394
Módulo: Administración de Usuarios

Como usuario del módulo de seguridad, necesito informar correctamente los datos BANCS vinculados a un usuario para mantener sincronía operativa con ese entorno relacionado. La evidencia surge en SSITP007.cbl, especialmente en VALIDA-CAMPOS, CONSULTA-BANCS, INGRESA-USR, MODIFICA-USR y MODIFICA-ESTADO-BANCS. El sistema legacy maneja la tabla T95BAN04 con campos USR_SIGLO21, USR_BANCS, TERM_NO, COD_EMPRESA, EST_PROCESO y observación, además de mensajes específicos cuando un usuario BANCS está duplicado o no existe. La validación clave es cruzada: si se informa usuario BANCS debe existir también terminal BANCS, y si se informa terminal BANCS debe existir usuario BANCS. Durante alta, solo se inserta T95BAN04 si ambos valores están presentes; durante modificación se actualiza o inserta según exista o no el registro. Además, el sistema consulta el estado previo EST_PROCESO y trata casos especiales como 'TE' y 'TC'. El valor de esta historia es conservar la integridad del vínculo con BANCS sin obligar a todos los usuarios a tenerlo, pero asegurando consistencia cuando sí se utiliza.

Actor: Usuario

Flujo funcional:
1. El usuario ingresa o modifica un usuario del sistema.
2. Opcionalmente informa usuario BANCS y terminal BANCS.
3. El sistema valida que ambos campos relacionados estén completos si se usa integración BANCS.
4. El sistema verifica si ya existe un registro BANCS para el usuario.
5. Si no existe y los datos están completos, el sistema lo inserta.
6. Si existe, el sistema lo actualiza con el nuevo estado o datos.
7. Si se detecta duplicidad de usuario BANCS, el sistema informa el error y no confirma la operación.

Pantallas / superficies: Legacy: SSI0701 campos M15UBAN/M15TBAN; Backend: persistencia sobre T95BAN04; React: formulario de usuario con sección BANCS

Reglas de negocio:
- Usuario BANCS y terminal BANCS son dependientes entre sí; no puede informarse uno sin el otro.
- Si se informa usuario BANCS y falta terminal BANCS: 'Ingrese Terminal BANCS.'.
- Si se informa terminal BANCS y falta usuario BANCS: 'Ingrese Usuario BANCS.'.
- En alta BANCS, EST_PROCESO se carga como 'TC' cuando ambos campos están presentes.
- Si SQLCODE = -1 en inserción o modificación BANCS, se interpreta como 'Usuario Bancs Duplicado'.
- La consulta BANCS puede devolver estado previo EST_PROCESO para condicionar modificaciones.

Notas técnicas:
Migración de T95BAN04 a tabla PostgreSQL con clave por usr_siglo21 y restricción de unicidad para usr_bancs si el comportamiento de duplicado detectado por SQLCODE -1 corresponde a un índice único existente. React debe presentar la sección BANCS como opcional pero consistente. Spring debe encapsular la lógica en un servicio transaccional que decida insertar o actualizar según existencia previa. Confianza: alta
Criterios:
  1. Dado un formulario donde el usuario informa '12345678' en usuario BANCS y deja vacía la terminal BANCS, cuando intenta guardar, entonces el sistema muestra el mensaje 'Ingrese Terminal BANCS.'.
  2. Dado un formulario donde el usuario informa '12345' en terminal BANCS y deja vacío el usuario BANCS, cuando intenta guardar, entonces el sistema muestra el mensaje 'Ingrese Usuario BANCS.'.
  3. Dado un alta de usuario con usuario BANCS '12345678' y terminal BANCS '12345', cuando la operación es exitosa, entonces el detalle persistido muestra ambos datos asociados al usuario sin requerir recarga manual completa de página.
  4. Dado un usuario que ya tiene relación BANCS registrada, cuando el operador modifica esos datos y guarda correctamente, entonces el sistema muestra los nuevos valores persistidos de usuario BANCS y terminal BANCS.
  5. Dado que el valor de usuario BANCS ya existe con restricción de unicidad, cuando se intenta registrar un duplicado, entonces el sistema muestra el mensaje 'Usuario Bancs Duplicado'.
  6. Dado que el backend devuelve la relación BANCS de un usuario, cuando el frontend consume ese recurso dentro del detalle, entonces el cuerpo JSON expone solo los campos de negocio usuarioBancs, terminalBancs, estadoProceso y observacion cuando apliquen.

---

## 9. Crear un usuario validando perfil, empresa, centro y observaciones obligatorias
sourceRunId: b783ee91-1896-4c86-98b7-b9049a644dd3-1775066446394
Módulo: Administración de Usuarios

Como usuario del módulo de seguridad, necesito registrar un nuevo usuario con todas las validaciones de negocio necesarias para asegurar integridad operativa y referencial. Esta historia se basa en VALIDA-INGRESO y, sobre todo, en VALIDA-CAMPOS de SSITP007.cbl. El programa exige usuario, nombre, observaciones, perfil, empresa y centro; valida que la oficina Swift, si se informa, sea exactamente 'MSQUTODO'; transforma el indicador de autorizador a 0 o 1; verifica que el perfil exista en T95PAR02 con COD_PARAMETRO='GR' y que también exista en T01GRE20; valida empresa en T06TC005 y centro en T06TC007 usando empresa+centro. Además, cuando el tipo es ingreso, inicializa datos de signon en cero o espacios. Tras el alta principal, actualiza observaciones en T95OBS04 y opcionalmente inserta relación BANCS en T95BAN04 si se informan usuario y terminal BANCS. El valor de negocio es garantizar altas consistentes y auditables, preservando las reglas reales del sistema legacy y evitando que el frontend o el backend acepten combinaciones incompletas o inválidas.

Actor: Usuario

Flujo funcional:
1. El usuario accede al formulario de alta de usuario.
2. Completa los campos requeridos del formulario.
3. El sistema valida datos obligatorios y consistencia entre campos relacionados.
4. El sistema verifica existencia de perfil, empresa y centro en las tablas de referencia.
5. Si las validaciones son correctas, el sistema registra el usuario.
6. El sistema registra o actualiza observaciones del usuario.
7. Si se informan usuario y terminal BANCS, el sistema registra también la relación BANCS.
8. El sistema muestra el detalle persistido del nuevo usuario.
9. Si alguna validación falla, el sistema destaca el campo correspondiente y muestra el mensaje de negocio.

Pantallas / superficies: Legacy: SSI0701 PF2 / SSITP007.cbl; React: /seguridad/usuarios/nuevo; Backend: recurso de creación de usuario y persistencia en T95USU03/T95OBS04/T95BAN04

Reglas de negocio:
- Usuario es obligatorio: 'Ingrese Usuario'.
- Nombre es obligatorio: 'Ingrese Nombre de Usr.'.
- Observaciones son obligatorias: 'Ingrese Observaciones'.
- Perfil es obligatorio: 'Ingrese Perfil de VM'.
- Si se informa oficina Swift, su valor válido es únicamente 'MSQUTODO'.
- El autorizador solo admite 0 o 1 según transformación de M15SAUTI.
- El perfil debe existir en T95PAR02 con COD_PARAMETRO='GR'; si no, 'Perfil NO definido en T95PAR02'.
- El perfil debe existir también en T01GRE20; si no, 'Perfil RE no definido en T01GRE20'.
- La empresa debe existir en T06TC005; si no, 'Empresa no definida T06TC005'.
- El centro debe existir en T06TC007 para la empresa indicada; si no, 'Centro no definido T06TC007'.
- Si se informa usuario BANCS, debe informarse también terminal BANCS, y viceversa.
- En altas, fechas y horas de logon iniciales se inicializan sin datos efectivos.

Notas técnicas:
Equivalencia funcional: PF2-INGRESA -> botón Guardar en formulario React; validación BMS + backend COBOL -> Zod/Yup en frontend y Bean Validation + validadores de dominio en Spring; SQL embebido de validación -> repositorios JPA/consultas nativas puntuales. Se recomienda transacción única en Spring para alta principal, observación y relación BANCS opcional. PostgreSQL debe mantener constraints e índices de soporte para códigos de usuario, perfil, empresa y centro. Confianza: alta
Criterios:
  1. Dado un formulario de alta vacío, cuando el usuario intenta guardar sin código de usuario, entonces el sistema muestra el mensaje 'Ingrese Usuario'.
  2. Dado un formulario de alta con usuario informado pero sin nombre, cuando el usuario intenta guardar, entonces el sistema muestra el mensaje 'Ingrese Nombre de Usr.'.
  3. Dado un formulario de alta sin observaciones, cuando el usuario intenta guardar, entonces el sistema muestra el mensaje 'Ingrese Observaciones'.
  4. Dado un formulario de alta con oficina Swift informada como 'OTRAOFICINA', cuando el usuario intenta guardar, entonces el sistema muestra el mensaje 'Of.Swift: MSQUTODO'.
  5. Dado un perfil inexistente en T95PAR02 con COD_PARAMETRO 'GR', cuando el usuario intenta guardar, entonces el sistema muestra el mensaje 'Perfil NO definido en T95PAR02'.
  6. Dado una empresa inexistente en T06TC005, cuando el usuario intenta guardar, entonces el sistema muestra el mensaje 'Empresa no definida T06TC005'.
  7. Dado un alta exitosa, cuando el backend persiste el usuario y la SPA recibe la confirmación, entonces el detalle mostrado refleja el estado persistido en PostgreSQL sin requerir recarga manual completa de página.

---

## 10. Levantar el sistema migrado de seguridad en entorno local con Docker, puertos no estándar y ejecución automática de pruebas
sourceRunId: b783ee91-1896-4c86-98b7-b9049a644dd3-1775066446394
Módulo: Infraestructura y Operación

Como equipo de desarrollo y validación, necesitamos ejecutar localmente la aplicación migrada de Seguridad Tecnológica de forma reproducible para probar la consulta general, el detalle y la administración de usuarios sin dependencias manuales del entorno legacy CICS. Aunque el código fuente proviene de COBOL/CICS con mapas BMS, la salida objetivo exige React, Spring Boot y PostgreSQL listos para producción y también operables en desarrollo local. Esta historia cubre la infraestructura mínima obligatoria para el módulo derivado de PRG000, SSITP002 y SSITP007: base de datos PostgreSQL con esquema versionado, backend Spring con CORS y OpenAPI, frontend React con proxy o configuración equivalente, y scripts unificados de arranque. El valor de negocio es permitir validación temprana, automatización de pruebas y reducción de fricción de onboarding técnico. La historia no inventa funcionalidad de dominio; habilita que las funcionalidades evidenciadas en el input puedan probarse de extremo a extremo en una plataforma moderna, con puertos no estándar para evitar conflictos y con instalación de dependencias incluida en los scripts de ejecución.

Actor: Usuario

Flujo funcional:
1. El desarrollador clona el proyecto migrado.
2. Ejecuta el script unificado de arranque según su sistema operativo.
3. El script verifica prerrequisitos y puertos libres.
4. El script instala dependencias backend y frontend.
5. El script ejecuta pruebas automáticas y reporta resultados.
6. El script construye imágenes y levanta PostgreSQL, backend y frontend con Docker Compose.
7. El sistema valida health checks y conectividad entre servicios.
8. El desarrollador accede a la aplicación en los puertos configurados.

Pantallas / superficies: N/A

Reglas de negocio:
- Deben usarse puertos no estándar para evitar conflictos: backend, frontend y base de datos en puertos configurables por variables de entorno.
- El entorno local debe permitir ejecutar las funciones de Seguridad Tecnológica migradas.
- La base de datos debe inicializarse con migraciones versionadas.
- El backend debe permitir requests del frontend en desarrollo mediante configuración CORS explícita o proxy de desarrollo.

Notas técnicas:
Propuesta objetivo alineada al requerimiento: React 18 + TypeScript en puerto 3001, Spring Boot 3 en puerto 8081 y PostgreSQL 15 en puerto 5433, todos configurables por .env. Docker Compose orquesta servicios; Flyway/Liquibase versiona esquema; Spring expone /actuator/health; frontend usa proxy o configuración equivalente para desarrollo. Incluye README.md y DOCS.md con mapeo CICS->React/Spring/PostgreSQL. Confianza: alta
Criterios:
  1. Dado que se despliega la aplicación en entorno local, cuando se ejecuta el script ./run.sh (Linux/Mac) o .\run.ps1 (Windows), entonces Docker Compose levanta PostgreSQL, backend Spring y frontend React, todos los tests se ejecutan exitosamente, las dependencias se instalan automáticamente, no hay errores de CORS, y la aplicación está accesible en los puertos configurados sin conflictos.
  2. Dado que los puertos 8081, 3001 o 5433 están ocupados, cuando el desarrollador ejecuta el script de arranque, entonces el sistema informa el conflicto antes de iniciar los contenedores y muestra cómo corregirlo.
  3. Dado un entorno local sin dependencias instaladas del proyecto, cuando se ejecuta el script de arranque, entonces se instalan automáticamente las dependencias de backend y frontend necesarias para construir la solución.
  4. Dado el backend Spring levantado en desarrollo, cuando el frontend React realiza llamadas a la API del proyecto, entonces las operaciones del módulo funcionan sin bloqueo por CORS.
  5. Dado el inicio exitoso del entorno local, cuando el desarrollador consulta los health checks y accede a las URLs publicadas, entonces puede verificar conectividad entre frontend, backend y base de datos.
  6. Dado que el backend expone recursos REST del módulo migrado, cuando se consultan desde el frontend o pruebas automatizadas, entonces el cuerpo JSON de cada recurso expone solo los campos de negocio acordados.

---

## 11. Consultar el detalle completo de un usuario con datos de perfil, empresa, centro y entorno BANCS
sourceRunId: b783ee91-1896-4c86-98b7-b9049a644dd3-1775066446394
Módulo: Administración de Usuarios

Como usuario del módulo de seguridad, necesito consultar el detalle completo de un usuario para revisar sus datos operativos, organizativos, de autorización y observaciones antes de decidir una modificación. Esta historia se apoya en SSITP007.cbl y el mapa SSIM007.bms. En VALIDA-ENTER, el programa exige el ingreso de usuario, llama a PROCESA-REQUERIMIENTO con tipo 'C', y si la respuesta es OK carga múltiples campos del mapa: identificación, nombre, empresa, centro, cargo, dominio, nodo, autorizador, oficina Swift, fechas de actualización y último signon. Además, obtiene descripciones auxiliares mediante GETRECU desde T95PAR02, GETCENTRO desde T06TC007, GETEMPRESA desde T06TC005, observaciones desde T95OBS04 y datos BANCS desde T95BAN04 mediante CONSULTA-USR/CONSULTA-BANCS. El valor entregado es ofrecer una vista única y clara del usuario, con información contextual legible en lugar de códigos crudos cuando exista catálogo asociado. Debe respetarse la validación principal de que el código de usuario sea obligatorio y la capacidad de mostrar mensajes de negocio provenientes del procesamiento principal PRG016, sin inventar campos no presentes en el legado.

Actor: Usuario

Flujo funcional:
1. El usuario abre el detalle de administración de usuarios.
2. Ingresa o selecciona un código de usuario para consultar.
3. El sistema valida que el usuario haya sido informado.
4. El sistema recupera el registro principal del usuario y los datos complementarios de perfil, empresa, centro, observaciones y BANCS.
5. El sistema muestra los datos completos en el formulario.
6. Si el usuario no fue informado, el sistema solicita ingresarlo.
7. Si la consulta no encuentra datos o retorna error de negocio, el sistema muestra el mensaje correspondiente en pantalla.

Pantallas / superficies: Legacy: SSI0701 / SSIM007.bms; React: /seguridad/usuarios/:usuario; Backend: recurso de detalle de usuario y consultas auxiliares sobre T95USU03, T95PAR02, T06TC005, T06TC007, T95OBS04, T95BAN04

Reglas de negocio:
- En VALIDA-ENTER y VALIDA-DATOS, el usuario es obligatorio; si falta, se muestra 'Ingrese Usuario'.
- La consulta principal se ejecuta con tipo 'C' vía PROCESA-REQUERIMIENTO hacia PRG016.
- La descripción del perfil se obtiene de T95PAR02 con COD_PARAMETRO='GR'.
- La descripción del centro se obtiene de T06TC007 por empresa y centro.
- La descripción de empresa se obtiene de T06TC005 por código de empresa.
- Las observaciones se obtienen de T95OBS04 por COD_USUARIO.
- Los datos BANCS se obtienen de T95BAN04 por USR_SIGLO21.

Notas técnicas:
Origen COBOL/CICS con COMMAREA y múltiples lecturas SQL auxiliares. Equivalencia funcional: mapa SSI0701 -> formulario React de detalle; PROCESA-REQUERIMIENTO/PRG016 -> endpoint REST de detalle orquestado por un servicio Spring; GETRECU/GETCENTRO/GETEMPRESA -> enriquecimiento en backend o composición de DTO; datos de auditoría y signon se exponen como campos de solo lectura. Mapeo de tipos: PIC X(n) a String, campos numéricos de empresa/centro/cid a String en API para preservar ceros a la izquierda. Confianza: alta
Criterios:
  1. Dado que el usuario abre el detalle sin informar código de usuario, cuando ejecuta la consulta, entonces el sistema muestra el mensaje 'Ingrese Usuario'.
  2. Dado que existe el usuario 'USER0001' en la base de datos, cuando se consulta su detalle, entonces el formulario muestra su código, nombre, empresa, centro, perfil, cargo, dominio, nodo y autorizador.
  3. Dado que el perfil del usuario existe en T95PAR02 con COD_PARAMETRO 'GR', cuando se visualiza el detalle, entonces se muestra también la descripción asociada al perfil.
  4. Dado que la empresa y el centro del usuario existen en T06TC005 y T06TC007, cuando se visualiza el detalle, entonces se muestran las descripciones legibles de empresa y centro junto a sus códigos.
  5. Dado que el usuario tiene observaciones registradas en T95OBS04, cuando se consulta el detalle, entonces el campo observaciones muestra el texto almacenado para ese usuario.
  6. Dado que el usuario tiene relación BANCS en T95BAN04, cuando se consulta el detalle, entonces se muestran el usuario BANCS y la terminal BANCS asociados.

---

## 12. Seleccionar un usuario desde la consulta general para abrir su detalle
sourceRunId: b783ee91-1896-4c86-98b7-b9049a644dd3-1775066446394
Módulo: Consulta General de Usuarios

Como usuario del módulo de seguridad, necesito seleccionar un registro desde la consulta general para abrir su mantenimiento detallado y continuar con consulta o edición. La evidencia está en SSITP002.cbl y SSIM002.bms: la grilla expone un campo de selección, y TECLA-PF4 valida que P02SELI esté entre 1 y 14, que exista SSI02-CLAVE(I), y luego transfiere control a SSITP007 por XCTL con P015-COMMAREA='2' y P015-SIGLO21 cargado. Este patrón muestra un flujo claramente dividido entre listado y detalle. En la migración no corresponde mantener un selector numérico de fila, sino ofrecer acciones de fila como “Ver” o “Editar” sobre una tabla React. El valor de negocio es reducir errores de selección y permitir continuidad operacional entre la búsqueda general y el formulario detallado de usuario, respetando la validación original de que la fila exista realmente. También debe contemplarse el flujo de alta, ya que TECLA-PF2 en SSITP002 abre SSITP007 con P015-COMMAREA='0', es decir, un formulario limpio para ingreso. La historia cubre la transición entre listado y detalle, no las reglas internas de mantenimiento.

Actor: Usuario

Flujo funcional:
1. El usuario ejecuta una búsqueda y visualiza la grilla de resultados.
2. El usuario elige una fila válida mediante una acción contextual.
3. El sistema abre el detalle del usuario seleccionado con sus datos cargados.
4. Si la fila seleccionada no contiene un usuario válido, el sistema informa error de selección.
5. El usuario también puede iniciar el alta de un nuevo usuario desde la consulta general.
6. El sistema abre un formulario vacío de administración para alta.

Pantallas / superficies: Legacy: SSI0201 PF2/PF4 hacia SSITP007; React: /seguridad/usuarios, /seguridad/usuarios/nuevo, /seguridad/usuarios/:usuario

Reglas de negocio:
- PF4 en SSITP002 solo permite selección si P02SELI > 0 y < 15.
- La fila debe contener SSI02-CLAVE(I) distinta de espacios; en caso contrario se muestra 'Seleccion Errada'.
- PF2 abre SSITP007 en modo alta con P015-COMMAREA='0'.
- PF4 abre SSITP007 con el código de usuario seleccionado y P015-COMMAREA='2'.

Notas técnicas:
Equivalencia funcional: selección numérica P02SELI y XCTL a SSITP007 -> acciones de fila en tabla React y navegación con React Router a rutas semánticas; COMMAREA de transferencia -> parámetro de ruta o estado de navegación; apertura de alta -> ruta /seguridad/usuarios/nuevo. Backend REST debe exponer consulta de detalle por identificador de usuario. Confianza: alta
Criterios:
  1. Dado que la grilla contiene un usuario con código 'USER0001', cuando el usuario selecciona la acción Ver o Editar en esa fila, entonces la aplicación navega al detalle de 'USER0001'.
  2. Dado que la grilla no contiene datos en la fila elegida, cuando el usuario intenta abrir el detalle de esa fila, entonces el sistema muestra un mensaje equivalente a 'Seleccion Errada'.
  3. Dado un usuario seleccionado desde la consulta general, cuando se abre su detalle, entonces el formulario muestra los datos persistidos del usuario elegido.
  4. Dado que el usuario se encuentra en la consulta general, cuando pulsa la acción Nuevo usuario, entonces la aplicación navega al formulario de alta con campos iniciales vacíos.
  5. Dado que el usuario regresa desde el detalle a la consulta general, cuando vuelve al listado, entonces se conservan el criterio de búsqueda y la página previamente utilizados dentro de la SPA.
  6. Dado que el backend expone el detalle de un usuario seleccionado, cuando el frontend consume ese recurso, entonces el cuerpo JSON expone solo los campos de negocio necesarios para el formulario detallado.
