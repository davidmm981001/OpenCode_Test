# Inventory asp v2

## Purpose
This repository is a generated project driven by OpenSpec and OpenCode.

## Working rules
- Treat "openspec/config.yaml", "openspec/specs/project-scope/spec.md", and "openspec/changes/cmnf0sw760003kvr3xhqh5r37" as the source of truth for scope.
- Read the full user stories before making changes.
- Use OpenSpec artifacts to plan the work before coding.
- Create the missing app scaffold, dependencies, scripts, and build files when the implementation needs them.
- Install dependencies from inside the project when the implementation needs them.
- Keep the result runnable and verify it before finishing.
- Prefer focused changes that satisfy the stories end to end.

## User stories
## 1. Gestionar productos del inventario para el usuario administrador
Módulo: Inventory

Permitir al usuario administrador listar todos los productos existentes en el inventario, agregar nuevos productos y eliminar productos existentes, asegurando la integridad del inventario y la validación de datos. Estas funcionalidades están implementadas en la capa de negocio mediante el servicio ProductoService y expuestas a la capa de presentación mediante controles Web Forms en la página Default.aspx. La operación de agregar un producto requiere validar la presencia del nombre y que cantidades y precios sean valores numéricos válidos, mostrando mensajes de error en el modal si no se cumple. La eliminación se realiza mediante la eliminación directa por id y refresca el listado. La fuente son las clases ProductoService.cs, Default.aspx.cs, Producto.cs y repositorio ProductoRepository.cs en el contexto de MiInventario.BLL y la UI WebFormsApp.

Actor: Administrador de inventario

Flujo funcional:
1. El usuario carga la página Default.aspx y se muestran todos los productos mediante service.ObtenerTodos(). 2. El usuario completa el formulario modal para agregar un producto con nombre, cantidad y precio. 3. Al guardar, se valida que el nombre esté presente y cantidades y precios sean numéricos válidos. 4. Si todo es correcto, se agrega el producto y se recarga la vista. 5. Si hay errores, se muestran mensajes y el modal permanece abierto. 6. El usuario puede eliminar un producto desde la tabla; tras confirmar la acción se elimina el producto por id y se actualiza la vista. Todo el flujo garantiza la coherencia y experiencia de usuario adecuada.

Pantallas / superficies: Default.aspx (gvProductos grid, modalNuevoProducto modal), Default.aspx.cs

Reglas de negocio:
No se admite producto sin nombre; Nombre no puede ser vacío o solo espacios. Cantidad y precio deben ser número válidos. Eliminar producto valida id existente y actualiza vista. Se deben mostrar mensajes específicos para errores de formato y ausencias de datos.

Notas técnicas:
La arquitectura usa patrón repositorio con ProductoRepository para acceso a la base de datos. El contexto es InventarioContext con EF DbContext. Se utiliza ASP.NET Web Forms con GridView para listado y modal Bootstrap para captura. Se implementan manejadores servidor en código atrás Default.aspx.cs. Servicios BLL implementan lógica de negocio y validaciones. Async Postbacks usan ScriptManager. Validaciones se manejan en capa servicio y en eventos de UI.
Criterios:
  1. Dado que el usuario está en Default.aspx y existen productos, cuando carga la página, entonces se muestran en el GridView todos los productos desde la base de datos.
  2. Dado que el usuario abre el modal para agregar producto, cuando ingresa nombre vacío o solo espacios, entonces se muestra error 'Nombre requerido' y no se añade producto.
  3. Dado que el usuario ingresa cantidad o precio no numérico en el modal, cuando intenta guardar, entonces se muestra mensaje de error 'Revise cantidad y precio: deben ser números válidos' y el modal permanece abierto.
  4. Dado que el usuario ingresa nombre válido y valores numéricos para cantidad y precio, cuando guarda en el modal, entonces el producto se agrega al inventario y el listado se refresca sin errores.
  5. Dado que el usuario selecciona eliminar un producto del GridView, cuando confirma la acción, entonces el producto se elimina de la base de datos y el listado se actualiza.
  6. Dado un producto ya eliminado, si el usuario intenta eliminarlo nuevamente, entonces no ocurre error y la vista se mantiene consistente.

---

## 2. Intercambiar vistas desktop y móvil con ViewSwitcher control
Módulo: WebFormsUI

Se proporciona a los usuarios la posibilidad de cambiar entre una vista móvil y una vista desktop mediante el control ViewSwitcher. Este control determina en base a la petición HTTP actual si la vista activa es móvil o no usando WebFormsFriendlyUrlResolver.IsMobileView. Al ejecutar Page_Load, configura CurrentView y AlternateView con los valores correspondientes (Mobile/Desktop). También construye una URL para alternar la vista que conserva la URL actual para regresar tras el cambio (query string ReturnUrl). Si la configuración de rutas FriendlyUrls no está disponible o el control no está habilitado, se oculta el control para evitar confusión. La fuente está en ViewSwitcher.ascx.cs y se usa en Master Pages.

Actor: Usuario Navegador

Flujo funcional:
1. En Page_Load, el control evalúa el contexto HTTP actual para determinar si la vista es móvil o desktop. 2. Se asigna CurrentView al valor activo, AlternativeView al opuesto. 3. Consulta rutas configuradas para FriendlyUrls para obtener URL de cambio. 4. Construye SwitchUrl que incluye la ruta para cambiar vista más query string ReturnUrl (la URL actual codificada). 5. Show u oculta el control según disponibilidad de rutas. 6. Al hacer click en el enlace del control el navegador se redirige a SwitchUrl y automáticamente se cambia la vista usada.

Pantallas / superficies: ViewSwitcher.ascx, incluidas en Site.Master o Site.Mobile.Master

Reglas de negocio:
La vista móvil y desktop deben estar disponibles para poder cambiar. Si no está la ruta para cambio o está deshabilitado, el control queda invisible. SwitchUrl conserva URL solicitada para regresar tras cambio. Los valores CurrentView y AlternateView indican cuál es la vista activa y la alternativa.

Notas técnicas:
Uso del namespace Microsoft.AspNet.FriendlyUrls.Resolvers y RouteTable para manejar rutas amigables y conmutación de vistas. Control de usuario WebForms personalizado que se puede reutilizar en master page. URL construida con GetRouteUrl y agregando ReturnUrl con HttpUtility.UrlEncode para preservar contexto navegación.
Criterios:
  1. Dado que la petición HTTP actual es detectada como vista móvil, entonces CurrentView es 'Mobile' y AlternateView es 'Desktop'.
  2. Dado que la petición HTTP actual es vista desktop, entonces CurrentView es 'Desktop' y AlternateView es 'Mobile'.
  3. Dado que la ruta 'AspNet.FriendlyUrls.SwitchView' está registrada, cuando carga el control, construye SwitchUrl usando esta ruta más query string con ReturnUrl apuntando a la URL actual.
  4. Dado que la ruta no está registrada o FriendlyUrls deshabilitado, entonces el control ViewSwitcher se oculta (Visible = false).
  5. Dado que el usuario hace click en el enlace generado por SwitchUrl, entonces la petición cambia la vista y retorna a la URL previa codificada en ReturnUrl.
  6. Dado que la vista alterna no está disponible, entonces el control no se muestra para evitar confusión en el usuario.

---

## 3. Configuración inicial y registro de rutas y bundles en la aplicación Web Forms
Módulo: WebFormsUI

Al inicio de la aplicación ASP.NET Web Forms, el sistema realiza el registro de rutas amigables para URLs y las definiciones de bundles para optimización de recursos (scripts y estilos). La clase Global.asax.cs gestiona en Application_Start el registro invocando RouteConfig.RegisterRoutes y BundleConfig.RegisterBundles. Las rutas usan FriendlyUrlSettings para redirecciones permanentes para vistas amigables. Los bundles agrupan scripts comunes de sistema WebForms, MS Ajax, Modernizr y Bootstrap para mejorar carga y administración. La fuente está en WebFormsApp/Global.asax.cs, App_Start/RouteConfig.cs y BundleConfig.cs, que configuran estructura base para navegación y arquitectura front-end con Web Forms.

Actor: Sistema / Administrador de Plataforma

Flujo funcional:
1. Al iniciar la aplicación, el método Application_Start se ejecuta. 2. Se registra configuración de rutas amigables para URLs via RouteConfig, incluyendo modo de redirección permanente. 3. Se registran agrupaciones (bundles) de scripts para conjuntos lógicos: WebForms, MsAjax, Modernizr y Bootstrap. 4. Estos bundles se utilizan para referenciar scripts minificados y optimizados en las páginas UI.

Pantallas / superficies: N/A (Configuración Global)

Reglas de negocio:
Las rutas amigables se aplican para mejorar UX y SEO. El orden de bundles es importante por dependencias. Se debe registrar bundles de scripts básicos para correcto funcionamiento.

Notas técnicas:
Uso de Microsoft.AspNet.FriendlyUrls para rutas amigables. Bundles usan System.Web.Optimization con ScriptBundle. Scripts referenciados conocidos como WebForms/*.js y librerías externas. Permite optimización y mantenimiento sencillo de recursos web.
Criterios:
  1. Dado que la aplicación inicia, cuando se llama Application_Start, entonces se registran las rutas amigables con RedirectMode.Permanent.
  2. Dado que hay scripts Web Forms base, cuando se registran bundles, entonces el bundle ~/bundles/WebFormsJs contiene los scripts WebForms.js, WebUIValidation.js, GridView.js, TreeView.js, etc.
  3. Dado que se registran bundles, cuando la aplicación solicite estos, los archivos estarán disponibles concatenados y minificados en el orden registrado.
  4. Dado que el bundle ~/bundles/MsAjaxJs existe, cuando se usa la aplicación, los scripts relacionados a MS AJAX se cargan desde dicho bundle.
  5. Dado que las rutas amigables están registradas, entonces URLs serán redirigidas permanentemente a versión amigable sin incluir parámetros antiestéticos.
  6. Dado que la configuración existe, cuando se desee agregar nuevas scripts o rutas, se deben respetar el orden y métodos definidos en BundleConfig y RouteConfig.

---

## 4. Eliminar productos del inventario mediante GridView desde interfaz web
Módulo: Inventory

El usuario administrador puede eliminar productos existentes haciendo clic en el botón eliminar en la fila correspondiente dentro del GridView gvProductos en Default.aspx. El evento RowDeleting captura el id del producto para eliminar, llama al servicio ProductoService.Eliminar que delega en ProductoRepository la eliminación desde la base de datos por id. Tras la operación se recarga la lista para reflejar los cambios. Esto permite mantener el inventario actualizado y evitar productos obsoletos o erróneos. El proceso asegura que solo se elimina producto si realmente existe. Toda la lógica se encuentra entre Default.aspx.cs (evento), ProductoService.cs y ProductoRepository.cs.

Actor: Administrador de inventario

Flujo funcional:
1. Usuario accede al listado de productos. 2. En la fila deseada, el usuario acciona botón eliminar. 3. Evento RowDeleting captura el id del producto e invoca ProductoService.Eliminar(id). 4. ProductoService delega en ProductoRepository.Delete(id) que elimina la entidad de la base si existe. 5. Tras eliminar, en UI se vuelve a llamar a Cargar() para refrescar el listado actual de productos.

Pantallas / superficies: Default.aspx GridView gvProductos con eventos RowDeleting

Reglas de negocio:
Solo eliminar producto si el id existe. Actualizar listado tras eliminación. Manejar el caso sin errores si id no existe.

Notas técnicas:
Evento RowDeleting de GridView se enlaza a controlador en código subyacente. ProductoRepository usa EF DbContext para Find y Remove. Guardado con SaveChanges(). Error controlado en capa negocio y UI.
Criterios:
  1. Dado un producto con Id 5, cuando el usuario pulsa eliminar en esa fila, entonces ProductoRepository elimina la entidad con Id 5 de la base.
  2. Dado que el producto a eliminar no existe, cuando se llama a eliminar con ese Id, entonces no se lanza excepción y la lista de productos se mantiene.
  3. Dado que se elimina un producto válido, cuando la operación termina, entonces la lista se actualiza mostrando los productos restantes.
  4. Dado que un producto fue eliminado, cuando se vuelve a cargar la página, entonces ese producto ya no aparece en el listado.
  5. Dado que el usuario inicia acción eliminar, entonces el sistema requiere confirmación implícita desde UI o no realiza acción si no es confirmada (si aplica).
  6. Dado que ocurre un error inesperado en la eliminación, se notifica al usuario y no se actualiza el listado erróneamente.

---

## 5. Mostrar listado de productos en GridView para revisión y manejo
Módulo: Inventory

Al acceder al módulo de inventario, el usuario visualiza un listado actualizado de productos almacenados. Este listado se obtiene mediante la llamada a ProductoService.ObtenerTodos(), que consulta la base de datos mediante Entity Framework para devolver la lista completa mapeada a objetos de negocio Producto. La tabla visualiza Id, Nombre, Cantidad y Precio de cada producto. La operación es realizada al cargar la página y luego de cada operación de alta o baja para mantener la información fresca. La referencia principal está en Default.aspx.cs en el método Cargar(), i.e., la interacción típica para mostrar datos relacionales en una tabla usando GridView.

Actor: Administrador de inventario

Flujo funcional:
1. Usuario accede a la página Default.aspx. 2. Evento Page_Load detecta primer acceso (!IsPostBack). 3. Se invoca Cargar() que llama ProductoService.ObtenerTodos(). 4. ProductoService.ObtenerTodos() obtiene entidades desde ProductoRepository.GetAll() y las mapea a objetos Producto. 5. Los datos se asignan al DataSource del GridView gvProductos. 6. Se ejecuta DataBind() para mostrar la información tabulada. 7. La tabla presenta las columnas Nombre, Cantidad y Precio para cada producto.

Pantallas / superficies: Default.aspx GridView gvProductos

Reglas de negocio:
Mostrar todos los productos guardados; Sin paginado ni filtros; El listado debe actualizarse tras alta o baja.

Notas técnicas:
GridView enlazado en modo clásico DataSource = lista y DataBind() para actualizar. Servicio y repositorio implementados con EF DbContext. ProductoService transforma entidades ProductoEntity a POCO Producto para UI.
Criterios:
  1. Dado que existen 10 productos en la base, cuando carga Default.aspx, entonces en el GridView se muestran 10 filas con sus respectivos nombres, cantidad y precio.
  2. Dado que no hay productos en la base, cuando se carga la página, entonces el GridView aparece vacío sin errores.
  3. Dado que se agrega o elimina un producto, cuando se ejecuta Cargar(), entonces el GridView muestra la lista actualizada sin necesidad de refrescar toda la página.
  4. Dado que el GridView está visible, entonces las columnas Nombre, Cantidad y Precio están visibles y correctamente pobladas.
  5. Dado que la consulta a la base falla, entonces se lanza excepción capturada fuera de este flujo y no se muestra listado.
  6. Dado que la página es accedida por primera vez, entonces la carga se realiza solo una vez y no en cada postback.

---

## 6. Validar y notificar errores en formulario de productos
Módulo: WebFormsUI

Cuando el usuario administra productos, es crítico validar que los campos del formulario para nuevo producto sean correctos y consistentes. La validación central en ProductoService asegura que el nombre no esté vacío y que cantidad y precio sean valores numéricos válidos. En la interfaz, los errores de validación se capturan y notifican por medio de etiquetas de texto dentro del modal con la clase CSS que controla la visibilidad y estilo de error (class 'inv-modal-error'). El control lblModalError visualiza mensajes útiles para corregir datos. Esta interacción mejora la calidad de datos ingresados, evitando productos inválidos en el sistema y problemas de integridad del inventario. La fuente se refiere a Default.aspx.cs en el manejo de eventos y ProductoService.cs en la capa de negocio.

Actor: Administrador de inventario

Flujo funcional:
1. Usuario abre modal nuevo producto y completa campos. 2. Al pulsar guardar, la capa UI captura el evento. 3. Se intenta agregar producto al servicio ProductoService.Agregar, que valida datos. 4. Si el nombre es nulo o vacío, lanza excepción capturada. 5. Si la cantidad o precio no son parseables como números, se captura FormatException. 6. El mensaje de error se muestra en lblModalError con el estilo adecuado (visible y marcado en rojo). 7. El modal no se oculta y se espera corrección. 8. En caso de éxito, se limpia formulario, se oculta modal y se refresca grid.

Pantallas / superficies: Default.aspx modal nuevo producto, Default.aspx.cs

Reglas de negocio:
Nombre obligatorio, no null ni espacios. Cantidad y precio deben poder parsearse como int y decimal respectivamente. Mensajes de error claros según excepción. Modal se mantiene visible en error para corrección.

Notas técnicas:
Validación combinada desde UI y servicio. En UI se parsean cantidad y precio con int.Parse y decimal.Parse. ProductoService lanza excepción para nombre no válido. Uso de ClientScript para mostrar u ocultar el modal con jQuery. Etiqueta lblModalError CSS cambia dinamicamente clase para visualización y estilos con OnPreRender.
Criterios:
  1. Dado que el usuario deja el campo nombre vacío y pulsa guardar, cuando se llama a ProductoService.Agregar, entonces se lanza excepción con mensaje 'Nombre requerido'.
  2. Dado que el usuario ingresa un valor no numérico en cantidad o precio, cuando pulsa guardar, entonces se captura FormatException y se muestra mensaje 'Revise cantidad y precio: deben ser números válidos.'
  3. Dado que ocurre cualquier excepción no esperada en agregar producto, cuando se captura, entonces se muestra el mensaje 'No se pudo guardar: ' seguido del mensaje de error generado.
  4. Dado que el formulario contiene datos válidos y producto se agrega con éxito, entonces el formulario se limpia, se oculta el modal y la tabla se actualiza para mostrar el nuevo producto.
  5. Dado que hay error al agregar producto, entonces el modal permanece visible y el usuario puede corregir los errores para intentar de nuevo.
  6. Dado que el modal está cerrado y no hay mensajes de error, entonces el control lblModalError tiene clase 'inv-modal-error hide' para ocultarlo.
