# Project Context

## Project
COBOL DEMO - Banco Internacional

## User Stories
<!-- nexti-sdd-meta {"projectId":"proj-0871bf58-c8a5-453f-bb56-15e3413ad979","sourceRunId":"run-70da8a3e-7318-42df-8d8f-ea5ce874e13c"} -->

## 1. Scaffolding del Proyecto e Infraestructura Base para el equipo de inventario
sourceRunId: run-70da8a3e-7318-42df-8d8f-ea5ce874e13c
Módulo: Infraestructura Base

Como base obligatoria del sistema de inventario, se debe crear una solución completa con /backend y /frontend que arranque localmente mediante ./run.sh y quede accesible desde el navegador en puertos libres. Esta historia nace de la migración de una solución WebForms/Entity Framework observada en Global.asax.cs, App_Start/RouteConfig.cs, App_Start/BundleConfig.cs, InventarioContext.cs y la estructura general de WebFormsApp, donde el sistema original dependía de inicialización centralizada, rutas amigables y un contexto de datos con una única entidad Producto. El objetivo aquí no es reproducir la UI legacy, sino garantizar una plataforma moderna, compilable y operable antes de implementar las funcionalidades. Debe incluir backend Spring Boot 3 con arquitectura hexagonal, frontend React 18 con Vite y Tailwind, PostgreSQL con Flyway y semillas mínimas, seguridad JWT, health checks, OpenAPI, CORS dinámico, manejo global de errores, auditoría y scripts cross-platform. La pantalla inicial visible al usuario será el Layout con navegación base y mensaje de bienvenida del dominio inventario. También se deben contemplar README.md y DOCS.md con troubleshooting, modelo relacional inicial y trazabilidad de migración. Decisión conservadora documentada: aunque el código fuente no evidencia autenticación legacy, se incluye seguridad mínima porque es requisito transversal del stack objetivo y habilita las historias posteriores sin bloquear el arranque local.

Actor: Equipo técnico de implementación

Flujo funcional:
1. El usuario ejecuta ./run.sh desde la raíz del proyecto.
2. El script valida prerrequisitos, instala dependencias faltantes cuando sea posible, resuelve artefactos Maven y paquetes NPM.
3. El script detecta puertos libres para base de datos, backend y frontend, persiste los valores en .pids/ports.env y crea logs/.
4. Se crea o prepara PostgreSQL, se ejecutan migraciones Flyway y seed inicial con usuario admin.
5. Se levanta el backend, se valida /actuator/health, /v3/api-docs y el endpoint protegido base.
6. Se levanta el frontend con hot-reload y el usuario abre la aplicación en el navegador.
7. Desviación: si no hay puertos libres en el rango permitido, el script falla con mensaje explícito sin dejar procesos huérfanos.
8. Desviación: si backend o frontend no superan sus health checks, el script muestra las últimas líneas del log correspondiente y termina con error controlado.
9. Desviación: si smoke tests o tests completos fallan, se registran en background pero la app permanece corriendo.

Pantallas / superficies: Rutas React: /, /login, /productos, /about, /contact, /pendiente. Componentes: App.tsx, Layout.tsx, ProtectedRoute.tsx, FuncionalidadPendiente.tsx. Endpoints Spring: GET /actuator/health, GET /v3/api-docs, GET /swagger-ui/index.html, POST /auth/login, POST /auth/refresh, GET /api/v1/. Botón retorno: definido como patrón reutilizable para pantallas secundarias, con destino configurable.

Reglas de negocio:
1. Ningún puerto puede estar hardcodeado en configuración, scripts o tests; deben salir de variables de entorno con defaults por perfil dev.
2. El script run.sh debe buscar puertos libres iniciando en 5433 para DB, 8081 para backend y 3001 para frontend, incrementando hasta 20 intentos.
3. Los tres puertos asignados deben ser distintos entre sí y persistirse en .pids/ports.env.
4. La app se considera lista solo si backend responde health=UP, api-docs contiene openapi 3 y /api/v1/ retorna 401 o 403.
5. El frontend se considera listo solo si GET / devuelve HTML y contiene div#root.
6. Debe existir usuario admin sembrado con username admin y password admin123 en hash bcrypt funcional.
7. Los smoke tests nunca deben detener la app por fallos; solo reportan estado actual.
8. Los tests completos nunca deben bloquear la ejecución ni apagar procesos.
9. stop.sh y stop.ps1 deben leer PIDs guardados, intentar SIGTERM/Stop-Process, esperar y forzar cierre si sigue vivo.
10. Debe existir estructura hexagonal backend con capas domain, application, infrastructure y api.
11. Debe existir TypeScript estricto en frontend y configuración Tailwind con tokens personalizados no default.
12. La primera pantalla visible al abrir el navegador debe ser un layout funcional y no una página vacía o error.
13. Deben instalarse todas las dependencias maestras backend y frontend indicadas en el mandato.
14. El JAR empaquetado debe superar 40MB y node_modules debe incluir más de 50 paquetes directos/instalados.
15. Debe existir endpoint base protegido /api/v1/ para smoke test de seguridad activa.
16. Debe existir soporte CORS dinámico para permitir al frontend consumir backend desde el puerto detectado.
17. Deben incluirse archivos de documentación operativa y arquitectura desde la primera historia.
18. Debe mantenerse compatibilidad local sin contenedores ni Docker.

Notas técnicas:
Endpoint API: GET /api/v1/ -> response 401/403 sin token; GET /actuator/health -> {status:string}; POST /auth/login request {username:string, password:string} required, response {token:string, refreshToken:string, expiresIn:number, roles:string[]}; POST /auth/refresh request {refreshToken:string} required, response igual. JSON de error estándar {timestamp,status,code,message,details?,path}. Tabla DB: V001__baseline_schema.sql crea t95usu03_usuarios {usr_id bigserial PK, usr_username varchar(50) NOT NULL UNIQUE, usr_password_hash varchar(255) NOT NULL, usr_roles varchar(200) NOT NULL, usr_activo boolean NOT NULL default true, usr_created_at timestamp NOT NULL default now(), usr_updated_at timestamp NOT NULL default now()} y t95prd01_productos {prd_id bigserial PK, prd_nombre varchar(150) NOT NULL, prd_cantidad integer NOT NULL, prd_precio numeric(15,2) NOT NULL, prd_created_at timestamp NOT NULL default now(), prd_updated_at timestamp NOT NULL default now()}. Auth/Authz: JWT y refresh token, roles ROLE_ADMIN y ROLE_OPERADOR, públicos /auth/** /actuator/health /v3/api-docs/** /swagger-ui/**, protegidos /api/v1/**. Error mapping: MethodArgumentNotValidException->400, EntityNotFoundException->404, DataIntegrityViolationException->409, AccessDeniedException->403, genérico->500 con ErrorResponse inmutable. Flyway: V001__baseline_schema.sql, V999__seed_datos_iniciales.sql. Paquetes: com.bancointernacional.inventario.{domain,application,infrastructure,api} y submódulo auth equivalente. Transacciones: @Transactional en services de escritura, readOnly en consultas base cuando aplique. Cache/estado: React Query con staleTime inicial 30s, gcTime 5m, invalidación por claves ['productos'] y ['auth']; AuthContext mantiene sesión en memoria. DEPENDENCIAS MAVEN: spring-boot-starter-web, data-jpa, security, validation, actuator, postgresql, flyway-core, flyway-database-postgresql, jjwt-api, jjwt-impl, jjwt-jackson, springdoc-openapi-starter-webmvc-ui, lombok, devtools, starter-test, security-test, h2. DEPENDENCIAS NPM: react, react-dom, react-router-dom, @tanstack/react-query, axios, zod, react-hook-form, @hookform/resolvers, tailwindcss, autoprefixer, postcss, sonner, lucide-react, clsx, date-fns, typescript, vite, @vitejs/plugin-react, eslint, prettier, testing-library, vitest, jsdom, coverage-v8, playwright. UI/UX: sidebar colapsable, breadcrumbs, skip link, estados idle/loading/error/empty/success, skeleton base, responsive mobile-first, botones 44x44, foco visible, colores por tokens propios, toasts Sonner. TESTS: backend ApplicationContextStartsTest, HealthEndpointTest, OpenApiEndpointTest, JwtUtilTest, SecurityProtectedRootTest; frontend AppRendersRootLayout.test.tsx, ProtectedRoute.test.tsx, AuthContext.test.tsx; integración con puertos vía variables BACKEND_PORT, FRONTEND_PORT, DATABASE_PORT; Playwright smoke de home y login. Cobertura ≥80% sobre lógica implementada en esta historia; puede fallar parcialmente hasta completar dependencias posteriores. confianza: alta
Criterios:
  1. Dado que se ejecuta ./run.sh sin Docker, cuando el entorno tiene Java 17+, Node 18+, npm y psql disponibles, entonces el script descarga dependencias, genera JAR >40MB y node_modules con más de 50 paquetes, detecta puertos libres distintos para DB/backend/frontend, aplica migraciones y seed con usuario admin funcional, inicia backend y frontend, deja la app accesible en navegador, mantiene hot-reload en frontend y no se detiene por tests fallidos.
  2. Dado que el puerto 8081 está ocupado, cuando ./run.sh busca puerto para backend, entonces asigna el siguiente puerto libre del rango permitido y lo guarda en .pids/ports.env junto con DB_PORT y FRONTEND_PORT.
  3. Dado que el backend está levantado, cuando se consulta GET /actuator/health en el puerto asignado, entonces responde 200 con JSON que contiene status='UP'.
  4. Dado que el backend está levantado, cuando se consulta GET /v3/api-docs en el puerto asignado, entonces responde 200 con un documento OpenAPI versión 3.
  5. Dado que el backend está levantado sin token, cuando se consulta GET /api/v1/ en el puerto asignado, entonces responde 401 o 403 confirmando seguridad activa.
  6. Dado que el frontend está levantado, cuando se consulta GET / en el puerto asignado, entonces responde 200 text/html y el HTML contiene id='root'.
  7. Dado que se ejecuta ./smoke-test.sh con la app corriendo, cuando finaliza la batería, entonces reporta los 8 tests de DB, health, api-docs, auth, protected, frontend HTML, frontend assets y CORS sin detener la app; exit code 0 si al menos 5 pasan.
  8. Dado que se ejecuta mvn dependency:tree y npm install, cuando finaliza la instalación, entonces están presentes spring-boot-starter-web, starter-data-jpa, starter-security, starter-validation, postgresql, flyway-core, jjwt-api, springdoc y en frontend react, react-dom, react-router-dom, react-query, axios, zod, vite, typescript, tailwindcss y al menos 15 paquetes adicionales.

---

## 2. Autenticación administrativa para operar el inventario de productos
sourceRunId: run-70da8a3e-7318-42df-8d8f-ea5ce874e13c
Módulo: Seguridad y Acceso

Como administrador del inventario, necesito iniciar sesión y mantener una sesión segura para acceder a los endpoints protegidos y a las pantallas operativas. Esta historia se apoya en la ausencia de autenticación explícita en el sistema origen, pero es necesaria para reemplazar el acceso implícito a páginas WebForms por un modelo moderno seguro. La trazabilidad técnica se vincula a la inicialización de páginas protegidas observadas en Default.aspx.cs y a la necesidad de centralizar acceso que antes dependía del ciclo de vida de página y del contexto HTTP de WebForms. La implementación debe proveer login, refresh de tokens, contexto de autenticación en memoria, guards de navegación y propagación del usuario autenticado a la auditoría backend. Se debe privilegiar la usabilidad operativa: el usuario administrador sembrado podrá ingresar con credenciales conocidas, recibir feedback visual, ser redirigido al módulo de productos y perder acceso al cerrar sesión. Decisión conservadora: dado que no existen perfiles funcionales adicionales en el código analizado, se define ROLE_ADMIN como rol principal y ROLE_OPERADOR como extensión futura sin inventar permisos de negocio no evidenciados. La historia cubre tanto la experiencia de acceso en frontend como la validación y emisión de JWT en backend, dejando la persistencia de refresh token en memoria de cliente por simplicidad segura, nunca en localStorage.

Actor: Administrador de inventario

Flujo funcional:
1. El usuario navega a /login.
2. Completa username y password visibles y envía el formulario.
3. El frontend valida formato mínimo y envía POST /auth/login.
4. El backend valida credenciales contra t95usu03_usuarios, genera JWT y refresh token, y responde roles y expiración.
5. AuthContext guarda tokens en memoria, React Query invalida estado auth y redirige a /productos.
6. Al expirar el access token, axios interceptor intenta POST /auth/refresh de forma transparente.
7. Desviación: si username o password están vacíos, el formulario muestra errores inline y no envía la solicitud.
8. Desviación: si credenciales son inválidas o usuario inactivo, backend responde 401 y frontend muestra toast de error sin navegar.
9. Desviación: si refresh falla o token es inválido, la sesión se limpia, se redirige a /login y se preserva la ruta destino para retorno posterior.

Pantallas / superficies: Rutas React: /login, /productos. Componentes: AuthContext.tsx, ProtectedRoute.tsx, LoginPage.tsx, Layout.tsx. Endpoints Spring: POST /auth/login, POST /auth/refresh, POST /auth/logout opcional sin persistencia server-side, GET /api/v1/. Botón retorno: N/A en login; desde pantallas secundarias se mantiene patrón hacia /productos.

Reglas de negocio:
1. El username es obligatorio y no debe enviarse en blanco ni solo con espacios.
2. La password es obligatoria y no debe enviarse en blanco.
3. Solo usuarios existentes en t95usu03_usuarios pueden autenticarse.
4. Si usr_activo es false, la autenticación debe rechazarse con 401.
5. El token JWT debe incluir claims sub, roles, iat, exp de 1 hora y jti UUID.
6. El refresh token debe emitirse y renovarse sin persistirse en localStorage ni en URL.
7. Las rutas /api/v1/** deben requerir token válido; /auth/** y endpoints de salud/documentación permanecen públicos.
8. Si el header Authorization no tiene esquema Bearer válido, la request protegida debe tratarse como no autenticada.
9. Si el token expira o firma no valida, la request protegida debe responder 401.
10. El frontend debe bloquear navegación a rutas protegidas si no hay sesión activa en memoria.
11. El logout debe limpiar completamente access token, refresh token y contexto de usuario.
12. Las pantallas protegidas no deben quedar visibles tras logout o refresh fallido.
13. Los errores de autenticación no deben exponer si falló usuario o contraseña por separado.
14. El admin seeded admin/admin123 debe poder iniciar sesión exitosamente desde entorno local.

Notas técnicas:
Endpoint API: POST /auth/login request {username:string required, password:string required}; success 200 {token:string, refreshToken:string, expiresIn:number, username:string, roles:string[]}; error 401 ErrorResponse. POST /auth/refresh request {refreshToken:string required}; success 200 mismo esquema; error 401. Tabla DB: usa t95usu03_usuarios {usr_id, usr_username unique, usr_password_hash, usr_roles, usr_activo}. Auth/Authz: Spring Security stateless, PasswordEncoder BCryptPasswordEncoder, AuthenticationManager o servicio propio, roles ROLE_ADMIN y ROLE_OPERADOR. Error mapping: credenciales inválidas -> 401 AUTH_INVALID_CREDENTIALS; usuario inactivo -> 401 AUTH_USER_INACTIVE; token inválido/expirado -> 401 AUTH_TOKEN_INVALID. Flyway: V999__seed_datos_iniciales.sql inserta admin con bcrypt de admin123. Paquetes: com.bancointernacional.inventario.auth.{domain,application,infrastructure,api}. Transacciones: @Transactional(readOnly=true) para lookup de usuario; escritura solo si luego se decide persistir refresh token, en esta historia no aplica. Cache/estado: AuthContext en memoria con React Context; axiosInstance intercepta 401, serializa un solo refresh concurrente y reintenta request original una vez; invalidación de query ['auth-session']. DEPENDENCIAS MAVEN: spring-boot-starter-security, jjwt-api, jjwt-impl, jjwt-jackson, spring-boot-starter-validation. DEPENDENCIAS NPM: axios, react-router-dom, zod, react-hook-form, @hookform/resolvers, sonner. UI/UX: /login con formulario centrado, labels visibles, errores inline, submit disabled con spinner, toast error 5s, acceso por teclado, contraste AA, responsive 375px y 1280px. TESTS: AuthControllerLoginSuccessTest entrada admin/admin123 salida 200 con token; AuthControllerLoginInvalidTest salida 401; JwtAuthenticationFilterValidTokenTest setea SecurityContext; ProtectedRouteRedirectsGuest.test.tsx redirige a /login; LoginPageShowsValidationErrors.test.tsx; interceptor refresh test con puertos dinámicos por variables. Cobertura ≥80%; si faltan historias dependientes algunos tests de navegación pueden fallar y es esperado. confianza: alta
Criterios:
  1. Dado el usuario admin sembrado, cuando envía POST /auth/login con {username:'admin',password:'admin123'}, entonces recibe 200 con campos token, refreshToken, expiresIn, username='admin' y roles tipados como arreglo JSON.
  2. Dado un formulario de login vacío, cuando el usuario intenta enviar, entonces se muestran errores inline para username y password y no se ejecuta ninguna llamada HTTP.
  3. Dado credenciales inválidas, cuando el usuario envía POST /auth/login con {username:'admin',password:'mala'}, entonces la API responde 401 con {timestamp,status,code,message,path} y el frontend muestra toast de error sin redirigir.
  4. Dado una sesión activa, cuando el access token expira y existe refresh token válido en memoria, entonces el interceptor ejecuta POST /auth/refresh y reintenta la solicitud original sin recarga de página.
  5. Dado un usuario no autenticado, cuando intenta abrir /productos, entonces ProtectedRoute lo redirige a /login y preserva la intención de navegación.
  6. Dado una autenticación exitosa, cuando la SPA redirige al usuario, entonces la vista /productos se renderiza sin recargar el navegador y refleja el estado autenticado actual.
  7. Dado una llamada válida a POST /auth/login, cuando la API responde éxito, entonces el contrato REST expone solo campos token, refreshToken, expiresIn, username y roles; si la validación falla responde 400 con ErrorResponse estándar.

---

## 3. Consulta de inventario de productos para el administrador
sourceRunId: run-70da8a3e-7318-42df-8d8f-ea5ce874e13c
Módulo: Inventario de Productos

Como administrador, necesito visualizar todos los productos cargados en el inventario para conocer nombre, cantidad disponible y precio. Esta historia proviene directamente de ProductoService.ObtenerTodos en MiInventario.BLL/Services/ProductoService.cs, del mapeo de ProductoEntity a Producto en líneas aproximadas 13-24, de ProductoRepository.GetAll en MiInventario.DAL/Repositories/ProductoRepository.cs y del método Cargar de Default.aspx.cs que enlazaba el GridView gvProductos al resultado del servicio. La migración debe preservar exactamente el comportamiento evidenciado: listado completo sin filtros obligatorios, proyección de campos Id, Nombre, Cantidad y Precio, y actualización inicial al abrir la pantalla principal. Se moderniza la entrega usando un endpoint REST paginable y una tabla React, pero sin introducir reglas de negocio nuevas no vistas en el código. Dado que el origen no imponía ordenamiento explícito, se toma la decisión conservadora de ordenar por id ascendente para estabilidad visual y pruebas repetibles. También se incorporan estados empty, loading y error porque el GridView legacy dependía del ciclo de página y la nueva SPA debe ser autosuficiente. Esta historia cubre toda la lectura del inventario y el mapeo entre entidad persistida y DTO de negocio.

Actor: Administrador de inventario

Flujo funcional:
1. El usuario autenticado abre /productos.
2. El frontend ejecuta GET /api/v1/productos?page=0&size=14.
3. El backend consulta t95prd01_productos, mapea cada registro a DTO y devuelve respuesta paginada.
4. La tabla renderiza columnas Id, Nombre, Cantidad y Precio.
5. El usuario puede cambiar de página, ordenar columnas y consultar total.
6. Desviación: si la API responde error 401, el interceptor redirige a login.
7. Desviación: si ocurre error 500 o de red, se muestra bloque de error con botón Reintentar.
8. Desviación: si no existen productos, se muestra estado vacío con mensaje y acción para crear el primero.

Pantallas / superficies: Ruta React: /productos. Componentes: ProductosPage.tsx, ProductoTable.tsx, Layout.tsx. Endpoints Spring: GET /api/v1/productos, GET /api/v1/productos/{id} opcional para detalle simple. Botón retorno: N/A en pantalla principal del módulo; para subpantallas futuras retorno a /productos.

Reglas de negocio:
1. El listado debe exponer exactamente los campos de negocio Id, Nombre, Cantidad y Precio derivados del código fuente.
2. Cada ProductoEntity recuperado debe mapearse a Producto DTO sin alterar valores.
3. La consulta debe devolver todos los productos disponibles, modernizada con paginación page/size.
4. Si page no se informa, debe usarse 0.
5. Si size no se informa, debe usarse 14.
6. Si size supera 100, debe ajustarse a 100.
7. El acceso al listado requiere autenticación válida.
8. El orden por defecto será id ascendente como decisión conservadora al no existir orden explícito en el legacy.
9. Si la tabla no tiene registros, no debe tratarse como error técnico sino como estado vacío.
10. Los valores de cantidad se tratan como enteros y precio como decimal de dos decimales por tipo implícito del modelo original.
11. No se deben exponer campos técnicos de auditoría ni password ni metadata interna en el contrato REST.
12. La lectura no debe modificar estado ni generar side effects.

Notas técnicas:
Endpoint API: GET /api/v1/productos?page:number optional default 0&size:number optional default 14&sort:string optional -> 200 {content:[{id:number,nombre:string,cantidad:number,precio:number}], totalElements:number,totalPages:number,size:number,number:number,first:boolean,last:boolean}. Response error estándar. Tabla DB: t95prd01_productos {prd_id bigserial PK, prd_nombre varchar(150) NOT NULL, prd_cantidad integer NOT NULL, prd_precio numeric(15,2) NOT NULL}. Auth/Authz: JWT requerido, roles ROLE_ADMIN y ROLE_OPERADOR permitidos para lectura. Error mapping: entidad no encontrada en GET /{id} -> 404 PRODUCTO_NOT_FOUND; parámetros inválidos page/size -> 400; acceso denegado -> 403. Flyway: usa V001__baseline_schema.sql; agregar índice V002__idx_t95prd01_productos_nombre.sql opcional para búsquedas futuras si se implementa. Paquetes: com.bancointernacional.inventario.productos.{domain,application,infrastructure,api}. Transacciones: @Transactional(readOnly=true) en servicio de consulta. Cache/estado: React Query key ['productos',page,size,sort], staleTime 30s, keepPreviousData al paginar. DEPENDENCIAS MAVEN: starter-web, data-jpa, validation, springdoc. DEPENDENCIAS NPM: @tanstack/react-query, axios, clsx, date-fns opcional para formato, lucide-react. UI/UX: tabla con hover, columnas ordenables, skeleton en carga, empty state con CTA 'Agregar producto', error con reintentar, responsive con tarjetas en mobile si ancho menor md, contraste AA. TESTS: ProductoRepositoryFindAllTest con datos semilla; ProductoServiceListMappingTest verifica id/nombre/cantidad/precio; ProductoControllerListPaginationTest; ProductosPageLoadsTable.test.tsx; ProductosPageEmptyState.test.tsx; Playwright navega a /productos y verifica cabeceras. URLs por variables de entorno. confianza: alta
Criterios:
  1. Dado productos existentes en la base, cuando el usuario autenticado consulta GET /api/v1/productos?page=0&size=14, entonces recibe 200 con content que contiene objetos {id,nombre,cantidad,precio} tipados y metadatos de paginación.
  2. Dado la pantalla /productos, cuando la consulta está en progreso, entonces se renderiza skeleton de tabla y luego se reemplaza por filas sin recargar la página.
  3. Dado que no existen registros en t95prd01_productos, cuando el usuario abre /productos, entonces ve un estado vacío con mensaje comprensible y acción para agregar el primer producto.
  4. Dado un error de red temporal, cuando la consulta falla, entonces la pantalla muestra mensaje de error y botón Reintentar que vuelve a ejecutar la consulta.
  5. Dado un size mayor a 100 en GET /api/v1/productos, cuando el backend procesa la solicitud, entonces ajusta el tamaño máximo permitido a 100 y responde dentro del contrato de paginación.
  6. Dado el contrato REST de lectura, cuando responde la API, entonces no expone columnas técnicas ni campos distintos de id, nombre, cantidad y precio en cada producto.
  7. Dado la ruta /productos, cuando se visualiza en 1280px y 375px, entonces renderiza correctamente, mantiene contraste 4.5:1 y controles táctiles mínimos de 44x44.

---

## 4. Alta de productos al inventario con validación de nombre, cantidad y precio
sourceRunId: run-70da8a3e-7318-42df-8d8f-ea5ce874e13c
Módulo: Inventario de Productos

Como administrador, necesito registrar nuevos productos para ampliar el inventario disponible. Esta historia se extrae de Default.aspx.cs en btnGuardar_Click, líneas aproximadas 28-60, donde se limpiaba lblModalError, se parseaban txtCantidad y txtPrecio con CultureInfo.InvariantCulture, se llamaba a service.Agregar, se limpiaban los campos y se recargaba la grilla; también de ProductoService.Agregar en ProductoService.cs, líneas aproximadas 26-41, donde se validaba que Nombre no fuera nulo o whitespace y luego se persistía la entidad mediante ProductoRepository.Add. La migración debe respetar esas reglas y errores: nombre requerido, cantidad y precio numéricos válidos, y feedback si no se pudo guardar. No hay evidencia en el código de límites mínimos o máximos para cantidad y precio, por lo que se decide conservar la semántica original: aceptar enteros y decimales siempre que el parseo sea correcto y el nombre no sea vacío. Se moderniza el flujo con modal o formulario lateral React y doble validación frontend-backend. Tras guardar, el listado debe refrescarse automáticamente sin recargar página, replicando el efecto de Cargar() en WebForms. También se preserva la limpieza de campos observada en el origen tras una alta exitosa.

Actor: Administrador de inventario

Flujo funcional:
1. En /productos el usuario pulsa 'Nuevo producto'.
2. Se abre un formulario con campos nombre, cantidad y precio.
3. El frontend valida obligatorios y formato numérico; si pasa, envía POST /api/v1/productos.
4. El backend valida nombre y tipos, persiste el registro y responde el producto creado.
5. React Query invalida ['productos'], cierra el modal, limpia el formulario y muestra toast de éxito.
6. Desviación: si cantidad o precio no son números válidos, el formulario muestra errores inline equivalentes al mensaje legacy y permanece abierto.
7. Desviación: si nombre está vacío o solo espacios, backend responde 400 y el modal permanece abierto con mensaje de error.
8. Desviación: si ocurre error inesperado al persistir, se muestra toast o banner 'No se pudo guardar' y no se limpia el formulario.

Pantallas / superficies: Ruta React: /productos. Componentes: ProductoCreateModal.tsx o ProductoForm.tsx integrado en ProductosPage.tsx. Endpoints Spring: POST /api/v1/productos. Botón retorno: N/A al ser modal dentro de /productos.

Reglas de negocio:
1. El nombre del producto es obligatorio; si string.IsNullOrWhiteSpace(nombre) se debe rechazar la operación.
2. El nombre debe persistirse con trim aplicado, ya que en el código origen se usaba txtNombre.Text.Trim().
3. La cantidad debe poder convertirse a entero válido; si falla el parseo, la operación no se ejecuta.
4. El precio debe poder convertirse a decimal válido; si falla el parseo, la operación no se ejecuta.
5. El parseo debe aceptar formato invariante con punto decimal, coherente con CultureInfo.InvariantCulture del origen.
6. Ante error de formato en cantidad o precio, el mensaje funcional debe indicar que ambos deben ser números válidos.
7. Tras un alta exitosa, nombre, cantidad y precio del formulario deben limpiarse.
8. Tras un alta exitosa, el listado debe recargarse automáticamente.
9. Si el backend lanza excepción de negocio, el mensaje de error debe exponerse como 'No se pudo guardar: {motivo}' o equivalente UI.
10. La persistencia de un nuevo producto debe crear una fila con nombre, cantidad y precio recibidos; el id es generado por la base.
11. No existe validación evidenciada de unicidad del nombre, por lo tanto no debe imponerse en esta historia.
12. No existe validación evidenciada de rangos positivos para cantidad o precio, por lo que no se agregan restricciones de negocio extra fuera del tipo de dato.

Notas técnicas:
Endpoint API: POST /api/v1/productos request {nombre:string required, cantidad:integer required, precio:number required}; success 201 {id:number,nombre:string,cantidad:number,precio:number}; error 400 ErrorResponse con details de validación o mensaje de negocio. Tabla DB: t95prd01_productos {prd_id bigserial PK, prd_nombre varchar(150) NOT NULL, prd_cantidad integer NOT NULL, prd_precio numeric(15,2) NOT NULL}. Auth/Authz: JWT requerido, ROLE_ADMIN permitido para escritura; ROLE_OPERADOR opcional solo lectura. Error mapping: nombre requerido -> 400 PRODUCTO_NOMBRE_REQUERIDO; parse inválido -> 400 PRODUCTO_FORMATO_INVALIDO; conflicto de integridad futuro -> 409. Flyway: estructura base en V001; no se agrega constraint adicional por falta de evidencia. Paquetes: com.bancointernacional.inventario.productos.api create DTOs y service. Transacciones: @Transactional en service create, aislamiento READ_COMMITTED por defecto. Cache/estado: invalidar ['productos']; optimistic update no requerido, preferir refetch conservador. DEPENDENCIAS MAVEN: starter-validation, data-jpa. DEPENDENCIAS NPM: react-hook-form, zod, @hookform/resolvers, sonner. UI/UX: modal con labels visibles, aria-invalid, spinner en submit, errores inline rojos con icono, botón cancelar, focus trap, toast éxito 3s, error 5s, mobile full-screen dialog. TESTS: ProductoServiceAgregarNombreVacioTest lanza excepción; ProductoControllerCreateSuccessTest entrada {Lapicera,10,2.50}; ProductoControllerCreateInvalidFormatIntegrationTest; ProductoFormValidation.test.tsx; ProductoCreateModalResetsOnSuccess.test.tsx; Playwright crea producto y ve fila nueva sin reload. Puertos dinámicos por variables. confianza: alta
Criterios:
  1. Dado un formulario válido con nombre='Cuaderno', cantidad=12 y precio=3.50, cuando se envía POST /api/v1/productos, entonces la API responde 201 con {id,nombre,cantidad,precio} y la tabla refleja el nuevo producto sin recargar la SPA.
  2. Dado un nombre compuesto solo por espacios, cuando el usuario intenta guardar, entonces el backend responde 400 con code='PRODUCTO_NOMBRE_REQUERIDO' y el formulario muestra el error inline.
  3. Dado cantidad='abc' y precio='2.50', cuando el usuario intenta guardar, entonces el formulario impide el envío o la API responde 400 indicando que cantidad y precio deben ser números válidos.
  4. Dado cantidad='10' y precio='x', cuando el usuario intenta guardar, entonces el modal permanece abierto y se muestra mensaje de validación sin limpiar los campos.
  5. Dado una creación exitosa, cuando el modal se cierra, entonces los campos nombre, cantidad y precio quedan vacíos para el siguiente alta.
  6. Dado un reenvío accidental del mismo payload por doble clic, cuando la UI está procesando la solicitud, entonces el botón submit queda deshabilitado con spinner evitando duplicados por la misma interacción.
  7. Dado el contrato API de POST /api/v1/productos, cuando la solicitud es válida, entonces acepta campos nombre:string, cantidad:integer y precio:number; si falla la validación devuelve 400 con ErrorResponse estándar.

---

## 5. Baja de productos desde el listado de inventario
sourceRunId: run-70da8a3e-7318-42df-8d8f-ea5ce874e13c
Módulo: Inventario de Productos

Como administrador, necesito eliminar productos del inventario cuando ya no correspondan, manteniendo el comportamiento silencioso del sistema origen. Esta historia se extrae de gvProductos_RowDeleting en Default.aspx.cs, líneas aproximadas 63-68, donde se obtenía el id desde gvProductos.DataKeys[e.RowIndex].Value, se invocaba service.Eliminar(id) y luego se ejecutaba Cargar(); también de ProductoService.Eliminar y ProductoRepository.Delete, donde se buscaba el producto con ctx.Productos.Find(id), se eliminaba si existía y se hacía SaveChanges, pero si no existía no se lanzaba error. La migración debe preservar esa semántica: eliminar por id, refrescar listado y tolerar ids inexistentes de forma idempotente. Se moderniza el flujo con acción destructiva confirmada por modal, retroalimentación visual y actualización SPA. La decisión conservadora es mapear la eliminación de un id inexistente a HTTP 204 igualmente, porque el código fuente no trataba el caso como error. Esta historia cubre toda la trazabilidad de borrado desde la UI hasta el repositorio, incluyendo la validación implícita de existencia previa antes de remover físicamente.

Actor: Administrador de inventario

Flujo funcional:
1. En /productos el usuario elige la acción Eliminar sobre una fila.
2. El sistema abre un modal de confirmación destructiva.
3. El usuario confirma y el frontend envía DELETE /api/v1/productos/{id}.
4. El backend busca el producto por id; si existe lo elimina y confirma 204.
5. El frontend invalida ['productos'], cierra el modal y muestra toast de éxito.
6. Desviación: si el usuario cancela la confirmación, no se realiza llamada HTTP ni cambia el listado.
7. Desviación: si el id ya no existe, backend responde 204 idempotente y la tabla se refresca sin error.
8. Desviación: si ocurre error técnico al eliminar, se muestra toast de error y la fila permanece visible hasta nuevo intento.

Pantallas / superficies: Ruta React: /productos. Componentes: ProductoDeleteDialog.tsx dentro de ProductosPage.tsx/ProductoTable.tsx. Endpoints Spring: DELETE /api/v1/productos/{id}. Botón retorno: N/A al ser acción en tabla principal.

Reglas de negocio:
1. La eliminación se ejecuta por id entero proveniente de la fila seleccionada.
2. Antes de eliminar, el repositorio debe buscar el producto por id.
3. Si el producto existe, se debe remover y persistir con Save/Delete equivalente.
4. Si el producto no existe, no debe lanzarse error de negocio; la operación termina silenciosamente.
5. Tras una eliminación solicitada, el listado debe recargarse automáticamente.
6. La operación debe ser idempotente: reintentar el mismo DELETE no genera error funcional ni duplicados.
7. La UI debe pedir confirmación antes de una acción destructiva.
8. Solo usuarios autenticados con rol autorizado pueden eliminar.
9. La eliminación física es consistente con el código origen; no hay evidencia de baja lógica.
10. Si falla el acceso a datos, el sistema debe informar error técnico sin asumir éxito.

Notas técnicas:
Endpoint API: DELETE /api/v1/productos/{id:number required} -> 204 No Content si existe o no existe; error 400 si id inválido no numérico en binding; 403 si sin permiso; 500 en error técnico. Tabla DB: t95prd01_productos PK prd_id. Auth/Authz: JWT requerido, ROLE_ADMIN para eliminar. Error mapping: id mal formado -> 400; acceso denegado -> 403; error inesperado DB -> 500. Flyway: sin cambios de esquema. Paquetes: com.bancointernacional.inventario.productos.{api,application,infrastructure}. Transacciones: @Transactional en delete. Cache/estado: invalidación React Query ['productos'] post-delete; remover fila optimistamente opcional pero preferir refetch por fidelidad. DEPENDENCIAS MAVEN: starter-web, data-jpa, security. DEPENDENCIAS NPM: sonner, lucide-react, @tanstack/react-query. UI/UX: modal destructivo con botón secundario cancelar y primario eliminar, texto claro del nombre del producto si disponible, spinner durante delete, foco inicial en cancelar, mobile responsive. TESTS: ProductoRepositoryDeleteExistingTest elimina registro; ProductoRepositoryDeleteMissingNoErrorTest; ProductoControllerDeleteReturns204WhenMissingTest; ProductoDeleteDialogCancel.test.tsx; ProductoDeleteFlowRefreshesList.test.tsx; Playwright elimina producto y verifica desaparición sin recarga. Variables de entorno dinámicas en tests. confianza: alta
Criterios:
  1. Dado un producto existente con id=5, cuando el usuario confirma DELETE /api/v1/productos/5, entonces la API responde 204 y la fila desaparece del listado sin recargar la SPA.
  2. Dado un producto inexistente con id=9999, cuando se envía DELETE /api/v1/productos/9999, entonces la API responde 204 y el sistema no muestra error funcional.
  3. Dado el modal de confirmación abierto, cuando el usuario pulsa Cancelar, entonces no se realiza llamada DELETE y el listado permanece igual.
  4. Dado una acción destructiva en /productos, cuando la pantalla se muestra en 1280px y 375px, entonces el diálogo mantiene accesibilidad, foco visible y botones táctiles de al menos 44x44.
  5. Dado un fallo técnico de base de datos al eliminar, cuando la API responde 500, entonces el frontend muestra toast de error de 5 segundos y mantiene la fila visible.
  6. Dado el contrato REST de DELETE /api/v1/productos/{id}, cuando el id es válido, entonces no devuelve cuerpo en éxito; si la validación de path falla devuelve 400 con ErrorResponse estándar.

---

## 6. Rutas informativas equivalentes a About y Contact para usuarios del sistema
sourceRunId: run-70da8a3e-7318-42df-8d8f-ea5ce874e13c
Módulo: Navegación y Experiencia

Como usuario del sistema, necesito acceder a páginas informativas equivalentes a About y Contact para mantener la estructura de navegación existente sin errores 404. Esta historia se extrae de About.aspx.cs y Contact.aspx.cs, cuyos Page_Load están vacíos pero evidencian la existencia de pantallas accesibles en el sistema original; también se relaciona con Site.Master.cs y Site.Mobile.Master.cs, que organizaban contenido compartido sin lógica adicional. Dado que no existe comportamiento de negocio asociado ni integraciones detrás de estas páginas, la migración debe ser mínima y conservadora: crear rutas React informativas modernas con contenido institucional del dominio inventario, respetando el patrón de navegación secundaria con breadcrumbs y botón de retorno. No se inventan formularios de contacto ni procesos adicionales porque no hay evidencia en el código. El valor aquí es de continuidad funcional y de cobertura total del código de navegación legacy. Estas pantallas deben integrarse al Layout y ser accesibles desde desktop y mobile.

Actor: Usuario del sistema

Flujo funcional:
1. El usuario abre la aplicación y navega mediante el sidebar o header a /about o /contact.
2. El sistema renderiza la pantalla informativa correspondiente dentro del Layout.
3. El usuario lee el contenido y puede volver a la pantalla anterior o a /productos mediante el botón de retorno.
4. Desviación: si llega directamente por URL, la SPA resuelve la ruta y muestra la pantalla correctamente.
5. Desviación: si no está autenticado y estas rutas se definen como públicas, puede verlas sin iniciar sesión; si se deciden protegidas por consistencia de layout, ProtectedRoute redirige a login. Decisión conservadora: se implementan públicas al no haber lógica sensible.

Pantallas / superficies: Rutas React: /about, /contact. Componentes: AboutPage.tsx, ContactPage.tsx, Layout.tsx. Endpoints Spring: N/A. Botón retorno: 'Volver a Inicio' hacia /.

Reglas de negocio:
1. Deben existir rutas explícitas para About y Contact porque aparecen como páginas del sistema origen.
2. No se debe implementar lógica de negocio adicional en estas pantallas porque el código fuente no la evidencia.
3. El Page_Load vacío implica que la pantalla solo informa contenido estático o institucional.
4. Las pantallas deben integrarse a la navegación principal y no devolver 404.
5. Toda pantalla secundaria debe incluir botón de retorno y breadcrumb.
6. Deben ser responsivas y accesibles tanto en desktop como en mobile.
7. No requieren backend propio.

Notas técnicas:
Endpoint API: N/A. Tabla DB: N/A. Auth/Authz: decisión conservadora pública; si el Layout global requiere sesión, usar variante pública simple. Error mapping: N/A. Flyway: no aplica. Paquetes: frontend/src/pages/about, frontend/src/pages/contact. Transacciones: N/A. Cache/estado: no usa React Query. DEPENDENCIAS MAVEN: N/A para esta historia. DEPENDENCIAS NPM: react-router-dom, lucide-react, clsx. UI/UX: pantallas con título, subtítulo, tarjeta de contenido, botón retorno a /, breadcrumb, estados idle solamente, responsive 375/1280, foco visible, contraste AA. TESTS: AboutRouteRenders.test.tsx, ContactRouteRenders.test.tsx, Playwright navega a ambas rutas y retorna con botón. confianza: alta
Criterios:
  1. Dado la ruta /about, cuando el usuario navega a ella, entonces la SPA renderiza una pantalla informativa con breadcrumb y botón 'Volver a Inicio' hacia '/'.
  2. Dado la ruta /contact, cuando el usuario navega a ella, entonces la SPA renderiza una pantalla informativa equivalente sin errores 404.
  3. Dado acceso directo por URL a /about, cuando se refresca el navegador en desarrollo, entonces Vite resuelve la ruta y muestra el contenido.
  4. Dado acceso directo por URL a /contact, cuando se refresca el navegador en desarrollo, entonces Vite resuelve la ruta y muestra el contenido.
  5. Dado una pantalla secundaria informativa, cuando se visualiza en 1280px y 375px, entonces mantiene contraste 4.5:1, foco visible y botón retorno usable.
  6. Dado que estas pantallas no tienen backend asociado, cuando se inspecciona la implementación, entonces no existe llamada REST innecesaria ni dependencia de datos remotos.

---

## 7. Navegación responsive y cambio de vista planificado para desktop y mobile
sourceRunId: run-70da8a3e-7318-42df-8d8f-ea5ce874e13c
Módulo: Navegación y Experiencia

Como usuario del sistema, necesito una navegación responsive coherente y una representación explícita del cambio de vista desktop/mobile para cubrir los componentes de presentación del sistema original. Esta historia se traza a RouteConfig.cs con Friendly URLs, a ViewSwitcher.ascx.cs donde se detectaba CurrentView, AlternateView y SwitchUrl usando AspNet.FriendlyUrls.SwitchView, y a Site.Master / Site.Mobile.Master que diferenciaban presentación desktop y mobile. En el stack moderno no existe una separación por master pages ni resolvers de FriendlyUrls, por lo que la migración apropiada es un layout responsive único con capacidad de mostrar el modo actual de visualización y una pantalla de funcionalidad pendiente para el cambio manual de vista si no se implementa como feature real. También absorbe la intención de navegación amigable del sistema origen. Decisión conservadora: se prioriza responsive automático por breakpoints y se expone un componente de indicador/cambio de vista sin persistencia compleja, evitando inventar una preferencia de usuario no evidenciada. Esto asegura cobertura de los artefactos de layout y del control ViewSwitcher sin reproducir mecánicas obsoletas.

Actor: Usuario del sistema

Flujo funcional:
1. El usuario abre la app desde desktop o móvil.
2. El Layout detecta el tamaño de pantalla y adapta sidebar, drawer y breadcrumbs.
3. El usuario puede visualizar una etiqueta de vista actual y acceder a una opción de cambio de vista planificada.
4. Si el cambio manual no está implementado aún, se muestra FuncionalidadPendiente con retorno al inicio.
5. Desviación: en mobile, el sidebar se transforma en drawer con overlay.
6. Desviación: si se navega a la ruta de switch view, no debe fallar con 404 y debe comunicar claramente que la capacidad está planificada.

Pantallas / superficies: Rutas React: /, /view-switcher, /pendiente/view-switcher. Componentes: Layout.tsx, ResponsiveViewIndicator.tsx, FuncionalidadPendiente.tsx. Endpoints Spring: N/A. Botón retorno: 'Volver a Inicio' hacia /.

Reglas de negocio:
1. Debe existir una representación de vista actual porque el control ViewSwitcher del origen calculaba CurrentView y AlternateView.
2. Debe existir una alternativa de navegación para cambio de vista o una pantalla pendiente explícita, nunca una ruta rota.
3. El sistema moderno debe resolver la diferenciación desktop/mobile de forma responsive en lugar de master pages separadas.
4. Sidebar colapsable en desktop y drawer con overlay en mobile.
5. Breadcrumbs visibles en pantallas secundarias.
6. Toda ruta de soporte al cambio de vista debe devolver una UI válida aunque la funcionalidad completa esté pendiente.
7. No se requiere backend porque el origen solo construía URL de cambio de vista y no mostraba lógica de negocio adicional.

Notas técnicas:
Endpoint API: N/A. Tabla DB: N/A. Auth/Authz: mismo comportamiento de las rutas de navegación, preferentemente públicas o protegidas según layout general; no requieren permisos especiales. Error mapping: N/A. Flyway: no aplica. Paquetes: frontend/src/components/layout y frontend/src/pages/pendiente. Transacciones: N/A. Cache/estado: estado local de UI para sidebar abierto/cerrado y viewport; optional useMediaQuery util. DEPENDENCIAS MAVEN: N/A. DEPENDENCIAS NPM: react-router-dom, lucide-react, clsx. UI/UX: tokens responsive sm/md/lg/xl, overlay mobile, animaciones 150-300ms, respeto a prefers-reduced-motion, skip link, botones retorno, badge de vista actual. TESTS: LayoutResponsiveDesktopMobile.test.tsx, ViewSwitcherRouteRendersPending.test.tsx, Playwright viewport desktop/mobile verifica menú. confianza: media
Criterios:
  1. Dado una pantalla en 1280px, cuando el usuario abre la aplicación, entonces ve sidebar colapsable y header con breadcrumbs.
  2. Dado una pantalla en 375px, cuando el usuario abre la aplicación, entonces el menú principal se presenta como drawer con overlay y navegación accesible.
  3. Dado la ruta /view-switcher, cuando el usuario navega a ella, entonces la aplicación no devuelve 404 y muestra una experiencia válida asociada al cambio de vista.
  4. Dado la ruta /pendiente/view-switcher, cuando se renderiza, entonces muestra FuncionalidadPendiente con icono, descripción, badge 'Próximamente' y botón retorno a '/'.
  5. Dado el patrón de navegación secundaria, cuando el usuario abre la pantalla de cambio de vista, entonces existe botón 'Volver a Inicio' con ChevronLeft y breadcrumb correspondiente.
  6. Dado preferencias de movimiento reducido del sistema operativo, cuando se abren o cierran drawer y sidebar, entonces las animaciones respetan prefers-reduced-motion.

---

## 8. Cobertura de inicialización, bundles legacy y activos de interfaz como funcionalidades de soporte
sourceRunId: run-70da8a3e-7318-42df-8d8f-ea5ce874e13c
Módulo: Funcionalidades Pendientes

Como Product Owner técnico, necesito que todos los fragmentos de código no funcionales del sistema origen queden cubiertos por artefactos equivalentes o notas explícitas para asegurar trazabilidad y evitar omisiones de migración. Esta historia agrupa los bloques sin lógica de negocio propia pero referenciados en el código: IProductoService.cs e IProductoRepository.cs vacíos, Producto.cs y ProductoEntity.cs como definición de datos, InventarioContext.cs como origen del modelo relacional, Global.asax.cs y AssemblyInfo.cs como metadatos e inicialización de app, y el gran conjunto de scripts WebForms, jQuery, Bootstrap y Modernizr incluidos por BundleConfig.cs. Dado que estos archivos representan infraestructura, modelado o librerías del framework origen, no deben migrarse literalmente; su cobertura se resuelve documentando el mapeo a DTOs/entidades modernas, dependencias NPM/Vite, routing SPA y componentes React equivalentes. Además, el sistema debe contemplar que ningún recurso legacy quede referenciado en runtime del proyecto nuevo. Esta historia no agrega negocio nuevo; cierra la cobertura del inventario de código y formaliza las decisiones de reemplazo tecnológico para producción.

Actor: Product Owner técnico

Flujo funcional:
1. El equipo revisa la trazabilidad de archivos no transaccionales del sistema origen.
2. Se documenta en DOCS.md el mapeo de copybooks/modelos/clases a entidades JPA y tipos TypeScript.
3. Se elimina toda dependencia de scripts legacy en la app nueva y se reemplaza por librerías modernas declaradas en package.json.
4. Se expone una ruta /pendiente/legacy-soporte para comunicar artefactos deliberadamente no migrados uno a uno cuando corresponda.
5. Desviación: si una ruta o activo legacy fuese solicitado por error, la app debe redirigir o mostrar FuncionalidadPendiente en vez de romper.

Pantallas / superficies: Ruta React: /pendiente/legacy-soporte. Componentes: FuncionalidadPendiente.tsx, DOCS.md, README.md. Endpoints Spring: N/A. Botón retorno: 'Volver a Inicio' hacia /.

Reglas de negocio:
1. Las interfaces vacías IProductoService e IProductoRepository no generan funcionalidad operativa; su cobertura es documental y arquitectónica.
2. Producto y ProductoEntity evidencian el contrato de datos mínimo: id, nombre, cantidad, precio.
3. InventarioContext evidencia una única colección Productos, que debe quedar reflejada en el modelo relacional moderno.
4. Global.asax y configuraciones de Bundle/Route se cubren por Application.java, Router SPA y Vite/Tailwind/React setup.
5. Los scripts WebForms, bootstrap, jquery y modernizr del origen se sustituyen por dependencias modernas; no deben copiarse ni cargarse en runtime del sistema nuevo.
6. Las páginas maestras Site.Master y Site.Mobile.Master se cubren por Layout responsive único.
7. ViewSwitcher se cubre por historia de navegación responsive y/o pantalla pendiente.
8. Ningún archivo del código fuente debe quedar sin trazabilidad funcional o técnica.

Notas técnicas:
Endpoint API: N/A. Tabla DB: documentación del modelo {usuarios, productos}. Auth/Authz: N/A para la ruta pendiente o protegida según layout. Error mapping: N/A. Flyway: documentación de V001 y semillas. Paquetes: documentación en DOCS.md del mapeo legacy->moderno; frontend/src/pages/pendiente/LegacySupportPage.tsx. Transacciones: N/A. Cache/estado: N/A. DEPENDENCIAS MAVEN: ninguna adicional. DEPENDENCIAS NPM: ninguna adicional salvo router. UI/UX: FuncionalidadPendiente con título del soporte legacy, descripción, icono neutro, badge Próximamente, botón retorno; no debe parecer error. TESTS: LegacySupportPendingRoute.test.tsx, documentación revisable manualmente; Playwright comprueba que /pendiente/legacy-soporte no devuelve 404. confianza: media
Criterios:
  1. Dado la ruta /pendiente/legacy-soporte, cuando el usuario navega a ella, entonces se muestra FuncionalidadPendiente con nombre, descripción, icono y botón retorno a '/'.
  2. Dado el inventario de archivos fuente, cuando se revisa DOCS.md, entonces existe mapeo explícito de Producto, ProductoEntity, InventarioContext, BundleConfig, RouteConfig, Global.asax y scripts de WebForms hacia equivalentes modernos.
  3. Dado el frontend nuevo, cuando se inspecciona el bundle generado, entonces no se cargan archivos jQuery, bootstrap legacy, MicrosoftAjax o WebForms.js del sistema origen.
  4. Dado una ruta pendiente, cuando se renderiza, entonces no devuelve 404 y se presenta como funcionalidad planificada para versión futura.
  5. Dado la pantalla pendiente en 1280px y 375px, cuando se visualiza, entonces mantiene accesibilidad AA, botón retorno usable y diseño no confuso.
  6. Dado la cobertura total requerida, cuando se cruza el código fuente con las historias, entonces todos los fragmentos sin negocio directo quedan cubiertos por documentación, scaffolding o pantalla pendiente.

## OpenSpec Change
cmno084x00000e9ln7dhbvxmn