# DOCS

## Arquitectura
- `backend/`: Spring Boot 3 con seguridad JWT, Flyway, OpenAPI, JPA y validación.
- `frontend/`: React 18 + Vite + TypeScript con layout responsive, autenticación y catálogo de productos.
- `scripts/`: automatización local de arranque, parada y smoke tests.

## Mapeo de migración
- `Global.asax.cs` → bootstrap de Spring Boot y configuración global.
- `RouteConfig.cs` → rutas React con BrowserRouter.
- `BundleConfig.cs` → bundling moderno de Vite.
- `Site.Master.cs` / `Site.Mobile.Master.cs` → `Layout.tsx` responsive unificado.
- `ViewSwitcher.ascx.cs` → `ResponsiveViewBadge.tsx` y comportamiento adaptativo por breakpoint.
- `About.aspx` / `Contact.aspx` → `AboutPage.tsx` y `ContactPage.tsx`.
- `WebFormsApp/Default.aspx.cs` → listado/alta/baja de productos en React + API REST.
- `IProductoService.cs` / `IProductoRepository.cs` → artefactos sin lógica migrable, documentados como pendientes.

## Seguridad y sesión
- El API usa JWT stateless.
- El usuario semilla es `admin / admin123`.
- El frontend conserva tokens en memoria/almacenamiento controlado; no usa `localStorage` para JWT.

## Operación local
- Los puertos se guardan en `.pids/ports.env`.
- Los logs quedan en `logs/`.
- `run.sh` inicia la app y deja los procesos activos.
- `stop.sh` limpia PIDs y puertos.
