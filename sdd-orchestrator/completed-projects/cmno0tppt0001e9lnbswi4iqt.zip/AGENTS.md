# DEMO Asp Forms Migration

## Purpose
This repository is a generated project driven by OpenSpec and OpenCode.

## Working rules
- Treat "openspec/config.yaml", "openspec/specs/project-scope/spec.md", and "openspec/changes/cmno0tppt0001e9lnbswi4iqt" as the source of truth for scope.
- Read the full user stories before making changes.
- Use OpenSpec artifacts to plan the work before coding.
- Create the missing app scaffold, dependencies, scripts, and build files when the implementation needs them.
- Install dependencies from inside the project when the implementation needs them.
- Keep the result runnable and verify it before finishing.
- Prefer focused changes that satisfy the stories end to end.

## User stories
## 1. Scaffolding del Proyecto e Infraestructura Base para el equipo de inventario
sourceRunId: run-407e1218-4311-4a29-b0c6-fa1fdaa95ccf
Módulo: Infraestructura Base

Como base obligatoria de la migración, se debe construir una aplicación moderna separada en /backend y /frontend que arranque localmente sin bloqueos y sea accesible desde navegador ejecutando ./run.sh o ./run.ps1. Esta historia toma como trazabilidad técnica el arranque global observado en Global.asax.cs, el registro de rutas en App_Start/RouteConfig.cs, el registro de bundles en App_Start/BundleConfig.cs y la estructura general de páginas maestras Site.Master.cs y Site.Mobile.Master.cs. Aunque el código fuente original está orientado a páginas servidor y scripts de soporte de framework, el objetivo aquí es reemplazar esa base por una arquitectura hexagonal en Spring Boot 3 y una SPA React 18 con Vite, sin depender de ningún contenedor. Debe incluirse configuración completa de seguridad JWT, CORS dinámico, auditoría, manejo global de errores, Flyway baseline y seed con usuario admin funcional, OpenAPI, health checks y scripts de run/stop/smoke test que detecten puertos libres para base de datos, backend y frontend. En frontend, el usuario debe ver al abrir el navegador un layout real con sidebar colapsable, header con breadcrumbs y pantalla inicial operativa. También se deben instalar todas las dependencias exigidas y validar que el JAR generado y node_modules cumplan el peso/volumen mínimo esperado. Si algún detalle del legado no tiene correlato funcional directo en esta base, se documenta en DOCS.md como mapeo de migración.

Actor: Administrador del sistema

Flujo funcional:
1. El usuario ejecuta ./run.sh o ./run.ps1 desde la raíz del proyecto.
2. El script valida Java 17+, Node 18+, npm y psql; instala dependencias si es viable con SUDO_AUTH.
3. El script resuelve dependencias Maven y NPM, compila backend, instala frontend y verifica artefactos mínimos.
4. El script detecta puertos libres para PostgreSQL, backend y frontend, los persiste en .pids/ports.env y los muestra en consola.
5. El sistema crea o reutiliza rol/base de datos, ejecuta migraciones Flyway y carga seed inicial con usuario admin.
6. El backend arranca en el puerto asignado, expone /actuator/health, /v3/api-docs y seguridad sobre /api/v1/.
7. El frontend arranca con Vite HMR en puerto libre, renderiza HTML con div#root y muestra el layout base.
8. El usuario abre la URL del frontend y navega la pantalla inicial.
9. Desviación: si no hay puerto libre en el rango permitido, el script informa error específico y finaliza.
10. Desviación: si el backend no llega a estado UP o no expone OpenAPI, se muestran últimas líneas del log backend y se aborta el arranque.
11. Desviación: si el frontend no responde 200 o no contiene root, se muestran últimas líneas del log frontend y se aborta el arranque.
12. En segundo plano se ejecutan smoke tests y tests completos sin detener la app por fallos.

Pantallas / superficies: Rutas React: /, /login, /productos, /about, /contact, /pendiente/*; componentes: App.tsx, Layout.tsx, ProtectedRoute.tsx, FuncionalidadPendiente.tsx, AuthContext.tsx; endpoints Spring: GET /actuator/health, GET /v3/api-docs, GET /swagger-ui/**, POST /auth/login, POST /auth/refresh, GET /api/v1/; retorno: desde toda pantalla secundaria botón 'Volver a Inicio' hacia /.

Reglas de negocio:
1. Ningún puerto puede hardcodearse; backend, frontend y base de datos deben leer variables de entorno con defaults por perfil dev.
2. El script de arranque debe buscar puerto libre desde 5433 para DB, 8081 para backend y 3001 para frontend, con máximo 20 intentos por servicio.
3. Los tres puertos asignados deben ser distintos entre sí.
4. Si no se encuentra puerto libre en el rango base-base+20, se debe abortar con mensaje explícito.
5. Debe existir perfil dev/test/prod en backend y los perfiles dev/test deben tener archivos separados.
6. Debe habilitarse seguridad stateless con JWT y dejar públicos solamente /auth/**, /actuator/health, /v3/api-docs/** y /swagger-ui/**.
7. Toda ruta /api/v1/** debe quedar protegida por autenticación y responder 401 o 403 sin credenciales válidas.
8. Debe generarse JWT con claims sub, roles, iat, exp a 1 hora y jti UUID.
9. Debe existir usuario admin sembrado con username admin y password admin123 en hash bcrypt funcional.
10. Debe configurarse CORS desde CORS_ALLOWED_ORIGINS, sin lista fija en código.
11. Debe existir manejo global de errores con shape {timestamp,status,code,message,details?,path}.
12. Debe existir baseline Flyway y seed inicial en SQL versionado.
13. El backend debe exponer health activo y documentación OpenAPI accesible tras arranque.
14. El frontend debe usar BrowserRouter, React Query, Axios con base URL dinámica y guards de autenticación.
15. El layout inicial visible al usuario debe incluir sidebar colapsable, header breadcrumbs y contenido.
16. Debe existir hot-reload en frontend mediante Vite.
17. run.sh y run.ps1 no pueden detener la aplicación si fallan smoke tests o tests completos.
18. smoke-test.sh y smoke-test.ps1 deben ejecutar 8 verificaciones y reportar resumen sin cortar en el primer fallo.
19. stop.sh y stop.ps1 deben leer PIDs, aplicar SIGTERM, esperar 5 segundos y forzar SIGKILL si el proceso sigue vivo.
20. Deben limpiarse .pids/*.pid y .pids/ports.env al detener.
21. package.json debe incluir las dependencias maestras indicadas y superar 15 dependencias directas.
22. pom.xml debe incluir starters web, data-jpa, security, validation, actuator, PostgreSQL, Flyway, JWT, springdoc, test y H2.
23. El JAR generado debe superar 40MB y node_modules debe contener al menos 50 paquetes directos/instalados.
24. Debe existir README.md con troubleshooting de puertos y conexión, y DOCS.md con arquitectura y mapeo de migración.
25. Los logs deben estar centralizados en logs/ con correlation ID y formato JSON en backend.
26. La app debe mantenerse corriendo al final del script mostrando logs, y Ctrl+C no debe matar procesos.

Notas técnicas:
Endpoint API: POST /auth/login request {username:string obligatorio,password:string obligatorio}; response 200 {token:string,refreshToken:string,tokenType:string,expiresIn:number,roles:string[]} o 401 ErrorResponse. POST /auth/refresh request {refreshToken:string obligatorio}; response 200 con mismo schema. GET /api/v1/ response 200 {service:string,status:string,version:string} autenticado. GET /actuator/health público. GET /v3/api-docs público. Tabla DB: V001__baseline_schema.sql crea t95usu03_usuarios {usr_id bigserial PK, usr_username varchar(50) NOT NULL UNIQUE, usr_password_hash varchar(255) NOT NULL, usr_roles varchar(255) NOT NULL, usr_activo boolean NOT NULL default true, aud_created_at timestamp NOT NULL default now(), aud_created_by varchar(100), aud_updated_at timestamp, aud_updated_by varchar(100)} y tabla t95rft01_refresh_tokens {rft_id bigserial PK, rft_username varchar(50) NOT NULL FK lógica a usuarios por username, rft_token varchar(255) NOT NULL UNIQUE, rft_expiration_at timestamp NOT NULL, rft_revocado boolean NOT NULL default false}. Auth/Authz: JWT con ROLE_ADMIN y ROLE_OPERADOR; sin JWT en localStorage, usar memoria/contexto y refresh token en cookie httpOnly o memoria controlada conservadora documentada; rutas /api/v1/** protegidas. Error mapping: MethodArgumentNotValidException->400 VALIDATION_ERROR; EntityNotFoundException->404 NOT_FOUND; DataIntegrityViolationException->409 DATA_INTEGRITY; AccessDeniedException->403 ACCESS_DENIED; AuthenticationException->401 UNAUTHORIZED; genérico->500 INTERNAL_ERROR. Flyway: V001__baseline_schema.sql y V999__seed_datos_iniciales.sql con admin/admin123 bcrypt. Paquetes: com.demoaspforms.infraestructura.{domain,application,infrastructure,api}; com.demoaspforms.auth.{domain,application,infrastructure,api}. Transacciones: @Transactional en AuthService para login/refresh/persistencia de refresh tokens; aislamiento READ_COMMITTED. Cache/estado: React Query con staleTime 30000 y gcTime 300000; invalidación de auth y recursos raíz tras login/logout. DEPENDENCIAS MAVEN: spring-boot-starter-web, spring-boot-starter-data-jpa, spring-boot-starter-security, spring-boot-starter-validation, spring-boot-starter-actuator, postgresql, flyway-core, flyway-database-postgresql, jjwt-api, jjwt-impl, jjwt-jackson, springdoc-openapi-starter-webmvc-ui, lombok, devtools, spring-boot-starter-test, spring-security-test, h2. DEPENDENCIAS NPM: react, react-dom, react-router-dom, @tanstack/react-query, axios, zod, react-hook-form, @hookform/resolvers, tailwindcss, autoprefixer, postcss, sonner, lucide-react, clsx, date-fns, typescript, vite, @vitejs/plugin-react, eslint, prettier, testing-library, vitest, jsdom, playwright. UI/UX: tokens propios en tailwind.config.js, skip link, estados idle/loading/error/empty/success, skeletons básicos en layout, responsive mobile-first, contraste AA, botón retorno en pantallas secundarias a /. TESTS: Backend unitarios SecurityConfigTest_publicEndpointsAccessible, JwtUtilTest_generatesValidClaims, AuthControllerTest_loginResponds200Or401, HealthEndpointIT_statusUp; frontend AppRenderTest_showsRootLayout, ProtectedRouteTest_redirectsUnauthenticated, LayoutTest_sidebarToggleWorks, axiosInstanceTest_readsEnvBaseUrl; smoke test coverage 8 checks definidos por script, todos parametrizados con env y puertos dinámicos. confianza: alta
Criterios:
  1. Dado que se ejecuta ./run.sh sin Docker, cuando el entorno tiene Java 17+, Node 18+, npm y psql disponibles, entonces el script descarga dependencias, genera un JAR mayor a 40MB, instala node_modules con más de 50 paquetes y continúa al arranque.
  2. Dado que 5433, 8081 o 3001 están ocupados, cuando se ejecuta ./run.sh, entonces se asigna el siguiente puerto libre para DB, backend y frontend, los 3 puertos resultan distintos y quedan persistidos en .pids/ports.env.
  3. Dado que la base de datos está disponible, cuando run.sh ejecuta migraciones, entonces existen tablas públicas creadas por Flyway y el usuario admin/admin123 queda sembrado y utilizable en la autenticación.
  4. Dado que el backend arrancó, cuando se consulta GET /actuator/health y GET /v3/api-docs en el puerto asignado, entonces health responde status UP y api-docs expone openapi 3.
  5. Dado que el backend está levantado, cuando se consulta GET /api/v1/ sin token, entonces responde HTTP 401 o 403 confirmando que la seguridad está activa.
  6. Dado que el frontend inició con Vite, cuando se abre http://localhost:$FRONTEND_PORT/, entonces responde HTTP 200 con HTML que contiene el div id="root" y renderiza el Layout base visible.
  7. Dado que la app está corriendo vía ./run.sh, cuando se ejecuta ./smoke-test.sh, entonces reporta el resultado de 8 pruebas sin detener la aplicación y retorna código 0 si al menos 5 pasan.
  8. Dado que existen procesos iniciados, cuando se ejecuta ./stop.sh, entonces se detienen backend y frontend, se limpian los PID files y se liberan los puertos registrados.
  9. mvn dependency:tree lista starter-web,-data-jpa,-security,-validation,postgresql,flyway-core,jjwt-api,springdoc. JAR >40MB. node_modules tiene react,react-dom,react-router-dom,@tanstack/react-query,axios,zod,vite,typescript,tailwindcss +15 más.
  10. Dado que se ejecuta ./run.sh sin Docker: (1) descarga dependencias, (2) JAR >40MB + node_modules >50 paquetes, (3) detecta puertos libres para DB/backend/frontend — si 5433/8081/3001 ocupados asigna siguiente libre, los 3 puertos son distintos entre sí, (4) migración+seed con usuario admin funcional, (5) backend inicia y /actuator/health=UP en puerto asignado, (6) frontend inicia y sirve HTML con div#root en puerto asignado, (7) el usuario puede abrir http://localhost:$FRONTEND_PORT en el navegador y ver la app, (8) el usuario puede abrir http://localhost:$BACKEND_PORT/swagger-ui/ y ver la documentación API, (9) CORS permite requests del frontend al backend, (10) smoke-test.sh reporta estado sin detener la app, (11) tests se ejecutan en background sin bloquear la app, (12) app se mantiene corriendo con hot-reload en frontend, (13) stop.sh mata procesos y libera puertos.

---

## 2. Consultar listado de productos para el operador de inventario
sourceRunId: run-407e1218-4311-4a29-b0c6-fa1fdaa95ccf
Módulo: Productos

Esta historia materializa la lectura principal del inventario, equivalente al flujo de carga inicial de la página principal. Se extrae de MiInventario.BLL.Services.ProductoService.ObtenerTodos, MiInventario.DAL.Repositories.ProductoRepository.GetAll y WebFormsApp/Default.aspx.cs en los bloques Page_Load, Cargar y DataBind del GridView. El comportamiento observado es directo: al entrar a la pantalla principal, si no es postback se consulta la totalidad de productos, se proyectan desde entidad a modelo y se muestran en grilla. En la migración moderna esto debe transformarse en un endpoint REST de lectura y una pantalla React de listado con tabla, búsqueda, paginación y estados visuales consistentes. Como el código fuente no implementa filtros ni ordenamientos explícitos, se adopta una decisión conservadora: mantener lectura completa como comportamiento base y añadir paginación técnica estándar sin alterar el resultado funcional del MVP. La historia también absorbe la definición implícita de datos presente en Producto.cs y ProductoEntity.cs: Id entero, Nombre string, Cantidad entero y Precio decimal. El valor de negocio es permitir que el operador vea el inventario disponible apenas ingresa al módulo, con información lista para tomar decisiones o ejecutar altas y bajas posteriores.

Actor: Operador de inventario

Flujo funcional:
1. El operador accede a la ruta /productos.
2. El frontend solicita al backend el listado paginado de productos.
3. El backend consulta la tabla de productos, mapea entidades a DTOs y devuelve la colección.
4. La pantalla muestra tabla con columnas Id, Nombre, Cantidad y Precio.
5. El usuario puede navegar páginas y ordenar visualmente por columnas permitidas.
6. Desviación: si no hay productos, se presenta estado empty con mensaje y CTA para crear producto.
7. Desviación: si falla la consulta por error de servidor o red, se muestra estado error con acción Reintentar.
8. Desviación: si el usuario no está autenticado, ProtectedRoute redirige al login.

Pantallas / superficies: Ruta React: /productos; componentes: Layout.tsx, ProductoListPage.tsx, ProductoTable.tsx; endpoint Spring: GET /api/v1/productos?page={number}&size={number}&sort={campo,dir}; botón retorno: N/A por ser pantalla padre, secundarias vuelven a /productos.

Reglas de negocio:
1. La carga inicial del listado debe ocurrir al ingresar a la pantalla, análogo a Page_Load con condición !IsPostBack.
2. Debe recuperarse la totalidad lógica de registros existentes en repositorio, ahora expuesta paginada para transporte.
3. Cada registro debe mapear Id, Nombre, Cantidad y Precio sin campos adicionales.
4. Id es numérico entero.
5. Nombre es texto y en el modelo origen nunca es nulo, por lo que la respuesta no debe devolver null para ese campo.
6. Cantidad es numérica entera.
7. Precio es decimal monetario.
8. Si no existen registros, la operación no falla; devuelve lista vacía.
9. El orden por defecto conservador será id ascendente para asegurar determinismo, ya que el legado hacía ToList sin orden explícito.
10. page por defecto es 0.
11. size por defecto es 14 y máximo 100 según contrato maestro.
12. Solo se exponen campos acordados del recurso producto.
13. La consulta requiere autenticación por pertenecer a /api/v1/**.

Notas técnicas:
Endpoint API: GET /api/v1/productos?page:number opcional&size:number opcional&sort:string opcional -> 200 {content:[{id:number,nombre:string,cantidad:number,precio:number}],totalElements:number,totalPages:number,size:number,number:number,first:boolean,last:boolean}. Tabla DB: V002__crear_tabla_productos.sql crea inv01_productos {prd_id bigserial PK, prd_nombre varchar(150) NOT NULL, prd_cantidad integer NOT NULL, prd_precio numeric(12,2) NOT NULL, aud_created_at timestamp NOT NULL default now(), aud_created_by varchar(100), aud_updated_at timestamp, aud_updated_by varchar(100)} con índice idx_inv01_productos_nombre sobre prd_nombre. Auth/Authz: JWT obligatorio; roles ROLE_ADMIN y ROLE_OPERADOR pueden consultar. Error mapping: token inválido->401, acceso denegado->403, errores inesperados->500 ErrorResponse. Flyway: V002__crear_tabla_productos.sql. Paquetes: com.demoaspforms.productos.{domain,application,infrastructure,api}. Transacciones: @Transactional(readOnly = true) en ProductoQueryService.listar. Cache/estado: React Query key ['productos', page, size, sort, q]; mantenerPreviousData para paginación; refetch manual en retry. DEPENDENCIAS MAVEN: starter-web, starter-data-jpa, starter-validation, springdoc. DEPENDENCIAS NPM: react-router-dom, @tanstack/react-query, axios, clsx, date-fns, lucide-react. UI/UX: tabla con hover de filas, orden visual, paginación, skeleton durante carga, empty state con CTA 'Agregar producto', error con botón Reintentar, responsive 1280/375, moneda con 2 decimales, foco visible. TESTS: unitarios ProductoMapperTest_mapsEntityToResponse, ProductoQueryServiceTest_returnsPagedResults; integración ProductoControllerIT_getProductos200WithAuth, ProductoRepositoryIT_findAllPaged; frontend ProductoListPage.test rendersRowsAndEmptyState, pagination changes query key; smoke coverage: endpoint documentado y protegido. confianza: alta
Criterios:
  1. Dado un usuario autenticado con ROLE_OPERADOR y 2 productos registrados, cuando consulta GET /api/v1/productos?page=0&size=14, entonces recibe 200 con content de 2 elementos y campos id, nombre, cantidad y precio tipados.
  2. Dado que existen productos en base, cuando el operador abre /productos, entonces la tabla refleja los registros sin recargar manualmente la página.
  3. Dado que no existen productos, cuando se abre /productos, entonces se muestra estado vacío con mensaje 'No hay productos cargados' y acción 'Agregar producto'.
  4. Dado un backend no disponible o error 500, cuando el frontend intenta cargar /productos, entonces se muestra mensaje de error y botón Reintentar.
  5. Dado un usuario sin autenticación, cuando accede a GET /api/v1/productos, entonces recibe 401 o 403 con ErrorResponse {timestamp,status,code,message,path}.
  6. Dado que se solicita size=200, cuando el backend procesa la consulta, entonces limita o rechaza el tamaño máximo a 100 según contrato paginado.
  7. GET /api/v1/productos válida → campos id,nombre,cantidad,precio tipos number,string,number,number. Error validación → 400 {timestamp,status,code,message,details,path}.
  8. Migraciones Flyway → tabla inv01_productos con columnas prd_id,prd_nombre,prd_cantidad,prd_precio,aud_created_at,aud_created_by,aud_updated_at,aud_updated_by, tipos PostgreSQL bigserial,varchar,integer,numeric,timestamp,varchar,timestamp,varchar, PK prd_id, FKs ninguna en V002__crear_tabla_productos.sql.
  9. /productos: (1) skeleton durante carga, (2) renderiza 1280px y 375px, (3) contraste 4.5:1 + touch 44x44, (4) botón retorno a N/A por ser pantalla base, (5) errores inline color+icono, (6) toast sonner tras éxito no aplica en lectura.

---

## 3. Registrar un producto nuevo desde modal para el operador de inventario
sourceRunId: run-407e1218-4311-4a29-b0c6-fa1fdaa95ccf
Módulo: Productos

Esta historia cubre el alta de productos tal como está implementada en la solución original. La trazabilidad principal está en WebFormsApp/Default.aspx.cs dentro de btnGuardar_Click, junto con MiInventario.BLL.Services.ProductoService.Agregar y MiInventario.DAL.Repositories.ProductoRepository.Add. El flujo observado es: limpiar mensaje de error, convertir cantidad y precio desde texto con CultureInfo.InvariantCulture, crear modelo Producto con Nombre trim, Cantidad y Precio parseados, invocar el servicio, limpiar los campos, recargar la grilla y cerrar el modal. También hay dos caminos de error diferenciados: FormatException para valores numéricos inválidos y Exception genérica para fallos de negocio como nombre requerido. En la migración, esto se debe traducir a un formulario React con validación Zod en frontend y Bean Validation/servicio en backend, preservando el comportamiento funcional y el texto de error de forma equivalente. El alcance no inventa reglas adicionales no presentes en el legado; por eso la validación de negocio explícita se limita a nombre requerido y a que cantidad/precio sean números válidos. Se adopta una decisión conservadora sobre negativos: el código fuente no los bloquea, por lo tanto no se prohíben en esta historia salvo que futuras reglas lo indiquen.

Actor: Operador de inventario

Flujo funcional:
1. El operador abre el modal o formulario de alta desde /productos.
2. Ingresa nombre, cantidad y precio.
3. El frontend normaliza trim del nombre y envía POST al backend.
4. El backend valida datos, persiste el producto y responde con el registro creado.
5. El frontend limpia formulario, cierra modal, muestra toast de éxito e invalida el listado para reflejar el nuevo producto sin recarga.
6. Desviación: si cantidad o precio no son numéricos válidos, se muestran errores inline equivalentes al mensaje de formato inválido.
7. Desviación: si el nombre está vacío o solo contiene espacios, el backend responde error de validación/negocio y el modal permanece abierto.
8. Desviación: si ocurre error inesperado de persistencia, se muestra toast de error y se conserva el contenido del formulario para corrección.

Pantallas / superficies: Ruta React: /productos/nuevo o modal sobre /productos; componentes: ProductoForm.tsx, ProductoCreateModal.tsx, ProductoListPage.tsx; endpoint Spring: POST /api/v1/productos; botón retorno: 'Volver a Productos' hacia /productos si se usa página dedicada.

Reglas de negocio:
1. Antes de procesar el alta se debe limpiar el mensaje de error previo, equivalente a lblModalError.Text = string.Empty.
2. El nombre enviado al servicio debe aplicarse con trim de espacios extremos.
3. Cantidad debe poder convertirse a entero válido usando formato invariante; si no, la operación falla por error de formato.
4. Precio debe poder convertirse a decimal válido usando formato invariante; si no, la operación falla por error de formato.
5. Si el nombre es null, vacío o whitespace, el servicio debe rechazar el alta con mensaje de negocio 'Nombre requerido'.
6. Si cantidad y precio son válidos y el nombre cumple, se debe persistir un nuevo producto.
7. En la persistencia de alta no se debe enviar Id manualmente; se genera en base de datos.
8. Tras alta exitosa, el formulario debe limpiarse.
9. Tras alta exitosa, el listado debe recargarse o invalidarse para incluir el nuevo registro.
10. Tras alta exitosa, la UI debe cerrarse si está en modal.
11. Si ocurre un FormatException en origen, en la app moderna debe mapearse a 400 con detalle funcional equivalente sobre cantidad/precio inválidos.
12. Si ocurre una excepción de negocio/genérica, debe mantenerse el formulario visible para corrección y mostrarse 'No se pudo guardar' con detalle controlado.
13. El modelo acepta Nombre string no nulo por defecto, Cantidad int y Precio decimal.
14. No existe validación explícita en el legado sobre máximos, mínimos o unicidad del nombre; no debe inventarse en esta historia.

Notas técnicas:
Endpoint API: POST /api/v1/productos request {nombre:string obligatorio,cantidad:integer obligatorio,precio:number obligatorio}. Response 201 {id:number,nombre:string,cantidad:number,precio:number}. Response 400 para formato/validación, 409 para integridad si apareciera una futura restricción, 500 genérico. Tabla DB: usa inv01_productos {prd_id, prd_nombre, prd_cantidad, prd_precio...}; constraints NOT NULL sobre nombre/cantidad/precio. Auth/Authz: JWT obligatorio; ROLE_ADMIN y ROLE_OPERADOR pueden crear. Error mapping: nombre en blanco->400 VALIDATION_ERROR o BUSINESS_RULE_VIOLATION con message 'Nombre requerido'; parse/format inválido->400 VALIDATION_ERROR con details sobre cantidad/precio; DataIntegrityViolation->409; error inesperado->500. Flyway: reutiliza V002__crear_tabla_productos.sql, sin nueva tabla. Paquetes: com.demoaspforms.productos.{domain,application,infrastructure,api}. Transacciones: @Transactional en ProductoCommandService.crearProducto. Cache/estado: invalidar query ['productos'] al éxito; actualización optimista opcional conservadora no requerida. DEPENDENCIAS MAVEN: starter-validation, starter-data-jpa, starter-web. DEPENDENCIAS NPM: react-hook-form, @hookform/resolvers, zod, @tanstack/react-query, sonner, axios, lucide-react. UI/UX: labels visibles Nombre/Cantidad/Precio, errores inline con icono rojo, submit disabled con spinner, modal accesible, cierre sólo al éxito o cancelación explícita, responsive, botón retorno a /productos si pantalla separada. TESTS: unitarios ProductoCommandServiceTest_rejectsBlankName, ProductoCommandServiceTest_createsProductoWhenValid; integración ProductoControllerIT_postProducto201, ProductoControllerIT_postProducto400WhenNombreBlank, ProductoControllerIT_postProducto400WhenInvalidPayload; frontend ProductoForm.test showsInlineErrorsAndSubmits, ProductoCreateModal.test closesOnSuccessAndInvalidatesList; smoke coverage: auth y endpoint vivo. confianza: alta
Criterios:
  1. Dado un usuario autenticado y payload {"nombre":"Teclado","cantidad":10,"precio":25.50}, cuando ejecuta POST /api/v1/productos, entonces recibe 201 con id generado y el listado refleja el nuevo registro sin recarga completa.
  2. Dado nombre compuesto solo por espacios, cuando el usuario intenta guardar, entonces el backend responde 400 con mensaje 'Nombre requerido' y el formulario permanece visible.
  3. Dado un valor de cantidad no numérico enviado desde frontend o cliente externo, cuando el backend procesa la solicitud, entonces responde 400 con ErrorResponse y detalle sobre cantidad inválida.
  4. Dado un valor de precio no numérico válido en esquema o malformado, cuando se intenta guardar, entonces se informa error de validación equivalente a 'Revise cantidad y precio: deben ser números válidos'.
  5. Dado una creación exitosa, cuando el modal se cierra, entonces la tabla de /productos muestra el nuevo producto y se limpia el formulario para el siguiente alta.
  6. Dado que el usuario reenvía la misma petición por doble click antes de recibir respuesta, cuando el frontend deshabilita submit durante loading, entonces no se generan duplicados por reenvío involuntario.
  7. POST /api/v1/productos válida → campos nombre,cantidad,precio tipos string,integer,number. Error validación → 400 {timestamp,status,code,message,details,path}.
  8. Tras operación exitosa, listado/detalle refleja estado sin recarga.
  9. Reenvío no genera duplicados.

---

## 4. Eliminar un producto desde el listado para el operador de inventario
sourceRunId: run-407e1218-4311-4a29-b0c6-fa1fdaa95ccf
Módulo: Productos

Esta historia implementa la baja de productos siguiendo exactamente el patrón observado en el legado. La extracción proviene de WebFormsApp/Default.aspx.cs en gvProductos_RowDeleting, MiInventario.BLL.Services.ProductoService.Eliminar y MiInventario.DAL.Repositories.ProductoRepository.Delete. El comportamiento es simple pero importante: al seleccionar eliminar sobre una fila, se recupera el Id desde DataKeys, se invoca el servicio y luego se vuelve a cargar el grid. En el repositorio, si el producto existe se elimina y se ejecuta SaveChanges; si no existe, no ocurre nada y no se lanza error. En la aplicación moderna esto debe reflejarse con una acción destructiva protegida por confirmación modal, endpoint DELETE y actualización inmediata del listado. También debe conservarse el comportamiento idempotente implícito del legado: borrar un Id inexistente no debe romper el flujo. No existe una validación adicional de integridad o estado en el código fuente, por lo que la historia no agrega restricciones artificiales. El valor funcional es permitir depurar inventario obsoleto o incorrecto con una operación segura y trazable.

Actor: Operador de inventario

Flujo funcional:
1. El operador visualiza la tabla de productos en /productos.
2. Selecciona la acción Eliminar en una fila.
3. El sistema muestra modal de confirmación destructiva.
4. Al confirmar, el frontend llama DELETE /api/v1/productos/{id}.
5. El backend intenta localizar y eliminar el registro si existe.
6. El frontend invalida el listado, muestra toast de éxito y la fila desaparece sin recarga completa.
7. Desviación: si el usuario cancela en el modal, no se ejecuta ninguna llamada.
8. Desviación: si el producto ya no existe, la operación se trata como idempotente y el listado se refresca sin error bloqueante.
9. Desviación: si ocurre un fallo de servidor, se informa error y no se altera visualmente la fila hasta refetch exitoso.

Pantallas / superficies: Ruta React: /productos; componentes: ProductoTable.tsx, ConfirmDeleteModal.tsx; endpoint Spring: DELETE /api/v1/productos/{id}; botón retorno: N/A por estar en pantalla principal.

Reglas de negocio:
1. El Id a eliminar proviene de la fila seleccionada, equivalente a DataKeys[e.RowIndex].Value.
2. La operación de eliminación debe invocar una capa de servicio intermedia.
3. Si el producto con ese Id existe, debe eliminarse físicamente de la tabla.
4. Si el producto no existe, no debe lanzarse excepción en el comportamiento base; la operación es silenciosa/idempotente.
5. Tras eliminar, el listado debe recargarse o invalidarse para reflejar la ausencia del registro.
6. La UI debe requerir confirmación explícita por tratarse de acción destructiva, decisión de UX moderna compatible con la operación legacy.
7. La eliminación requiere autenticación por pertenecer al API protegido.
8. El código fuente no define soft delete ni estados intermedios; la baja es definitiva.

Notas técnicas:
Endpoint API: DELETE /api/v1/productos/{id:number obligatorio} -> 204 sin body si elimina o si el recurso ya no existe para preservar idempotencia; opcional 404 sólo si se decide semántica estricta, pero por trazabilidad se recomienda 204. Tabla DB: inv01_productos con PK prd_id. Auth/Authz: JWT obligatorio; ROLE_ADMIN y ROLE_OPERADOR pueden eliminar. Error mapping: id malformado->400; acceso denegado->403; fallo de persistencia->500; no encontrado->204 por idempotencia conservadora. Flyway: sin cambios de esquema. Paquetes: com.demoaspforms.productos.{domain,application,infrastructure,api}. Transacciones: @Transactional en ProductoCommandService.eliminarProducto. Cache/estado: invalidar ['productos']; alternativamente update local eliminando fila por id tras 204. DEPENDENCIAS MAVEN: starter-web, starter-data-jpa. DEPENDENCIAS NPM: @tanstack/react-query, axios, sonner, lucide-react. UI/UX: botón eliminar con icono y texto accesible, modal destructivo con foco atrapado, botón cancelar y confirmar, toast success 3s / error 5s, responsive. TESTS: unitarios ProductoCommandServiceTest_deletesExistingProducto, ProductoCommandServiceTest_deleteMissingDoesNothing; integración ProductoControllerIT_deleteReturns204Existing, ProductoControllerIT_deleteReturns204Missing; frontend ProductoTable.test opensConfirmModal, delete mutation removesRowWithoutReload. confianza: alta
Criterios:
  1. Dado un producto existente con id 5, cuando el operador confirma DELETE /api/v1/productos/5, entonces la respuesta es 204 y la fila desaparece del listado sin recarga completa.
  2. Dado un producto inexistente con id 9999, cuando se ejecuta DELETE /api/v1/productos/9999, entonces la respuesta sigue siendo 204 para mantener idempotencia y la pantalla permanece consistente.
  3. Dado que el usuario presiona cancelar en el modal de confirmación, cuando vuelve al listado, entonces no se invoca el endpoint y el registro sigue visible.
  4. Dado un usuario no autenticado, cuando intenta eliminar un producto, entonces recibe 401 o 403 con ErrorResponse estándar.
  5. Dado un error interno de base de datos, cuando se ejecuta la baja, entonces el frontend muestra toast de error y conserva el estado visual previo hasta reintento.
  6. Dado que dos operadores intentan eliminar el mismo producto, cuando el segundo confirma después del primero, entonces el segundo flujo no falla funcionalmente y el resultado final sigue siendo que el producto no existe.
  7. DELETE /api/v1/productos/{id} válida → campos de ruta id tipo number. Error validación → 400 {timestamp,status,code,message,details,path}.
  8. Tras operación exitosa, listado/detalle refleja estado sin recarga.
  9. Reenvío no genera duplicados.

---

## 5. Modelar dominio y persistencia de productos para asegurar trazabilidad de inventario
sourceRunId: run-407e1218-4311-4a29-b0c6-fa1fdaa95ccf
Módulo: Productos

Esta historia consolida el modelo de datos de producto que aparece repartido entre BLL y DAL en la solución original. La trazabilidad nace en MiInventario.BLL.Models.Producto, MiInventario.DAL.Entities.ProductoEntity, MiInventario.DAL.Context.InventarioContext y los repositorios/servicios que utilizan dichos tipos. Aunque ya existe comportamiento visible en historias anteriores, aquí se formaliza la estructura persistente y de dominio para que el sistema moderno quede listo para producción con convenciones explícitas, auditoría y mapeos claros. El legado define solamente cuatro propiedades esenciales: Id, Nombre, Cantidad y Precio, sin nullable explícitos y con Nombre inicializado a string.Empty. Esto implica en la migración una entidad JPA y DTOs inmutables con restricciones NOT NULL y semántica simple. También se migra la noción de contexto InventarioContext como fuente única del conjunto Productos hacia PostgreSQL con Spring Data JPA. Esta historia agrega valor arquitectónico: evita ambigüedades entre modelos de entrada, salida y persistencia, habilita índices y deja la base preparada para futuras ampliaciones sin desviarse del comportamiento actual.

Actor: Arquitecto de soluciones

Flujo funcional:
1. El desarrollador ejecuta migraciones Flyway del módulo productos.
2. La base crea la tabla y restricciones del recurso producto.
3. El backend expone entidad JPA, repositorio Spring Data y mappers a DTO.
4. Las historias de consulta, alta y baja utilizan el mismo modelo persistente y de dominio.
5. Desviación: si la migración ya fue aplicada, Flyway no la reejecuta.
6. Desviación: si existe inconsistencia de esquema, Flyway detiene la aplicación en startup y deja trazabilidad en logs.
7. Desviación: si algún campo requerido es null desde código, JPA/validación impide la persistencia.

Pantallas / superficies: N/A

Reglas de negocio:
1. Producto tiene Id entero/autogenerado.
2. Producto tiene Nombre obligatorio y no nulo.
3. Producto tiene Cantidad obligatoria y numérica entera.
4. Producto tiene Precio obligatorio y decimal.
5. InventarioContext legacy tenía un único DbSet de productos; el módulo moderno debe tener un único agregado persistente para productos en el MVP.
6. El modelo de entidad y el modelo de negocio deben mapear uno a uno esos cuatro campos base.
7. La tabla debe respetar convención underscore universal en nombre de tabla y columnas.
8. La persistencia debe soportar lectura completa, inserción y eliminación ya identificadas en código.
9. El contexto de datos debe apuntar a la base de inventario configurada por variables de entorno.

Notas técnicas:
Endpoint API: N/A directo, soporta historias 2-4. Tabla DB: inv01_productos {prd_id bigserial PK, prd_nombre varchar(150) NOT NULL, prd_cantidad integer NOT NULL, prd_precio numeric(12,2) NOT NULL, aud_created_at timestamp NOT NULL default now(), aud_created_by varchar(100), aud_updated_at timestamp, aud_updated_by varchar(100)}; índice idx_inv01_productos_nombre(prd_nombre). Auth/Authz: sin regla adicional, hereda JWT para endpoints consumidores. Error mapping: violación NOT NULL ->409 o 500 según capa; startup schema error -> app fail-fast. Flyway: V002__crear_tabla_productos.sql y si se requiere índice explícito V003__indice_productos_nombre.sql. Paquetes: com.demoaspforms.productos.domain.Producto, com.demoaspforms.productos.infrastructure.persistence.ProductoEntity/ProductoRepositoryJpa, mappers en application. Transacciones: repositorio usado bajo servicios transaccionales; lecturas readOnly, escrituras estándar. Cache/estado: no aplica directo. DEPENDENCIAS MAVEN: starter-data-jpa, postgresql, flyway-core. DEPENDENCIAS NPM: N/A específica. UI/UX: N/A. TESTS: @DataJpaTest ProductoEntityMappingTest_persistsRequiredFields, FlywayMigrationIT_productosTableExists, ProductoRepositoryJpaTest_saveAndDelete; smoke coverage indirecta mediante conteo de tablas y operaciones CRUD. confianza: alta
Criterios:
  1. Dado que se ejecutan migraciones Flyway, cuando inicia el backend, entonces existe la tabla inv01_productos con columnas prd_id, prd_nombre, prd_cantidad y prd_precio definidas según PostgreSQL.
  2. Dado un ProductoEntity válido, cuando se persiste vía JPA, entonces se genera prd_id automáticamente y los campos obligatorios quedan almacenados.
  3. Dado un intento de persistir un producto sin nombre, cuando JPA/servicio lo procesa, entonces la operación falla por validación o restricción NOT NULL.
  4. Dado el repositorio del módulo, cuando se consulta pageable, entonces devuelve entidades mapeables al DTO de negocio sin N+1 ni campos extra.
  5. Dado el esquema ya aplicado, cuando el backend reinicia, entonces Flyway reconoce la versión y no duplica objetos.
  6. Migraciones Flyway → tabla inv01_productos con columnas prd_id,prd_nombre,prd_cantidad,prd_precio,aud_created_at,aud_created_by,aud_updated_at,aud_updated_by, tipos PostgreSQL bigserial,varchar,integer,numeric,timestamp,varchar,timestamp,varchar, PK prd_id, FKs ninguna en V002__crear_tabla_productos.sql.

---

## 6. Publicar páginas institucionales About y Contact para usuarios del sistema
sourceRunId: run-407e1218-4311-4a29-b0c6-fa1fdaa95ccf
Módulo: Navegación Institucional

La solución original incluye páginas About y Contact sin lógica de negocio en sus code-behind, además de una página maestra Site.Master que estructura el contenido. Esta historia traduce esas páginas a vistas modernas del frontend manteniendo su carácter informativo. La trazabilidad se encuentra en About.aspx.cs, Contact.aspx.cs, Site.Master.cs, Site.Master.designer.cs y en la configuración de navegación de Global.asax.cs y RouteConfig.cs. Dado que los code-behind están vacíos, se toma una decisión conservadora: las páginas se implementan como contenido estático institucional del sistema de inventario, con navegación desde el layout principal y sin backend asociado. El objetivo es cubrir completamente los artefactos de interfaz visibles del legado para que ningún recurso equivalente quede sin representación en la aplicación migrada. Además, la historia absorbe la existencia de Site.Mobile.Master.cs como indicio de intención responsive; en la nueva SPA esa necesidad se resuelve con diseño responsive único en vez de plantillas separadas.

Actor: Usuario autenticado

Flujo funcional:
1. El usuario abre el menú lateral del sistema.
2. Selecciona la opción Acerca de o Contacto.
3. El sistema navega a la ruta correspondiente y renderiza contenido informativo.
4. El usuario puede volver al inicio mediante botón de retorno y breadcrumb.
5. Desviación: si la ruta se carga directamente por URL, se renderiza correctamente dentro del layout.
6. Desviación: si ocurre error de carga diferida del bundle, se muestra mensaje de error y opción de reintentar.

Pantallas / superficies: Rutas React: /about, /contact; componentes: AboutPage.tsx, ContactPage.tsx, Layout.tsx; endpoint Spring: N/A; botón retorno: 'Volver a Inicio' hacia /.

Reglas de negocio:
1. About y Contact son páginas presentes en el legado y deben existir en la SPA.
2. No tienen lógica de negocio ni persistencia asociada.
3. Deben ser accesibles desde la navegación principal.
4. Deben renderizar dentro del layout común del sistema.
5. Deben incluir botón de retorno a la pantalla principal.
6. Deben ser responsive para cubrir la intención original de Site.Mobile.Master sin duplicar plantillas.

Notas técnicas:
Endpoint API: N/A. Tabla DB: N/A. Auth/Authz: accesibles para usuarios autenticados si se mantienen dentro del layout protegido; alternativamente públicas si el negocio lo requiere, conservadoramente protegidas por la app. Error mapping: N/A backend; frontend error boundary para lazy import. Flyway: N/A. Paquetes: frontend route pages en src/modules/navegacion-institucional; backend sin paquete específico. Transacciones: N/A. Cache/estado: lazy loading de rutas, sin React Query. DEPENDENCIAS MAVEN: N/A específica. DEPENDENCIAS NPM: react-router-dom, lucide-react, clsx. UI/UX: contenido con heading y párrafos, breadcrumbs, botón retorno a /, responsive 375/1280, foco visible, sin parecer pantalla vacía. TESTS: frontend AboutPage.test rendersContentAndBackButton, ContactPage.test rendersContentAndBreadcrumb; Playwright navigation-institutional.e2e.ts. confianza: media
Criterios:
  1. Dado un usuario autenticado, cuando navega a /about, entonces visualiza una página informativa dentro del layout con breadcrumb y botón 'Volver a Inicio'.
  2. Dado un usuario autenticado, cuando navega a /contact, entonces visualiza datos de contacto o texto institucional dentro del layout y puede regresar a /.
  3. Dado acceso directo por URL a /about o /contact, cuando la aplicación carga la ruta, entonces no responde 404 y renderiza correctamente.
  4. Dado resolución móvil 375px, cuando se renderiza /about, entonces el contenido mantiene legibilidad, contraste y objetivos táctiles mínimos.
  5. Dado resolución desktop 1280px, cuando se renderiza /contact, entonces el layout conserva sidebar, breadcrumbs y contenido alineado.
  6. /about: (1) skeleton durante carga, (2) renderiza 1280px y 375px, (3) contraste 4.5:1 + touch 44x44, (4) botón retorno a /, (5) errores inline color+icono no aplica, (6) toast sonner tras éxito no aplica.

---

## 7. Implementar selector de vista responsive moderno en reemplazo del conmutador de vistas
sourceRunId: run-407e1218-4311-4a29-b0c6-fa1fdaa95ccf
Módulo: Navegación Institucional

El código original incluye un control ViewSwitcher.ascx.cs que detecta vista móvil o desktop mediante Friendly URLs, calcula CurrentView, AlternateView y construye una URL de cambio de vista con ReturnUrl. También existen Site.Mobile.Master.cs y Site.Master.cs como plantillas separadas. En una SPA React moderna no corresponde mantener vistas paralelas por plantilla, pero sí debe conservarse la capacidad funcional de adaptación de experiencia al dispositivo. Esta historia migra ese propósito a un diseño responsive unificado y documenta la equivalencia. La trazabilidad se ubica en ViewSwitcher.ascx.cs, Site.Mobile.Master.cs y Site.Master.cs. Como no existe una regla de negocio profunda más allá de identificar Mobile/Desktop y ofrecer cambio de vista, la decisión conservadora es mostrar un indicador de modo actual basado en breakpoint y permitir, si se desea, un selector de preferencia de densidad visual en frontend sin alterar rutas. Esto cubre el artefacto legado sin reintroducir complejidad innecesaria.

Actor: Usuario del sistema

Flujo funcional:
1. El usuario accede al sistema desde desktop o móvil.
2. El layout detecta el breakpoint activo y adapta navegación y contenido.
3. En configuración visual o header se muestra el modo actual de visualización.
4. El usuario puede alternar preferencia de densidad/colapso de navegación sin cambiar de ruta.
5. Desviación: si el viewport cambia de tamaño, el layout se reacomoda automáticamente.
6. Desviación: si no hay soporte de storage local para preferencia, se usa comportamiento por defecto sin romper navegación.

Pantallas / superficies: Rutas React: / y todas las protegidas; componentes: Layout.tsx, ResponsiveViewBadge.tsx; endpoint Spring: N/A; botón retorno: N/A.

Reglas de negocio:
1. Debe distinguirse visualmente entre experiencia móvil y desktop según breakpoint.
2. El artefacto ViewSwitcher original calcula CurrentView y AlternateView; la SPA debe representar al menos el concepto de vista actual.
3. No se deben crear páginas móviles y desktop separadas; se resuelve con diseño responsive unificado.
4. Debe preservarse la continuidad de navegación actual al cambiar adaptación visual, equivalente al ReturnUrl del switcher original.
5. Si el mecanismo de cambio no está disponible, el sistema sigue siendo usable con adaptación automática.
6. La funcionalidad no requiere backend.

Notas técnicas:
Endpoint API: N/A. Tabla DB: N/A. Auth/Authz: sin impacto. Error mapping: N/A. Flyway: N/A. Paquetes: frontend/shared/layout. Transacciones: N/A. Cache/estado: preferencia UI en React Context o sessionStorage/localStorage si disponible; jamás en URL. DEPENDENCIAS MAVEN: N/A. DEPENDENCIAS NPM: react, react-router-dom, clsx. UI/UX: drawer móvil con overlay para sidebar, sidebar fija en desktop, badge de vista actual, animaciones 150-300ms, respeto a prefers-reduced-motion. TESTS: frontend LayoutResponsive.test mobileDrawerAppears, ViewModeIndicator.test showsMobileOrDesktop, Playwright responsive-layout.e2e.ts. confianza: media
Criterios:
  1. Dado viewport de 375px, cuando el usuario abre la app, entonces el sidebar se comporta como drawer con overlay y la experiencia se identifica como móvil.
  2. Dado viewport de 1280px, cuando el usuario abre la app, entonces el sidebar se muestra fijo/colapsable y la experiencia se identifica como desktop.
  3. Dado que el usuario navega en una ruta secundaria, cuando cambia el tamaño de pantalla, entonces mantiene la misma ruta y estado visual equivalente al ReturnUrl original.
  4. Dado que existe una preferencia visual almacenada, cuando el usuario vuelve a abrir la app, entonces se reaplica sin alterar seguridad ni navegación.
  5. Dado que storage del navegador no está disponible, cuando el usuario usa la app, entonces la adaptación responsive automática sigue funcionando.
  6. Ruta /: (1) skeleton durante carga, (2) renderiza 1280px y 375px, (3) contraste 4.5:1 + touch 44x44, (4) botón retorno a N/A, (5) errores inline no aplica, (6) toast sonner tras éxito no aplica.

---

## 8. Exponer funcionalidades y artefactos legacy no migrados aún como pendientes navegables
sourceRunId: run-407e1218-4311-4a29-b0c6-fa1fdaa95ccf
Módulo: Funcionalidades Pendientes

Durante el análisis se detectaron varios artefactos de soporte del framework anterior y componentes sin correlato funcional directo en el MVP de inventario: interfaces vacías IProductoService.cs e IProductoRepository.cs, los numerosos scripts de WebForms/MSAjax/Menu/TreeView/WebParts/SmartNav/WebUIValidation/Modernizr/jQuery/Bootstrap que pertenecen a infraestructura del framework previo más que a negocio, además de referencias de conmutación de vistas y master pages auxiliares. Para cobertura total sin inventar funcionalidades, esta historia crea el módulo de Funcionalidades Pendientes con rutas explícitas que documenten qué fue detectado y por qué no forma parte del MVP moderno. El objetivo es evitar 404 conceptuales, preservar trazabilidad y dejar claro al usuario y al equipo qué quedó planificado para versión futura o qué se descartó por ser infraestructura no aplicable. Esta historia se apoya en BundleConfig.cs, ViewSwitcher.ascx.cs, Site.Mobile.Master.cs, las interfaces vacías y el conjunto de scripts listados bajo WebFormsApp/Scripts.

Actor: Stakeholder del proyecto

Flujo funcional:
1. El usuario o tester navega a una ruta de pendiente desde menú técnico o documentación interna.
2. La aplicación muestra el componente reutilizable FuncionalidadPendiente con título, descripción y contexto.
3. El usuario entiende que la capacidad está planificada o no aplica al MVP.
4. Puede volver a la pantalla previa usando el botón de retorno.
5. Desviación: si se ingresa por URL directa, la ruta responde correctamente y no 404.
6. Desviación: si el nombre del pendiente no tiene detalle suficiente, se muestra una descripción conservadora de trazabilidad.

Pantallas / superficies: Rutas React sugeridas: /pendiente/interfaces-legacy, /pendiente/componentes-webforms, /pendiente/switcher-vistas-legado; componente: FuncionalidadPendiente.tsx; endpoint Spring: N/A; botón retorno: configurable hacia /.

Reglas de negocio:
1. Toda pantalla o artefacto referenciado sin backend/módulo moderno equivalente debe tener representación en Funcionalidades Pendientes.
2. Las interfaces vacías IProductoService e IProductoRepository deben documentarse como artefactos sin lógica migrable.
3. Los scripts de soporte WebForms/MSAjax/jQuery/bootstrap/modernizr del framework anterior no deben migrarse funcionalmente uno a uno; se documentan como reemplazados por stack moderno.
4. Las rutas de pendientes no deben devolver 404.
5. El componente pendiente debe indicar que la capacidad está planificada para versión futura o no aplica al MVP.
6. Cada pendiente debe ofrecer botón de retorno a una ruta válida.
7. No debe presentarse visualmente como error.

Notas técnicas:
Endpoint API: N/A. Tabla DB: N/A. Auth/Authz: accesible para usuarios autenticados; opcional solo ROLE_ADMIN si se desea menú técnico, pero la ruta debe existir. Error mapping: N/A. Flyway: N/A. Paquetes: frontend/modules/funcionalidades-pendientes. Transacciones: N/A. Cache/estado: N/A. DEPENDENCIAS MAVEN: N/A. DEPENDENCIAS NPM: react-router-dom, lucide-react, clsx. UI/UX: usar FuncionalidadPendiente con icono 64x64 neutro, badge 'Próximamente', descripción secundaria, botón retorno, copy en tono neutro; no parecer fallo. TESTS: frontend FuncionalidadPendiente.test rendersPropsAndBackButton; Playwright pendientes-routes.e2e.ts valida no 404 y retorno. confianza: alta
Criterios:
  1. Dado acceso a /pendiente/interfaces-legacy, cuando la ruta se renderiza, entonces muestra FuncionalidadPendiente con nombre, descripción y botón de retorno a /.
  2. Dado acceso a /pendiente/componentes-webforms, cuando la ruta se renderiza, entonces informa que los scripts del framework previo fueron sustituidos por capacidades nativas del stack moderno.
  3. Dado acceso por URL directa a cualquier ruta pendiente registrada, cuando la SPA resuelve la navegación, entonces no responde 404.
  4. Dado el componente FuncionalidadPendiente, cuando recibe props de título, descripción, rutaRetorno y nombreRetorno, entonces renderiza esos valores correctamente y el botón navega a la ruta indicada.
  5. Dado un usuario en móvil, cuando abre una ruta pendiente, entonces el contenido mantiene estética informativa y no se percibe como error técnico.
  6. /pendiente/interfaces-legacy: FuncionalidadPendiente con nombre, descripción, icono, 'planificada para versión futura', botón retorno a /. En Router, no 404.
