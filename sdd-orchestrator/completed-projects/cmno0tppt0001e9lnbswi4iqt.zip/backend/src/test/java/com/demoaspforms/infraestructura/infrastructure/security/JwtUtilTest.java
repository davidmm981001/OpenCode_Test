package com.demoaspforms.infraestructura.infrastructure.security;

import java.util.List;

import com.demoaspforms.infraestructura.infrastructure.config.JwtProperties;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class JwtUtilTest {

    @Test
    void generatesValidClaims() {
        JwtService service = new JwtService(new JwtProperties("demo-asp-forms", "ZGVtby1hc3AtZm9ybXMtZG9uZS1zZWNyZXQtMzItYnl0ZXMtbG9uZyEh", 60));

        String token = service.generateAccessToken("admin", List.of("ROLE_ADMIN", "ROLE_OPERADOR"));

        assertThat(service.getUsername(token)).isEqualTo("admin");
        assertThat(service.getRoles(token)).containsExactly("ROLE_ADMIN", "ROLE_OPERADOR");
        assertThat(service.isValid(token)).isTrue();
    }
}
