package com.demoaspforms.productos.application;

import java.math.BigDecimal;

import com.demoaspforms.productos.infrastructure.persistence.ProductoEntity;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class ProductoMapperTest {

    @Test
    void mapsEntityToResponse() {
        ProductoEntity entity = new ProductoEntity();
        entity.setId(1L);
        entity.setNombre("Teclado");
        entity.setCantidad(10);
        entity.setPrecio(new BigDecimal("25.50"));

        var producto = ProductoMapper.toDomain(entity);

        assertThat(producto.id()).isEqualTo(1L);
        assertThat(producto.nombre()).isEqualTo("Teclado");
        assertThat(producto.cantidad()).isEqualTo(10);
        assertThat(producto.precio()).isEqualByComparingTo("25.50");
    }
}
