package com.demoaspforms.productos.application;

import java.math.BigDecimal;

import com.demoaspforms.DemoAspFormsApplication;
import com.demoaspforms.productos.infrastructure.persistence.ProductoEntity;
import com.demoaspforms.productos.infrastructure.persistence.ProductoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(classes = DemoAspFormsApplication.class)
@ActiveProfiles("test")
class ProductoQueryServiceTest {

    @Autowired
    private ProductoRepository repository;

    @Autowired
    private ProductoQueryService service;

    @BeforeEach
    void setUp() {
        repository.deleteAll();
        ProductoEntity first = new ProductoEntity();
        first.setNombre("Teclado");
        first.setCantidad(10);
        first.setPrecio(new BigDecimal("25.50"));
        repository.save(first);

        ProductoEntity second = new ProductoEntity();
        second.setNombre("Mouse");
        second.setCantidad(20);
        second.setPrecio(new BigDecimal("15.00"));
        repository.save(second);
    }

    @Test
    void returnsPagedResults() {
        var page = service.listar(0, 14, null, null);
        assertThat(page.getContent()).hasSize(2);
        assertThat(page.getTotalElements()).isEqualTo(2);
    }
}
