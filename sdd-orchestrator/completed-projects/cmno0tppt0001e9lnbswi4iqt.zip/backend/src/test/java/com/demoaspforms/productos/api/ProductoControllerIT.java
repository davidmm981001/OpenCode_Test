package com.demoaspforms.productos.api;

import java.math.BigDecimal;

import com.demoaspforms.DemoAspFormsApplication;
import com.demoaspforms.auth.infrastructure.persistence.UsuarioEntity;
import com.demoaspforms.auth.infrastructure.persistence.UsuarioRepository;
import com.demoaspforms.infraestructura.infrastructure.security.JwtService;
import com.demoaspforms.productos.infrastructure.persistence.ProductoEntity;
import com.demoaspforms.productos.infrastructure.persistence.ProductoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(classes = DemoAspFormsApplication.class)
@AutoConfigureMockMvc
@ActiveProfiles("test")
class ProductoControllerIT {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;

    private String bearerToken;

    @BeforeEach
    void setUp() {
        productoRepository.deleteAll();
        usuarioRepository.deleteAll();

        UsuarioEntity admin = new UsuarioEntity();
        admin.setUsername("admin");
        admin.setPasswordHash(passwordEncoder.encode("admin123"));
        admin.setRoles("ROLE_ADMIN,ROLE_OPERADOR");
        admin.setActivo(true);
        usuarioRepository.save(admin);

        bearerToken = "Bearer " + jwtService.generateAccessToken("admin", java.util.List.of("ROLE_ADMIN", "ROLE_OPERADOR"));
    }

    @Test
    void getProductos200WithAuth() throws Exception {
        seedProducto("Teclado", 10, "25.50");
        seedProducto("Mouse", 20, "15.00");

        mockMvc.perform(get("/api/v1/productos").header("Authorization", bearerToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray())
                .andExpect(jsonPath("$.content.length()").value(2))
                .andExpect(jsonPath("$.content[0].id").isNumber())
                .andExpect(jsonPath("$.content[0].nombre").isString())
                .andExpect(jsonPath("$.content[0].cantidad").isNumber())
                .andExpect(jsonPath("$.content[0].precio").isNumber());
    }

    @Test
    void postProducto201() throws Exception {
        mockMvc.perform(post("/api/v1/productos").header("Authorization", bearerToken).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"nombre\":\"Teclado\",\"cantidad\":10,\"precio\":25.5}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").isNumber())
                .andExpect(jsonPath("$.nombre").value("Teclado"));
    }

    @Test
    void postProducto400WhenNombreBlank() throws Exception {
        mockMvc.perform(post("/api/v1/productos").header("Authorization", bearerToken).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"nombre\":\"   \",\"cantidad\":10,\"precio\":25.5}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("VALIDATION_ERROR"));
    }

    @Test
    void postProducto400WhenInvalidPayload() throws Exception {
        mockMvc.perform(post("/api/v1/productos").header("Authorization", bearerToken).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"nombre\":\"Teclado\",\"cantidad\":\"abc\",\"precio\":25.5}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void deleteReturns204Existing() throws Exception {
        Long id = seedProducto("Teclado", 10, "25.50");

        mockMvc.perform(delete("/api/v1/productos/{id}", id).header("Authorization", bearerToken))
                .andExpect(status().isNoContent());

        assertThat(productoRepository.findById(id)).isEmpty();
    }

    @Test
    void deleteReturns204Missing() throws Exception {
        mockMvc.perform(delete("/api/v1/productos/{id}", 9999).header("Authorization", bearerToken))
                .andExpect(status().isNoContent());
    }

    private Long seedProducto(String nombre, int cantidad, String precio) {
        ProductoEntity entity = new ProductoEntity();
        entity.setNombre(nombre);
        entity.setCantidad(cantidad);
        entity.setPrecio(new BigDecimal(precio));
        return productoRepository.save(entity).getId();
    }
}
