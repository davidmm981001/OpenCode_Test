package com.demoaspforms.productos.infrastructure.persistence;

import java.math.BigDecimal;

import com.demoaspforms.DemoAspFormsApplication;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(classes = DemoAspFormsApplication.class)
@ActiveProfiles("test")
class ProductoRepositoryIT {

    @Autowired
    private ProductoRepository repository;

    @BeforeEach
    void setUp() {
        repository.deleteAll();
    }

    @Test
    void findAllPaged() {
        ProductoEntity entity = new ProductoEntity();
        entity.setNombre("Teclado");
        entity.setCantidad(10);
        entity.setPrecio(new BigDecimal("25.50"));
        repository.save(entity);

        var page = repository.findAll(PageRequest.of(0, 10));
        assertThat(page.getContent()).hasSize(1);
        assertThat(page.getContent().get(0).getNombre()).isEqualTo("Teclado");
    }
}
