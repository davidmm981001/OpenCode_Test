CREATE TABLE IF NOT EXISTS inv01_productos (
    prd_id BIGSERIAL PRIMARY KEY,
    prd_nombre VARCHAR(150) NOT NULL,
    prd_cantidad INTEGER NOT NULL,
    prd_precio NUMERIC(12,2) NOT NULL,
    aud_created_at TIMESTAMP NOT NULL DEFAULT now(),
    aud_created_by VARCHAR(100),
    aud_updated_at TIMESTAMP,
    aud_updated_by VARCHAR(100)
);

CREATE INDEX IF NOT EXISTS idx_inv01_productos_nombre ON inv01_productos (prd_nombre);
