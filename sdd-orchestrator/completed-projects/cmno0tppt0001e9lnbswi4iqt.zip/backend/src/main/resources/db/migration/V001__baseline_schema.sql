CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS t95usu03_usuarios (
    usr_id BIGSERIAL PRIMARY KEY,
    usr_username VARCHAR(50) NOT NULL UNIQUE,
    usr_password_hash VARCHAR(255) NOT NULL,
    usr_roles VARCHAR(255) NOT NULL,
    usr_activo BOOLEAN NOT NULL DEFAULT TRUE,
    aud_created_at TIMESTAMP NOT NULL DEFAULT now(),
    aud_created_by VARCHAR(100),
    aud_updated_at TIMESTAMP,
    aud_updated_by VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS t95rft01_refresh_tokens (
    rft_id BIGSERIAL PRIMARY KEY,
    rft_username VARCHAR(50) NOT NULL REFERENCES t95usu03_usuarios (usr_username),
    rft_token VARCHAR(255) NOT NULL UNIQUE,
    rft_expiration_at TIMESTAMP NOT NULL,
    rft_revocado BOOLEAN NOT NULL DEFAULT FALSE
);
