INSERT INTO t95usu03_usuarios (usr_username, usr_password_hash, usr_roles, usr_activo, aud_created_by)
VALUES (
    'admin',
    crypt('admin123', gen_salt('bf')),
    'ROLE_ADMIN,ROLE_OPERADOR',
    TRUE,
    'flyway-seed'
)
ON CONFLICT (usr_username) DO NOTHING;
