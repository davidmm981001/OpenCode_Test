package com.demoaspforms.infraestructura.domain;

public record SystemStatus(String service, String status, String version) {
}
