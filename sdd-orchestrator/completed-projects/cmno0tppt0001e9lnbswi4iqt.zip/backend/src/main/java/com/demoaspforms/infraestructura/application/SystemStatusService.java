package com.demoaspforms.infraestructura.application;

import com.demoaspforms.infraestructura.domain.SystemStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class SystemStatusService {

    private final String version;

    public SystemStatusService(@Value("${app.version:0.0.1-SNAPSHOT}") String version) {
        this.version = version;
    }

    public SystemStatus current() {
        return new SystemStatus("demo-asp-forms-migration", "UP", version);
    }
}
