package com.demoaspforms.infraestructura.api;

import com.demoaspforms.infraestructura.application.SystemStatusService;
import com.demoaspforms.infraestructura.domain.SystemStatus;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class RootController {

    private final SystemStatusService statusService;

    public RootController(SystemStatusService statusService) {
        this.statusService = statusService;
    }

    @Operation(summary = "Estado autenticado del servicio")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Servicio disponible"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @GetMapping({"", "/"})
    public SystemStatus current() {
        return statusService.current();
    }
}
