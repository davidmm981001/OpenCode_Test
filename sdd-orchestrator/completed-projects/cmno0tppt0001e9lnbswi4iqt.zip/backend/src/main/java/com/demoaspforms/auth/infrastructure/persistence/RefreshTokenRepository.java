package com.demoaspforms.auth.infrastructure.persistence;

import java.time.OffsetDateTime;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RefreshTokenRepository extends JpaRepository<RefreshTokenEntity, Long> {
    Optional<RefreshTokenEntity> findByTokenAndRevokedFalseAndExpirationAtAfter(String token, OffsetDateTime now);
    Optional<RefreshTokenEntity> findByToken(String token);
}
