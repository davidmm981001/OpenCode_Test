package com.demoaspforms.productos.domain;

import java.math.BigDecimal;

public record Producto(Long id, String nombre, Integer cantidad, BigDecimal precio) {
}
