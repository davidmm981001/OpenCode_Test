package com.demoaspforms.productos.application;

import com.demoaspforms.productos.domain.Producto;
import com.demoaspforms.productos.infrastructure.persistence.ProductoEntity;

public final class ProductoMapper {

    private ProductoMapper() {
    }

    public static Producto toDomain(ProductoEntity entity) {
        return new Producto(entity.getId(), entity.getNombre(), entity.getCantidad(), entity.getPrecio());
    }
}
