package com.demoaspforms.infraestructura.infrastructure.security;

import java.io.IOException;

import com.demoaspforms.infraestructura.infrastructure.error.ErrorCode;
import com.demoaspforms.infraestructura.infrastructure.error.ErrorResponse;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;

public class RestAuthenticationEntryPoint implements AuthenticationEntryPoint {

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException)
            throws IOException, ServletException {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        ErrorResponse payload = ErrorResponse.of(401, ErrorCode.UNAUTHORIZED, "Autenticación inválida", request.getRequestURI());
        response.getWriter().write(new com.fasterxml.jackson.databind.ObjectMapper().findAndRegisterModules().writeValueAsString(payload));
    }
}
