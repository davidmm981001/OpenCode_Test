package com.demoaspforms.infraestructura.infrastructure.security;

import java.io.IOException;

import com.demoaspforms.infraestructura.infrastructure.error.ErrorCode;
import com.demoaspforms.infraestructura.infrastructure.error.ErrorResponse;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;

public class RestAccessDeniedHandler implements AccessDeniedHandler {

    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException)
            throws IOException, ServletException {
        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        ErrorResponse payload = ErrorResponse.of(403, ErrorCode.ACCESS_DENIED, "Acceso denegado", request.getRequestURI());
        response.getWriter().write(new com.fasterxml.jackson.databind.ObjectMapper().findAndRegisterModules().writeValueAsString(payload));
    }
}
