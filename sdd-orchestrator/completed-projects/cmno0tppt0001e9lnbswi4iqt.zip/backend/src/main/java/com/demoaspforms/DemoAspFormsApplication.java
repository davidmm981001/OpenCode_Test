package com.demoaspforms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoAspFormsApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoAspFormsApplication.class, args);
    }
}
