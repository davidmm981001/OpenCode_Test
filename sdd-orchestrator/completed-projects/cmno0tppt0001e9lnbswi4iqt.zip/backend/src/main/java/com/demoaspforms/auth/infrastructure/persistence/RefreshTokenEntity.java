package com.demoaspforms.auth.infrastructure.persistence;

import java.time.OffsetDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "t95rft01_refresh_tokens")
public class RefreshTokenEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "rft_id")
    private Long id;

    @Column(name = "rft_username", nullable = false, length = 50)
    private String username;

    @Column(name = "rft_token", nullable = false, unique = true, length = 255)
    private String token;

    @Column(name = "rft_expiration_at", nullable = false)
    private OffsetDateTime expirationAt;

    @Column(name = "rft_revocado", nullable = false)
    private boolean revoked = false;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
    public OffsetDateTime getExpirationAt() { return expirationAt; }
    public void setExpirationAt(OffsetDateTime expirationAt) { this.expirationAt = expirationAt; }
    public boolean isRevoked() { return revoked; }
    public void setRevoked(boolean revoked) { this.revoked = revoked; }
}
