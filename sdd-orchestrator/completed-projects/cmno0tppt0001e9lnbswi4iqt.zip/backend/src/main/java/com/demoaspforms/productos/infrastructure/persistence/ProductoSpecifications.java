package com.demoaspforms.productos.infrastructure.persistence;

import org.springframework.data.jpa.domain.Specification;

public final class ProductoSpecifications {

    private ProductoSpecifications() {
    }

    public static Specification<ProductoEntity> bySearch(String q) {
        return (root, query, criteriaBuilder) -> {
            if (q == null || q.isBlank()) {
                return criteriaBuilder.conjunction();
            }
            String like = "%" + q.trim().toLowerCase() + "%";
            return criteriaBuilder.like(criteriaBuilder.lower(root.get("nombre")), like);
        };
    }
}
