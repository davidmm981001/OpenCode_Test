package com.demoaspforms.auth.application;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;

import com.demoaspforms.auth.domain.AuthenticatedSession;
import com.demoaspforms.auth.infrastructure.persistence.RefreshTokenEntity;
import com.demoaspforms.auth.infrastructure.persistence.RefreshTokenRepository;
import com.demoaspforms.auth.infrastructure.persistence.UsuarioEntity;
import com.demoaspforms.auth.infrastructure.persistence.UsuarioRepository;
import com.demoaspforms.infraestructura.infrastructure.error.BusinessRuleViolationException;
import com.demoaspforms.infraestructura.infrastructure.security.JwtService;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {

    private final UsuarioRepository usuarioRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthService(UsuarioRepository usuarioRepository,
                       RefreshTokenRepository refreshTokenRepository,
                       PasswordEncoder passwordEncoder,
                       JwtService jwtService) {
        this.usuarioRepository = usuarioRepository;
        this.refreshTokenRepository = refreshTokenRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public AuthenticatedSession login(String username, String password) {
        UsuarioEntity user = usuarioRepository.findByUsernameAndActivoTrue(username)
                .orElseThrow(() -> new BadCredentialsException("Credenciales inválidas"));
        if (!passwordEncoder.matches(password, user.getPasswordHash())) {
            throw new BadCredentialsException("Credenciales inválidas");
        }
        return issueSession(user);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public AuthenticatedSession refresh(String refreshToken) {
        RefreshTokenEntity token = refreshTokenRepository.findByTokenAndRevokedFalseAndExpirationAtAfter(refreshToken, OffsetDateTime.now())
                .orElseThrow(() -> new BadCredentialsException("Refresh token inválido"));
        UsuarioEntity user = usuarioRepository.findByUsernameAndActivoTrue(token.getUsername())
                .orElseThrow(() -> new BadCredentialsException("Usuario inválido"));
        token.setRevoked(true);
        refreshTokenRepository.save(token);
        return issueSession(user);
    }

    private AuthenticatedSession issueSession(UsuarioEntity user) {
        List<String> roles = List.of(user.getRoles().split(",")).stream()
                .map(String::trim)
                .filter(role -> !role.isBlank())
                .toList();
        String accessToken = jwtService.generateAccessToken(user.getUsername(), roles);
        String refreshToken = UUID.randomUUID().toString();
        RefreshTokenEntity refreshTokenEntity = new RefreshTokenEntity();
        refreshTokenEntity.setUsername(user.getUsername());
        refreshTokenEntity.setToken(refreshToken);
        refreshTokenEntity.setExpirationAt(OffsetDateTime.now(ZoneOffset.UTC).plusDays(7));
        refreshTokenRepository.save(refreshTokenEntity);
        return new AuthenticatedSession(accessToken, refreshToken, "Bearer", 3600L, roles);
    }
}
