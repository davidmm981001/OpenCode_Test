package com.demoaspforms.infraestructura.infrastructure.error;

public enum ErrorCode {
    VALIDATION_ERROR,
    BUSINESS_RULE_VIOLATION,
    NOT_FOUND,
    DATA_INTEGRITY,
    ACCESS_DENIED,
    UNAUTHORIZED,
    INTERNAL_ERROR
}
