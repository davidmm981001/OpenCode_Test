package com.demoaspforms.auth.domain;

import java.util.List;

public record AuthenticatedSession(String token, String refreshToken, String tokenType, long expiresIn, List<String> roles) {
}
