package com.demoaspforms.productos.application;

import java.util.List;

import com.demoaspforms.productos.domain.Producto;
import com.demoaspforms.productos.infrastructure.persistence.ProductoRepository;
import com.demoaspforms.productos.infrastructure.persistence.ProductoSpecifications;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProductoQueryService {

    private final ProductoRepository repository;

    public ProductoQueryService(ProductoRepository repository) {
        this.repository = repository;
    }

    @Transactional(readOnly = true)
    public Page<Producto> listar(int page, int size, String sort, String q) {
        int safeSize = Math.min(Math.max(size, 1), 100);
        Pageable pageable = PageRequest.of(Math.max(page, 0), safeSize, parseSort(sort));
        Page<Producto> productos = repository.findAll(ProductoSpecifications.bySearch(q), pageable)
                .map(ProductoMapper::toDomain);
        return productos;
    }

    private Sort parseSort(String sort) {
        if (sort == null || sort.isBlank()) {
            return Sort.by(Sort.Direction.ASC, "id");
        }
        String[] parts = sort.split(",");
        String property = switch (parts[0]) {
            case "nombre" -> "nombre";
            case "cantidad" -> "cantidad";
            case "precio" -> "precio";
            default -> "id";
        };
        Sort.Direction direction = parts.length > 1 && "desc".equalsIgnoreCase(parts[1])
                ? Sort.Direction.DESC
                : Sort.Direction.ASC;
        return Sort.by(direction, property);
    }
}
