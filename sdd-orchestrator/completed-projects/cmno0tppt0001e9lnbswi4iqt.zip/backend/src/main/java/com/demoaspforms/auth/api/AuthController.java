package com.demoaspforms.auth.api;

import java.util.List;

import com.demoaspforms.auth.application.AuthService;
import com.demoaspforms.auth.domain.AuthenticatedSession;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @Operation(summary = "Autenticar usuario")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Autenticación exitosa"),
            @ApiResponse(responseCode = "401", description = "Credenciales inválidas", content = @Content)
    })
    @PostMapping("/login")
    public AuthResponse login(@Valid @RequestBody LoginRequest request) {
        return AuthResponse.from(authService.login(request.username(), request.password()));
    }

    @Operation(summary = "Renovar sesión")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Sesión renovada"),
            @ApiResponse(responseCode = "401", description = "Refresh token inválido", content = @Content)
    })
    @PostMapping("/refresh")
    public AuthResponse refresh(@Valid @RequestBody RefreshRequest request) {
        return AuthResponse.from(authService.refresh(request.refreshToken()));
    }

    public record LoginRequest(@NotBlank(message = "Usuario requerido") String username,
                               @NotBlank(message = "Contraseña requerida") String password) {
    }

    public record RefreshRequest(@NotBlank(message = "Refresh token requerido") String refreshToken) {
    }

    public record AuthResponse(String token, String refreshToken, String tokenType, long expiresIn, List<String> roles) {
        static AuthResponse from(AuthenticatedSession session) {
            return new AuthResponse(session.token(), session.refreshToken(), session.tokenType(), session.expiresIn(), session.roles());
        }
    }
}
