package com.demoaspforms.infraestructura.infrastructure.error;

import java.time.OffsetDateTime;
import java.util.Map;

public record ErrorResponse(OffsetDateTime timestamp,
                            int status,
                            String code,
                            String message,
                            Object details,
                            String path) {

    public static ErrorResponse of(int status, ErrorCode code, String message, Object details, String path) {
        return new ErrorResponse(OffsetDateTime.now(), status, code.name(), message, details, path);
    }

    public static ErrorResponse of(int status, ErrorCode code, String message, String path) {
        return of(status, code, message, null, path);
    }

    public ErrorResponse withDetails(Map<String, Object> newDetails) {
        return new ErrorResponse(timestamp, status, code, message, newDetails, path);
    }
}
