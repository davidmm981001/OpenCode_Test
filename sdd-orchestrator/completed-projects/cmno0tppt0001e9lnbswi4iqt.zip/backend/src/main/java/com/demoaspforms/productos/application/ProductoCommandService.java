package com.demoaspforms.productos.application;

import java.util.Optional;

import com.demoaspforms.infraestructura.infrastructure.error.BusinessRuleViolationException;
import com.demoaspforms.productos.domain.Producto;
import com.demoaspforms.productos.infrastructure.persistence.ProductoEntity;
import com.demoaspforms.productos.infrastructure.persistence.ProductoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProductoCommandService {

    private final ProductoRepository repository;

    public ProductoCommandService(ProductoRepository repository) {
        this.repository = repository;
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public Producto crearProducto(Producto producto) {
        String nombre = Optional.ofNullable(producto.nombre()).map(String::trim).orElse("");
        if (nombre.isBlank()) {
            throw new BusinessRuleViolationException("Nombre requerido");
        }
        ProductoEntity entity = new ProductoEntity();
        entity.setNombre(nombre);
        entity.setCantidad(producto.cantidad());
        entity.setPrecio(producto.precio());
        ProductoEntity saved = repository.save(entity);
        return ProductoMapper.toDomain(saved);
    }

    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void eliminarProducto(Long id) {
        repository.findById(id).ifPresent(repository::delete);
    }
}
