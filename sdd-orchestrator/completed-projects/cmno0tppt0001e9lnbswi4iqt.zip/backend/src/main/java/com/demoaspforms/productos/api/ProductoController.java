package com.demoaspforms.productos.api;

import java.math.BigDecimal;
import java.util.List;

import com.demoaspforms.productos.application.ProductoCommandService;
import com.demoaspforms.productos.application.ProductoQueryService;
import com.demoaspforms.productos.domain.Producto;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/productos")
public class ProductoController {

    private final ProductoQueryService queryService;
    private final ProductoCommandService commandService;

    public ProductoController(ProductoQueryService queryService, ProductoCommandService commandService) {
        this.queryService = queryService;
        this.commandService = commandService;
    }

    @Operation(summary = "Listar productos paginados")
    @ApiResponses(@ApiResponse(responseCode = "200", description = "Lista paginada de productos"))
    @GetMapping
    public ProductoPageResponse list(@RequestParam(defaultValue = "0") int page,
                                     @RequestParam(defaultValue = "14") @Min(1) @Max(100) int size,
                                     @RequestParam(required = false) String sort,
                                     @RequestParam(required = false, name = "q") String q) {
        Page<Producto> productos = queryService.listar(page, size, sort, q);
        return ProductoPageResponse.from(productos);
    }

    @Operation(summary = "Crear producto")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Producto creado"),
            @ApiResponse(responseCode = "400", description = "Validación inválida", content = @Content)
    })
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ProductoResponse create(@Valid @RequestBody CreateProductoRequest request) {
        Producto created = commandService.crearProducto(new Producto(null, request.nombre(), request.cantidad(), request.precio()));
        return ProductoResponse.from(created);
    }

    @Operation(summary = "Eliminar producto")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Eliminado o no existente"),
            @ApiResponse(responseCode = "400", description = "Id inválido", content = @Content)
    })
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        commandService.eliminarProducto(id);
    }

    public record CreateProductoRequest(@NotBlank(message = "Nombre requerido") String nombre,
                                        @NotNull(message = "Cantidad requerida") Integer cantidad,
                                        @NotNull(message = "Precio requerido") BigDecimal precio) {
    }

    public record ProductoResponse(Long id, String nombre, Integer cantidad, BigDecimal precio) {
        static ProductoResponse from(Producto producto) {
            return new ProductoResponse(producto.id(), producto.nombre(), producto.cantidad(), producto.precio());
        }
    }

    public record ProductoPageResponse(List<ProductoResponse> content, long totalElements, int totalPages, int size,
                                       int number, boolean first, boolean last) {
        static ProductoPageResponse from(Page<Producto> page) {
            List<ProductoResponse> items = page.getContent().stream().map(ProductoResponse::from).toList();
            return new ProductoPageResponse(items, page.getTotalElements(), page.getTotalPages(), page.getSize(), page.getNumber(), page.isFirst(), page.isLast());
        }
    }
}
