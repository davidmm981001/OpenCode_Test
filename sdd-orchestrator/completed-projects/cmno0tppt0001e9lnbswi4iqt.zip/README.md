# DEMO Asp Forms Migration

## Requisitos
- Java 17+
- Node 18+
- npm
- psql
- Maven

## Arranque
```bash
./run.sh
```

## Parada
```bash
./stop.sh
```

## Smoke test
```bash
./smoke-test.sh
```

## Troubleshooting
- **Puerto ocupado**: el script busca DB desde 5433, backend desde 8081 y frontend desde 3001, con 20 intentos.
- **PostgreSQL no conecta**: revise que `psql` apunte al servidor local y que el usuario superusuario tenga permisos.
- **Login falla**: use `admin / admin123`.
- **Frontend no carga**: verifique `VITE_API_BASE_URL` y que el backend esté en `UP`.

## Variables de entorno
- `DB_HOST`
- `DB_PORT`
- `DB_NAME`
- `DB_USERNAME`
- `DB_PASSWORD`
- `SERVER_PORT`
- `CORS_ALLOWED_ORIGINS`
- `JWT_SECRET`

## Accesos
- Frontend: `http://localhost:<FRONTEND_PORT>/`
- Backend: `http://localhost:<BACKEND_PORT>/swagger-ui/`
