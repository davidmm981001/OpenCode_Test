#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$ROOT_DIR/scripts/common.sh"

ensure_command java
ensure_command node
ensure_command npm
ensure_command psql
ensure_command mvn
ensure_command curl
ensure_command python3

DB_PORT="${DB_PORT:-$(find_free_port 5433)}"
BACKEND_PORT="${BACKEND_PORT:-$(find_free_port 8081 "$DB_PORT") }"
BACKEND_PORT="${BACKEND_PORT// /}"
FRONTEND_PORT="${FRONTEND_PORT:-$(find_free_port 3001 "$DB_PORT" "$BACKEND_PORT") }"
FRONTEND_PORT="${FRONTEND_PORT// /}"

if [[ "$DB_PORT" == "$BACKEND_PORT" || "$DB_PORT" == "$FRONTEND_PORT" || "$BACKEND_PORT" == "$FRONTEND_PORT" ]]; then
  printf 'Los puertos seleccionados deben ser distintos.\n' >&2
  exit 1
fi

export DB_HOST="${DB_HOST:-localhost}"
export DB_NAME="${DB_NAME:-demo_asp_forms}"
export DB_USERNAME="${DB_USERNAME:-demo_asp_forms}"
export DB_PASSWORD="${DB_PASSWORD:-demo_asp_forms}"
export DB_PORT
export BACKEND_PORT
export FRONTEND_PORT

write_ports_env "$DB_PORT" "$BACKEND_PORT" "$FRONTEND_PORT"
log "Puertos asignados: DB=$DB_PORT BACKEND=$BACKEND_PORT FRONTEND=$FRONTEND_PORT"

if ! start_local_postgres "$DB_PORT"; then
  exit 1
fi

export PGHOST=127.0.0.1
export PGPASSWORD="${PGSUPERPASSWORD:-${PGPASSWORD:-}}"
if ! psql -h "$PGHOST" -p "$DB_PORT" -U "${PGSUPERUSER:-postgres}" -d postgres -tAc "SELECT 1 FROM pg_roles WHERE rolname='${DB_USERNAME}'" | grep -q 1; then
  log "Creando rol ${DB_USERNAME}"
  psql -h "$PGHOST" -p "$DB_PORT" -U "${PGSUPERUSER:-postgres}" -d postgres -v ON_ERROR_STOP=1 -c "CREATE ROLE \"${DB_USERNAME}\" LOGIN PASSWORD '${DB_PASSWORD}'"
fi
if ! psql -h "$PGHOST" -p "$DB_PORT" -U "${PGSUPERUSER:-postgres}" -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'" | grep -q 1; then
  log "Creando base ${DB_NAME}"
  psql -h "$PGHOST" -p "$DB_PORT" -U "${PGSUPERUSER:-postgres}" -d postgres -v ON_ERROR_STOP=1 -c "CREATE DATABASE \"${DB_NAME}\" OWNER \"${DB_USERNAME}\""
fi

log "Compilando backend"
mvn -q -f "$BACKEND_DIR/pom.xml" -DskipTests package

if [[ ! -d "$FRONTEND_DIR/node_modules" ]]; then
  log "Instalando dependencias frontend"
  npm install --prefix "$FRONTEND_DIR" --no-fund --no-audit
fi

cat >"$FRONTEND_DIR/.env.local" <<EOF
VITE_API_BASE_URL=http://localhost:$BACKEND_PORT
EOF

BACKEND_JAR="$(ls "$BACKEND_DIR"/target/*.jar | grep -v 'original' | head -n 1)"
BACKEND_LOG="$LOG_DIR/backend.log"
FRONTEND_LOG="$LOG_DIR/frontend.log"

log "Iniciando backend"
nohup env \
  SPRING_PROFILES_ACTIVE=dev \
  SERVER_PORT="$BACKEND_PORT" \
  DB_HOST="${DB_HOST}" \
  DB_PORT="${DB_PORT}" \
  DB_NAME="${DB_NAME}" \
  DB_USERNAME="${DB_USERNAME}" \
  DB_PASSWORD="${DB_PASSWORD}" \
  CORS_ALLOWED_ORIGINS="http://localhost:$FRONTEND_PORT" \
  LOG_DIR="$LOG_DIR" \
  java -jar "$BACKEND_JAR" >"$BACKEND_LOG" 2>&1 &
echo $! > "$PID_DIR/backend.pid"

log "Iniciando frontend"
nohup env VITE_API_BASE_URL="http://localhost:$BACKEND_PORT" npm run dev --prefix "$FRONTEND_DIR" -- --host 0.0.0.0 --port "$FRONTEND_PORT" >"$FRONTEND_LOG" 2>&1 &
echo $! > "$PID_DIR/frontend.pid"

wait_for_backend() {
  for _ in $(seq 1 120); do
    if curl -fsS "http://localhost:$BACKEND_PORT/actuator/health" | grep -q '"status":"UP"'; then
      return 0
    fi
    sleep 1
  done
  return 1
}

wait_for_frontend() {
  for _ in $(seq 1 120); do
    if curl -fsS "http://localhost:$FRONTEND_PORT/" | grep -q 'id="root"'; then
      return 0
    fi
    sleep 1
  done
  return 1
}

if ! wait_for_backend; then
  log "Backend no alcanzó estado UP"
  tail -n 40 "$BACKEND_LOG" || true
  exit 1
fi

if ! wait_for_frontend; then
  log "Frontend no respondió con root"
  tail -n 40 "$FRONTEND_LOG" || true
  exit 1
fi

log "Backend y frontend listos"

("$ROOT_DIR/smoke-test.sh" >"$LOG_DIR/smoke-test.log" 2>&1; log "Smoke test finalizado") &
(mvn -q -f "$BACKEND_DIR/pom.xml" test >"$LOG_DIR/backend-tests.log" 2>&1; log "Tests backend finalizados") &
(npm test --prefix "$FRONTEND_DIR" >"$LOG_DIR/frontend-tests.log" 2>&1; log "Tests frontend finalizados") &

trap 'log "Ctrl+C recibido: los procesos continúan en segundo plano."' INT TERM
log "Aplicación en ejecución. Backend: http://localhost:$BACKEND_PORT | Frontend: http://localhost:$FRONTEND_PORT"
tail -n 20 -F "$BACKEND_LOG" "$FRONTEND_LOG"
