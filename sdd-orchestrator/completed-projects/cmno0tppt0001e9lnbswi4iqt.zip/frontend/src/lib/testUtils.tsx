import { ReactNode } from 'react';
import { QueryClientProvider } from '@tanstack/react-query';
import { MemoryRouter } from 'react-router-dom';
import { render } from '@testing-library/react';
import { AuthProvider } from '../auth/AuthContext';
import { queryClient } from './queryClient';

type RenderOptions = {
  initialEntries?: string[];
};

export function renderWithProviders(ui: ReactNode, options: RenderOptions = {}) {
  return render(
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <MemoryRouter initialEntries={options.initialEntries ?? ['/']}>{ui}</MemoryRouter>
      </AuthProvider>
    </QueryClientProvider>,
  );
}
