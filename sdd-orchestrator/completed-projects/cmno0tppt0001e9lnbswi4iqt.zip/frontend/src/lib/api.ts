import axios from 'axios';
import type { InternalAxiosRequestConfig } from 'axios';
import { tokenStore } from './tokenStore';

const baseURL = import.meta.env.VITE_API_BASE_URL || '/';

export const api = axios.create({
  baseURL,
  timeout: 15000,
});

api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = tokenStore.getAccessToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});
