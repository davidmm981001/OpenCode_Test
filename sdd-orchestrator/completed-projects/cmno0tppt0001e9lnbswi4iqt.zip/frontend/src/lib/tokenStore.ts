let accessToken: string | null = null;
let refreshToken: string | null = null;
let roles: string[] = [];

export const tokenStore = {
  getAccessToken: () => accessToken,
  getRefreshToken: () => refreshToken,
  getRoles: () => roles,
  setSession: (nextAccessToken: string, nextRefreshToken: string, nextRoles: string[]) => {
    accessToken = nextAccessToken;
    refreshToken = nextRefreshToken;
    roles = nextRoles;
  },
  clear: () => {
    accessToken = null;
    refreshToken = null;
    roles = [];
  },
};
