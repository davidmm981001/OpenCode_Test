import { api } from './lib/api';

describe('axiosInstanceTest', () => {
  it('readsEnvBaseUrl', () => {
    expect(api.defaults.baseURL).toBe(import.meta.env.VITE_API_BASE_URL || '/');
  });
});
