import { Layout } from './components/Layout';
import { renderWithProviders } from './lib/testUtils';
import { tokenStore } from './lib/tokenStore';
import { fireEvent, screen } from '@testing-library/react';
import { Routes, Route } from 'react-router-dom';

describe('LayoutTest', () => {
  it('sidebarToggleWorks', async () => {
    tokenStore.setSession('token', 'refresh', ['ROLE_ADMIN']);
    renderWithProviders(
      <Routes>
        <Route element={<Layout />}>
          <Route index element={<div>Home</div>} />
        </Route>
      </Routes>,
    );

    expect(await screen.findByText('Productos')).toBeInTheDocument();
    fireEvent.click(screen.getByLabelText('Colapsar menú'));
    expect(screen.queryByText('Productos')).not.toBeInTheDocument();
    tokenStore.clear();
  });
});
