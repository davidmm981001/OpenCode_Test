import { FuncionalidadPendiente } from './FuncionalidadPendiente';
import { renderWithProviders } from '../lib/testUtils';
import { screen } from '@testing-library/react';

describe('FuncionalidadPendiente', () => {
  it('rendersPropsAndBackButton', () => {
    renderWithProviders(
      <FuncionalidadPendiente title="Pendiente" description="Descripción" backTo="/" backLabel="Volver a Inicio" />,
    );

    expect(screen.getByText('Pendiente')).toBeInTheDocument();
    expect(screen.getByText('Descripción')).toBeInTheDocument();
    expect(screen.getByText('Volver a Inicio')).toBeInTheDocument();
  });
});
