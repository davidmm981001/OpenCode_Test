import { Monitor, Smartphone } from 'lucide-react';
import { useMediaQuery } from '../hooks/useMediaQuery';

export function ResponsiveViewBadge() {
  const mobile = useMediaQuery('(max-width: 767px)');
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-medium text-slate-200">
      {mobile ? <Smartphone className="h-3.5 w-3.5" /> : <Monitor className="h-3.5 w-3.5" />}
      {mobile ? 'Vista móvil' : 'Vista escritorio'}
    </span>
  );
}
