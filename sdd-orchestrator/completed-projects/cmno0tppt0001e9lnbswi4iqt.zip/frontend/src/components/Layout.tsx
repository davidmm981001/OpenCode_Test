import { useEffect, useMemo, useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Menu, LayoutDashboard, Package, Info, Mail, ArrowLeft, LogOut, PanelLeftClose, PanelLeftOpen } from 'lucide-react';
import { ResponsiveViewBadge } from './ResponsiveViewBadge';
import { useMediaQuery } from '../hooks/useMediaQuery';
import { useAuth } from '../auth/AuthContext';
import { cn } from '../utils/cn';

const sidebarLinks = [
  { to: '/', label: 'Inicio', icon: LayoutDashboard },
  { to: '/productos', label: 'Productos', icon: Package },
  { to: '/about', label: 'About', icon: Info },
  { to: '/contact', label: 'Contact', icon: Mail },
  { to: '/pendiente/interfaces-legacy', label: 'Pendientes', icon: ArrowLeft },
];

function readSidebarPreference() {
  try {
    const value = window.sessionStorage.getItem('layout.sidebar.collapsed');
    return value === 'true';
  } catch {
    return false;
  }
}

function saveSidebarPreference(value: boolean) {
  try {
    window.sessionStorage.setItem('layout.sidebar.collapsed', String(value));
  } catch {
    // no-op
  }
}

export function Layout() {
  const { logout, isAuthenticated } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const mobile = useMediaQuery('(max-width: 767px)');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => readSidebarPreference());
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => {
    saveSidebarPreference(sidebarCollapsed);
  }, [sidebarCollapsed]);

  useEffect(() => {
    setDrawerOpen(false);
  }, [location.pathname]);

  const breadcrumbs = useMemo(() => {
    const segments = location.pathname.split('/').filter(Boolean);
    const items = [{ label: 'Inicio', href: '/' }];
    if (segments.length === 0) {
      return items;
    }
    if (segments[0] === 'productos') {
      items.push({ label: 'Productos', href: '/productos' });
    } else if (segments[0] === 'about') {
      items.push({ label: 'About', href: '/about' });
    } else if (segments[0] === 'contact') {
      items.push({ label: 'Contact', href: '/contact' });
    } else if (segments[0] === 'pendiente') {
      items.push({ label: 'Pendientes', href: '/pendiente/interfaces-legacy' });
    } else if (segments[0] === 'login') {
      items.push({ label: 'Login', href: '/login' });
    }
    return items;
  }, [location.pathname]);

  const sidebarWidth = mobile ? 'w-72' : sidebarCollapsed ? 'w-20' : 'w-72';

  return (
    <div className="min-h-screen text-slate-100">
      <a href="#main-content" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-xl focus:bg-brand-500 focus:px-4 focus:py-2 focus:text-white">
        Saltar al contenido
      </a>

      <div className="flex min-h-screen">
        <aside
          className={cn(
            'fixed inset-y-0 left-0 z-40 flex flex-col border-r border-white/10 bg-slate-950/95 backdrop-blur transition-transform duration-200',
            sidebarWidth,
            mobile ? (drawerOpen ? 'translate-x-0' : '-translate-x-full') : 'translate-x-0',
          )}
        >
          <div className="flex items-center justify-between gap-3 border-b border-white/10 px-4 py-4">
            <div className={cn('flex items-center gap-3', !sidebarCollapsed || mobile ? 'opacity-100' : 'opacity-0')}>
              <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-brand-500/20 text-brand-300">A</div>
              {(mobile || !sidebarCollapsed) && (
                <div>
                  <p className="text-sm font-semibold">DEMO Asp Forms</p>
                  <p className="text-xs text-slate-400">Migración inventario</p>
                </div>
              )}
            </div>
            {!mobile && (
              <button className="app-button-secondary h-10 w-10 p-0" onClick={() => setSidebarCollapsed((value) => !value)} aria-label="Colapsar menú">
                {sidebarCollapsed ? <PanelLeftOpen className="h-4 w-4" /> : <PanelLeftClose className="h-4 w-4" />}
              </button>
            )}
            {mobile && (
              <button className="app-button-secondary h-10 w-10 p-0" onClick={() => setDrawerOpen(false)} aria-label="Cerrar menú">
                <ArrowLeft className="h-4 w-4" />
              </button>
            )}
          </div>

          <nav className="flex-1 space-y-1 p-3">
            {sidebarLinks.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                className={({ isActive }) =>
                  cn(
                    'flex items-center gap-3 rounded-xl px-4 py-3 text-sm transition hover:bg-white/5 focus:outline-none focus:ring-2 focus:ring-brand-400/30',
                    isActive ? 'bg-brand-500/15 text-brand-200' : 'text-slate-300',
                    !mobile && sidebarCollapsed && 'justify-center px-0',
                  )
                }
              >
                <Icon className="h-4 w-4" />
                {(mobile || !sidebarCollapsed) && <span>{label}</span>}
              </NavLink>
            ))}
          </nav>

          <div className="border-t border-white/10 p-3">
            {isAuthenticated ? (
              <button className={cn('app-button-secondary w-full justify-start', !mobile && sidebarCollapsed && 'justify-center px-0')} onClick={() => { logout(); navigate('/login'); }}>
                <LogOut className="h-4 w-4" />
                {(mobile || !sidebarCollapsed) && <span>Cerrar sesión</span>}
              </button>
            ) : null}
          </div>
        </aside>

        {mobile && drawerOpen && <div className="fixed inset-0 z-30 bg-slate-950/70" onClick={() => setDrawerOpen(false)} aria-hidden="true" />}

        <div className={cn('flex min-h-screen flex-1 flex-col', mobile ? 'ml-0' : sidebarCollapsed ? 'ml-20' : 'ml-72')}>
          <header className="sticky top-0 z-20 border-b border-white/10 bg-slate-950/80 px-4 py-4 backdrop-blur">
            <div className="flex items-center gap-3">
              {mobile && (
                <button className="app-button-secondary h-10 w-10 p-0" onClick={() => setDrawerOpen(true)} aria-label="Abrir menú">
                  <Menu className="h-4 w-4" />
                </button>
              )}
              <div className="min-w-0 flex-1">
                <nav className="flex items-center gap-2 text-xs text-slate-400" aria-label="breadcrumbs">
                  {breadcrumbs.map((item, index) => (
                    <span key={item.href} className="flex items-center gap-2">
                      {index > 0 && <span aria-hidden="true">/</span>}
                      <button
                        className={cn('rounded focus:outline-none focus:ring-2 focus:ring-brand-400/40', index === breadcrumbs.length - 1 ? 'text-slate-100' : 'hover:text-slate-200')}
                        onClick={() => navigate(item.href)}
                        type="button"
                      >
                        {item.label}
                      </button>
                    </span>
                  ))}
                </nav>
                <h1 className="truncate text-xl font-semibold tracking-tight">{breadcrumbs.at(-1)?.label ?? 'Inicio'}</h1>
              </div>
              <ResponsiveViewBadge />
            </div>
          </header>

          <main id="main-content" className="flex-1 px-4 py-6 md:px-6">
            <div className="mx-auto w-full max-w-7xl">
              <Outlet />
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}
