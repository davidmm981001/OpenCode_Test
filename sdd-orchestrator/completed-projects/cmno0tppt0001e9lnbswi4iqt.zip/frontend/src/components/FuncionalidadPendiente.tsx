import { ArrowLeft, Clock3, Construction } from 'lucide-react';
import { Link } from 'react-router-dom';

type Props = {
  title: string;
  description: string;
  backTo?: string;
  backLabel?: string;
};

export function FuncionalidadPendiente({ title, description, backTo = '/', backLabel = 'Volver a Inicio' }: Props) {
  return (
    <section className="app-card space-y-5 p-6 md:p-8">
      <div className="flex items-center gap-3 text-brand-200">
        <Clock3 className="h-6 w-6" />
        <span className="rounded-full bg-brand-500/15 px-3 py-1 text-xs font-medium">Próximamente</span>
      </div>
      <div className="flex items-start gap-4">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/5 text-slate-100">
          <Construction className="h-6 w-6" />
        </div>
        <div className="space-y-2">
          <h2 className="text-3xl font-semibold text-white">{title}</h2>
          <p className="max-w-3xl text-sm leading-7 text-slate-300 md:text-base">{description}</p>
        </div>
      </div>
      <Link to={backTo} className="app-button-secondary inline-flex">
        <ArrowLeft className="h-4 w-4" /> {backLabel}
      </Link>
    </section>
  );
}
