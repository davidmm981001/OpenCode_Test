import { App } from './App';
import { renderWithProviders } from './lib/testUtils';
import { tokenStore } from './lib/tokenStore';
import { screen } from '@testing-library/react';

describe('AppRenderTest', () => {
  it('showsRootLayout', async () => {
    tokenStore.setSession('token', 'refresh', ['ROLE_ADMIN']);
    renderWithProviders(<App />);

    expect(await screen.findByText('Bienvenido a la base migrada del inventario.')).toBeInTheDocument();
    tokenStore.clear();
  });
});
