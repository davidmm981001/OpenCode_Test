import { createContext, useContext, useMemo, useState, type ReactNode } from 'react';
import { api } from '../lib/api';
import { tokenStore } from '../lib/tokenStore';

type LoginPayload = {
  username: string;
  password: string;
};

type AuthSession = {
  token: string | null;
  refreshToken: string | null;
  roles: string[];
};

type AuthContextValue = AuthSession & {
  isAuthenticated: boolean;
  hasRole: (role: string) => boolean;
  login: (payload: LoginPayload) => Promise<void>;
  logout: () => void;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<AuthSession>({
    token: tokenStore.getAccessToken(),
    refreshToken: tokenStore.getRefreshToken(),
    roles: tokenStore.getRoles(),
  });

  const value = useMemo<AuthContextValue>(() => {
    return {
      ...session,
      isAuthenticated: Boolean(session.token),
      hasRole: (role: string) => session.roles.includes(role),
      login: async (payload: LoginPayload) => {
        const { data } = await api.post('/auth/login', payload);
        const roles = Array.isArray(data.roles) ? data.roles : [];
        tokenStore.setSession(data.token, data.refreshToken, roles);
        setSession({ token: data.token, refreshToken: data.refreshToken, roles });
      },
      logout: () => {
        tokenStore.clear();
        setSession({ token: null, refreshToken: null, roles: [] });
      },
    };
  }, [session]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth debe usarse dentro de AuthProvider');
  }
  return context;
}
