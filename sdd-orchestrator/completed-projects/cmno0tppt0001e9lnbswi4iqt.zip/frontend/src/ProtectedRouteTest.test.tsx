import { Routes, Route } from 'react-router-dom';
import { ProtectedRoute } from './components/ProtectedRoute';
import { LoginPage } from './pages/LoginPage';
import { renderWithProviders } from './lib/testUtils';
import { screen } from '@testing-library/react';
import { tokenStore } from './lib/tokenStore';

describe('ProtectedRouteTest', () => {
  it('redirectsUnauthenticated', async () => {
    tokenStore.clear();
    renderWithProviders(
      <Routes>
        <Route element={<ProtectedRoute />}>
          <Route path="/private" element={<div>Private</div>} />
        </Route>
        <Route path="/login" element={<LoginPage />} />
      </Routes>,
      { initialEntries: ['/private'] },
    );

    expect(await screen.findByText('Acceso')).toBeInTheDocument();
  });
});
