export type Producto = {
  id: number;
  nombre: string;
  cantidad: number;
  precio: number;
};

export type ProductoPageResponse = {
  content: Producto[];
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
  first: boolean;
  last: boolean;
};
