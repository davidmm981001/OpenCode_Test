import { ArrowDownAZ, ArrowUpZA, PencilLine, Trash2 } from 'lucide-react';
import { Producto } from './types';
import { cn } from '../../utils/cn';

type Props = {
  productos: Producto[];
  sort: string;
  onSortChange: (value: string) => void;
  onDelete: (producto: Producto) => void;
  loading?: boolean;
};

const columns = [
  { key: 'id', label: 'Id' },
  { key: 'nombre', label: 'Nombre' },
  { key: 'cantidad', label: 'Cantidad' },
  { key: 'precio', label: 'Precio' },
];

export function ProductoTable({ productos, sort, onSortChange, onDelete, loading = false }: Props) {
  const sortKey = sort.split(',')[0] ?? 'id';
  const sortDirection = sort.split(',')[1] ?? 'asc';

  return (
    <div className="overflow-hidden rounded-2xl border border-white/10">
      <table className="min-w-full divide-y divide-white/10">
        <thead className="bg-white/5">
          <tr>
            {columns.map((column) => (
              <th key={column.key} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-300">
                <button
                  className="inline-flex items-center gap-2 focus:outline-none focus:ring-2 focus:ring-brand-400/30"
                  type="button"
                  onClick={() => onSortChange(`${column.key},${sortKey === column.key && sortDirection === 'asc' ? 'desc' : 'asc'}`)}
                >
                  {column.label}
                  {sortKey === column.key ? (
                    sortDirection === 'asc' ? <ArrowDownAZ className="h-3.5 w-3.5" /> : <ArrowUpZA className="h-3.5 w-3.5" />
                  ) : null}
                </button>
              </th>
            ))}
            <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-slate-300">Acciones</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-white/10 bg-slate-950/40">
          {loading
            ? Array.from({ length: 5 }).map((_, index) => (
                <tr key={index}>
                  <td className="px-4 py-4" colSpan={5}>
                    <div className="h-4 w-full animate-pulse rounded bg-white/10" />
                  </td>
                </tr>
              ))
            : productos.map((producto) => (
                <tr key={producto.id} className="transition hover:bg-white/5">
                  <td className="px-4 py-4 text-sm text-slate-200">{producto.id}</td>
                  <td className="px-4 py-4 text-sm text-slate-100">{producto.nombre}</td>
                  <td className="px-4 py-4 text-sm text-slate-200">{producto.cantidad}</td>
                  <td className="px-4 py-4 text-sm text-slate-200">{producto.precio.toFixed(2)}</td>
                  <td className="px-4 py-4">
                    <div className="flex items-center justify-end gap-2">
                      <button className="app-button-secondary h-10 px-3" type="button" onClick={() => onDelete(producto)}>
                        <Trash2 className="h-4 w-4" /> Eliminar
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
        </tbody>
      </table>
    </div>
  );
}
