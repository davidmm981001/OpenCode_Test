import * as Dialog from '@radix-ui/react-dialog';
import { X } from 'lucide-react';
import { toast } from 'sonner';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../../lib/api';
import { ProductoForm, ProductoFormValues } from './ProductoForm';
import { ProductoPageResponse } from './types';

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

export function ProductoCreateModal({ open, onOpenChange }: Props) {
  const queryClient = useQueryClient();
  const mutation = useMutation({
    mutationFn: async (values: ProductoFormValues) => {
      const { data } = await api.post('/api/v1/productos', values);
      return data;
    },
    onSuccess: async () => {
      toast.success('Producto creado');
      await queryClient.invalidateQueries({ queryKey: ['productos'] });
      onOpenChange(false);
    },
    onError: (error: unknown) => {
      const message = error instanceof Error ? error.message : 'No se pudo guardar';
      toast.error(message);
    },
  });

  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm" />
        <Dialog.Content className="fixed left-1/2 top-1/2 z-50 w-[min(92vw,48rem)] -translate-x-1/2 -translate-y-1/2 rounded-3xl border border-white/10 bg-slate-950 p-6 shadow-soft outline-none md:p-8">
          <div className="mb-6 flex items-start justify-between gap-4">
            <div>
              <Dialog.Title className="text-2xl font-semibold text-white">Nuevo producto</Dialog.Title>
              <Dialog.Description className="mt-2 text-sm text-slate-400">
                Ingresa nombre, cantidad y precio para guardar el registro.
              </Dialog.Description>
            </div>
            <Dialog.Close className="app-button-secondary h-10 w-10 p-0" aria-label="Cerrar">
              <X className="h-4 w-4" />
            </Dialog.Close>
          </div>

          <ProductoForm
            onSubmit={async (values) => {
              await mutation.mutateAsync(values);
            }}
            submitLabel="Guardar producto"
            isSubmitting={mutation.isPending}
            onCancel={() => onOpenChange(false)}
          />
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
