import * as Dialog from '@radix-ui/react-dialog';
import { AlertTriangle, X } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../../lib/api';
import { toast } from 'sonner';
import { Producto } from './types';

type Props = {
  producto: Producto | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

export function ConfirmDeleteModal({ producto, open, onOpenChange }: Props) {
  const queryClient = useQueryClient();
  const mutation = useMutation({
    mutationFn: async (id: number) => {
      await api.delete(`/api/v1/productos/${id}`);
    },
    onSuccess: async () => {
      toast.success('Producto eliminado');
      await queryClient.invalidateQueries({ queryKey: ['productos'] });
      onOpenChange(false);
    },
    onError: () => {
      toast.error('No se pudo eliminar');
    },
  });

  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm" />
        <Dialog.Content className="fixed left-1/2 top-1/2 z-50 w-[min(92vw,34rem)] -translate-x-1/2 -translate-y-1/2 rounded-3xl border border-rose-400/20 bg-slate-950 p-6 shadow-soft outline-none md:p-8">
          <div className="mb-4 flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-rose-500/15 text-rose-200">
                <AlertTriangle className="h-5 w-5" />
              </div>
              <div>
                <Dialog.Title className="text-xl font-semibold text-white">Eliminar producto</Dialog.Title>
                <Dialog.Description className="mt-2 text-sm text-slate-400">
                  Esta acción es permanente. {producto ? `Se eliminará ${producto.nombre}.` : ''}
                </Dialog.Description>
              </div>
            </div>
            <Dialog.Close className="app-button-secondary h-10 w-10 p-0" aria-label="Cerrar">
              <X className="h-4 w-4" />
            </Dialog.Close>
          </div>

          <div className="flex flex-wrap justify-end gap-3">
            <button className="app-button-secondary" type="button" onClick={() => onOpenChange(false)}>
              Cancelar
            </button>
            <button className="app-button-danger" type="button" disabled={!producto || mutation.isPending} onClick={() => producto && mutation.mutate(producto.id)}>
              Eliminar
            </button>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
