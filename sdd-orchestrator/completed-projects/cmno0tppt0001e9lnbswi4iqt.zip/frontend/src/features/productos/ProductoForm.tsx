import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { LoaderCircle, Save } from 'lucide-react';

const schema = z.object({
  nombre: z.string().trim().min(1, 'Nombre requerido'),
  cantidad: z.number({ invalid_type_error: 'Revise cantidad y precio: deben ser números válidos' }).int('Cantidad debe ser entera'),
  precio: z.number({ invalid_type_error: 'Revise cantidad y precio: deben ser números válidos' }),
});

export type ProductoFormValues = z.infer<typeof schema>;

type Props = {
  onSubmit: (values: ProductoFormValues) => Promise<void> | void;
  defaultValues?: Partial<ProductoFormValues>;
  submitLabel?: string;
  isSubmitting?: boolean;
  onCancel?: () => void;
};

export function ProductoForm({ onSubmit, defaultValues, submitLabel = 'Guardar', isSubmitting = false, onCancel }: Props) {
  const form = useForm<ProductoFormValues>({
    resolver: zodResolver(schema),
    defaultValues: { nombre: '', cantidad: 0, precio: 0, ...defaultValues },
  });

  const { register, handleSubmit, reset, formState: { errors } } = form;

  useEffect(() => {
    reset({ nombre: '', cantidad: 0, precio: 0, ...defaultValues });
  }, [defaultValues, reset]);

  return (
    <form className="space-y-4" onSubmit={handleSubmit(onSubmit)}>
      <label className="block space-y-2 text-sm">
        <span className="text-slate-200">Nombre</span>
        <input className="app-input" {...register('nombre')} />
        {errors.nombre ? <p className="text-xs text-rose-300">{errors.nombre.message}</p> : null}
      </label>

      <div className="grid gap-4 md:grid-cols-2">
        <label className="block space-y-2 text-sm">
          <span className="text-slate-200">Cantidad</span>
          <input className="app-input" type="number" step="1" {...register('cantidad', { valueAsNumber: true })} />
          {errors.cantidad ? <p className="text-xs text-rose-300">{errors.cantidad.message}</p> : null}
        </label>

        <label className="block space-y-2 text-sm">
          <span className="text-slate-200">Precio</span>
          <input className="app-input" type="number" step="0.01" {...register('precio', { valueAsNumber: true })} />
          {errors.precio ? <p className="text-xs text-rose-300">{errors.precio.message}</p> : null}
        </label>
      </div>

      <div className="flex flex-wrap justify-end gap-3 pt-2">
        {onCancel ? (
          <button className="app-button-secondary" type="button" onClick={onCancel}>
            Cancelar
          </button>
        ) : null}
        <button className="app-button-primary" type="submit" disabled={isSubmitting}>
          {isSubmitting ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} {submitLabel}
        </button>
      </div>
    </form>
  );
}
