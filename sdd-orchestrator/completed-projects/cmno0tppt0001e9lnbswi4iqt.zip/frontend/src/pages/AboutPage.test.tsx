import { AboutPage } from './AboutPage';
import { renderWithProviders } from '../lib/testUtils';
import { screen } from '@testing-library/react';

describe('AboutPage', () => {
  it('rendersContentAndBackButton', async () => {
    renderWithProviders(<AboutPage />);
    expect(await screen.findByText('Acerca de')).toBeInTheDocument();
    expect(screen.getByText('Volver a Inicio')).toBeInTheDocument();
  });
});
