import { ContactPage } from './ContactPage';
import { renderWithProviders } from '../lib/testUtils';
import { screen } from '@testing-library/react';

describe('ContactPage', () => {
  it('rendersContentAndBreadcrumb', async () => {
    renderWithProviders(<ContactPage />);
    expect(await screen.findByText('Contacto')).toBeInTheDocument();
    expect(screen.getByText('Volver a Inicio')).toBeInTheDocument();
  });
});
