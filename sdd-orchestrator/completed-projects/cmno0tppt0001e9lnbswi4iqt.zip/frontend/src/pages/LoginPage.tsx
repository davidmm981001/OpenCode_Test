import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import { LockKeyhole, LoaderCircle, LogIn } from 'lucide-react';
import { useAuth } from '../auth/AuthContext';
import { toast } from 'sonner';

const loginSchema = z.object({
  username: z.string().trim().min(1, 'Usuario requerido'),
  password: z.string().min(1, 'Contraseña requerida'),
});

type LoginForm = z.infer<typeof loginSchema>;

export function LoginPage() {
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as { from?: string } | null)?.from ?? '/';

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: { username: 'admin', password: 'admin123' },
  });

  useEffect(() => {
    if (isAuthenticated) {
      navigate(from, { replace: true });
    }
  }, [from, isAuthenticated, navigate]);

  if (isAuthenticated) {
    return <Navigate to={from} replace />;
  }

  const onSubmit = async (values: LoginForm) => {
    await login(values);
    toast.success('Sesión iniciada');
    navigate(from, { replace: true });
  };

  return (
    <section className="mx-auto max-w-md">
      <div className="app-card p-6 md:p-8">
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-500/15 text-brand-200">
            <LockKeyhole className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-2xl font-semibold text-white">Acceso</h2>
            <p className="text-sm text-slate-400">Usa admin / admin123 para entrar.</p>
          </div>
        </div>

        <form className="space-y-4" onSubmit={handleSubmit(onSubmit)}>
          <label className="block space-y-2 text-sm">
            <span className="text-slate-200">Usuario</span>
            <input className="app-input" {...register('username')} autoComplete="username" />
            {errors.username ? <p className="text-xs text-rose-300">{errors.username.message}</p> : null}
          </label>

          <label className="block space-y-2 text-sm">
            <span className="text-slate-200">Contraseña</span>
            <input className="app-input" {...register('password')} type="password" autoComplete="current-password" />
            {errors.password ? <p className="text-xs text-rose-300">{errors.password.message}</p> : null}
          </label>

          <button className="app-button-primary w-full" type="submit" disabled={isSubmitting}>
            {isSubmitting ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <LogIn className="h-4 w-4" />} Ingresar
          </button>
        </form>
      </div>
    </section>
  );
}
