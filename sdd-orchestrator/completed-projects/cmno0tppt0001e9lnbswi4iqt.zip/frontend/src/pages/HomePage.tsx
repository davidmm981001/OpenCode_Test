import { ArrowRight, Package, ShieldCheck, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

const cards = [
  {
    title: 'Seguridad JWT',
    description: 'Sesión stateless con login y refresh centralizado.',
    icon: ShieldCheck,
  },
  {
    title: 'Inventario',
    description: 'Listado, alta y baja de productos con validaciones.',
    icon: Package,
  },
  {
    title: 'Navegación moderna',
    description: 'Sidebar responsive, breadcrumbs y placeholders informativos.',
    icon: Sparkles,
  },
];

export function HomePage() {
  return (
    <section className="space-y-6">
      <div className="app-card p-6 md:p-8">
        <p className="mb-3 inline-flex rounded-full bg-brand-500/15 px-3 py-1 text-xs font-medium text-brand-200">
          Sistema operativo de inventario
        </p>
        <h2 className="max-w-2xl text-3xl font-semibold tracking-tight text-white md:text-5xl">
          Bienvenido a la base migrada del inventario.
        </h2>
        <p className="mt-4 max-w-3xl text-sm leading-7 text-slate-300 md:text-base">
          Aquí puedes consultar productos, iniciar sesión y navegar las superficies institucionales del sistema moderno sin depender de páginas servidor clásicas.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link to="/productos" className="app-button-primary">
            Ir a productos <ArrowRight className="h-4 w-4" />
          </Link>
          <Link to="/about" className="app-button-secondary">
            Acerca de
          </Link>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {cards.map(({ title, description, icon: Icon }) => (
          <article key={title} className="app-card p-5">
            <Icon className="h-6 w-6 text-brand-300" />
            <h3 className="mt-4 text-lg font-semibold text-white">{title}</h3>
            <p className="mt-2 text-sm leading-6 text-slate-300">{description}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
