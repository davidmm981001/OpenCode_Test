import { useMemo, useState } from 'react';
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { AlertCircle, ArrowLeft, LoaderCircle, PackagePlus, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { api } from '../lib/api';
import { ProductoCreateModal } from '../features/productos/ProductoCreateModal';
import { ConfirmDeleteModal } from '../features/productos/ConfirmDeleteModal';
import { ProductoTable } from '../features/productos/ProductoTable';
import { Producto, ProductoPageResponse } from '../features/productos/types';

const pageSize = 14;

async function fetchProductos(page: number, sort: string, q: string) {
  const { data } = await api.get<ProductoPageResponse>('/api/v1/productos', {
    params: { page, size: pageSize, sort, q: q || undefined },
  });
  return data;
}

export function ProductoListPage() {
  const [page, setPage] = useState(0);
  const [sort, setSort] = useState('id,asc');
  const [q, setQ] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Producto | null>(null);
  const queryClient = useQueryClient();

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['productos', page, pageSize, sort, q],
    queryFn: () => fetchProductos(page, sort, q),
    placeholderData: keepPreviousData,
  });

  const productos = data?.content ?? [];

  const totalPages = data?.totalPages ?? 0;

  return (
    <section className="space-y-6">
      <div className="app-card space-y-4 p-6 md:p-8">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div className="space-y-2">
            <p className="inline-flex rounded-full bg-brand-500/15 px-3 py-1 text-xs font-medium text-brand-200">Inventario</p>
            <h2 className="text-3xl font-semibold text-white">Productos</h2>
            <p className="max-w-2xl text-sm text-slate-300">
              Consulta, crea y elimina productos con seguridad protegida por JWT.
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <button className="app-button-primary" onClick={() => setCreateOpen(true)}>
              <Plus className="h-4 w-4" /> Agregar producto
            </button>
          </div>
        </div>

        <div className="grid gap-3 md:grid-cols-[1fr_auto]">
          <label className="block space-y-2 text-sm">
            <span className="text-slate-200">Buscar</span>
            <input className="app-input" value={q} onChange={(event) => { setQ(event.target.value); setPage(0); }} placeholder="Buscar por nombre" />
          </label>
          <div className="flex items-end gap-3">
            <button className="app-button-secondary" type="button" onClick={() => { setQ(''); setPage(0); }}>
              Limpiar
            </button>
          </div>
        </div>
      </div>

      {isError ? (
        <div className="app-card flex items-start gap-3 p-6 text-rose-200">
          <AlertCircle className="mt-1 h-5 w-5" />
          <div>
            <p className="font-semibold">No fue posible cargar productos</p>
            <p className="mt-1 text-sm text-slate-300">{error instanceof Error ? error.message : 'Error inesperado'}</p>
            <button className="app-button-secondary mt-4" onClick={() => refetch()}>Reintentar</button>
          </div>
        </div>
      ) : productos.length === 0 && !isLoading ? (
        <div className="app-card flex flex-col items-center justify-center gap-4 px-6 py-12 text-center">
          <PackagePlus className="h-10 w-10 text-brand-300" />
          <div>
            <h3 className="text-xl font-semibold text-white">No hay productos cargados</h3>
            <p className="mt-2 text-sm text-slate-300">Agrega el primer producto para comenzar.</p>
          </div>
          <button className="app-button-primary" onClick={() => setCreateOpen(true)}>
            <Plus className="h-4 w-4" /> Agregar producto
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          <ProductoTable
            productos={productos}
            sort={sort}
            onSortChange={setSort}
            onDelete={setDeleteTarget}
            loading={isLoading && productos.length === 0}
          />

          <div className="flex flex-wrap items-center justify-between gap-3 text-sm text-slate-300">
            <p>
              {data?.totalElements ?? 0} registros
            </p>
            <div className="flex items-center gap-2">
              <button className="app-button-secondary" onClick={() => setPage((value) => Math.max(0, value - 1))} disabled={(data?.first ?? true) || isLoading}>
                Anterior
              </button>
              <span className="rounded-xl border border-white/10 bg-white/5 px-3 py-2">{page + 1} / {Math.max(totalPages, 1)}</span>
              <button className="app-button-secondary" onClick={() => setPage((value) => value + 1)} disabled={(data?.last ?? true) || isLoading}>
                Siguiente
              </button>
            </div>
          </div>
        </div>
      )}

      <ProductoCreateModal open={createOpen} onOpenChange={setCreateOpen} />
      <ConfirmDeleteModal producto={deleteTarget} open={Boolean(deleteTarget)} onOpenChange={(open) => !open && setDeleteTarget(null)} />
    </section>
  );
}
