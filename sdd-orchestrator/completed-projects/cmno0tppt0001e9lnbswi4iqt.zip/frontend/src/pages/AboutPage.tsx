import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

export function AboutPage() {
  return (
    <section className="app-card space-y-4 p-6 md:p-8">
      <p className="inline-flex rounded-full bg-white/5 px-3 py-1 text-xs text-slate-300">Institucional</p>
      <h2 className="text-3xl font-semibold text-white">Acerca de</h2>
      <p className="max-w-3xl text-sm leading-7 text-slate-300 md:text-base">
        Esta SPA reemplaza las páginas servidor del legado con una experiencia responsiva, accesible y preparada para el flujo de inventario.
      </p>
      <Link to="/" className="app-button-secondary inline-flex">
        <ArrowLeft className="h-4 w-4" /> Volver a Inicio
      </Link>
    </section>
  );
}
