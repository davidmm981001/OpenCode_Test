import { useLocation } from 'react-router-dom';
import { FuncionalidadPendiente } from '../components/FuncionalidadPendiente';

const pendingMap: Record<string, { title: string; description: string }> = {
  '/pendiente/interfaces-legacy': {
    title: 'Interfaces legacy',
    description: 'Las interfaces vacías del legado se documentan como artefactos sin lógica migrable.',
  },
  '/pendiente/componentes-webforms': {
    title: 'Componentes WebForms',
    description: 'Los scripts de soporte del framework previo fueron sustituidos por capacidades nativas del stack moderno.',
  },
  '/pendiente/switcher-vistas-legado': {
    title: 'Switcher de vistas legado',
    description: 'El conmutador móvil/desktop se representó con un layout responsive unificado.',
  },
};

export function PendingPage() {
  const location = useLocation();
  const info = pendingMap[location.pathname] ?? {
    title: 'Pendiente de migración',
    description: 'Este artefacto todavía no tiene correlato funcional en el MVP y queda documentado para una versión futura.',
  };

  return <FuncionalidadPendiente title={info.title} description={info.description} />;
}
