import { ArrowLeft, Mail } from 'lucide-react';
import { Link } from 'react-router-dom';

export function ContactPage() {
  return (
    <section className="app-card space-y-4 p-6 md:p-8">
      <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-500/15 text-brand-200">
        <Mail className="h-5 w-5" />
      </div>
      <h2 className="text-3xl font-semibold text-white">Contacto</h2>
      <p className="max-w-3xl text-sm leading-7 text-slate-300 md:text-base">
        Para soporte del sistema de migración, usa los canales corporativos del equipo de tecnología o abre un ticket interno.
      </p>
      <Link to="/" className="app-button-secondary inline-flex">
        <ArrowLeft className="h-4 w-4" /> Volver a Inicio
      </Link>
    </section>
  );
}
