/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#eef8ff',
          100: '#d9eeff',
          200: '#b9ddff',
          300: '#7bc1ff',
          400: '#36a0ff',
          500: '#0b84ff',
          600: '#0067db',
          700: '#004faa',
          800: '#003a7a',
          900: '#02284f',
        },
      },
      boxShadow: {
        soft: '0 20px 60px rgba(15, 23, 42, 0.22)',
      },
    },
  },
  plugins: [],
};
