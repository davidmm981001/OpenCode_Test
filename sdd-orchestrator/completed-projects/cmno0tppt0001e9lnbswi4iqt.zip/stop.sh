#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$ROOT_DIR/scripts/common.sh"

if [[ -f "$PORTS_FILE" ]]; then
  # shellcheck disable=SC1090
  source "$PORTS_FILE"
fi

terminate_pid() {
  local pid_file="$1"
  if [[ -f "$pid_file" ]]; then
    local pid
    pid="$(cat "$pid_file")"
    if kill -0 "$pid" >/dev/null 2>&1; then
      kill -TERM "$pid" || true
      for _ in $(seq 1 5); do
        if ! kill -0 "$pid" >/dev/null 2>&1; then
          break
        fi
        sleep 1
      done
      if kill -0 "$pid" >/dev/null 2>&1; then
        kill -KILL "$pid" || true
      fi
    fi
    rm -f "$pid_file"
  fi
}

terminate_pid "$PID_DIR/backend.pid"
terminate_pid "$PID_DIR/frontend.pid"
stop_local_postgres
rm -f "$PORTS_FILE"
log "Procesos detenidos y metadata limpiada"
