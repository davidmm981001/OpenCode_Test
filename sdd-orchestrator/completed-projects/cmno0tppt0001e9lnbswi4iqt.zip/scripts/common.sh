#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKEND_DIR="$ROOT_DIR/backend"
FRONTEND_DIR="$ROOT_DIR/frontend"
PID_DIR="$ROOT_DIR/.pids"
LOG_DIR="$ROOT_DIR/logs"
PORTS_FILE="$PID_DIR/ports.env"
POSTGRES_BIN_DIR="${POSTGRES_BIN_DIR:-/usr/lib/postgresql/16/bin}"
POSTGRES_DATA_DIR="$PID_DIR/postgres-data"
POSTGRES_LOG_FILE="$LOG_DIR/postgres.log"

mkdir -p "$PID_DIR" "$LOG_DIR"

log() { printf '[%s] %s\n' "$(date '+%H:%M:%S')" "$*"; }

port_is_free() {
  local port="$1"
  python3 - "$port" <<'PY'
import socket, sys
port = int(sys.argv[1])
s = socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
try:
    s.bind(('127.0.0.1', port))
except OSError:
    sys.exit(1)
finally:
    s.close()
PY
}

find_free_port() {
  local base="$1"
  shift
  local used=("$@")
  for offset in $(seq 0 20); do
    local candidate=$((base + offset))
    local skip=0
    for taken in "${used[@]:-}"; do
      if [[ "$taken" == "$candidate" ]]; then
        skip=1
        break
      fi
    done
    if [[ "$skip" -eq 0 ]] && port_is_free "$candidate"; then
      printf '%s' "$candidate"
      return 0
    fi
  done
  printf 'No se encontró un puerto libre desde %s con 20 intentos\n' "$base" >&2
  return 1
}

write_ports_env() {
  cat >"$PORTS_FILE" <<EOF
export DB_PORT=$1
export BACKEND_PORT=$2
export FRONTEND_PORT=$3
export DB_HOST=localhost
export DB_NAME=${DB_NAME:-demo_asp_forms}
export DB_USERNAME=${DB_USERNAME:-demo_asp_forms}
export DB_PASSWORD=${DB_PASSWORD:-demo_asp_forms}
export SERVER_PORT=$2
export CORS_ALLOWED_ORIGINS=http://localhost:$3
export VITE_API_BASE_URL=http://localhost:$2
EOF
}

load_ports_env() {
  if [[ -f "$PORTS_FILE" ]]; then
    # shellcheck disable=SC1090
    source "$PORTS_FILE"
  fi
}

ensure_command() {
  local cmd="$1"
  if ! command -v "$cmd" >/dev/null 2>&1; then
    printf 'Falta el comando requerido: %s\n' "$cmd" >&2
    exit 1
  fi
}

ensure_postgres_bin() {
  if [[ ! -x "$POSTGRES_BIN_DIR/pg_ctl" || ! -x "$POSTGRES_BIN_DIR/initdb" || ! -x "$POSTGRES_BIN_DIR/postgres" ]]; then
    printf 'No se encontraron binarios locales de PostgreSQL en %s\n' "$POSTGRES_BIN_DIR" >&2
    exit 1
  fi
}

start_local_postgres() {
  local db_port="$1"
  local superuser="${PGSUPERUSER:-postgres}"
  local superpassword="${PGSUPERPASSWORD:-}"

  ensure_postgres_bin

  if [[ ! -d "$POSTGRES_DATA_DIR" ]]; then
    "$POSTGRES_BIN_DIR/initdb" -D "$POSTGRES_DATA_DIR" --auth=trust --no-instructions >/dev/null
  fi

  if "$POSTGRES_BIN_DIR/pg_ctl" -D "$POSTGRES_DATA_DIR" status >/dev/null 2>&1; then
    if ! "$POSTGRES_BIN_DIR/pg_isready" -h 127.0.0.1 -p "$db_port" >/dev/null 2>&1; then
      "$POSTGRES_BIN_DIR/pg_ctl" -D "$POSTGRES_DATA_DIR" -m fast stop >/dev/null 2>&1 || true
    fi
  fi

  if ! "$POSTGRES_BIN_DIR/pg_isready" -h 127.0.0.1 -p "$db_port" >/dev/null 2>&1; then
    log "Iniciando PostgreSQL local en el puerto $db_port"
    "$POSTGRES_BIN_DIR/pg_ctl" -D "$POSTGRES_DATA_DIR" -l "$POSTGRES_LOG_FILE" \
      -o "-p $db_port -h 127.0.0.1" start >/dev/null
  fi

  for _ in $(seq 1 60); do
    if "$POSTGRES_BIN_DIR/pg_isready" -h 127.0.0.1 -p "$db_port" >/dev/null 2>&1; then
      return 0
    fi
    sleep 1
  done

  printf 'PostgreSQL local no quedó disponible en el puerto %s\n' "$db_port" >&2
  return 1
}

stop_local_postgres() {
  if [[ -d "$POSTGRES_DATA_DIR" ]]; then
    "$POSTGRES_BIN_DIR/pg_ctl" -D "$POSTGRES_DATA_DIR" -m fast stop >/dev/null 2>&1 || true
  fi
}
