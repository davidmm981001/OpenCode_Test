#!/usr/bin/env bash
set -u

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck disable=SC1091
source "$ROOT_DIR/scripts/common.sh"

load_ports_env

: "${BACKEND_PORT:?Falta .pids/ports.env o BACKEND_PORT}"
: "${FRONTEND_PORT:?Falta .pids/ports.env o FRONTEND_PORT}"

pass=0
fail=0

check() {
  local name="$1"
  shift
  if "$@"; then
    printf 'PASS %s\n' "$name"
    pass=$((pass + 1))
  else
    printf 'FAIL %s\n' "$name"
    fail=$((fail + 1))
  fi
}

check 'health-up' bash -lc "curl -fsS http://localhost:$BACKEND_PORT/actuator/health | grep -q '\"status\":\"UP\"'"
check 'openapi' bash -lc "curl -fsS http://localhost:$BACKEND_PORT/v3/api-docs | grep -q '\"openapi\"'"
check 'api-root-auth' bash -lc "code=\$(curl -ks -o /dev/null -w '%{http_code}' http://localhost:$BACKEND_PORT/api/v1/); [[ \$code == '401' || \$code == '403' ]]"
check 'login' bash -lc "token=\$(curl -fsS -X POST http://localhost:$BACKEND_PORT/auth/login -H 'Content-Type: application/json' -d '{\"username\":\"admin\",\"password\":\"admin123\"}' | python3 -c 'import json,sys; print(json.load(sys.stdin)[\"token\"], end=\"\")'); [[ -n \"\$token\" ]]"
check 'frontend-root' bash -lc "curl -fsS http://localhost:$FRONTEND_PORT/ | grep -q 'id=\"root\"'"
check 'frontend-layout' bash -lc "curl -fsS http://localhost:$FRONTEND_PORT/ | grep -q 'DEMO Asp Forms'"
check 'swagger-ui' bash -lc "curl -fsS http://localhost:$BACKEND_PORT/swagger-ui/ >/dev/null"
check 'products-list-auth' bash -lc "token=\$(curl -fsS -X POST http://localhost:$BACKEND_PORT/auth/login -H 'Content-Type: application/json' -d '{\"username\":\"admin\",\"password\":\"admin123\"}' | python3 -c 'import json,sys; print(json.load(sys.stdin)[\"token\"], end=\"\")'); code=\$(curl -ks -o /dev/null -w '%{http_code}' -H \"Authorization: Bearer \$token\" http://localhost:$BACKEND_PORT/api/v1/productos); [[ \$code == '200' ]]"

printf 'Resumen smoke: %s OK, %s FAIL\n' "$pass" "$fail"
if [[ "$pass" -ge 5 ]]; then
  exit 0
fi
exit 1
