## ADDED Requirements

### Requirement: product listing
The system MUST expose authenticated paginated product listing.

#### Scenario: products are returned with paging
- **GIVEN** authenticated access and existing products
- **WHEN** the user requests `/api/v1/productos` with paging parameters
- **THEN** the response contains only id, nombre, cantidad, and precio fields in a paged envelope

#### Scenario: empty catalog is valid
- **GIVEN** no products exist
- **WHEN** the user requests the product list
- **THEN** an empty page is returned without error

### Requirement: product creation
The system MUST allow authenticated creation of products with validation.

#### Scenario: valid product is created
- **GIVEN** a valid payload with nombre, cantidad, and precio
- **WHEN** the user submits the create request
- **THEN** the product is stored and returned with a generated identifier

#### Scenario: blank name is rejected
- **GIVEN** a payload whose name is blank or whitespace
- **WHEN** the user submits the create request
- **THEN** the request fails with a controlled validation error

### Requirement: product deletion
The system MUST support idempotent authenticated deletion.

#### Scenario: deleting an existing or missing product succeeds
- **GIVEN** an authenticated caller and a product id
- **WHEN** the caller submits delete for an existing or already removed record
- **THEN** the response is successful and the list can be refreshed without error
