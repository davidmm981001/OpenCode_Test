## ADDED Requirements

### Requirement: local runnable scaffold
The system MUST provide a runnable local application split into backend and frontend without Docker.

#### Scenario: application is launched locally
- **GIVEN** the workspace contains the generated project
- **WHEN** the user runs the root start script
- **THEN** the backend and frontend start on distinct free ports
- **AND** the selected ports are persisted for later stop and smoke commands

### Requirement: backend platform services
The backend MUST expose health, OpenAPI, CORS, error handling, logging, and protected root API endpoints.

#### Scenario: health and docs are available
- **GIVEN** the backend is running
- **WHEN** the user requests `/actuator/health` and `/v3/api-docs`
- **THEN** both endpoints respond successfully

#### Scenario: security is enforced on API routes
- **GIVEN** the backend is running
- **WHEN** the user requests `/api/v1/` without valid credentials
- **THEN** the request is rejected with HTTP 401 or 403

### Requirement: operational configuration
The system MUST support environment-based configuration for ports, database connection, JWT, and CORS.

#### Scenario: configuration comes from environment
- **GIVEN** environment variables are set for database, backend, frontend, and allowed origins
- **WHEN** the application starts
- **THEN** it uses the provided values instead of hardcoded ports or origins
