## ADDED Requirements

### Requirement: navigable legacy placeholders
The system MUST expose informational routes for legacy artifacts that are not part of the MVP.

#### Scenario: legacy routes render informative content
- **GIVEN** a user opens a known pending route
- **WHEN** the route resolves
- **THEN** the application shows a neutral placeholder with return navigation

#### Scenario: pending routes are not errors
- **GIVEN** a user reaches a pending route directly
- **WHEN** the page loads
- **THEN** the route does not present as a technical error or 404 page
