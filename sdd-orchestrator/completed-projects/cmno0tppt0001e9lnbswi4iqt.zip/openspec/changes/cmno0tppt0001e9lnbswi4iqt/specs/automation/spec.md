## ADDED Requirements

### Requirement: dynamic run and stop scripts
The system MUST provide scripts to start, stop, and verify the application locally.

#### Scenario: start script discovers free ports
- **GIVEN** the configured base ports are partially occupied
- **WHEN** the user runs the start script
- **THEN** the script finds free distinct ports within the permitted range and persists them

#### Scenario: stop script cleans resources
- **GIVEN** processes were started by the project scripts
- **WHEN** the user runs the stop script
- **THEN** the processes are terminated, PIDs are removed, and port metadata is cleaned up

#### Scenario: smoke tests report multiple checks
- **GIVEN** the application is running
- **WHEN** the smoke test script executes
- **THEN** it reports multiple checks and returns success when the majority pass
