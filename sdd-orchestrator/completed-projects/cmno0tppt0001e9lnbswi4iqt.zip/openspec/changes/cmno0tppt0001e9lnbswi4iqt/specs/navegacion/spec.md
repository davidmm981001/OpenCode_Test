## ADDED Requirements

### Requirement: responsive shell and institutional pages
The frontend MUST provide a responsive application shell with home, about, contact, and login surfaces.

#### Scenario: the shell renders on desktop and mobile
- **GIVEN** the application is open
- **WHEN** the viewport changes between mobile and desktop widths
- **THEN** the layout adapts without changing the current route

#### Scenario: about and contact pages exist
- **GIVEN** an authenticated user
- **WHEN** the user opens `/about` or `/contact`
- **THEN** the page renders inside the common layout and provides a return action to the home page

### Requirement: pending legacy surfaces are navigable
The system MUST provide informative placeholder routes for legacy artifacts not migrated in the MVP.

#### Scenario: pending routes do not 404
- **GIVEN** a known pending path
- **WHEN** the user opens it directly
- **THEN** the app renders an informational placeholder with a return button
