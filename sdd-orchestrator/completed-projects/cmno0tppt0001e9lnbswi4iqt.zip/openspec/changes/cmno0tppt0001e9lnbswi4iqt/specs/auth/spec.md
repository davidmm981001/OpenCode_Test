## ADDED Requirements

### Requirement: stateless authentication
The system MUST authenticate users with JWT and keep the API stateless.

#### Scenario: login returns tokens
- **GIVEN** valid credentials for a seeded user
- **WHEN** the user submits `/auth/login`
- **THEN** the response includes access and refresh tokens, token type, expiry, and roles

#### Scenario: invalid credentials are rejected
- **GIVEN** invalid credentials
- **WHEN** the user submits `/auth/login`
- **THEN** the request fails with HTTP 401 and a standardized error body

#### Scenario: refresh token can renew the session
- **GIVEN** a valid refresh token
- **WHEN** the user submits `/auth/refresh`
- **THEN** a new access token and refresh token are issued

### Requirement: seeded administrator
The system MUST seed an admin account with username `admin` and password `admin123`.

#### Scenario: seeded admin can authenticate
- **GIVEN** the database has been migrated and seeded
- **WHEN** the admin submits valid credentials
- **THEN** the authentication succeeds and returns authorized roles
