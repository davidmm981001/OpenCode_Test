## Why

We need to generate the DEMO Asp Forms Migration application from the provided user stories and keep the initial scope stable for OpenCode and OpenSpec while the implementation is created locally.

## What Changes

- Preserve the full user story block as persistent workspace context.
- Seed the project with change artifacts for infrastructure, auth, products, navigation, and pending legacy surfaces.
- Keep OpenCode configuration isolated from OpenSpec configuration.
- Drive the workspace toward a runnable local app with backend, frontend, scripts, tests, and validation.

## Capabilities

### New Capabilities
- `project-scope`: generated project context and initial SDD seed.
- `infraestructura-base`: Spring Boot 3 backend, JWT security, Flyway, health, OpenAPI, CORS, logging, and run/stop automation.
- `auth`: login/refresh endpoints and stateless authentication flow.
- `productos`: paginated list/create/delete inventory APIs and UI.
- `navegacion-institucional`: About, Contact, responsive layout, and home shell.
- `funcionalidades-pendientes`: navigable placeholders for unmigrated legacy artifacts.

### Modified Capabilities
- None.

## Impact

- Project-local OpenSpec artifacts and OpenCode instructions.
- Backend and frontend runtime scaffolding.
- Scripts, README, DOCS, and validation artifacts.

## Assumptions

- The migration runs without Docker containers; scripts target a local PostgreSQL instance discovered via `psql`.
- Refresh tokens are returned by the API and handled conservatively in frontend memory/documented session storage, never in localStorage.
