## Context

This change creates the complete local migration target for DEMO Asp Forms Migration. The implementation must remain traceable to the OpenSpec artifacts and deliver a runnable backend/frontend stack without Docker.

## Goals / Non-Goals

**Goals:**
- Preserve the full story block in the workspace.
- Keep OpenSpec and OpenCode artifacts isolated and referenced by file path.
- Deliver a Spring Boot 3 backend with JWT, Flyway, OpenAPI, health, CORS, logging, and product/auth APIs.
- Deliver a React 18 + Vite frontend with BrowserRouter, React Query, Axios, auth guards, and the required screens.
- Provide local run/stop/smoke scripts that manage ports dynamically and keep the app running.

**Non-Goals:**
- Container orchestration.
- Adding functionality outside the supplied user stories.

## Decisions

- Use project-local OpenSpec change artifacts as the primary planning context.
- Keep the raw user stories in a dedicated workspace file for traceability.
- Build the backend as a modular monolith with package boundaries aligned to the stories (`infraestructura`, `auth`, `productos`).
- Build the frontend as a single Vite app with lazy-loaded routes for secondary surfaces.
- Store runtime connection data in `.pids/ports.env` and generate frontend runtime env files from the selected ports.
- Use PostgreSQL-managed bcrypt seeding (`pgcrypto`) so the admin seed is deterministic and valid.
- Use JSON logging with a correlation ID and a rolling file appender under `logs/`.

## Risks / Trade-offs

- The environment may not have a running local PostgreSQL instance; scripts will fail fast with explicit messages if `psql` cannot connect.
- Keeping the refresh token in memory avoids localStorage but means the session is intentionally conservative across page reloads.
- The generic repository configuration mentions Docker, but the supplied user stories explicitly require local scripts without containers; the story requirement takes precedence.
