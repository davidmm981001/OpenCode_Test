## 1. Setup

- [x] 1.1 Confirm the scope and OpenSpec change artifacts for infrastructure, auth, products, navigation, and pending legacy surfaces.
- [x] 1.2 Create the backend/frontend scaffold, root scripts, and build tooling needed to run locally without Docker.

## 2. Backend foundation

- [x] 2.1 Implement the Spring Boot application shell, profiles, logging, error handling, CORS, OpenAPI, and health endpoints.
- [x] 2.2 Implement Flyway baseline and seed migrations plus the PostgreSQL persistence model for users, refresh tokens, and products.
- [x] 2.3 Implement JWT security, auth/login refresh endpoints, and the authenticated /api/v1/ root endpoint.

## 3. Product module

- [x] 3.1 Implement the product query and command services plus the paginated REST API.
- [x] 3.2 Add backend unit and integration tests for security, auth, health, and products.

## 4. Frontend foundation

- [x] 4.1 Implement the Vite/React app shell, router, query client, auth context, layout, and responsive shell.
- [x] 4.2 Implement login, home, about, contact, pending routes, and the product list/create/delete experience.

## 5. Runtime automation and validation

- [x] 5.1 Implement run/stop/smoke scripts with dynamic ports, PID tracking, and log inspection.
- [x] 5.2 Add frontend component tests, smoke checks, README, and DOCS mapping the legacy migration.
- [ ] 5.3 Verify the project with build, test, and local run validation.
