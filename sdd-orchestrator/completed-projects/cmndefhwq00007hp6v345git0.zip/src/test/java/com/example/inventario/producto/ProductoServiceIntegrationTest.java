package com.example.inventario.producto;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

@SpringBootTest
@Testcontainers
class ProductoServiceIntegrationTest {

  @Container
  static final PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:17-alpine")
      .withDatabaseName("inventario")
      .withUsername("postgres")
      .withPassword("postgres");

  @DynamicPropertySource
  static void registrarPropiedades(DynamicPropertyRegistry registry) {
    registry.add("spring.datasource.url", postgres::getJdbcUrl);
    registry.add("spring.datasource.username", postgres::getUsername);
    registry.add("spring.datasource.password", postgres::getPassword);
  }

  @Autowired
  private ProductoService productoService;

  @Autowired
  private ProductoRepository productoRepository;

  @Test
  void agregar_listar_y_eliminar_producto_en_base_real() {
    Producto producto = new Producto("Laptop", 3, new BigDecimal("2500.00"));

    Producto guardado = productoService.agregar(producto);

    assertThat(guardado.getId()).isNotNull();
    assertThat(productoService.obtenerTodos()).hasSize(1);

    productoService.eliminar(guardado.getId());

    assertThat(productoRepository.findAll()).isEmpty();
  }
}
