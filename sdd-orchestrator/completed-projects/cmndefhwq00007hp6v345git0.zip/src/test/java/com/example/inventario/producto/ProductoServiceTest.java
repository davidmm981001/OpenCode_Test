package com.example.inventario.producto;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ProductoServiceTest {

  @Mock
  private ProductoRepository productoRepository;

  @InjectMocks
  private ProductoService productoService;

  @Test
  void agregar_persiste_producto_cuando_nombre_es_valido() {
    Producto producto = new Producto("Teclado", 5, new BigDecimal("120.50"));
    when(productoRepository.save(producto)).thenReturn(producto);

    Producto resultado = productoService.agregar(producto);

    assertThat(resultado).isSameAs(producto);
    verify(productoRepository).save(producto);
  }

  @Test
  void agregar_lanza_excepcion_cuando_nombre_esta_vacio() {
    Producto producto = new Producto("   ", 5, new BigDecimal("120.50"));

    assertThatThrownBy(() -> productoService.agregar(producto))
        .isInstanceOf(IllegalArgumentException.class)
        .hasMessage("Nombre requerido");
  }

  @Test
  void eliminar_delega_en_el_repositorio() {
    productoService.eliminar(10L);

    verify(productoRepository).deleteById(10L);
  }

  @Test
  void obtenerTodos_retorna_la_lista_completa() {
    List<Producto> productos = List.of(
        new Producto("Mouse", 2, new BigDecimal("25.00")),
        new Producto("Monitor", 1, new BigDecimal("300.00")));
    when(productoRepository.findAll()).thenReturn(productos);

    List<Producto> resultado = productoService.obtenerTodos();

    assertThat(resultado).containsExactlyElementsOf(productos);
  }
}
