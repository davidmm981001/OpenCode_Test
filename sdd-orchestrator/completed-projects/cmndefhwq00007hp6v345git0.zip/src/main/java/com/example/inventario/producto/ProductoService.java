package com.example.inventario.producto;

import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProductoService {

  private final ProductoRepository productoRepository;

  public ProductoService(ProductoRepository productoRepository) {
    this.productoRepository = productoRepository;
  }

  @Transactional
  public Producto agregar(Producto producto) {
    validarNombre(producto);
    return productoRepository.save(producto);
  }

  @Transactional
  public void eliminar(Long id) {
    productoRepository.deleteById(id);
  }

  @Transactional(readOnly = true)
  public List<Producto> obtenerTodos() {
    return productoRepository.findAll();
  }

  private static void validarNombre(Producto producto) {
    if (producto == null || producto.getNombre() == null || producto.getNombre().trim().isEmpty()) {
      throw new IllegalArgumentException("Nombre requerido");
    }
  }
}
