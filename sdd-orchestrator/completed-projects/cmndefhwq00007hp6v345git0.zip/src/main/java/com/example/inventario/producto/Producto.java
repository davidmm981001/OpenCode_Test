package com.example.inventario.producto;

import java.math.BigDecimal;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "productos")
public class Producto {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(nullable = false)
  private String nombre;

  @Column(nullable = false)
  private Integer cantidad;

  @Column(nullable = false, precision = 19, scale = 2)
  private BigDecimal precio;

  protected Producto() {
  }

  public Producto(String nombre, Integer cantidad, BigDecimal precio) {
    this.nombre = nombre;
    this.cantidad = cantidad;
    this.precio = precio;
  }

  public Long getId() {
    return id;
  }

  public String getNombre() {
    return nombre;
  }

  public Integer getCantidad() {
    return cantidad;
  }

  public BigDecimal getPrecio() {
    return precio;
  }
}
