Gestión básica de productos para usuarios del sistema de inventario
Gestión de Inventarios
Como usuario del sistema de inventario, es necesario gestionar los productos almacenados con sus atributos esenciales para controlar el stock y los precios asociados. Según el código de la clase Producto, cada producto se identifica con un Id único, un nombre descriptivo, una cantidad disponible y un precio decimal. En la sección de ProductoService.cs se define la lógica central para obtener todos los productos, agregar nuevos productos y eliminar productos existentes mediante el repositorio ProductoRepository y el contexto InventarioContext, que mapea a la tabla de productos de la base de datos. Se requiere que el nombre del producto sea un campo obligatorio para asegurar la integridad de la información. Este proceso beneficia a los administradores o encargados de inventario para mantener actualizada la información del catálogo, facilitando decisiones de compra y ventas.
1
Dado un producto con Nombre no vacío, cuando se agrega el producto, entonces el sistema lo persiste correctamente en el repositorio.
2
Dado un producto con Nombre vacío o solo espacios, cuando se intenta agregar, entonces el sistema arroja una excepción con mensaje "Nombre requerido".
3
Dado un identificador de producto existente, cuando se elimina el producto, entonces el sistema remueve la entidad del repositorio de forma persistente.
4
Dado una solicitud para obtener productos, cuando se invoca el método ObtenerTodos, entonces el sistema retorna la lista completa de productos con sus propiedades Id, Nombre, Cantidad y Precio.