# Inventario

Aplicacion Spring Boot para gestionar productos de inventario.

## Requisitos

- Java 21
- Maven 3.9+
- PostgreSQL 15+

## Ejecutar pruebas

```bash
mvn test
```

## Ejecutar localmente

1. Levanta una base de datos PostgreSQL accesible en `localhost:5432`.
2. Ajusta `SPRING_DATASOURCE_USERNAME` y `SPRING_DATASOURCE_PASSWORD` si hace falta.
3. Inicia la aplicacion:

```bash
mvn spring-boot:run
```
