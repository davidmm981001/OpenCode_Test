#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$ROOT_DIR/backend"
FRONTEND_DIR="$ROOT_DIR/frontend"
RUNTIME_DIR="$ROOT_DIR/.runtime"
mkdir -p "$RUNTIME_DIR"

check_cmd() { command -v "$1" >/dev/null 2>&1 || { echo "Falta $1"; exit 1; }; }
check_cmd java
check_cmd node
check_cmd npm
check_cmd psql

pick_port() {
  local preferred="$1"
  local p="$preferred"
  while ss -ltn "sport = :$p" >/dev/null 2>&1; do p=$((p+1)); done
  echo "$p"
}

BACKEND_PORT="$(pick_port "${BACKEND_PORT:-8081}")"
FRONTEND_PORT="$(pick_port "${FRONTEND_PORT:-3001}")"
DATABASE_PORT="$(pick_port "${DATABASE_PORT:-5433}")"

export BACKEND_PORT FRONTEND_PORT DATABASE_PORT
export VITE_API_URL="http://localhost:$BACKEND_PORT"

if [ -f "$ROOT_DIR/.env" ]; then set -a; source "$ROOT_DIR/.env"; set +a; fi

echo "Compilando backend..."
mvn -q -f "$BACKEND_DIR/pom.xml" -DskipTests package

JAR_FILE="$(ls "$BACKEND_DIR"/target/*.jar | head -n 1)"
if [ -f "$JAR_FILE" ]; then
  echo "JAR: $(du -h "$JAR_FILE" | cut -f1)"
fi

echo "Instalando frontend..."
npm install --prefix "$FRONTEND_DIR"

nohup java -jar "$JAR_FILE" --server.port="$BACKEND_PORT" > "$RUNTIME_DIR/backend.log" 2>&1 &
echo $! > "$RUNTIME_DIR/backend.pid"

for i in {1..60}; do curl -fsS "http://localhost:$BACKEND_PORT/actuator/health" >/dev/null 2>&1 && break || sleep 2; done

nohup npm --prefix "$FRONTEND_DIR" run dev -- --host 0.0.0.0 --port "$FRONTEND_PORT" > "$RUNTIME_DIR/frontend.log" 2>&1 &
echo $! > "$RUNTIME_DIR/frontend.pid"

echo "Backend: http://localhost:$BACKEND_PORT"
echo "Frontend: http://localhost:$FRONTEND_PORT"
