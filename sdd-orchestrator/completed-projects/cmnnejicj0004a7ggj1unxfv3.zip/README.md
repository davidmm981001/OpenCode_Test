# COBOL Application Test 01

Aplicación moderna para el módulo de seguridad tecnológica.

## Prerrequisitos
- Java 17+
- Node.js 18+
- npm
- psql si se usará PostgreSQL local

## Estructura
- `backend/`: Spring Boot + PostgreSQL/Flyway
- `frontend/`: React + Vite + Tailwind

## Ejecutar
1. Copia `.env.example` a `.env`.
2. Ejecuta `./run.sh`.

## Seguridad
- JWT stateless
- Refresh token persistido hasheado
- Rutas públicas: `/auth/**`, `/actuator/health`, `/v3/api-docs/**`, `/swagger-ui/**`

## OpenAPI
- Swagger UI: `/swagger-ui/index.html`

## Funcionalidades pendientes
- Opciones 02 a 09 del menú principal navegan a pantallas pendientes.
