# DOCS

## Arquitectura
- Hexagonal por capas: domain, application, infrastructure, api.
- Frontend con React Router y TanStack Query.

## Datos
- Flyway crea baseline, refresh tokens, índices, auditoría y seed inicial.

## Scripts
- `run.sh` y `stop.sh` levantan o detienen backend y frontend.
