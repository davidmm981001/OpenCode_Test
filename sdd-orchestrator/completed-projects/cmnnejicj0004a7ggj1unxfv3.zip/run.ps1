Write-Host "Use run.sh on Linux"
