package com.cobolapp.shared.config;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import java.util.Map;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

@Validated
@ConfigurationProperties(prefix = "app")
public record AppProperties(
    @NotBlank String corsAllowedOrigins,
    @NotBlank String jwtSecret,
    @Min(60000) long jwtExpirationMs,
    @Min(60000) long refreshExpirationMs,
    @Valid Map<String, DemoUser> demoUsers) {

  public record DemoUser(
      @NotBlank String username,
      @NotBlank String password,
      @NotEmpty List<@NotBlank String> roles) {}
}
