package com.cobolapp.shared.exception;

import java.time.OffsetDateTime;
import java.util.List;

public record ErrorResponse(
    OffsetDateTime timestamp,
    int status,
    String code,
    String message,
    List<String> details,
    String path) {}
