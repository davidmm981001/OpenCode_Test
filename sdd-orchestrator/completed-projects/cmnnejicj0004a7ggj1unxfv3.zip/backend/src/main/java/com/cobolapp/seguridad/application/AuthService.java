package com.cobolapp.seguridad.application;

import com.cobolapp.shared.config.AppProperties;
import com.cobolapp.shared.exception.BusinessException;
import com.cobolapp.shared.security.JwtUtil;
import com.cobolapp.shared.security.RefreshTokenService;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {
  private final AppProperties properties;
  private final JwtUtil jwtUtil;
  private final RefreshTokenService refreshTokenService;

  public AuthService(AppProperties properties, JwtUtil jwtUtil, RefreshTokenService refreshTokenService) {
    this.properties = properties;
    this.jwtUtil = jwtUtil;
    this.refreshTokenService = refreshTokenService;
  }

  public AuthResponse login(String username, String password) {
    AppProperties.DemoUser user = properties.demoUsers().values().stream()
        .filter(candidate -> candidate.username().equals(username) && candidate.password().equals(password))
        .findFirst()
        .orElseThrow(() -> new BusinessException("AUTH_INVALID", "Credenciales inválidas"));
    return createSession(user.username(), user.roles());
  }

  @Transactional
  public AuthResponse refresh(String refreshToken) {
    var token = refreshTokenService.validate(refreshToken);
    AppProperties.DemoUser user = properties.demoUsers().values().stream()
        .filter(candidate -> candidate.username().equals(token.getUsername()))
        .findFirst()
        .orElseThrow(() -> new BusinessException("AUTH_INVALID", "Credenciales inválidas"));
    refreshTokenService.revoke(refreshToken);
    return createSession(user.username(), user.roles());
  }

  @Transactional
  public MessageResponse logout(String refreshToken) {
    refreshTokenService.revoke(refreshToken);
    return new MessageResponse("Sesión cerrada");
  }

  private AuthResponse createSession(String username, List<String> roles) {
    String accessToken = jwtUtil.generateAccessToken(username, roles, properties.jwtExpirationMs());
    var refresh = refreshTokenService.issue(username);
    return new AuthResponse(accessToken, refresh.plainToken(), "Bearer", properties.jwtExpirationMs() / 1000, roles, username);
  }

  public record AuthResponse(String accessToken, String refreshToken, String tokenType, long expiresIn, List<String> roles, String username) {}
  public record MessageResponse(String message) {}
}
