package com.cobolapp.consultausuarios.api;

import com.cobolapp.seguridad.application.UserConsultationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/usuarios")
@Tag(name = "Consulta de usuarios")
public class UsuarioConsultaController {
  private final UserConsultationService service;

  public UsuarioConsultaController(UserConsultationService service) {
    this.service = service;
  }

  @GetMapping("/consulta")
  @Operation(summary = "Consulta de usuarios")
  public ResponseEntity<UserConsultationService.UserPageResponse> search(
      @RequestParam(required = false) @Size(max = 4) String empresa,
      @RequestParam(required = false) @Size(max = 4) String centro,
      @RequestParam(required = false) @Size(max = 8) String usuario,
      @RequestParam(required = false) @Size(max = 8) String perfil,
      @RequestParam(required = false) @Size(max = 40) String nombre,
      @RequestParam(defaultValue = "0") @Min(0) int page,
      @RequestParam(defaultValue = "14") @Min(1) @Max(100) int size,
      @RequestParam(required = false) String sort) {
    return ResponseEntity.ok(service.search(empresa, centro, usuario, perfil, nombre, page, size, sort));
  }
}
