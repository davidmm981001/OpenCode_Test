package com.cobolapp.shared.config;

import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
@EnableConfigurationProperties(AppProperties.class)
public class CorsConfig implements InitializingBean {
  private final AppProperties properties;
  private final Environment environment;

  public CorsConfig(AppProperties properties, Environment environment) {
    this.properties = properties;
    this.environment = environment;
  }

  @Bean
  public CorsConfigurationSource corsConfigurationSource() {
    CorsConfiguration configuration = new CorsConfiguration();
    List<String> allowed = Arrays.stream(properties.corsAllowedOrigins().split(",")).map(String::trim).filter(s -> !s.isBlank()).toList();
    configuration.setAllowedOriginPatterns(allowed);
    configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
    configuration.setAllowedHeaders(List.of("*"));
    configuration.setAllowCredentials(true);
    UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
    source.registerCorsConfiguration("/**", configuration);
    return source;
  }

  @Override
  public void afterPropertiesSet() {
    boolean dev = Arrays.asList(environment.getActiveProfiles()).contains("dev");
    if (!dev && (properties.corsAllowedOrigins() == null || properties.corsAllowedOrigins().isBlank())) {
      throw new IllegalStateException("CORS_ALLOWED_ORIGINS must not be empty outside dev profile");
    }
  }
}
