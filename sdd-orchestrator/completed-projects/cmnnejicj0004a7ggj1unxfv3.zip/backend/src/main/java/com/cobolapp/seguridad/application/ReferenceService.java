package com.cobolapp.seguridad.application;

import com.cobolapp.shared.exception.BusinessException;
import com.cobolapp.seguridad.infrastructure.entity.CentroEntity;
import com.cobolapp.seguridad.infrastructure.entity.EmpresaEntity;
import com.cobolapp.seguridad.infrastructure.repository.GrupoRecursoRepository;
import com.cobolapp.seguridad.infrastructure.entity.ParametroGrupoEntity;
import com.cobolapp.seguridad.infrastructure.repository.CentroRepository;
import com.cobolapp.seguridad.infrastructure.repository.EmpresaRepository;
import com.cobolapp.seguridad.infrastructure.repository.ParametroGrupoRepository;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class ReferenceService {
  private final ParametroGrupoRepository parametroGrupoRepository;
  private final GrupoRecursoRepository grupoRecursoRepository;
  private final EmpresaRepository empresaRepository;
  private final CentroRepository centroRepository;

  public ReferenceService(ParametroGrupoRepository parametroGrupoRepository, GrupoRecursoRepository grupoRecursoRepository, EmpresaRepository empresaRepository, CentroRepository centroRepository) {
    this.parametroGrupoRepository = parametroGrupoRepository;
    this.grupoRecursoRepository = grupoRecursoRepository;
    this.empresaRepository = empresaRepository;
    this.centroRepository = centroRepository;
  }

  public ReferenceResponse profile(String code) {
    ParametroGrupoEntity entity = parametroGrupoRepository.findByCodGrupoUsuarioAndCodParametro("GR", code)
        .orElseThrow(() -> new BusinessException("PERFIL_PARAM_NO_DEFINIDO", "Perfil no definido"));
    return new ReferenceResponse(code, entity.getDescripcion());
  }

  public ReferenceResponse company(String code) {
    EmpresaEntity entity = empresaRepository.findByCodEmpresa(code)
        .orElseThrow(() -> new BusinessException("EMPRESA_NO_DEFINIDA", "Empresa no definida"));
    return new ReferenceResponse(code, entity.getNombre());
  }

  public CenterReferenceResponse center(String empresa, String centro) {
    CentroEntity entity = centroRepository.findFirstByCodEmpresaAndCodCentro(empresa, centro)
        .orElseThrow(() -> new BusinessException("CENTRO_NO_DEFINIDO", "Centro no definido"));
    return new CenterReferenceResponse(empresa, centro, entity.getNombre());
  }

  public void validateProfileExists(String profile) {
    if (!parametroGrupoRepository.existsByCodGrupoUsuarioAndCodParametro("GR", profile)) {
      throw new BusinessException("PERFIL_PARAM_NO_DEFINIDO", "Perfil no definido en parámetros");
    }
  }

  public void validateCompanyExists(String empresa) {
    if (!empresaRepository.existsById(empresa)) {
      throw new BusinessException("EMPRESA_NO_DEFINIDA", "Empresa no definida");
    }
  }

  public void validateCenterExists(String empresa, String centro) {
    if (!centroRepository.existsByCodEmpresaAndCodCentro(empresa, centro)) {
      throw new BusinessException("CENTRO_NO_DEFINIDO", "Centro no definido");
    }
  }

  public void validateResourceExists(String profile) {
    if (!grupoRecursoRepository.existsByCodGrupoUsuarioAndCodRecurso(profile, "USUARIO")) {
      throw new BusinessException("PERFIL_RECURSO_NO_DEFINIDO", "Perfil no definido en recursos");
    }
  }

  public void validateResourceAccess(String profile) {
    validateResourceExists(profile);
  }

  public record ReferenceResponse(String codigo, String descripcion) {}
  public record CenterReferenceResponse(String empresa, String centro, String descripcion) {}
}
