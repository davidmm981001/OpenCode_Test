package com.cobolapp.seguridad.infrastructure.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t95ban04_usuarios_bancs")
public class BancsEntity {
  @Id
  @Column(name = "usr_siglo21_id", length = 8)
  private String usrSiglo21Id;
  @Column(name = "usr_bancs", nullable = false, unique = true, length = 8)
  private String usrBancs;
  @Column(name = "usr_nombre", nullable = false, length = 60)
  private String usrNombre;
  @Column(name = "branch_no", nullable = false, length = 4)
  private String branchNo = "";
  @Column(name = "term_no", nullable = false)
  private Integer termNo;
  @Column(name = "cod_empresa", nullable = false, length = 4)
  private String codEmpresa;
  @Column(name = "est_proceso", nullable = false, length = 2)
  private String estProceso = "TC";
  @Column(name = "observacion", nullable = false, length = 80)
  private String observacion = "";
  @Column(name = "fec_ult_cambio", nullable = false)
  private LocalDateTime fecUltCambio;
  @Column(name = "usr_ult_cambio", nullable = false, length = 8)
  private String usrUltCambio;
}
