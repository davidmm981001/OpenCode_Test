package com.cobolapp.seguridad.infrastructure.repository;

import com.cobolapp.seguridad.infrastructure.entity.BancsEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BancsRepository extends JpaRepository<BancsEntity, String> {
  Optional<BancsEntity> findByUsrBancs(String usrBancs);
}
