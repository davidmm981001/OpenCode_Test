package com.cobolapp.seguridad.infrastructure.repository;

import com.cobolapp.seguridad.infrastructure.entity.CentroEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CentroRepository extends JpaRepository<CentroEntity, Long> {
  Optional<CentroEntity> findFirstByCodEmpresaAndCodCentro(String codEmpresa, String codCentro);
  boolean existsByCodEmpresaAndCodCentro(String codEmpresa, String codCentro);
}
