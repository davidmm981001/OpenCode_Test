package com.cobolapp.seguridad.infrastructure.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t06tc007_centros")
public class CentroEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @Column(name = "cod_empresa", nullable = false, length = 4)
  private String codEmpresa;
  @Column(name = "cod_centro", nullable = false, length = 4)
  private String codCentro;
  @Column(name = "nombre", nullable = false, length = 40)
  private String nombre;
  @Column(name = "cod_tipo_via", nullable = false, length = 3)
  private String codTipoVia;
  @Column(name = "nom_via", nullable = false, length = 40)
  private String nomVia;
  @Column(name = "num_via", nullable = false, length = 10)
  private String numVia;
  @Column(name = "codigo_postal", nullable = false)
  private Integer codigoPostal;
  @Column(name = "cod_pueblo", nullable = false, length = 4)
  private String codPueblo;
  @Column(name = "cod_municipio", nullable = false, length = 3)
  private String codMunicipio;
  @Column(name = "cod_provincia", nullable = false, length = 2)
  private String codProvincia;
  @Column(name = "cod_pais", nullable = false, length = 4)
  private String codPais;
  @Column(name = "prefijo_tf", nullable = false)
  private Integer prefijoTf;
  @Column(name = "num_telefono", nullable = false)
  private Long numTelefono;
  @Column(name = "num_fax", nullable = false)
  private Long numFax;
  @Column(name = "dec_juzga_tribuna", nullable = false, length = 20)
  private String decJuzgaTribuna;
  @Column(name = "ind_actividad", nullable = false, length = 1)
  private String indActividad;
  @Column(name = "fec_inic_validez", nullable = false)
  private LocalDate fecInicValidez;
  @Column(name = "fec_finalvalidez", nullable = false)
  private LocalDate fecFinalvalidez;
  @Column(name = "timestamp_siglo", nullable = false)
  private LocalDateTime timestampSiglo;
  @Column(name = "cod_usu_modif", nullable = false, length = 8)
  private String codUsuModif;
}
