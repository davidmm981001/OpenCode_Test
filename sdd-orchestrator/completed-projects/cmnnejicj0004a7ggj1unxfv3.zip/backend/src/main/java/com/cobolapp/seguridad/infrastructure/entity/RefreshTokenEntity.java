package com.cobolapp.seguridad.infrastructure.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "auth_refresh_tokens")
public class RefreshTokenEntity {
  @Id
  @Column(name = "id", nullable = false)
  private UUID id;
  @Column(name = "username", nullable = false, length = 100)
  private String username;
  @Column(name = "token_hash", nullable = false, unique = true, length = 255)
  private String tokenHash;
  @Column(name = "expires_at", nullable = false)
  private Instant expiresAt;
  @Column(name = "revoked", nullable = false)
  private boolean revoked;
  @Column(name = "created_at", nullable = false)
  private Instant createdAt;
}
