package com.cobolapp.seguridad.infrastructure.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t95log01_auditoria")
public class AuditEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @Column(name = "num_puesto", length = 8)
  private String numPuesto;
  @Column(name = "transaccion", nullable = false, length = 10)
  private String transaccion;
  @Column(name = "operacion", nullable = false, length = 12)
  private String operacion;
  @Column(name = "fecha_ingreso", nullable = false)
  private LocalDateTime fechaIngreso;
  @Column(name = "terminal", length = 10)
  private String terminal;
  @Column(name = "cod_usuario_mod", length = 20)
  private String codUsuarioMod;
  @Column(name = "mensajeria", length = 100)
  private String mensajeria;
  @Column(name = "cmp_observacion", length = 100)
  private String cmpObservacion;
}
