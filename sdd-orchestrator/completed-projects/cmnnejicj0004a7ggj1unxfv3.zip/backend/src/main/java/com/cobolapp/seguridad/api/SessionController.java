package com.cobolapp.seguridad.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/auth")
@Tag(name = "Session")
public class SessionController {

  @GetMapping("/me")
  @Operation(summary = "Current session")
  public ResponseEntity<MeResponse> me(Authentication authentication) {
    return ResponseEntity.ok(new MeResponse(authentication.getName(), authentication.getAuthorities().stream().map(a -> a.getAuthority()).toList()));
  }

  public record MeResponse(String username, List<String> roles) {}
}
