package com.cobolapp.administracionusuarios.api;

import com.cobolapp.seguridad.application.UserAdministrationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/usuarios")
@Tag(name = "Administración de usuarios")
public class UsuarioController {
  private final UserAdministrationService service;

  public UsuarioController(UserAdministrationService service) {
    this.service = service;
  }

  @GetMapping("/{usuarioId}")
  @Operation(summary = "Detalle de usuario")
  public ResponseEntity<UserAdministrationService.UserDetailResponse> get(@PathVariable String usuarioId) {
    return ResponseEntity.ok(service.detail(usuarioId));
  }

  @PostMapping
  @PreAuthorize("hasRole('ADMIN')")
  @Operation(summary = "Crear usuario")
  public ResponseEntity<UserAdministrationService.UserDetailResponse> create(@Valid @RequestBody UserCommandRequest request) {
    return ResponseEntity.ok(service.create(request.toCommand(), "system"));
  }

  @PutMapping("/{usuarioId}")
  @PreAuthorize("hasRole('ADMIN')")
  @Operation(summary = "Actualizar usuario")
  public ResponseEntity<UserAdministrationService.UserDetailResponse> update(@PathVariable String usuarioId, @Valid @RequestBody UserCommandRequest request) {
    return ResponseEntity.ok(service.update(usuarioId, request.toCommand().withUsuarioId(usuarioId), "system"));
  }

  @DeleteMapping("/{usuarioId}")
  @PreAuthorize("hasRole('ADMIN')")
  @Operation(summary = "Eliminar usuario")
  public ResponseEntity<UserAdministrationService.UserDeleteResponse> delete(@PathVariable String usuarioId, @Valid @RequestBody UserDeleteRequest request) {
    return ResponseEntity.ok(service.delete(usuarioId, new UserAdministrationService.UserDeleteCommand(request.observaciones(), request.usuarioBancs()), "system"));
  }

  public record UserCommandRequest(
      @NotBlank @Size(max = 8) String usuarioId,
      @NotBlank @Size(max = 60) String nombre,
      @Size(max = 10) String cid,
      @NotBlank @Size(max = 4) String empresa,
      @NotBlank @Size(max = 4) String centro,
      @Size(max = 18) String cargo,
      @NotBlank @Size(max = 8) String perfil,
      boolean autorizador,
      @Size(max = 12) String swift,
      @NotBlank @Size(max = 100) String observaciones,
      @Size(max = 8) String usuarioBancs,
      Integer terminalBancs,
      @Size(max = 4) String dominio,
      @Size(max = 4) String nodo) {
    UserAdministrationService.UserCommand toCommand() {
      return new UserAdministrationService.UserCommand(usuarioId, nombre, cid, empresa, centro, cargo, perfil, autorizador, swift, observaciones, usuarioBancs, terminalBancs, dominio, nodo);
    }
  }

  public record UserDeleteRequest(@NotBlank @Size(max = 100) String observaciones, @Size(max = 8) String usuarioBancs) {}
}
