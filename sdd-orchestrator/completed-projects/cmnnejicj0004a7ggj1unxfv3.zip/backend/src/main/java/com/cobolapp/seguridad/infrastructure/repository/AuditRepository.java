package com.cobolapp.seguridad.infrastructure.repository;

import com.cobolapp.seguridad.infrastructure.entity.AuditEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditRepository extends JpaRepository<AuditEntity, Long> {}
