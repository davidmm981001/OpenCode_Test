package com.cobolapp.shared.security;

import com.cobolapp.seguridad.infrastructure.entity.RefreshTokenEntity;
import com.cobolapp.seguridad.infrastructure.repository.RefreshTokenRepository;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.Base64;
import java.util.Optional;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RefreshTokenService {
  private final RefreshTokenRepository refreshTokenRepository;
  private final com.cobolapp.shared.config.AppProperties properties;

  public RefreshTokenService(RefreshTokenRepository refreshTokenRepository, com.cobolapp.shared.config.AppProperties properties) {
    this.refreshTokenRepository = refreshTokenRepository;
    this.properties = properties;
  }

  @Transactional
  public TokenPair issue(String username) {
    String token = UUID.randomUUID() + "." + UUID.randomUUID();
    RefreshTokenEntity entity = new RefreshTokenEntity();
    entity.setId(UUID.randomUUID());
    entity.setUsername(username);
    entity.setTokenHash(hash(token));
    entity.setRevoked(false);
    entity.setCreatedAt(Instant.now());
    entity.setExpiresAt(Instant.now().plusMillis(properties.refreshExpirationMs()));
    refreshTokenRepository.save(entity);
    return new TokenPair(token, entity);
  }

  @Transactional(readOnly = true)
  public RefreshTokenEntity validate(String refreshToken) {
    String hash = hash(refreshToken);
    RefreshTokenEntity entity = refreshTokenRepository.findByTokenHash(hash)
        .orElseThrow(() -> new IllegalArgumentException("TOKEN_INVALID"));
    if (entity.isRevoked() || entity.getExpiresAt().isBefore(Instant.now())) {
      throw new IllegalStateException("TOKEN_EXPIRED");
    }
    return entity;
  }

  @Transactional
  public void revoke(String refreshToken) {
    refreshTokenRepository.findByTokenHash(hash(refreshToken)).ifPresent(entity -> {
      entity.setRevoked(true);
      refreshTokenRepository.save(entity);
    });
  }

  private String hash(String token) {
    try {
      MessageDigest digest = MessageDigest.getInstance("SHA-256");
      return Base64.getEncoder().encodeToString(digest.digest(token.getBytes(StandardCharsets.UTF_8)));
    } catch (Exception e) {
      throw new IllegalStateException("HASH_ERROR", e);
    }
  }

  public record TokenPair(String plainToken, RefreshTokenEntity entity) {}
}
