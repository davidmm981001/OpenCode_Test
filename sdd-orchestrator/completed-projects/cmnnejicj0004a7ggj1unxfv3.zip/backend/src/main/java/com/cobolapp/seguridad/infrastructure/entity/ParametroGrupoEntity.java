package com.cobolapp.seguridad.infrastructure.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t95par02_parametros_grupo")
public class ParametroGrupoEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @Column(name = "cod_grupo_usuario", nullable = false, length = 12)
  private String codGrupoUsuario;
  @Column(name = "cod_parametro", nullable = false, length = 4)
  private String codParametro;
  @Column(name = "descripcion", nullable = false, length = 100)
  private String descripcion;
}
