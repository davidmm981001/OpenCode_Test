package com.cobolapp.seguridad.infrastructure.repository;

import com.cobolapp.seguridad.infrastructure.entity.ObservationEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ObservationRepository extends JpaRepository<ObservationEntity, Long> {
  Optional<ObservationEntity> findByCodUsuario(String codUsuario);
  void deleteByCodUsuario(String codUsuario);
}
