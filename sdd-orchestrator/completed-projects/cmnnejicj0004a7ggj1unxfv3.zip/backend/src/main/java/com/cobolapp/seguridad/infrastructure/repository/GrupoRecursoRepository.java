package com.cobolapp.seguridad.infrastructure.repository;

import com.cobolapp.seguridad.infrastructure.entity.GrupoRecursoEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GrupoRecursoRepository extends JpaRepository<GrupoRecursoEntity, Long> {
  Optional<GrupoRecursoEntity> findFirstByCodGrupoUsuarioAndCodRecurso(String codGrupoUsuario, String codRecurso);
  boolean existsByCodGrupoUsuarioAndCodRecurso(String codGrupoUsuario, String codRecurso);
}
