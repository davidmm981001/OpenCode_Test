package com.cobolapp.seguridad.infrastructure.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t95obs04_observaciones_usuario")
public class ObservationEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "obs_id")
  private Long id;
  @Column(name = "cod_usuario", nullable = false, unique = true, length = 8)
  private String codUsuario;
  @Column(name = "cod_usuario_mod", nullable = false, length = 8)
  private String codUsuarioMod;
  @Column(name = "fec_ult_obs", nullable = false)
  private LocalDateTime fecUltObs;
  @Column(name = "cmp_observacion", nullable = false, length = 100)
  private String cmpObservacion;
}
