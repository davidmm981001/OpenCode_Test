package com.cobolapp.shared.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.stereotype.Component;

@Component
public class JwtUtil {
  private final Key key;

  public JwtUtil(com.cobolapp.shared.config.AppProperties properties) {
    String secret = properties.jwtSecret();
    byte[] bytes = secret.length() >= 32 ? secret.getBytes(StandardCharsets.UTF_8) : Decoders.BASE64.decode(padBase64(secret));
    this.key = Keys.hmacShaKeyFor(bytes);
  }

  private String padBase64(String value) {
    return value + "=".repeat(Math.max(0, 32 - value.length()));
  }

  public String generateAccessToken(String username, List<String> roles, long expiresInMs) {
    Instant now = Instant.now();
    return Jwts.builder()
        .subject(username)
        .claims(Map.of("roles", roles, "jti", UUID.randomUUID().toString()))
        .issuedAt(Date.from(now))
        .expiration(Date.from(now.plusMillis(expiresInMs)))
        .signWith(key)
        .compact();
  }

  public Claims parseClaims(String token) {
    return Jwts.parser().verifyWith((javax.crypto.SecretKey) key).build().parseSignedClaims(token).getPayload();
  }

  public boolean isTokenValid(String token) {
    try {
      parseClaims(token);
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  public String subject(String token) {
    return parseClaims(token).getSubject();
  }
}
