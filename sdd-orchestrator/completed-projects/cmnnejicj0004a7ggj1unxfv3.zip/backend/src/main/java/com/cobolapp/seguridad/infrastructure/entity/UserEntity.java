package com.cobolapp.seguridad.infrastructure.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalTime;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t95usu03_usuarios")
public class UserEntity extends BaseTimestampEntity {
  @Id
  @Column(name = "usr_siglo21_id", length = 8)
  private String usrSiglo21Id;
  @Column(name = "usr_nombre", nullable = false, length = 60)
  private String usrNombre;
  @Column(name = "usr_status", nullable = false, length = 1)
  private String usrStatus = "N";
  @Column(name = "usr_cid", nullable = false, length = 10)
  private String usrCid = "";
  @Column(name = "usr_offset", nullable = false, length = 8)
  private String usrOffset = "";
  @Column(name = "usr_cargo", nullable = false, length = 18)
  private String usrCargo = "";
  @Column(name = "usr_empresa", nullable = false, length = 4)
  private String usrEmpresa;
  @Column(name = "usr_centro", nullable = false, length = 4)
  private String usrCentro;
  @Column(name = "usr_pers", nullable = false, length = 8)
  private String usrPers;
  @Column(name = "usr_dominio", nullable = false, length = 4)
  private String usrDominio = "";
  @Column(name = "usr_nodo", nullable = false, length = 4)
  private String usrNodo = "";
  @Column(name = "usr_autoriza", nullable = false)
  private boolean usrAutoriza;
  @Column(name = "usr_updfch")
  private LocalDate usrUpdfch;
  @Column(name = "usr_uptime")
  private LocalTime usrUptime;
  @Column(name = "usr_updusr", length = 8)
  private String usrUpdusr;
  @Column(name = "usr_updterm", length = 15)
  private String usrUpdterm;
  @Column(name = "usr_fchlogon")
  private LocalDate usrFchlogon;
  @Column(name = "usr_timelogon")
  private LocalTime usrTimelogon;
  @Column(name = "usr_logonsiglo", length = 15)
  private String usrLogonsiglo;
  @Column(name = "usr_ofcswift", length = 12)
  private String usrOfcswift;
}
