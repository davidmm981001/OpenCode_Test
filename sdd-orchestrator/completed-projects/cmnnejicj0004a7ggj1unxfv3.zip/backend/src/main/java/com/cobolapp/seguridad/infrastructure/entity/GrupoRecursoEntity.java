package com.cobolapp.seguridad.infrastructure.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t01gre20_grupo_recurso")
public class GrupoRecursoEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @Column(name = "cod_grupo_usuario", nullable = false, length = 8)
  private String codGrupoUsuario;
  @Column(name = "cod_recurso", nullable = false, length = 12)
  private String codRecurso;
  @Column(name = "cod_acceso", nullable = false)
  private BigDecimal codAcceso;
  @Column(name = "cod_usuario_mod", nullable = false, length = 8)
  private String codUsuarioMod;
  @Column(name = "tim_modificacion", nullable = false)
  private LocalDateTime timModificacion;
}
