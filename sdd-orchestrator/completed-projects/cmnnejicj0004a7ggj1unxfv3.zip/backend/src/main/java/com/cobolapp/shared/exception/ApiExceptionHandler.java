package com.cobolapp.shared.exception;

import jakarta.persistence.EntityNotFoundException;
import jakarta.servlet.http.HttpServletRequest;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Objects;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ApiExceptionHandler {

  @ExceptionHandler(MethodArgumentNotValidException.class)
  public ResponseEntity<ErrorResponse> handleValidation(MethodArgumentNotValidException ex, HttpServletRequest request) {
    List<String> details = ex.getBindingResult().getFieldErrors().stream()
        .map(this::formatFieldError)
        .toList();
    return build(HttpStatus.BAD_REQUEST, "VALIDATION_ERROR", "Error de validación", details, request);
  }

  @ExceptionHandler(BusinessException.class)
  public ResponseEntity<ErrorResponse> handleBusiness(BusinessException ex, HttpServletRequest request) {
    HttpStatus status = switch (ex.getCode()) {
      case "AUTH_INVALID", "TOKEN_EXPIRED", "AUTH_REQUIRED" -> HttpStatus.UNAUTHORIZED;
      case "ACCESS_DENIED" -> HttpStatus.FORBIDDEN;
      case "NOT_FOUND", "USUARIO_NOT_FOUND" -> HttpStatus.NOT_FOUND;
      case "DATA_INTEGRITY", "USUARIO_CONSULTA_SIN_CRITERIO" -> HttpStatus.BAD_REQUEST;
      case "SWIFT_INVALIDO", "VALIDATION_ERROR" -> HttpStatus.BAD_REQUEST;
      case "PERFIL_PARAM_NO_DEFINIDO", "PERFIL_RECURSO_NO_DEFINIDO", "EMPRESA_NO_DEFINIDA", "CENTRO_NO_DEFINIDO", "USUARIO_BANCS_DUPLICADO" -> HttpStatus.CONFLICT;
      default -> HttpStatus.BAD_REQUEST;
    };
    return build(status, ex.getCode(), ex.getMessage(), List.of(), request);
  }

  @ExceptionHandler(BadCredentialsException.class)
  public ResponseEntity<ErrorResponse> handleBadCredentials(BadCredentialsException ex, HttpServletRequest request) {
    return build(HttpStatus.UNAUTHORIZED, "AUTH_INVALID", "Credenciales inválidas", List.of(), request);
  }

  @ExceptionHandler({EntityNotFoundException.class, java.util.NoSuchElementException.class})
  public ResponseEntity<ErrorResponse> handleNotFound(RuntimeException ex, HttpServletRequest request) {
    return build(HttpStatus.NOT_FOUND, "NOT_FOUND", ex.getMessage(), List.of(), request);
  }

  @ExceptionHandler(AccessDeniedException.class)
  public ResponseEntity<ErrorResponse> handleAccessDenied(AccessDeniedException ex, HttpServletRequest request) {
    return build(HttpStatus.FORBIDDEN, "ACCESS_DENIED", "Acceso denegado", List.of(), request);
  }

  @ExceptionHandler(DataIntegrityViolationException.class)
  public ResponseEntity<ErrorResponse> handleIntegrity(DataIntegrityViolationException ex, HttpServletRequest request) {
    return build(HttpStatus.CONFLICT, "DATA_INTEGRITY", "Violación de integridad", List.of(), request);
  }

  @ExceptionHandler(IllegalArgumentException.class)
  public ResponseEntity<ErrorResponse> handleIllegalArgument(IllegalArgumentException ex, HttpServletRequest request) {
    String code = Objects.requireNonNullElse(ex.getMessage(), "VALIDATION_ERROR");
    HttpStatus status = "TOKEN_EXPIRED".equals(code) ? HttpStatus.UNAUTHORIZED : HttpStatus.BAD_REQUEST;
    return build(status, code, ex.getMessage(), List.of(), request);
  }

  @ExceptionHandler(Exception.class)
  public ResponseEntity<ErrorResponse> handleGeneric(Exception ex, HttpServletRequest request) {
    return build(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL_ERROR", "Error interno", List.of(), request);
  }

  private String formatFieldError(FieldError error) {
    return error.getField() + ": " + error.getDefaultMessage();
  }

  private ResponseEntity<ErrorResponse> build(HttpStatus status, String code, String message, List<String> details, HttpServletRequest request) {
    return ResponseEntity.status(status).body(new ErrorResponse(OffsetDateTime.now(), status.value(), code, message, details, request.getRequestURI()));
  }
}
