package com.cobolapp.seguridad.application;

import com.cobolapp.shared.exception.BusinessException;
import com.cobolapp.seguridad.infrastructure.entity.AuditEntity;
import com.cobolapp.seguridad.infrastructure.entity.BancsEntity;
import com.cobolapp.seguridad.infrastructure.entity.ObservationEntity;
import com.cobolapp.seguridad.infrastructure.entity.UserEntity;
import com.cobolapp.seguridad.infrastructure.repository.AuditRepository;
import com.cobolapp.seguridad.infrastructure.repository.BancsRepository;
import com.cobolapp.seguridad.infrastructure.repository.ObservationRepository;
import com.cobolapp.seguridad.infrastructure.repository.UserRepository;
import java.time.LocalDateTime;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserAdministrationService {
  private final UserRepository userRepository;
  private final ObservationRepository observationRepository;
  private final BancsRepository bancsRepository;
  private final AuditRepository auditRepository;
  private final ReferenceService referenceService;

  public UserAdministrationService(UserRepository userRepository, ObservationRepository observationRepository, BancsRepository bancsRepository, AuditRepository auditRepository, ReferenceService referenceService) {
    this.userRepository = userRepository;
    this.observationRepository = observationRepository;
    this.bancsRepository = bancsRepository;
    this.auditRepository = auditRepository;
    this.referenceService = referenceService;
  }

  @Transactional(readOnly = true)
  public UserDetailResponse detail(String usuarioId) {
    UserEntity user = userRepository.findById(usuarioId).orElseThrow(() -> new BusinessException("USUARIO_NOT_FOUND", "Usuario no encontrado"));
    var empresa = referenceService.company(user.getUsrEmpresa());
    var centro = referenceService.center(user.getUsrEmpresa(), user.getUsrCentro());
    var perfil = referenceService.profile(user.getUsrPers());
    Optional<ObservationEntity> observation = observationRepository.findByCodUsuario(usuarioId);
    Optional<BancsEntity> bancs = bancsRepository.findById(usuarioId);
    return UserDetailResponse.from(user, empresa.descripcion(), centro.descripcion(), perfil.descripcion(), observation.map(ObservationEntity::getCmpObservacion).orElse(null), bancs.map(UserDetailResponse.Bancs::from).orElse(null));
  }

  @Transactional
  public UserDetailResponse create(UserCommand command, String updatedBy) {
    if (userRepository.existsById(command.usuarioId())) throw new BusinessException("USUARIO_BANCS_DUPLICADO", "Usuario ya existe");
    validateCommand(command, true);
    UserEntity user = mapToUser(command);
    userRepository.save(user);
    saveObservation(command, updatedBy);
    saveOrUpdateBancs(command, updatedBy, user.getUsrEmpresa(), false);
    saveAudit(command.usuarioId(), "ALTA", updatedBy, command.observaciones());
    return detail(command.usuarioId());
  }

  @Transactional
  public UserDetailResponse update(String usuarioId, UserCommand command, String updatedBy) {
    UserEntity user = userRepository.findById(usuarioId).orElseThrow(() -> new BusinessException("USUARIO_NOT_FOUND", "Usuario no encontrado"));
    validateCommand(command.withUsuarioId(usuarioId), false);
    user.setUsrNombre(command.nombre());
    user.setUsrCid(defaultString(command.cid()));
    user.setUsrEmpresa(command.empresa());
    user.setUsrCentro(command.centro());
    user.setUsrPers(command.perfil());
    user.setUsrAutoriza(command.autorizador());
    user.setUsrDominio(defaultString(command.dominio()));
    user.setUsrNodo(defaultString(command.nodo()));
    user.setUsrOfcswift(command.swift());
    user.setUsrStatus("N");
    userRepository.save(user);
    saveObservation(command, updatedBy);
    saveOrUpdateBancs(command, updatedBy, command.empresa(), true);
    saveAudit(usuarioId, "MODIFICACION", updatedBy, command.observaciones());
    return detail(usuarioId);
  }

  @Transactional
  public UserDeleteResponse delete(String usuarioId, UserDeleteCommand command, String updatedBy) {
    UserEntity user = userRepository.findById(usuarioId).orElseThrow(() -> new BusinessException("USUARIO_NOT_FOUND", "Usuario no encontrado"));
    user.setUsrStatus("I");
    userRepository.save(user);
    observationRepository.deleteByCodUsuario(usuarioId);
    bancsRepository.findById(usuarioId).ifPresent(b -> { b.setEstProceso("TE"); b.setFecUltCambio(LocalDateTime.now()); b.setUsrUltCambio(updatedBy); bancsRepository.save(b); });
    saveAudit(usuarioId, "BAJA", updatedBy, command.observaciones());
    return new UserDeleteResponse(usuarioId, user.getUsrStatus(), bancsRepository.findById(usuarioId).map(BancsEntity::getEstProceso).orElse(null), "Usuario dado de baja");
  }

  private void validateCommand(UserCommand command, boolean creation) {
    if (command.usuarioId() == null || command.usuarioId().isBlank()) throw new BusinessException("VALIDATION_ERROR", "Usuario obligatorio");
    if (command.nombre() == null || command.nombre().isBlank()) throw new BusinessException("VALIDATION_ERROR", "Nombre obligatorio");
    if (command.observaciones() == null || command.observaciones().isBlank()) throw new BusinessException("VALIDATION_ERROR", "Observaciones obligatorias");
    if (command.swift() != null && !command.swift().isBlank() && !"MSQUTODO".equals(command.swift())) throw new BusinessException("SWIFT_INVALIDO", "Swift inválido");
    if ((command.usuarioBancs() == null) != (command.terminalBancs() == null)) throw new BusinessException("VALIDATION_ERROR", command.usuarioBancs() == null ? "Ingrese Usuario BANCS" : "Ingrese Terminal BANCS");
    referenceService.validateProfileExists(command.perfil());
    referenceService.validateResourceAccess(command.perfil());
    referenceService.validateCompanyExists(command.empresa());
    referenceService.validateCenterExists(command.empresa(), command.centro());
  }

  private UserEntity mapToUser(UserCommand command) {
    UserEntity user = new UserEntity();
    user.setUsrSiglo21Id(command.usuarioId());
    user.setUsrNombre(command.nombre());
    user.setUsrCid(defaultString(command.cid()));
    user.setUsrEmpresa(command.empresa());
    user.setUsrCentro(command.centro());
    user.setUsrPers(command.perfil());
    user.setUsrAutoriza(command.autorizador());
    user.setUsrDominio(defaultString(command.dominio()));
    user.setUsrNodo(defaultString(command.nodo()));
    user.setUsrOfcswift(command.swift());
    user.setUsrStatus("N");
    return user;
  }

  private void saveObservation(UserCommand command, String updatedBy) {
    ObservationEntity observation = observationRepository.findByCodUsuario(command.usuarioId()).orElseGet(ObservationEntity::new);
    observation.setCodUsuario(command.usuarioId());
    observation.setCodUsuarioMod(updatedBy);
    observation.setFecUltObs(LocalDateTime.now());
    observation.setCmpObservacion(command.observaciones());
    observationRepository.save(observation);
  }

  private void saveOrUpdateBancs(UserCommand command, String updatedBy, String empresa, boolean preserveExisting) {
    if (command.usuarioBancs() == null || command.terminalBancs() == null) {
      if (!preserveExisting) return;
      if (bancsRepository.findById(command.usuarioId()).isPresent()) return;
      return;
    }
    BancsEntity entity = bancsRepository.findById(command.usuarioId()).orElseGet(BancsEntity::new);
    entity.setUsrSiglo21Id(command.usuarioId());
    entity.setUsrBancs(command.usuarioBancs());
    entity.setUsrNombre(command.nombre());
    entity.setBranchNo(defaultString(command.dominio()));
    entity.setTermNo(command.terminalBancs());
    entity.setCodEmpresa(empresa);
    entity.setEstProceso("TC");
    entity.setObservacion(command.observaciones());
    entity.setFecUltCambio(LocalDateTime.now());
    entity.setUsrUltCambio(updatedBy);
    bancsRepository.save(entity);
  }

  private void saveAudit(String usuario, String operacion, String updatedBy, String observacion) {
    AuditEntity audit = new AuditEntity();
    audit.setNumPuesto(usuario);
    audit.setTransaccion("T95USU03");
    audit.setOperacion(operacion);
    audit.setFechaIngreso(LocalDateTime.now());
    audit.setCodUsuarioMod(updatedBy);
    audit.setMensajeria(operacion);
    audit.setCmpObservacion(observacion);
    auditRepository.save(audit);
  }

  private String defaultString(String value) { return value == null ? "" : value; }

  public record UserCommand(String usuarioId, String nombre, String cid, String empresa, String centro, String cargo, String perfil, boolean autorizador, String swift, String observaciones, String usuarioBancs, Integer terminalBancs, String dominio, String nodo) {
    public UserCommand withUsuarioId(String usuarioId) { return new UserCommand(usuarioId, nombre, cid, empresa, centro, cargo, perfil, autorizador, swift, observaciones, usuarioBancs, terminalBancs, dominio, nodo); }
  }

  public record UserDetailResponse(String usuarioId, String nombre, String cid, String empresa, String empresaDescripcion, String centro, String centroDescripcion, String cargo, String perfil, String perfilDescripcion, String dominio, String nodo, boolean autorizador, String swift, String observaciones, String fechaActualizacion, String horaActualizacion, String usuarioActualizacion, String terminalActualizacion, String fechaUltimoLogon, String horaUltimoLogon, String logonSiglo, Bancs bancs, String status) {
    static UserDetailResponse from(UserEntity u, String empresaDesc, String centroDesc, String perfilDesc, String obs, Bancs bancs) {
      return new UserDetailResponse(u.getUsrSiglo21Id(), u.getUsrNombre(), u.getUsrCid(), u.getUsrEmpresa(), empresaDesc, u.getUsrCentro(), centroDesc, u.getUsrCargo(), u.getUsrPers(), perfilDesc, u.getUsrDominio(), u.getUsrNodo(), u.isUsrAutoriza(), u.getUsrOfcswift(), obs, null, null, null, null, null, null, null, bancs, u.getUsrStatus());
    }
    public record Bancs(String usuarioBancs, Integer terminalBancs, String estadoProceso) {
      static Bancs from(BancsEntity e) { return new Bancs(e.getUsrBancs(), e.getTermNo(), e.getEstProceso()); }
    }
  }

  public record UserDeleteCommand(String observaciones, String usuarioBancs) {}
  public record UserDeleteResponse(String usuarioId, String status, String bancsEstado, String message) {}
}
