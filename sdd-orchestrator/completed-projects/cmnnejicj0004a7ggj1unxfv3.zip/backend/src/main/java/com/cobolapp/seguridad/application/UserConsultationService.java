package com.cobolapp.seguridad.application;

import com.cobolapp.shared.exception.BusinessException;
import com.cobolapp.seguridad.infrastructure.entity.UserEntity;
import com.cobolapp.seguridad.infrastructure.repository.UserRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserConsultationService {
  private final UserRepository userRepository;

  public UserConsultationService(UserRepository userRepository) {
    this.userRepository = userRepository;
  }

  @Transactional(readOnly = true)
  public UserPageResponse search(String empresa, String centro, String usuario, String perfil, String nombre, int page, int size, String sort) {
    String criterio = appliedCriterion(empresa, centro, usuario, perfil, nombre);
    Pageable pageable = PageRequest.of(page, Math.min(Math.max(size, 1), 100), parseSort(sort));
    Page<UserEntity> result = userRepository.findAll(byCriterion(criterio, empresa, centro, usuario, perfil, nombre), pageable);
    List<UserSummary> content = result.stream().map(UserConsultationService::mapSummary).toList();
    return new UserPageResponse(content, result.getTotalElements(), result.getTotalPages(), result.getSize(), result.getNumber(), result.isFirst(), result.isLast(), criterio);
  }

  private static Sort parseSort(String sort) {
    if (sort == null || sort.isBlank()) return Sort.by(Sort.Direction.ASC, "usrSiglo21Id");
    String[] parts = sort.split(",");
    return Sort.by(parts.length > 1 && "desc".equalsIgnoreCase(parts[1]) ? Sort.Direction.DESC : Sort.Direction.ASC, parts[0]);
  }

  private static Specification<UserEntity> byCriterion(String criterio, String empresa, String centro, String usuario, String perfil, String nombre) {
    return (root, query, cb) -> {
      if (criterio == null) {
        throw new BusinessException("USUARIO_CONSULTA_SIN_CRITERIO", "Ingrese criterio de consulta");
      }
      return switch (criterio) {
        case "empresa" -> cb.equal(root.get("usrEmpresa"), normalize(empresa));
        case "centro" -> cb.equal(root.get("usrCentro"), normalize(centro));
        case "usuario" -> cb.like(cb.lower(root.get("usrSiglo21Id")), likeValue(usuario));
        case "perfil" -> cb.like(cb.lower(root.get("usrPers")), likeValue(perfil));
        default -> cb.like(cb.lower(root.get("usrNombre")), likeValue(nombre));
      };
    };
  }

  private static String appliedCriterion(String empresa, String centro, String usuario, String perfil, String nombre) {
    if (hasText(empresa)) return "empresa";
    if (hasText(centro)) return "centro";
    if (hasText(usuario)) return "usuario";
    if (hasText(perfil)) return "perfil";
    if (hasText(nombre)) return "nombre";
    throw new BusinessException("USUARIO_CONSULTA_SIN_CRITERIO", "Ingrese criterio de consulta");
  }

  private static boolean hasText(String value) { return value != null && !value.isBlank(); }
  private static String normalize(String value) { return value == null ? "" : value.trim(); }
  private static String likeValue(String value) { return "%" + normalize(value).toLowerCase(Locale.ROOT) + "%"; }

  private static UserSummary mapSummary(UserEntity entity) {
    return new UserSummary(entity.getUsrSiglo21Id(), entity.getUsrNombre(), entity.getUsrPers(), entity.getUsrEmpresa(), entity.getUsrCentro(), entity.getUsrDominio(), entity.getUsrNodo(), entity.isUsrAutoriza());
  }

  public record UserPageResponse(List<UserSummary> content, long totalElements, int totalPages, int size, int number, boolean first, boolean last, String criterioAplicado) {}
  public record UserSummary(String usuarioId, String nombre, String perfil, String empresa, String centro, String dominio, String nodo, boolean autorizador) {}
}
