package com.cobolapp.seguridad.api;

import com.cobolapp.seguridad.application.ReferenceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/referencias")
@Tag(name = "Referencias")
public class ReferenceController {
  private final ReferenceService referenceService;

  public ReferenceController(ReferenceService referenceService) {
    this.referenceService = referenceService;
  }

  @GetMapping("/perfiles/{codigo}")
  @Operation(summary = "Get profile reference")
  public ResponseEntity<ReferenceService.ReferenceResponse> profile(@PathVariable String codigo) {
    return ResponseEntity.ok(referenceService.profile(codigo));
  }

  @GetMapping("/empresas/{codigo}")
  @Operation(summary = "Get company reference")
  public ResponseEntity<ReferenceService.ReferenceResponse> company(@PathVariable String codigo) {
    return ResponseEntity.ok(referenceService.company(codigo));
  }

  @GetMapping("/empresas/{empresa}/centros/{centro}")
  @Operation(summary = "Get center reference")
  public ResponseEntity<ReferenceService.CenterReferenceResponse> center(@PathVariable String empresa, @PathVariable String centro) {
    return ResponseEntity.ok(referenceService.center(empresa, centro));
  }
}
