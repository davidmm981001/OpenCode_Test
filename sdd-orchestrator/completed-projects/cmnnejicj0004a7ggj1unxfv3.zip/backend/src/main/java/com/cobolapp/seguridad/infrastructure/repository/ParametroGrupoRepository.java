package com.cobolapp.seguridad.infrastructure.repository;

import com.cobolapp.seguridad.infrastructure.entity.ParametroGrupoEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParametroGrupoRepository extends JpaRepository<ParametroGrupoEntity, Long> {
  Optional<ParametroGrupoEntity> findByCodGrupoUsuarioAndCodParametro(String codGrupoUsuario, String codParametro);
  boolean existsByCodGrupoUsuarioAndCodParametro(String codGrupoUsuario, String codParametro);
}
