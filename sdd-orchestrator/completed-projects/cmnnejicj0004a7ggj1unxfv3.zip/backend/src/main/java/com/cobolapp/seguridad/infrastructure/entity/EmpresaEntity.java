package com.cobolapp.seguridad.infrastructure.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t06tc005_empresas")
public class EmpresaEntity {
  @Id
  @Column(name = "cod_empresa", length = 4)
  private String codEmpresa;
  @Column(name = "nombre", nullable = false, length = 40)
  private String nombre;
  @Column(name = "cod_num_doc_oficia", nullable = false, length = 14)
  private String codNumDocOficia;
  @Column(name = "timestamp_siglo", nullable = false)
  private LocalDateTime timestampSiglo;
  @Column(name = "cod_usu_modif", nullable = false, length = 8)
  private String codUsuModif;
}
