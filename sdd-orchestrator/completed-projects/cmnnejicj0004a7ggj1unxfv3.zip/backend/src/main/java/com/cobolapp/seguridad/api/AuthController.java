package com.cobolapp.seguridad.api;

import com.cobolapp.seguridad.application.AuthService;
import com.cobolapp.shared.security.JwtUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
@Tag(name = "Auth")
public class AuthController {
  private final AuthService authService;
  private final JwtUtil jwtUtil;

  public AuthController(AuthService authService, JwtUtil jwtUtil) {
    this.authService = authService;
    this.jwtUtil = jwtUtil;
  }

  @PostMapping("/login")
  @Operation(summary = "Login")
  @ApiResponse(responseCode = "200", description = "Login successful")
  public ResponseEntity<AuthService.AuthResponse> login(@Valid @RequestBody LoginRequest request) {
    return ResponseEntity.ok(authService.login(request.username(), request.password()));
  }

  @PostMapping("/refresh")
  @Operation(summary = "Refresh token")
  public ResponseEntity<AuthService.AuthResponse> refresh(@Valid @RequestBody RefreshRequest request) {
    return ResponseEntity.ok(authService.refresh(request.refreshToken()));
  }

  @PostMapping("/logout")
  @Operation(summary = "Logout")
  public ResponseEntity<AuthService.MessageResponse> logout(@Valid @RequestBody RefreshRequest request) {
    return ResponseEntity.ok(authService.logout(request.refreshToken()));
  }

  public record LoginRequest(@NotBlank String username, @NotBlank String password) {}
  public record RefreshRequest(@NotBlank String refreshToken) {}
}
