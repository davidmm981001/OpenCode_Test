insert into t06tc005_empresas (cod_empresa, nombre, cod_num_doc_oficia, timestamp_siglo, cod_usu_modif)
values ('0001', 'Empresa Demo', 'DOC00000000001', current_timestamp, 'system');

insert into t06tc007_centros (cod_empresa, cod_centro, nombre, cod_tipo_via, nom_via, num_via, codigo_postal, cod_pueblo, cod_municipio, cod_provincia, cod_pais, prefijo_tf, num_telefono, num_fax, dec_juzga_tribuna, ind_actividad, fec_inic_validez, fec_finalvalidez, timestamp_siglo, cod_usu_modif)
values ('0001', '0001', 'Centro Demo', 'CLL', 'Principal', '1', 28001, '0001', '001', '28', 'ES', 34, 9000000000, 9000000001, 'N/A', 'S', current_date, current_date, current_timestamp, 'system');

insert into t95par02_parametros_grupo (cod_grupo_usuario, cod_parametro, descripcion)
values ('GR', 'P001', 'Perfil administrador'), ('GR', 'P002', 'Perfil operador');

insert into t01gre20_grupo_recurso (cod_grupo_usuario, cod_recurso, cod_acceso, cod_usuario_mod, tim_modificacion)
values ('P001', 'USUARIO', 1, 'system', current_timestamp), ('P002', 'USUARIO', 1, 'system', current_timestamp);

insert into t95usu03_usuarios (usr_siglo21_id, usr_nombre, usr_status, usr_cid, usr_offset, usr_cargo, usr_empresa, usr_centro, usr_pers, usr_dominio, usr_nodo, usr_autoriza, usr_ofcswift, created_at, updated_at)
values ('ADMIN001', 'Administrador', 'N', '', '', 'ADMIN', '0001', '0001', 'P001', '', '', true, 'MSQUTODO', current_timestamp, current_timestamp),
       ('OPER0001', 'Operador Demo', 'N', '', '', 'OPER', '0001', '0001', 'P002', '', '', false, null, current_timestamp, current_timestamp);

insert into t95obs04_observaciones_usuario (cod_usuario, cod_usuario_mod, fec_ult_obs, cmp_observacion)
values ('ADMIN001', 'system', current_timestamp, 'Usuario inicial del sistema');
