create index if not exists idx_t95usu03_empresa on t95usu03_usuarios(usr_empresa);
create index if not exists idx_t95usu03_centro on t95usu03_usuarios(usr_centro);
create index if not exists idx_t95usu03_pers on t95usu03_usuarios(usr_pers);
create index if not exists idx_t95usu03_nombre on t95usu03_usuarios(usr_nombre);
create index if not exists idx_t95usu03_siglo21 on t95usu03_usuarios(usr_siglo21_id);
