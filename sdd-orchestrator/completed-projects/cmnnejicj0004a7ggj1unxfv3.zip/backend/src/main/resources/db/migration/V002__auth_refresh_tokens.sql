create table if not exists auth_refresh_tokens (
  id uuid primary key,
  username varchar(100) not null,
  token_hash varchar(255) not null unique,
  expires_at timestamp not null,
  revoked boolean not null default false,
  created_at timestamp not null
);
