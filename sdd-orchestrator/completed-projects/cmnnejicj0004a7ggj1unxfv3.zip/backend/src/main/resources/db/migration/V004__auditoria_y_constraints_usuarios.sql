create table if not exists t95log01_auditoria (
  id bigserial primary key,
  num_puesto varchar(8),
  transaccion varchar(10) not null,
  operacion varchar(12) not null,
  fecha_ingreso timestamp not null,
  terminal varchar(10),
  cod_usuario_mod varchar(20),
  mensajeria varchar(100),
  cmp_observacion varchar(100)
);
