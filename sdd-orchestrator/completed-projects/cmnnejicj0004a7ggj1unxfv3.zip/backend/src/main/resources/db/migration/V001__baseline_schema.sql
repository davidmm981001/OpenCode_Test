create table if not exists t06tc005_empresas (
  cod_empresa varchar(4) primary key,
  nombre varchar(40) not null,
  cod_num_doc_oficia varchar(14) not null,
  timestamp_siglo timestamp not null,
  cod_usu_modif varchar(8) not null
);

create table if not exists t06tc007_centros (
  id bigserial primary key,
  cod_empresa varchar(4) not null references t06tc005_empresas(cod_empresa),
  cod_centro varchar(4) not null,
  nombre varchar(40) not null,
  cod_tipo_via varchar(3) not null,
  nom_via varchar(40) not null,
  num_via varchar(10) not null,
  codigo_postal numeric(5,0) not null,
  cod_pueblo varchar(4) not null,
  cod_municipio varchar(3) not null,
  cod_provincia varchar(2) not null,
  cod_pais varchar(4) not null,
  prefijo_tf numeric(3,0) not null,
  num_telefono numeric(10,0) not null,
  num_fax numeric(10,0) not null,
  dec_juzga_tribuna varchar(20) not null,
  ind_actividad varchar(1) not null,
  fec_inic_validez date not null,
  fec_finalvalidez date not null,
  timestamp_siglo timestamp not null,
  cod_usu_modif varchar(8) not null,
  unique(cod_empresa, cod_centro)
);

create table if not exists t95usu03_usuarios (
  usr_siglo21_id varchar(8) primary key,
  usr_nombre varchar(60) not null,
  usr_status varchar(1) not null default 'N',
  usr_cid varchar(10) not null default '',
  usr_offset varchar(8) not null default '',
  usr_cargo varchar(18) not null default '',
  usr_empresa varchar(4) not null references t06tc005_empresas(cod_empresa),
  usr_centro varchar(4) not null,
  usr_pers varchar(8) not null,
  usr_dominio varchar(4) not null default '',
  usr_nodo varchar(4) not null default '',
  usr_autoriza boolean not null default false,
  usr_updfch date,
  usr_uptime time,
  usr_updusr varchar(8),
  usr_updterm varchar(15),
  usr_fchlogon date,
  usr_timelogon time,
  usr_logonsiglo varchar(15),
  usr_ofcswift varchar(12),
  created_at timestamp not null,
  updated_at timestamp not null,
  constraint fk_user_center foreign key (usr_empresa, usr_centro) references t06tc007_centros(cod_empresa, cod_centro)
);

create table if not exists t95obs04_observaciones_usuario (
  obs_id bigserial primary key,
  cod_usuario varchar(8) not null references t95usu03_usuarios(usr_siglo21_id),
  cod_usuario_mod varchar(8) not null,
  fec_ult_obs timestamp not null,
  cmp_observacion varchar(100) not null,
  unique(cod_usuario)
);

create table if not exists t95ban04_usuarios_bancs (
  usr_siglo21_id varchar(8) primary key references t95usu03_usuarios(usr_siglo21_id),
  usr_bancs varchar(8) not null unique,
  usr_nombre varchar(60) not null,
  branch_no varchar(4) not null,
  term_no integer not null,
  cod_empresa varchar(4) not null,
  est_proceso varchar(2) not null,
  observacion varchar(80) not null,
  fec_ult_cambio timestamp not null,
  usr_ult_cambio varchar(8) not null
);

create table if not exists t95par02_parametros_grupo (
  id bigserial primary key,
  cod_grupo_usuario varchar(12) not null,
  cod_parametro varchar(4) not null,
  descripcion varchar(100) not null,
  unique(cod_grupo_usuario, cod_parametro)
);

create table if not exists t01gre20_grupo_recurso (
  id bigserial primary key,
  cod_grupo_usuario varchar(8) not null,
  cod_recurso varchar(12) not null,
  cod_acceso numeric(4,0) not null,
  cod_usuario_mod varchar(8) not null,
  tim_modificacion timestamp not null
);
