package com.cobolapp.seguridad.api;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.cobolapp.shared.security.JwtUtil;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class SecurityConfigTest {
  @Autowired MockMvc mockMvc;
  @Autowired JwtUtil jwtUtil;

  @Test
  void allowsPublicAndProtectsApi() throws Exception {
    mockMvc.perform(get("/actuator/health")).andExpect(status().isOk());
    mockMvc.perform(get("/api/v1/usuarios/ADMIN001")).andExpect(status().isUnauthorized());
    String token = jwtUtil.generateAccessToken("admin", List.of("ROLE_ADMIN"), 900000);
    mockMvc.perform(get("/api/v1/usuarios/ADMIN001").header(HttpHeaders.AUTHORIZATION, "Bearer " + token)).andExpect(status().isOk());
  }
}
