package com.cobolapp.seguridad.api;

import static org.assertj.core.api.Assertions.assertThat;

import javax.sql.DataSource;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")
class FlywayMigrationIT {
  @Autowired DataSource dataSource;

  @Test
  void createsExpectedTablesAndSeeds() {
    JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
    Integer users = jdbcTemplate.queryForObject("select count(*) from t95usu03_usuarios", Integer.class);
    Integer companies = jdbcTemplate.queryForObject("select count(*) from t06tc005_empresas", Integer.class);
    assertThat(users).isGreaterThan(0);
    assertThat(companies).isGreaterThan(0);
  }
}
