package com.cobolapp.shared.security;

import static org.assertj.core.api.Assertions.assertThat;

import com.cobolapp.shared.config.AppProperties;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

class JwtUtilTest {

  @Test
  void generatesAndParsesClaims() {
    AppProperties props = new AppProperties("http://localhost:3001", "01234567890123456789012345678901", 900000, 604800000, Map.of());
    JwtUtil jwtUtil = new JwtUtil(props);
    String token = jwtUtil.generateAccessToken("admin", List.of("ROLE_ADMIN"), 900000);

    assertThat(jwtUtil.isTokenValid(token)).isTrue();
    assertThat(jwtUtil.subject(token)).isEqualTo("admin");
    assertThat(jwtUtil.parseClaims(token).get("roles", List.class)).containsExactly("ROLE_ADMIN");
  }
}
