package com.cobolapp.seguridad.api;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class AuthControllerIT {
  @Autowired MockMvc mockMvc;
  @Autowired ObjectMapper objectMapper;

  @Test
  void loginRefreshLogoutFlowWorks() throws Exception {
    var login = mockMvc.perform(post("/auth/login").contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(Map.of("username", "admin", "password", "Admin123!"))))
        .andExpect(status().isOk())
        .andReturn();
    String body = login.getResponse().getContentAsString();
    String refreshToken = objectMapper.readTree(body).get("refreshToken").asText();

    var refreshed = mockMvc.perform(post("/auth/refresh").contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(Map.of("refreshToken", refreshToken))))
        .andExpect(status().isOk())
        .andReturn();
    assertThat(objectMapper.readTree(refreshed.getResponse().getContentAsString()).get("username").asText()).isEqualTo("admin");

    mockMvc.perform(post("/auth/logout").contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(Map.of("refreshToken", refreshToken))))
        .andExpect(status().isOk());
  }
}
