package com.cobolapp.shared.exception;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.cobolapp.shared.security.JwtUtil;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class GlobalExceptionHandlerTest {
  @Autowired MockMvc mockMvc;
  @Autowired JwtUtil jwtUtil;

  @Test
  void mapsMissingCriteriaToValidationError() throws Exception {
    String token = jwtUtil.generateAccessToken("admin", List.of("ROLE_ADMIN"), 900000);
    mockMvc.perform(get("/api/v1/usuarios/consulta").header(HttpHeaders.AUTHORIZATION, "Bearer " + token))
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("$.code").value("USUARIO_CONSULTA_SIN_CRITERIO"));
  }
}
