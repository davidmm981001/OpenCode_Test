package com.cobolapp.shared.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.cobolapp.seguridad.infrastructure.repository.RefreshTokenRepository;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")
class RefreshTokenServiceTest {
  @Autowired RefreshTokenService service;
  @Autowired RefreshTokenRepository repository;

  @Test
  void issuesAndRevokesTokens() {
    var token = service.issue("admin");
    assertThat(repository.findByTokenHash(token.entity().getTokenHash())).isPresent();
    assertThat(service.validate(token.plainToken()).getUsername()).isEqualTo("admin");
    service.revoke(token.plainToken());
    assertThrows(IllegalStateException.class, () -> service.validate(token.plainToken()));
  }
}
