#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
RUNTIME_DIR="$ROOT_DIR/.runtime"
for file in backend.pid frontend.pid; do
  if [ -f "$RUNTIME_DIR/$file" ]; then
    kill "$(cat "$RUNTIME_DIR/$file")" >/dev/null 2>&1 || true
    rm -f "$RUNTIME_DIR/$file"
  fi
done
