Write-Host "Use stop.sh on Linux"
