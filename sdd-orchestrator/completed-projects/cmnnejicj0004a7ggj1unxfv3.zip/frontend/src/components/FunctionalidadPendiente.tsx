import { ArrowRight, ChevronLeft, Construction } from 'lucide-react'
import { Link } from 'react-router-dom'

export function FunctionalidadPendiente({ codigo, titulo, descripcion, backTo = '/' }: { codigo: string; titulo: string; descripcion: string; backTo?: string }) {
  return (
    <div className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-soft">
      <div className="flex items-start gap-4">
        <div className="rounded-2xl bg-primary-50 p-4 text-primary-500"><Construction className="h-10 w-10" /></div>
        <div className="space-y-3">
          <span className="inline-flex rounded-full bg-neutral-100 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-neutral-600">Próximamente</span>
          <h1 className="text-2xl font-semibold text-neutral-900">{titulo}</h1>
          <p className="max-w-2xl text-neutral-600">{descripcion} La capacidad está planificada para una versión futura.</p>
          <p className="text-sm text-neutral-500">Código: {codigo}</p>
          <Link to={backTo} className="inline-flex items-center gap-2 rounded-xl bg-primary-500 px-4 py-2 font-medium text-white hover:bg-primary-400"><ChevronLeft className="h-4 w-4" /> Volver a Inicio</Link>
        </div>
      </div>
    </div>
  )
}
