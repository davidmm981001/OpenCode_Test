import { describe, expect, it, vi, beforeEach } from 'vitest'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { render, screen } from '@testing-library/react'
import { SecurityMenuPage } from './SecurityMenuPage'

const useAuthMock = vi.fn()
const navigateMock = vi.fn()

vi.mock('@/context/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}))

vi.mock('react-router-dom', async () => {
  const actual = await vi.importActual<typeof import('react-router-dom')>('react-router-dom')
  return {
    ...actual,
    useNavigate: () => navigateMock,
  }
})

describe('SecurityMenuPage', () => {
  beforeEach(() => {
    useAuthMock.mockReturnValue({ user: { username: 'admin' } })
  })

  it('renders menu options and validates numeric input', async () => {
    const user = userEvent.setup()

    render(
      <MemoryRouter initialEntries={['/']}>
        <Routes>
          <Route path="/" element={<SecurityMenuPage />} />
        </Routes>
      </MemoryRouter>,
    )

    expect(screen.getByText('Opción 01')).toBeInTheDocument()
    expect(screen.getByText('Administración de Menús')).toBeInTheDocument()

    await user.type(screen.getByPlaceholderText('01'), 'AB')
    await user.click(screen.getByRole('button', { name: /ir/i }))

    expect(screen.getByText('Ingrese un valor numérico')).toBeInTheDocument()
  })

  it('navigates to usuarios for option 01', async () => {
    const user = userEvent.setup()
    navigateMock.mockReset()

    render(
      <MemoryRouter initialEntries={['/']}>
        <Routes>
          <Route path="/" element={<SecurityMenuPage />} />
        </Routes>
      </MemoryRouter>,
    )

    const optionInput = screen.getAllByPlaceholderText('01')[0]
    await user.clear(optionInput)
    await user.type(optionInput, '01{enter}')

    expect(navigateMock).toHaveBeenCalledWith('/usuarios')
  })
})
