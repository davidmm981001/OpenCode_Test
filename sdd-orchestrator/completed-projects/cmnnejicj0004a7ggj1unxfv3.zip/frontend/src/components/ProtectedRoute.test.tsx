import { describe, expect, it, vi } from 'vitest'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { render, screen } from '@testing-library/react'
import { ProtectedRoute } from './ProtectedRoute'

const useAuthMock = vi.fn()

vi.mock('@/context/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}))

describe('ProtectedRoute', () => {
  it('redirects unauthenticated users to login', () => {
    useAuthMock.mockReturnValue({ isAuthenticated: false })

    render(
      <MemoryRouter initialEntries={['/usuarios']}>
        <Routes>
          <Route path="/login" element={<div>Login screen</div>} />
          <Route
            path="/usuarios"
            element={(
              <ProtectedRoute>
                <div>Secret area</div>
              </ProtectedRoute>
            )}
          />
        </Routes>
      </MemoryRouter>,
    )

    expect(screen.getByText('Login screen')).toBeInTheDocument()
  })
})
