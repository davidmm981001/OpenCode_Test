import { Link, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { AlertCircle, ArrowRight, Shield } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'

const options = [
  { code: '01', title: 'Administración de Usuarios', path: '/usuarios', icon: Shield },
  { code: '02', title: 'Administración de Menús', path: '/pendiente/02', icon: Shield },
  { code: '03', title: 'Parámetros', path: '/pendiente/03', icon: Shield },
  { code: '04', title: 'Perfiles', path: '/pendiente/04', icon: Shield },
  { code: '05', title: 'Recursos Host', path: '/pendiente/05', icon: Shield },
  { code: '06', title: 'Consulta Ventana', path: '/pendiente/06', icon: Shield },
  { code: '07', title: 'Consulta Recursos', path: '/pendiente/07', icon: Shield },
  { code: '08', title: 'Consulta Host', path: '/pendiente/08', icon: Shield },
  { code: '09', title: 'Reseteo Claves / Dominio', path: '/pendiente/09', icon: Shield },
]

export function SecurityMenuPage() {
  const [value, setValue] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()
  const { user } = useAuth()

  const submit = () => {
    if (!/^\d+$/.test(value)) return setError('Ingrese un valor numérico')
    const selected = options.find((item) => item.code === value.padStart(2, '0'))
    if (!selected) return setError('Opción inválida')
    navigate(selected.path)
  }

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-soft">
        <p className="text-sm text-neutral-500">Bienvenido</p>
        <h1 className="text-2xl font-semibold">{user?.username ?? 'Usuario'}</h1>
        <p className="mt-1 text-neutral-600">Módulo de Seguridad · Fecha y hora de sistema</p>
        <div className="mt-4 flex flex-wrap gap-3">
          <input value={value} onChange={(e) => { setValue(e.target.value); setError('') }} onKeyDown={(e) => e.key === 'Enter' && submit()} className="w-32 rounded-xl border border-neutral-300 px-3 py-2" placeholder="01" />
          <button onClick={submit} className="rounded-xl bg-primary-500 px-4 py-2 font-medium text-white hover:bg-primary-400">Ir</button>
          <button onClick={() => { setValue(''); setError('') }} className="rounded-xl border border-neutral-300 px-4 py-2 font-medium">Limpiar</button>
          {error && <span className="inline-flex items-center gap-1 rounded-xl bg-rose-50 px-3 py-2 text-sm text-semantic-error"><AlertCircle className="h-4 w-4" /> {error}</span>}
        </div>
      </section>
      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {options.map((option) => {
          const Icon = option.icon
          return <Link key={option.code} to={option.path} className="rounded-2xl border border-neutral-200 bg-white p-4 shadow-soft transition hover:-translate-y-0.5 hover:border-primary-200">
            <div className="flex items-start gap-3">
              <div className="rounded-xl bg-primary-50 p-3 text-primary-500"><Icon className="h-5 w-5" /></div>
              <div>
                <div className="text-sm font-semibold text-neutral-500">Opción {option.code}</div>
                <div className="mt-1 font-medium text-neutral-900">{option.title}</div>
              </div>
              <ArrowRight className="ml-auto h-4 w-4 text-neutral-400" />
            </div>
          </Link>
        })}
      </section>
    </div>
  )
}
