import { Link, NavLink, Outlet, useLocation } from 'react-router-dom'
import { ChevronLeft, LogOut, Menu, Shield, Users } from 'lucide-react'
import clsx from 'clsx'
import { useAuth } from '@/context/AuthContext'
import { useState } from 'react'

export function Layout({ backTo = '/' }: { backTo?: string }) {
  const [open, setOpen] = useState(false)
  const { user, logout } = useAuth()
  const location = useLocation()
  const breadcrumbs = location.pathname === '/' ? ['Inicio'] : ['Inicio', location.pathname.split('/').filter(Boolean).map((x) => decodeURIComponent(x)).join(' / ')]

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900">
      <a href="#content" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-xl focus:bg-white focus:px-4 focus:py-2">Saltar al contenido</a>
      <header className="border-b border-neutral-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3 lg:px-6">
          <button className="rounded-xl border border-neutral-200 p-2 lg:hidden" onClick={() => setOpen((v) => !v)} aria-label="Abrir menú"><Menu className="h-5 w-5" /></button>
          <div className="flex items-center gap-2 font-semibold text-primary-500"><Shield className="h-5 w-5" /> Seguridad Moderna</div>
          <div className="ml-auto flex items-center gap-3 text-sm text-neutral-600">
            {backTo !== location.pathname && (
              <Link to={backTo} className="inline-flex items-center gap-1 rounded-xl border border-neutral-200 px-3 py-2 text-sm font-medium text-neutral-700 hover:bg-neutral-100"><ChevronLeft className="h-4 w-4" /> Volver</Link>
            )}
            {user && <span className="rounded-full bg-primary-50 px-3 py-1 text-primary-500">{user.username}</span>}
            <button onClick={() => void logout()} className="inline-flex items-center gap-1 rounded-xl border border-neutral-200 px-3 py-2 font-medium hover:bg-neutral-100"><LogOut className="h-4 w-4" /> Salir</button>
          </div>
        </div>
        <div className="mx-auto max-w-7xl px-4 pb-3 text-sm text-neutral-500 lg:px-6">{breadcrumbs.join(' / ')}</div>
      </header>
      <div className="mx-auto flex max-w-7xl gap-6 px-4 py-6 lg:px-6">
        <aside className={clsx('w-72 shrink-0 space-y-2 rounded-2xl border border-neutral-200 bg-white p-4 shadow-soft', open ? 'block' : 'hidden lg:block')}>
          <NavLink to="/" className={({ isActive }) => clsx('flex items-center gap-2 rounded-xl px-3 py-2', isActive ? 'bg-primary-50 text-primary-500' : 'hover:bg-neutral-100')}><Shield className="h-4 w-4" /> Menú</NavLink>
          <NavLink to="/usuarios" className={({ isActive }) => clsx('flex items-center gap-2 rounded-xl px-3 py-2', isActive ? 'bg-primary-50 text-primary-500' : 'hover:bg-neutral-100')}><Users className="h-4 w-4" /> Usuarios</NavLink>
        </aside>
        <main id="content" className="min-w-0 flex-1">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
