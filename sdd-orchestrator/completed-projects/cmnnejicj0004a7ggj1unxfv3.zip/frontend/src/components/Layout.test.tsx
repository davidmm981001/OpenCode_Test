import { describe, expect, it, vi } from 'vitest'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { fireEvent, render, screen } from '@testing-library/react'
import { Layout } from './Layout'

const useAuthMock = vi.fn()

vi.mock('@/context/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}))

describe('Layout', () => {
  it('renders breadcrumbs, username and logout action', () => {
    const logout = vi.fn()
    useAuthMock.mockReturnValue({ user: { username: 'admin' }, logout })

    render(
      <MemoryRouter initialEntries={['/usuarios']}>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/usuarios" element={<div>Usuarios content</div>} />
          </Route>
        </Routes>
      </MemoryRouter>,
    )

    expect(screen.getByText('admin')).toBeInTheDocument()
    expect(screen.getByText('Inicio / usuarios')).toBeInTheDocument()

    fireEvent.click(screen.getByRole('button', { name: /salir/i }))
    expect(logout).toHaveBeenCalledOnce()
  })
})
