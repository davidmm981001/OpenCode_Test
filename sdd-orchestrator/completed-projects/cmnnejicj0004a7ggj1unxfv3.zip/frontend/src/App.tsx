import { Navigate, Route, Routes } from 'react-router-dom'
import { Layout } from '@/components/Layout'
import { ProtectedRoute } from '@/components/ProtectedRoute'
import { SecurityMenuPage } from '@/components/SecurityMenuPage'
import { FunctionalidadPendiente } from '@/components/FunctionalidadPendiente'
import { LoginPage } from '@/pages/LoginPage'
import { UsersListPage } from '@/pages/UsersListPage'
import { UserFormPage } from '@/pages/UserFormPage'

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
        <Route path="/" element={<SecurityMenuPage />} />
        <Route path="/usuarios" element={<UsersListPage />} />
        <Route path="/usuarios/nuevo" element={<UserFormPage mode="create" />} />
        <Route path="/usuarios/:usuarioId" element={<UserFormPage mode="edit" />} />
        {['02','03','04','05','06','07','08','09'].map((codigo) => (
          <Route key={codigo} path={`/pendiente/${codigo}`} element={<FunctionalidadPendiente codigo={codigo} titulo={`Funcionalidad ${codigo}`} descripcion="Funcionalidad pendiente del módulo de seguridad." backTo="/" />} />
        ))}
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
