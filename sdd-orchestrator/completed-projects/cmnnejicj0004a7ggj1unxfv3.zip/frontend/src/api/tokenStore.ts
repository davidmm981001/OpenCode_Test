export type SessionTokens = {
  accessToken: string
  refreshToken: string
  username: string
  roles: string[]
}

let tokens: SessionTokens | null = null

export const tokenStore = {
  get: () => tokens,
  set: (value: SessionTokens | null) => {
    tokens = value
  },
}
