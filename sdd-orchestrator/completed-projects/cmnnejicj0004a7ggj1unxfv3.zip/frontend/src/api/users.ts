import { axiosInstance } from './axiosInstance'

export type UserSummary = {
  usuarioId: string
  nombre: string
  perfil: string
  empresa: string
  centro: string
  dominio: string
  nodo: string
  autorizador: boolean
}

export type UserDetail = {
  usuarioId: string
  nombre: string
  cid?: string | null
  empresa: string
  empresaDescripcion: string
  centro: string
  centroDescripcion: string
  cargo?: string | null
  perfil: string
  perfilDescripcion: string
  dominio?: string | null
  nodo?: string | null
  autorizador: boolean
  swift?: string | null
  observaciones?: string | null
  bancs: { usuarioBancs?: string; terminalBancs?: number; estadoProceso?: string } | null
  status: string
}

export type UserPage = {
  content: UserSummary[]
  totalElements: number
  totalPages: number
  size: number
  number: number
  first: boolean
  last: boolean
  criterioAplicado: string
}

export const usersApi = {
  search: async (params: Record<string, string | number | undefined>) => (await axiosInstance.get<UserPage>('/api/v1/usuarios/consulta', { params })).data,
  detail: async (usuarioId: string) => (await axiosInstance.get<UserDetail>(`/api/v1/usuarios/${usuarioId}`)).data,
  create: async (payload: unknown) => (await axiosInstance.post<UserDetail>('/api/v1/usuarios', payload)).data,
  update: async (usuarioId: string, payload: unknown) => (await axiosInstance.put<UserDetail>(`/api/v1/usuarios/${usuarioId}`, payload)).data,
  remove: async (usuarioId: string, payload: unknown) => (await axiosInstance.delete(`/api/v1/usuarios/${usuarioId}`, { data: payload })).data as Promise<{ usuarioId: string; status: string; bancsEstado?: string; message: string }>,
}
