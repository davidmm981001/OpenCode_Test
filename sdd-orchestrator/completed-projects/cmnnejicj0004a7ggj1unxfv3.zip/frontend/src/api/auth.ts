import { publicApi } from './axiosInstance'

export type AuthResponse = {
  accessToken: string
  refreshToken: string
  tokenType: string
  expiresIn: number
  roles: string[]
  username: string
}

export const authApi = {
  login: async (username: string, password: string) => (await publicApi.post<AuthResponse>('/auth/login', { username, password })).data,
  refresh: async (refreshToken: string) => (await publicApi.post<AuthResponse>('/auth/refresh', { refreshToken })).data,
  logout: async (refreshToken: string) => (await publicApi.post<{ message: string }>('/auth/logout', { refreshToken })).data,
  me: async () => (await publicApi.get<{ username: string; roles: string[] }>('/api/v1/auth/me')).data,
}
