import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios'
import { tokenStore } from './tokenStore'

const baseURL = import.meta.env.VITE_API_URL ?? 'http://localhost:8081'

export const publicApi = axios.create({ baseURL })

export const axiosInstance = axios.create({ baseURL })

axiosInstance.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const session = tokenStore.get()
  if (session?.accessToken) {
    config.headers.Authorization = `Bearer ${session.accessToken}`
  }
  return config
})

axiosInstance.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const original = error.config as InternalAxiosRequestConfig & { _retry?: boolean }
    const session = tokenStore.get()
    if (error.response?.status === 401 && !original._retry && session?.refreshToken) {
      original._retry = true
      try {
        const { data } = await publicApi.post('/auth/refresh', { refreshToken: session.refreshToken })
        tokenStore.set({
          accessToken: data.accessToken,
          refreshToken: data.refreshToken,
          username: data.username,
          roles: data.roles,
        })
        original.headers.Authorization = `Bearer ${data.accessToken}`
        return axiosInstance(original)
      } catch {
        tokenStore.set(null)
        if (typeof window !== 'undefined') window.location.assign('/login')
      }
    }
    return Promise.reject(error)
  },
)
