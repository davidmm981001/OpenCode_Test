import { axiosInstance } from './axiosInstance'

export const referencesApi = {
  profile: async (codigo: string) => (await axiosInstance.get<{ codigo: string; descripcion: string }>(`/api/v1/referencias/perfiles/${codigo}`)).data,
  company: async (codigo: string) => (await axiosInstance.get<{ codigo: string; descripcion: string }>(`/api/v1/referencias/empresas/${codigo}`)).data,
  center: async (empresa: string, centro: string) => (await axiosInstance.get<{ empresa: string; centro: string; descripcion: string }>(`/api/v1/referencias/empresas/${empresa}/centros/${centro}`)).data,
}
