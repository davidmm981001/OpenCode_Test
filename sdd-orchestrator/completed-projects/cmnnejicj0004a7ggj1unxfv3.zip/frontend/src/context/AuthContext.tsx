import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { authApi } from '@/api/auth'
import { tokenStore, type SessionTokens } from '@/api/tokenStore'

type AuthContextValue = {
  user: SessionTokens | null
  login: (username: string, password: string) => Promise<void>
  logout: () => Promise<void>
  isAuthenticated: boolean
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<SessionTokens | null>(tokenStore.get())

  useEffect(() => {
    tokenStore.set(user)
  }, [user])

  const value = useMemo<AuthContextValue>(() => ({
    user,
    isAuthenticated: Boolean(user),
    login: async (username, password) => {
      const data = await authApi.login(username, password)
      const session = { accessToken: data.accessToken, refreshToken: data.refreshToken, username: data.username, roles: data.roles }
      setUser(session)
      tokenStore.set(session)
    },
    logout: async () => {
      const refreshToken = user?.refreshToken
      if (refreshToken) {
        try { await authApi.logout(refreshToken) } catch {}
      }
      setUser(null)
      tokenStore.set(null)
    },
  }), [user])

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used within AuthProvider')
  return context
}
