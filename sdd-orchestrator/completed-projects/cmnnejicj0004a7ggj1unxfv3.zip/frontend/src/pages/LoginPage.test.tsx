import { describe, expect, it, vi } from 'vitest'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { render, screen } from '@testing-library/react'
import { LoginPage } from './LoginPage'

const useAuthMock = vi.fn()

vi.mock('@/context/AuthContext', () => ({
  useAuth: () => useAuthMock(),
}))

describe('LoginPage', () => {
  it('logs in and redirects home', async () => {
    const user = userEvent.setup()
    const login = vi.fn().mockResolvedValue(undefined)
    useAuthMock.mockReturnValue({ login })

    render(
      <MemoryRouter initialEntries={['/login']}>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/" element={<div>Home screen</div>} />
        </Routes>
      </MemoryRouter>,
    )

    await user.click(screen.getByRole('button', { name: /entrar/i }))

    expect(login).toHaveBeenCalledWith('admin', 'Admin123!')
    expect(screen.getByText('Home screen')).toBeInTheDocument()
  })
})
