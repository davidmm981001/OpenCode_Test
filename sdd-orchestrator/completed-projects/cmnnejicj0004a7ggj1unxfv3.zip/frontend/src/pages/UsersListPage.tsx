import { useState } from 'react'
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link, useNavigate } from 'react-router-dom'
import { AlertCircle, Search } from 'lucide-react'
import { usersApi } from '@/api/users'
import { toast } from 'sonner'

type Filters = { empresa: string; centro: string; usuario: string; perfil: string; nombre: string; page: number }

export function UsersListPage() {
  const [filters, setFilters] = useState<Filters>({ empresa: '', centro: '', usuario: '', perfil: '', nombre: '', page: 0 })
  const [draft, setDraft] = useState<Omit<Filters, 'page'>>(filters)
  const [message, setMessage] = useState('')
  const queryClient = useQueryClient()
  const navigate = useNavigate()
  const query = useQuery({
    queryKey: ['usuarios-consulta', filters],
    queryFn: () => usersApi.search({ ...filters, size: 14 }),
    placeholderData: keepPreviousData,
  })

  const remove = useMutation({ mutationFn: async (id: string) => usersApi.remove(id, { observaciones: 'Eliminar desde listado' }), onSuccess: async () => { toast.success('Usuario eliminado'); await queryClient.invalidateQueries({ queryKey: ['usuarios-consulta'] }) } })

  const submit = () => {
    if (!draft.empresa && !draft.centro && !draft.usuario && !draft.perfil && !draft.nombre) return setMessage('Ingrese criterio de consulta')
    setMessage('')
    setFilters({ ...draft, page: 0 })
  }

  return <div className="space-y-6">
    <div className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-soft">
      <div className="grid gap-3 md:grid-cols-5">
        {(['empresa','centro','usuario','perfil','nombre'] as const).map((k) => <input key={k} className="rounded-xl border border-neutral-300 px-3 py-2" placeholder={k} value={draft[k]} onChange={(e) => setDraft((d) => ({ ...d, [k]: e.target.value }))} />)}
      </div>
      <div className="mt-4 flex gap-3">
        <button onClick={submit} className="inline-flex items-center gap-2 rounded-xl bg-primary-500 px-4 py-2 font-medium text-white"><Search className="h-4 w-4" /> Buscar</button>
        <Link to="/usuarios/nuevo" className="rounded-xl border border-neutral-300 px-4 py-2 font-medium">Agregar usuario</Link>
      </div>
      {message && <p className="mt-3 inline-flex items-center gap-2 text-semantic-error"><AlertCircle className="h-4 w-4" />{message}</p>}
    </div>
    <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-soft">
      {query.isPending ? <div className="p-6 text-neutral-500">Cargando...</div> : query.isError ? <div className="p-6 text-semantic-error">Error al consultar</div> : query.data?.content.length ? <table className="w-full text-left text-sm"><thead className="bg-neutral-100 text-neutral-600"><tr>{['Usuario','Nombre','Perfil','Empresa','Centro','Dominio','Nodo','Autorizador','Acciones'].map((h) => <th key={h} className="px-4 py-3">{h}</th>)}</tr></thead><tbody>{query.data.content.map((row) => <tr key={row.usuarioId} className="border-t border-neutral-100"><td className="px-4 py-3">{row.usuarioId}</td><td className="px-4 py-3">{row.nombre}</td><td className="px-4 py-3">{row.perfil}</td><td className="px-4 py-3">{row.empresa}</td><td className="px-4 py-3">{row.centro}</td><td className="px-4 py-3">{row.dominio}</td><td className="px-4 py-3">{row.nodo}</td><td className="px-4 py-3">{row.autorizador ? 'Sí' : 'No'}</td><td className="px-4 py-3"><div className="flex gap-2"><button onClick={() => navigate(`/usuarios/${row.usuarioId}`)} className="rounded-lg border border-neutral-300 px-3 py-1">Editar</button><button onClick={() => remove.mutate(row.usuarioId)} className="rounded-lg border border-neutral-300 px-3 py-1 text-semantic-error">Eliminar</button></div></td></tr>)}</tbody></table> : <div className="p-6 text-neutral-500">Sin datos</div>}
      <div className="flex items-center justify-between border-t border-neutral-100 p-4">
        <button disabled={filters.page === 0} onClick={() => setFilters((f) => ({ ...f, page: Math.max(0, f.page - 1) }))} className="rounded-xl border border-neutral-300 px-4 py-2 disabled:opacity-40">Anterior</button>
        <span className="text-sm text-neutral-500">Página {(query.data?.number ?? 0) + 1}</span>
        <button disabled={query.data?.last ?? true} onClick={() => setFilters((f) => ({ ...f, page: f.page + 1 }))} className="rounded-xl border border-neutral-300 px-4 py-2 disabled:opacity-40">Siguiente</button>
      </div>
    </div>
  </div>
}
