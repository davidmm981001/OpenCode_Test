import { describe, expect, it, vi, beforeEach } from 'vitest'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor } from '@testing-library/react'
import { UsersListPage } from './UsersListPage'

const usersApiMock = vi.hoisted(() => ({
  search: vi.fn(),
  remove: vi.fn(),
  detail: vi.fn(),
  create: vi.fn(),
  update: vi.fn(),
}))

vi.mock('@/api/users', () => ({
  usersApi: usersApiMock,
}))

vi.mock('sonner', () => ({
  toast: { success: vi.fn(), error: vi.fn() },
}))

describe('UsersListPage', () => {
  beforeEach(() => {
    usersApiMock.search.mockResolvedValue({
      content: [
        {
          usuarioId: 'USR00001',
          nombre: 'Admin User',
          perfil: 'P001',
          empresa: '0001',
          centro: '0001',
          dominio: 'DOM',
          nodo: 'NOD',
          autorizador: true,
        },
      ],
      totalElements: 1,
      totalPages: 1,
      size: 14,
      number: 0,
      first: true,
      last: true,
      criterioAplicado: 'empresa',
    })
    usersApiMock.remove.mockResolvedValue({
      usuarioId: 'USR00001',
      status: 'I',
      message: 'Eliminado',
    })
  })

  it('shows validation message when no criteria are entered', async () => {
    const user = userEvent.setup()
    const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } })

    render(
      <QueryClientProvider client={queryClient}>
        <MemoryRouter>
          <UsersListPage />
        </MemoryRouter>
      </QueryClientProvider>,
    )

    await waitFor(() => expect(usersApiMock.search).toHaveBeenCalled())
    await user.click(screen.getByRole('button', { name: /buscar/i }))

    expect(screen.getByText('Ingrese criterio de consulta')).toBeInTheDocument()
    expect(usersApiMock.search).toHaveBeenCalledTimes(1)
  })
})
