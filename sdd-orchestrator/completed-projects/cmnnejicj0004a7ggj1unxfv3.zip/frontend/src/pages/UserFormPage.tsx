import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { usersApi } from '@/api/users'

type Props = { mode: 'create' | 'edit' }

type UserFormState = {
  usuarioId: string
  nombre: string
  empresa: string
  centro: string
  perfil: string
  autorizador: boolean
  observaciones: string
  swift: string
  usuarioBancs: string
  terminalBancs: string
}

export function UserFormPage({ mode }: Props) {
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const params = useParams()
  const [form, setForm] = useState<UserFormState>({ usuarioId: '', nombre: '', empresa: '0001', centro: '0001', perfil: 'P001', autorizador: true, observaciones: '', swift: '', usuarioBancs: '', terminalBancs: '' })
  const detail = useQuery({ queryKey: ['usuario-detalle', params.usuarioId], queryFn: () => usersApi.detail(params.usuarioId ?? ''), enabled: mode === 'edit' && Boolean(params.usuarioId) })

  useEffect(() => { if (detail.data && mode === 'edit') setForm((f) => ({ ...f, usuarioId: detail.data.usuarioId, nombre: detail.data.nombre, empresa: detail.data.empresa, centro: detail.data.centro, perfil: detail.data.perfil, autorizador: detail.data.autorizador, observaciones: detail.data.observaciones ?? '', swift: detail.data.swift ?? '' })) }, [detail.data, mode])

  const mutation = useMutation({
    mutationFn: async () => {
      const payload = {
        usuarioId: form.usuarioId,
        nombre: form.nombre,
        empresa: form.empresa,
        centro: form.centro,
        perfil: form.perfil,
        autorizador: form.autorizador,
        observaciones: form.observaciones,
        swift: form.swift || undefined,
        usuarioBancs: form.usuarioBancs || undefined,
        terminalBancs: form.terminalBancs ? Number(form.terminalBancs) : undefined,
      }
      return mode === 'create' ? usersApi.create(payload) : usersApi.update(params.usuarioId ?? '', payload)
    },
    onSuccess: async () => {
      toast.success('Guardado')
      await queryClient.invalidateQueries({ queryKey: ['usuarios-consulta'] })
      navigate('/usuarios')
    },
  })

  const remove = useMutation({ mutationFn: async () => usersApi.remove(params.usuarioId ?? '', { observaciones: 'Salida de la organización' }), onSuccess: async () => { toast.success('Eliminado'); await queryClient.invalidateQueries({ queryKey: ['usuarios-consulta'] }); navigate('/usuarios') } })

  return <div className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-soft">
    <h1 className="text-2xl font-semibold">{mode === 'create' ? 'Nuevo usuario' : 'Detalle de usuario'}</h1>
    <div className="mt-4 grid gap-3 md:grid-cols-2">
        {(['usuarioId','nombre','empresa','centro','perfil','observaciones','swift','usuarioBancs','terminalBancs'] as const).map((k) => <input key={k} value={form[k]} onChange={(e) => setForm((f) => ({ ...f, [k]: e.target.value }))} placeholder={k} className="rounded-xl border border-neutral-300 px-3 py-2" />)}
    </div>
    <div className="mt-4 flex gap-3">
      <button onClick={() => mutation.mutate()} className="rounded-xl bg-primary-500 px-4 py-2 font-medium text-white">Guardar</button>
      {mode === 'edit' && <button onClick={() => remove.mutate()} className="rounded-xl border border-neutral-300 px-4 py-2 font-medium text-semantic-error">Eliminar</button>}
      <button onClick={() => navigate('/usuarios')} className="rounded-xl border border-neutral-300 px-4 py-2 font-medium">Volver a Usuarios</button>
    </div>
  </div>
}
