import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'

export function LoginPage() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [username, setUsername] = useState('admin')
  const [password, setPassword] = useState('Admin123!')
  const [error, setError] = useState('')

  const submit = async () => {
    try {
      await login(username, password)
      navigate('/', { replace: true })
    } catch {
      setError('Credenciales inválidas')
    }
  }

  return <div className="grid min-h-screen place-items-center bg-neutral-50 px-4">
    <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-soft">
      <h1 className="text-2xl font-semibold">Ingresar</h1>
      <p className="mt-1 text-sm text-neutral-500">Acceso al módulo de seguridad</p>
      <div className="mt-6 space-y-4">
        <input className="w-full rounded-xl border border-neutral-300 px-3 py-2" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="usuario" />
        <input className="w-full rounded-xl border border-neutral-300 px-3 py-2" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="contraseña" type="password" />
        {error && <p className="text-sm text-semantic-error">{error}</p>}
        <button className="w-full rounded-xl bg-primary-500 px-4 py-2 font-medium text-white" onClick={() => void submit()}>Entrar</button>
      </div>
    </div>
  </div>
}
