@ui @regression
Feature: Login de usuario
  Como usuario del sistema
  Quiero poder iniciar sesión
  Para acceder a las funcionalidades de la aplicación

  Background:
    Given el actor está en la página de login

  @smoke
  Scenario: Login exitoso con credenciales válidas
    When inicia sesión con usuario "qa_user@test.com" y contraseña "SecureP@ss123"
    Then debe ser redirigido al dashboard
    And debe ver el mensaje de bienvenida

  @negative
  Scenario: Login fallido con credenciales inválidas
    When inicia sesión con usuario "fake@test.com" y contraseña "wrongpass"
    Then debe ver un mensaje de error en pantalla

  @data-driven
  Scenario Outline: Login con múltiples combinaciones de credenciales
    When inicia sesión con usuario "<username>" y contraseña "<password>"
    Then el resultado del login es "<resultado>"

    Examples:
      | username           | password      | resultado |
      | qa_user@test.com   | SecureP@ss123 | exitoso   |
      | fake@test.com      | wrongpass     | error     |
      |                    | SecureP@ss123 | error     |
      | qa_user@test.com   |               | error     |

  @e2e
  Scenario: Flujo completo login, navegación y logout
    When inicia sesión con usuario "qa_user@test.com" y contraseña "SecureP@ss123"
    Then debe ser redirigido al dashboard
    When el actor cierra sesión
    Then debe estar en la página de login
