@api @regression
Feature: API - CRUD de recursos
  Como consumidor de la API
  Quiero gestionar recursos via REST
  Para mantener la información del sistema

  Background:
    Given el actor tiene acceso a la API

  @smoke @post
  Scenario: POST - Crear recurso exitosamente
    When el actor crea un recurso con nombre "Recurso Test" y status "active"
    Then el código de respuesta debe ser 201
    And la respuesta contiene el campo "id"
    And la respuesta contiene "name" igual a "Recurso Test"

  @negative @post
  Scenario: POST - Crear recurso con datos inválidos
    When el actor crea un recurso con nombre "" y status "invalid"
    Then el código de respuesta debe ser 400

  @smoke @get
  Scenario: GET - Consultar recurso existente
    Given el actor ha creado un recurso previamente
    When el actor consulta el recurso por su ID
    Then el código de respuesta debe ser 200
    And la respuesta contiene el campo "name"

  @negative @get
  Scenario: GET - Consultar recurso inexistente
    When el actor consulta el recurso con ID "999999999"
    Then el código de respuesta debe ser 404

  @data-driven @get
  Scenario Outline: GET - Filtrar recursos por status
    When el actor busca recursos con status "<filtro>"
    Then el código de respuesta debe ser <statusCode>

    Examples:
      | filtro    | statusCode |
      | active    | 200        |
      | inactive  | 200        |
      | INVALID!! | 400        |

  @smoke @put
  Scenario: PUT - Actualizar recurso existente
    Given el actor ha creado un recurso previamente
    When el actor actualiza el recurso con nombre "Actualizado" y status "inactive"
    Then el código de respuesta debe ser 200
    And la respuesta contiene "name" igual a "Actualizado"

  @smoke @delete
  Scenario: DELETE - Eliminar recurso
    Given el actor ha creado un recurso previamente
    When el actor elimina el recurso
    Then el código de respuesta debe ser 200
    When el actor consulta el recurso por su ID
    Then el código de respuesta debe ser 404

  @e2e
  Scenario: E2E - Ciclo completo CRUD
    When el actor crea un recurso con nombre "E2E Resource" y status "active"
    Then el código de respuesta debe ser 201
    And guarda el ID de la respuesta

    When el actor consulta el recurso por su ID
    Then el código de respuesta debe ser 200
    And la respuesta contiene "name" igual a "E2E Resource"

    When el actor actualiza el recurso con nombre "E2E Updated" y status "inactive"
    Then el código de respuesta debe ser 200

    When el actor elimina el recurso
    Then el código de respuesta debe ser 200

    When el actor consulta el recurso por su ID
    Then el código de respuesta debe ser 404
