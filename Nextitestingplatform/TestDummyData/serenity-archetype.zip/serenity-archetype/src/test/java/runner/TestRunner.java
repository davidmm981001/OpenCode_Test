package runner;

import org.junit.platform.suite.api.*;

import static io.cucumber.junit.platform.engine.Constants.*;

/**
 * ═══════════════════════════════════════════════════════════════
 * RUNNER PRINCIPAL - Serenity BDD + Cucumber + JUnit5
 * ═══════════════════════════════════════════════════════════════
 *
 * Ejecución:
 *   gradle test                                          → Todos
 *   gradle test -Denv=qa                                 → Ambiente QA
 *   gradle smoke                                         → Solo @smoke
 *   gradle api                                           → Solo @api
 *   gradle test -Dcucumber.filter.tags="@e2e"            → Solo E2E
 *   gradle test -Dwebdriver.driver=firefox               → Firefox
 *   gradle test -Dchrome.switches="--headless=new"       → Headless
 *
 * Reportes: target/site/serenity/index.html (Living Documentation)
 */
@Suite
@IncludeEngines("cucumber")
@SelectClasspathResource("features")
@ConfigurationParameter(key = GLUE_PROPERTY_NAME, value = "steps,config")
@ConfigurationParameter(key = FEATURES_PROPERTY_NAME, value = "src/test/resources/features")
@ConfigurationParameter(key = FILTER_TAGS_PROPERTY_NAME, value = "not @ignore")
@ConfigurationParameter(key = PLUGIN_PROPERTY_NAME, value = "io.cucumber.core.plugin.SerenityReporterParallel")
public class TestRunner {
}
