package userinterfaces;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

/**
 * ═══════════════════════════════════════════════════════════════
 * DashboardUI - Targets del Dashboard (template)
 * ═══════════════════════════════════════════════════════════════
 * TODO: Reemplazar con los elementos reales de tu app.
 */
public class DashboardUI {

    public static final Target PAGE_TITLE = Target
            .the("título del dashboard")
            .locatedBy("h1.page-title");

    public static final Target CREATE_BUTTON = Target
            .the("botón crear nuevo")
            .locatedBy("[data-testid='btn-create']");

    public static final Target SEARCH_INPUT = Target
            .the("campo de búsqueda")
            .located(By.id("search"));

    public static final Target RESULTS_TABLE = Target
            .the("tabla de resultados")
            .locatedBy("table.results-table");

    public static final Target FIRST_ROW = Target
            .the("primera fila de resultados")
            .locatedBy("table.results-table tbody tr:first-child");
}
