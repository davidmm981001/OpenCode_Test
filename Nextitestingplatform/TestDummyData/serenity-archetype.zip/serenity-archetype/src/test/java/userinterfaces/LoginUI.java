package userinterfaces;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

/**
 * ═══════════════════════════════════════════════════════════════
 * LoginUI - Targets de la página de Login (User Interface layer)
 * ═══════════════════════════════════════════════════════════════
 * En Screenplay, los locators se definen como Targets.
 * Son inmutables y descriptivos para los reportes.
 *
 * TODO: Reemplazar selectores con los de tu aplicación.
 */
public class LoginUI {

    public static final Target USERNAME_INPUT = Target
            .the("campo de usuario")
            .located(By.id("username"));

    public static final Target PASSWORD_INPUT = Target
            .the("campo de contraseña")
            .located(By.id("password"));

    public static final Target LOGIN_BUTTON = Target
            .the("botón de login")
            .locatedBy("button[type='submit']");

    public static final Target ERROR_MESSAGE = Target
            .the("mensaje de error")
            .locatedBy("[data-testid='error-message']");

    public static final Target WELCOME_MESSAGE = Target
            .the("mensaje de bienvenida")
            .locatedBy("[data-testid='welcome']");

    public static final Target LOGOUT_BUTTON = Target
            .the("botón de logout")
            .locatedBy("[data-testid='logout']");
}
