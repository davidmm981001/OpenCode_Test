package tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.thucydides.core.annotations.Step;
import userinterfaces.LoginUI;

import static net.serenitybdd.screenplay.Tasks.instrumented;

/**
 * ═══════════════════════════════════════════════════════════════
 * LoginOnTheApp - Task: Iniciar sesión en la aplicación
 * ═══════════════════════════════════════════════════════════════
 * Screenplay Pattern: Un Task encapsula una acción de negocio
 * que un Actor realiza (compuesta de Interactions).
 *
 * Uso en Steps:
 *   actor.attemptsTo(LoginOnTheApp.withCredentials("user", "pass"));
 */
public class LoginOnTheApp implements Task {

    private final String username;
    private final String password;

    public LoginOnTheApp(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public static LoginOnTheApp withCredentials(String username, String password) {
        return instrumented(LoginOnTheApp.class, username, password);
    }

    @Override
    @Step("{0} inicia sesión con usuario '#username'")
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Enter.theValue(username).into(LoginUI.USERNAME_INPUT),
                Enter.theValue(password).into(LoginUI.PASSWORD_INPUT),
                Click.on(LoginUI.LOGIN_BUTTON)
        );
    }
}
