package tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Delete;
import net.serenitybdd.screenplay.rest.interactions.Get;
import net.serenitybdd.screenplay.rest.interactions.Post;
import net.serenitybdd.screenplay.rest.interactions.Put;
import net.thucydides.core.annotations.Step;

import java.util.Map;

import static net.serenitybdd.screenplay.Tasks.instrumented;

/**
 * ═══════════════════════════════════════════════════════════════
 * ApiRequest - Tasks para operaciones REST (Screenplay REST)
 * ═══════════════════════════════════════════════════════════════
 *
 * Uso:
 *   actor.attemptsTo(ApiRequest.postTo("/resource").withBody(payload));
 *   actor.attemptsTo(ApiRequest.getFrom("/resource/123"));
 *   actor.attemptsTo(ApiRequest.putTo("/resource/123").withBody(payload));
 *   actor.attemptsTo(ApiRequest.deleteFrom("/resource/123"));
 */
public class ApiRequest {

    // ─── POST ───
    public static PostRequest postTo(String endpoint) {
        return new PostRequest(endpoint);
    }

    // ─── GET ───
    public static GetRequest getFrom(String endpoint) {
        return new GetRequest(endpoint);
    }

    // ─── GET con parámetros ───
    public static GetWithParamsRequest getFrom(String endpoint, Map<String, ?> params) {
        return new GetWithParamsRequest(endpoint, params);
    }

    // ─── PUT ───
    public static PutRequest putTo(String endpoint) {
        return new PutRequest(endpoint);
    }

    // ─── DELETE ───
    public static DeleteRequest deleteFrom(String endpoint) {
        return new DeleteRequest(endpoint);
    }

    // ═══════════════════════════════════════════════════════════

    public static class PostRequest implements Task {
        private final String endpoint;
        private Object body;

        public PostRequest(String endpoint) { this.endpoint = endpoint; }
        public PostRequest withBody(Object body) { this.body = body; return this; }

        @Override
        @Step("{0} envía POST a '#endpoint'")
        public <T extends Actor> void performAs(T actor) {
            actor.attemptsTo(
                    Post.to(endpoint)
                            .with(spec -> spec.header("Content-Type", "application/json")
                                    .body(body))
            );
        }
    }

    public static class GetRequest implements Task {
        private final String endpoint;
        public GetRequest(String endpoint) { this.endpoint = endpoint; }

        @Override
        @Step("{0} envía GET a '#endpoint'")
        public <T extends Actor> void performAs(T actor) {
            actor.attemptsTo(Get.resource(endpoint));
        }
    }

    public static class GetWithParamsRequest implements Task {
        private final String endpoint;
        private final Map<String, ?> params;
        public GetWithParamsRequest(String endpoint, Map<String, ?> params) {
            this.endpoint = endpoint;
            this.params = params;
        }

        @Override
        @Step("{0} envía GET a '#endpoint' con parámetros")
        public <T extends Actor> void performAs(T actor) {
            actor.attemptsTo(
                    Get.resource(endpoint).with(spec -> spec.queryParams(params))
            );
        }
    }

    public static class PutRequest implements Task {
        private final String endpoint;
        private Object body;
        public PutRequest(String endpoint) { this.endpoint = endpoint; }
        public PutRequest withBody(Object body) { this.body = body; return this; }

        @Override
        @Step("{0} envía PUT a '#endpoint'")
        public <T extends Actor> void performAs(T actor) {
            actor.attemptsTo(
                    Put.to(endpoint)
                            .with(spec -> spec.header("Content-Type", "application/json")
                                    .body(body))
            );
        }
    }

    public static class DeleteRequest implements Task {
        private final String endpoint;
        public DeleteRequest(String endpoint) { this.endpoint = endpoint; }

        @Override
        @Step("{0} envía DELETE a '#endpoint'")
        public <T extends Actor> void performAs(T actor) {
            actor.attemptsTo(Delete.from(endpoint));
        }
    }
}
