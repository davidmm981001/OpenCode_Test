package tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Open;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.screenplay.Tasks.instrumented;

/**
 * ═══════════════════════════════════════════════════════════════
 * NavigateTo - Task: Navegar a una URL/path
 * ═══════════════════════════════════════════════════════════════
 *
 * Uso:
 *   actor.attemptsTo(NavigateTo.thePage("/login"));
 */
public class NavigateTo implements Task {

    private final String path;

    public NavigateTo(String path) {
        this.path = path;
    }

    public static NavigateTo thePage(String path) {
        return instrumented(NavigateTo.class, path);
    }

    public static NavigateTo theLoginPage() {
        return instrumented(NavigateTo.class, "/login");
    }

    public static NavigateTo theDashboard() {
        return instrumented(NavigateTo.class, "/dashboard");
    }

    @Override
    @Step("{0} navega a la página '#path'")
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Open.url(path));
    }
}
