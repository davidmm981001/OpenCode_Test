package questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.rest.questions.LastResponse;

/**
 * ═══════════════════════════════════════════════════════════════
 * ApiQuestions - Preguntas sobre respuestas de API
 * ═══════════════════════════════════════════════════════════════
 *
 * Uso:
 *   actor.should(seeThat(ApiQuestions.responseStatusCode(), equalTo(200)));
 *   actor.should(seeThat(ApiQuestions.responseField("name"), equalTo("Test")));
 */
public class ApiQuestions {

    public static Question<Integer> responseStatusCode() {
        return actor -> LastResponse.received().answeredBy(actor).statusCode();
    }

    public static Question<String> responseField(String jsonPath) {
        return actor -> LastResponse.received().answeredBy(actor)
                .jsonPath().getString(jsonPath);
    }

    public static Question<Object> responseFieldAsObject(String jsonPath) {
        return actor -> LastResponse.received().answeredBy(actor)
                .jsonPath().get(jsonPath);
    }

    public static Question<String> responseBody() {
        return actor -> LastResponse.received().answeredBy(actor)
                .body().asString();
    }

    public static Question<Integer> responseFieldAsInt(String jsonPath) {
        return actor -> LastResponse.received().answeredBy(actor)
                .jsonPath().getInt(jsonPath);
    }

    public static Question<Boolean> responseContainsField(String jsonPath) {
        return actor -> {
            Object value = LastResponse.received().answeredBy(actor)
                    .jsonPath().get(jsonPath);
            return value != null;
        };
    }
}
