package questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;
import net.serenitybdd.screenplay.questions.Visibility;
import userinterfaces.LoginUI;

/**
 * ═══════════════════════════════════════════════════════════════
 * LoginQuestions - Preguntas sobre la página de Login
 * ═══════════════════════════════════════════════════════════════
 * En Screenplay, las Questions extraen información del estado
 * actual de la aplicación para hacer assertions.
 *
 * Uso:
 *   actor.should(seeThat(LoginQuestions.errorMessage(), equalTo("Invalid")));
 *   actor.should(seeThat(LoginQuestions.isErrorVisible(), is(true)));
 */
public class LoginQuestions {

    public static Question<String> errorMessage() {
        return actor -> Text.of(LoginUI.ERROR_MESSAGE).answeredBy(actor);
    }

    public static Question<Boolean> isErrorVisible() {
        return actor -> Visibility.of(LoginUI.ERROR_MESSAGE).answeredBy(actor);
    }

    public static Question<Boolean> isWelcomeVisible() {
        return actor -> Visibility.of(LoginUI.WELCOME_MESSAGE).answeredBy(actor);
    }

    public static Question<String> welcomeMessage() {
        return actor -> Text.of(LoginUI.WELCOME_MESSAGE).answeredBy(actor);
    }

    public static Question<Boolean> isLoginFormVisible() {
        return actor -> Visibility.of(LoginUI.USERNAME_INPUT).answeredBy(actor)
                && Visibility.of(LoginUI.PASSWORD_INPUT).answeredBy(actor)
                && Visibility.of(LoginUI.LOGIN_BUTTON).answeredBy(actor);
    }
}
