package helpers;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.*;
import java.util.*;

/**
 * ═══════════════════════════════════════════════════════════════
 * DataLoader - JSON, CSV, Excel
 * ═══════════════════════════════════════════════════════════════
 */
public class DataLoader {

    private static final ObjectMapper mapper = new ObjectMapper();

    @SuppressWarnings("unchecked")
    public static Map<String, Object> fromJson(String filename) {
        try (InputStream is = getResource("data/json/" + filename)) {
            return mapper.readValue(is, Map.class);
        } catch (Exception e) {
            throw new RuntimeException("Error leyendo JSON: " + e.getMessage(), e);
        }
    }

    public static <T> T fromJson(String filename, Class<T> type) {
        try (InputStream is = getResource("data/json/" + filename)) {
            return mapper.readValue(is, type);
        } catch (Exception e) {
            throw new RuntimeException("Error leyendo JSON: " + e.getMessage(), e);
        }
    }

    public static List<Map<String, String>> fromCsv(String filename) {
        List<Map<String, String>> data = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(getResource("data/csv/" + filename)))) {
            String headerLine = br.readLine();
            if (headerLine == null) return data;
            String[] headers = headerLine.split(",");
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] values = line.split(",", -1);
                Map<String, String> row = new LinkedHashMap<>();
                for (int i = 0; i < headers.length; i++) {
                    row.put(headers[i].trim(), i < values.length ? values[i].trim() : "");
                }
                data.add(row);
            }
        } catch (Exception e) {
            throw new RuntimeException("Error leyendo CSV: " + e.getMessage(), e);
        }
        return data;
    }

    public static List<Map<String, Object>> fromExcel(String filename, String sheetName) {
        List<Map<String, Object>> data = new ArrayList<>();
        try (InputStream is = getResource("data/excel/" + filename);
             Workbook wb = new XSSFWorkbook(is)) {
            Sheet sheet = wb.getSheet(sheetName);
            if (sheet == null) throw new RuntimeException("Hoja no encontrada: " + sheetName);
            Row header = sheet.getRow(0);
            List<String> headers = new ArrayList<>();
            for (Cell c : header) headers.add(c.getStringCellValue().trim());
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;
                Map<String, Object> m = new LinkedHashMap<>();
                for (int j = 0; j < headers.size(); j++) {
                    Cell c = row.getCell(j, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                    m.put(headers.get(j), getCellValue(c));
                }
                data.add(m);
            }
        } catch (Exception e) {
            throw new RuntimeException("Error leyendo Excel: " + e.getMessage(), e);
        }
        return data;
    }

    private static InputStream getResource(String path) {
        InputStream is = DataLoader.class.getClassLoader().getResourceAsStream(path);
        if (is == null) throw new RuntimeException("Recurso no encontrado: " + path);
        return is;
    }

    private static Object getCellValue(Cell cell) {
        if (cell == null) return "";
        switch (cell.getCellType()) {
            case STRING:  return cell.getStringCellValue().trim();
            case NUMERIC:
                double n = cell.getNumericCellValue();
                if (n == Math.floor(n) && !Double.isInfinite(n)) return (long) n;
                return n;
            case BOOLEAN: return cell.getBooleanCellValue();
            default:      return "";
        }
    }
}
