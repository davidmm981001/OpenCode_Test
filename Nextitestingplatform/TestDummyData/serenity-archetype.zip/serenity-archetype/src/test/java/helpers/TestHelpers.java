package helpers;

import java.util.UUID;

/**
 * ═══════════════════════════════════════════════════════════════
 * TestHelpers - Utilidades comunes
 * ═══════════════════════════════════════════════════════════════
 */
public class TestHelpers {

    public static int generateId() {
        return (int) (Math.random() * 900000) + 100000;
    }

    public static String randomName(String prefix) {
        return prefix + "_" + UUID.randomUUID().toString().substring(0, 8);
    }

    public static String randomEmail() {
        return "test_" + UUID.randomUUID().toString().substring(0, 8) + "@test.com";
    }

    public static String timestamp() {
        return java.time.Instant.now().toString();
    }
}
