package steps;

import helpers.TestHelpers;
import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.serenitybdd.screenplay.rest.questions.LastResponse;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;
import questions.ApiQuestions;
import tasks.ApiRequest;

import java.util.HashMap;
import java.util.Map;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static org.hamcrest.Matchers.*;

/**
 * ═══════════════════════════════════════════════════════════════
 * ApiResourceSteps - Screenplay REST Steps para resource-api.feature
 * ═══════════════════════════════════════════════════════════════
 * Usa Screenplay REST:
 *   Actor → attemptsTo(ApiRequest.postTo(...)) → should(seeThat(ApiQuestions...))
 *
 * TODO: Reemplazar "/resource" con el endpoint real de tu API.
 */
public class ApiResourceSteps {

    private Actor actor;
    private String savedId;
    private static final String ENDPOINT = "/resource";

    @Before("@api")
    public void setUp() {
        EnvironmentVariables env = SystemEnvironmentVariables.createEnvironmentVariables();
        String apiBaseUrl = env.getProperty("restapi.baseurl",
                "https://qa-api.yourcompany.com/api/v1");

        actor = Actor.named("El consumidor API");
        actor.whoCan(CallAnApi.at(apiBaseUrl));
    }

    // ─── Given ───

    @Given("el actor tiene acceso a la API")
    public void elActorTieneAccesoALaApi() {
        // Setup ya hecho en @Before
    }

    @Given("el actor ha creado un recurso previamente")
    public void elActorHaCreadoUnRecursoPreviamente() {
        Map<String, Object> payload = new HashMap<>();
        payload.put("id", TestHelpers.generateId());
        payload.put("name", TestHelpers.randomName("Precondition"));
        payload.put("status", "active");

        actor.attemptsTo(ApiRequest.postTo(ENDPOINT).withBody(payload));

        savedId = LastResponse.received().answeredBy(actor)
                .jsonPath().getString("id");
    }

    // ─── When: POST ───

    @When("el actor crea un recurso con nombre {string} y status {string}")
    public void elActorCreaUnRecurso(String name, String status) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("id", TestHelpers.generateId());
        payload.put("name", name);
        payload.put("status", status);

        actor.attemptsTo(ApiRequest.postTo(ENDPOINT).withBody(payload));
    }

    // ─── When: GET ───

    @When("el actor consulta el recurso por su ID")
    public void elActorConsultaElRecursoPorSuId() {
        actor.attemptsTo(ApiRequest.getFrom(ENDPOINT + "/" + savedId));
    }

    @When("el actor consulta el recurso con ID {string}")
    public void elActorConsultaElRecursoConId(String id) {
        actor.attemptsTo(ApiRequest.getFrom(ENDPOINT + "/" + id));
    }

    @When("el actor busca recursos con status {string}")
    public void elActorBuscaRecursosConStatus(String status) {
        Map<String, Object> params = new HashMap<>();
        params.put("status", status);
        actor.attemptsTo(ApiRequest.getFrom(ENDPOINT, params));
    }

    // ─── When: PUT ───

    @When("el actor actualiza el recurso con nombre {string} y status {string}")
    public void elActorActualizaElRecurso(String name, String status) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("name", name);
        payload.put("status", status);

        actor.attemptsTo(ApiRequest.putTo(ENDPOINT + "/" + savedId).withBody(payload));
    }

    // ─── When: DELETE ───

    @When("el actor elimina el recurso")
    public void elActorEliminaElRecurso() {
        actor.attemptsTo(ApiRequest.deleteFrom(ENDPOINT + "/" + savedId));
    }

    // ─── Then ───

    @Then("el código de respuesta debe ser {int}")
    public void elCodigoDeRespuestaDebeser(int expectedStatus) {
        actor.should(seeThat(ApiQuestions.responseStatusCode(), equalTo(expectedStatus)));
    }

    @Then("la respuesta contiene el campo {string}")
    public void laRespuestaContieneElCampo(String field) {
        actor.should(seeThat(ApiQuestions.responseContainsField(field), is(true)));
    }

    @Then("la respuesta contiene {string} igual a {string}")
    public void laRespuestaContieneIgualA(String field, String expectedValue) {
        actor.should(seeThat(ApiQuestions.responseField(field), equalTo(expectedValue)));
    }

    @Then("guarda el ID de la respuesta")
    public void guardaElIdDeLaRespuesta() {
        savedId = LastResponse.received().answeredBy(actor)
                .jsonPath().getString("id");
    }
}
