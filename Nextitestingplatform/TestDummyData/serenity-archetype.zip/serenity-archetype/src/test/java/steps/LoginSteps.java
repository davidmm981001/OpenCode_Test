package steps;

import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Open;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;
import questions.LoginQuestions;
import tasks.LoginOnTheApp;
import userinterfaces.LoginUI;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static org.hamcrest.Matchers.*;

/**
 * ═══════════════════════════════════════════════════════════════
 * LoginSteps - Screenplay Steps para login.feature
 * ═══════════════════════════════════════════════════════════════
 * Usa el patrón Screenplay:
 *   Actor → attemptsTo(Task) → should(seeThat(Question))
 */
public class LoginSteps {

    @Managed
    private WebDriver browser;

    private Actor actor;

    @Before("@ui")
    public void setUp() {
        actor = Actor.named("El usuario");
        actor.can(BrowseTheWeb.with(browser));
    }

    // ─── Given ───

    @Given("el actor está en la página de login")
    public void elActorEstaEnLaPaginaDeLogin() {
        actor.attemptsTo(Open.browserOn().the(loginPage()));
    }

    // ─── When ───

    @When("inicia sesión con usuario {string} y contraseña {string}")
    public void iniciaSesionConCredenciales(String username, String password) {
        actor.attemptsTo(LoginOnTheApp.withCredentials(username, password));
    }

    @When("el actor cierra sesión")
    public void elActorCierraSesion() {
        actor.attemptsTo(Click.on(LoginUI.LOGOUT_BUTTON));
    }

    // ─── Then ───

    @Then("debe ser redirigido al dashboard")
    public void debeSerRedirigidoAlDashboard() {
        // TODO: Adaptar la URL esperada
        // actor.should(seeThat(CurrentUrl.value(), containsString("/dashboard")));
    }

    @Then("debe ver el mensaje de bienvenida")
    public void debeVerMensajeDeBienvenida() {
        actor.should(seeThat(LoginQuestions.isWelcomeVisible(), is(true)));
    }

    @Then("debe ver un mensaje de error en pantalla")
    public void debeVerMensajeDeError() {
        actor.should(seeThat(LoginQuestions.isErrorVisible(), is(true)));
    }

    @Then("debe estar en la página de login")
    public void debeEstarEnLogin() {
        actor.should(seeThat(LoginQuestions.isLoginFormVisible(), is(true)));
    }

    @Then("el resultado del login es {string}")
    public void elResultadoDelLoginEs(String resultado) {
        if ("exitoso".equals(resultado)) {
            // actor.should(seeThat(CurrentUrl.value(), containsString("/dashboard")));
        } else {
            actor.should(seeThat(LoginQuestions.isErrorVisible(), is(true)));
        }
    }

    // ─── Helpers ───

    private net.serenitybdd.core.pages.PageObject loginPage() {
        return new net.serenitybdd.core.pages.PageObject() {};
    }
}
