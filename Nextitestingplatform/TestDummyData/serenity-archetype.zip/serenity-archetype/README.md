# 🎬 Serenity BDD Framework — Arquetipo

Arquetipo base para automatización de pruebas **UI + API** con **Serenity BDD** usando el **patrón Screenplay**.  
Combina Cucumber para Gherkin, Selenium para UI, y Serenity REST para API.

---

## 📁 Estructura

```
serenity-bdd-framework/
├── build.gradle                                   # Dependencias + plugin Serenity
├── serenity.properties                            # Config WebDriver, screenshots, reportes
├── serenity.conf                                  # Ambientes (dev, qa, staging)
│
└── src/test/
    ├── java/
    │   ├── runner/
    │   │   └── TestRunner.java                    # Suite JUnit5 Platform
    │   │
    │   ├── steps/                                 # Step Definitions (glue)
    │   │   ├── LoginSteps.java                    # Steps UI → Screenplay
    │   │   └── ApiResourceSteps.java              # Steps API → Screenplay REST
    │   │
    │   ├── tasks/                                 # TASKS: Qué hace el actor
    │   │   ├── LoginOnTheApp.java                 # Task: iniciar sesión
    │   │   ├── NavigateTo.java                    # Task: navegar a una página
    │   │   └── ApiRequest.java                    # Tasks: POST/GET/PUT/DELETE
    │   │
    │   ├── questions/                             # QUESTIONS: Qué observa el actor
    │   │   ├── LoginQuestions.java                # ¿Error visible? ¿Bienvenida?
    │   │   └── ApiQuestions.java                  # ¿Status code? ¿Campo en JSON?
    │   │
    │   ├── userinterfaces/                        # UI: Targets (locators)
    │   │   ├── LoginUI.java                       # Targets del login
    │   │   └── DashboardUI.java                   # Targets del dashboard
    │   │
    │   └── helpers/
    │       ├── DataLoader.java                    # JSON, CSV, Excel
    │       └── TestHelpers.java                   # IDs, nombres, timestamps
    │
    └── resources/
        ├── cucumber.properties                    # Glue + plugin Serenity
        │
        ├── features/sample/                       # Features Gherkin
        │   ├── login.feature                      # UI: login
        │   └── resource-api.feature               # API: CRUD
        │
        ├── data/                                  # Datos de prueba
        │   ├── json/ · csv/ · excel/
        │
        └── schemas/                               # JSON Schemas
```

---

## 🎭 Patrón Screenplay

Serenity BDD implementa el **patrón Screenplay** (también llamado Journey pattern), que organiza el código en 5 capas:

```
Feature (Gherkin)
  └─ Steps (glue code)
       └─ Tasks (acciones de negocio)           → "Qué hace el actor"
            └─ Interactions (acciones atómicas)  → "Cómo lo hace" (Click, Enter, Get...)
       └─ Questions (verificaciones)             → "Qué observa el actor"
            └─ Targets (User Interfaces)         → "Dónde mira" (locators)
```

### ¿Por qué Screenplay?

| Aspecto | Page Object tradicional | Screenplay |
|---------|------------------------|------------|
| Quién actúa | Test llama métodos | Actor ejecuta Tasks |
| Legibilidad | `loginPage.login(u,p)` | `actor.attemptsTo(LoginOnTheApp.withCredentials(u,p))` |
| Reutilización | Herencia de clases | Composición de Tasks |
| Reportes | Genéricos | Cada paso se documenta automáticamente |
| API + UI | Separados | Mismo Actor, misma sintaxis |

---

## 🚀 Inicio Rápido

### 1. Compilar

```bash
gradle build -x test
```

### 2. Configurar

Edita `serenity.conf` con las URLs de tu aplicación:

```hocon
qa {
  webdriver.base.url = "https://tu-app.com"
  restapi.baseurl    = "https://api.tu-app.com/v1"
}
```

### 3. Ejecutar

```bash
gradle test                  # Todos los tests
gradle smoke                 # Solo @smoke
gradle api                   # Solo @api
gradle e2e                   # Solo @e2e
```

### 4. Ver reportes

```bash
# El reporte se genera automáticamente al final
open target/site/serenity/index.html
```

---

## 📋 Comandos Completos

### Por tipo

| Comando | Qué ejecuta |
|---------|-------------|
| `gradle test` | Todos (excepto `@ignore`) |
| `gradle smoke` | Solo `@smoke` |
| `gradle regression` | Solo `@regression` |
| `gradle api` | Solo `@api` |
| `gradle e2e` | Solo `@e2e` |

### Por ambiente

```bash
gradle test -Denv=dev
gradle test -Denv=qa            # default
gradle test -Denv=staging
```

### Por browser

```bash
gradle test -Dwebdriver.driver=chrome        # default
gradle test -Dwebdriver.driver=firefox
gradle test -Dwebdriver.driver=edge
gradle test -Dchrome.switches="--headless=new,--no-sandbox"
```

### Por tags

```bash
gradle test -Dcucumber.filter.tags="@smoke"
gradle test -Dcucumber.filter.tags="@smoke and @ui"
gradle test -Dcucumber.filter.tags="@regression and not @negative"
```

---

## 📊 Reportes

Serenity BDD genera **Living Documentation** automáticamente:

| Reporte | Ubicación |
|---------|-----------|
| Serenity HTML (full) | `target/site/serenity/index.html` |
| Single Page | `target/site/serenity/serenity-summary.html` |
| Screenshots | Embebidos en el reporte (por paso) |
| Estadísticas | Tags, features, duración, tendencias |

El reporte incluye: resultados por feature, por tag, por historia de usuario, capturas de pantalla paso a paso, y documentación viva del sistema.

---

## 🏗️ Cómo Agregar un Nuevo Módulo

### 1. Crear Targets (User Interface)

```java
// userinterfaces/ProductUI.java
public class ProductUI {
    public static final Target NAME_INPUT = Target
            .the("nombre del producto")
            .located(By.id("product-name"));

    public static final Target SAVE_BUTTON = Target
            .the("botón guardar")
            .locatedBy("[data-testid='save']");
}
```

### 2. Crear Task

```java
// tasks/CreateProduct.java
public class CreateProduct implements Task {
    private final String name;

    public CreateProduct(String name) { this.name = name; }

    public static CreateProduct withName(String name) {
        return instrumented(CreateProduct.class, name);
    }

    @Override
    @Step("{0} crea el producto '#name'")
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
            Enter.theValue(name).into(ProductUI.NAME_INPUT),
            Click.on(ProductUI.SAVE_BUTTON)
        );
    }
}
```

### 3. Crear Question

```java
// questions/ProductQuestions.java
public class ProductQuestions {
    public static Question<String> productName() {
        return actor -> Text.of(ProductUI.NAME_INPUT).answeredBy(actor);
    }
}
```

### 4. Escribir el Feature

```gherkin
@ui @regression @products
Feature: Gestión de productos

  @smoke
  Scenario: Crear producto exitosamente
    Given el actor está en la página de productos
    When crea un producto con nombre "Widget Pro"
    Then el producto se muestra en la lista
```

### 5. Crear Step Definitions

```java
// steps/ProductSteps.java
@When("crea un producto con nombre {string}")
public void creaUnProducto(String name) {
    actor.attemptsTo(CreateProduct.withName(name));
}
```

---

## 📋 Cómo Cargar Datos de Prueba

### JSON

```java
Map<String, Object> data = DataLoader.fromJson("sample-data.json");
```

### CSV

```java
List<Map<String, String>> rows = DataLoader.fromCsv("sample-data.csv");
```

### Excel

```java
List<Map<String, Object>> rows = DataLoader.fromExcel("data.xlsx", "Sheet1");
```

### DataTable de Cucumber

```gherkin
When crea un recurso con:
  | name   | Mi recurso |
  | status | active     |
```

---

## 🏷️ Tags

| Tag | Propósito |
|-----|-----------|
| `@ui` | Tests con browser (Selenium) |
| `@api` | Tests REST sin browser |
| `@smoke` | Mínimos críticos |
| `@regression` | Suite completa |
| `@e2e` | Flujos end-to-end |
| `@negative` | Manejo de errores |
| `@data-driven` | Parametrizados |
| `@ignore` | Excluir |

---

## 🔑 Buenas Prácticas

1. **Screenplay siempre**: Usa Tasks para acciones, Questions para validaciones, nunca accedas al driver directo desde Steps.
2. **Targets descriptivos**: El nombre del Target aparece en los reportes → `Target.the("botón de envío")` no `Target.the("btn1")`.
3. **Tasks compuestas**: Un Task puede invocar otros Tasks → `CreateAndPublishArticle` llama `CreateArticle` + `PublishArticle`.
4. **Un Step = Un performAs o seeThat**: Mantén Steps delgados, la lógica va en Tasks/Questions.
5. **API para precondiciones**: Usa `@Given` con `ApiRequest` para crear datos rápido, luego valida en UI.
6. **serenity.conf para ambientes**: Nunca hardcodees URLs en el código.

---

## ⚙️ Requisitos

- Java 11+
- Gradle 8+
- Chrome, Firefox o Edge (WebDriver se descarga automáticamente)
