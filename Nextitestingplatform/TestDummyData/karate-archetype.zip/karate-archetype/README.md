# 🧪 Karate API Testing Framework — Arquetipo

Arquetipo base para automatización de pruebas API con **Karate DSL** + **Gradle**.  
Listo para clonar, configurar tu API y empezar a escribir features.

---

## 📁 Estructura

```
karate-api-framework/
├── build.gradle                               # Dependencias y tareas Gradle
├── settings.gradle                            # Nombre del proyecto
├── gradle/wrapper/                            # Wrapper de Gradle
│
└── src/test/
    ├── java/runner/
    │   ├── TestRunner.java                    # Runner JUnit5 (paralelo, tags)
    │   └── ExcelDataReader.java               # Helper para leer .xlsx
    │
    └── resources/
        ├── karate-config.js                   # Config multi-ambiente
        ├── logback-test.xml                   # Logs
        │
        ├── features/                          # Tus features organizados por módulo
        │   └── sample/
        │       └── sample-crud.feature        # Template CRUD completo
        │
        ├── data/                              # Datos de prueba
        │   ├── json/                          # Payloads y datos estructurados
        │   ├── csv/                           # Datos para Scenario Outline
        │   └── excel/                         # Datos .xlsx (via ExcelDataReader)
        │
        ├── helpers/                           # Features reutilizables (@ignore)
        │   └── create-resource.feature
        │
        └── schemas/                           # Schemas para Contract Testing
            └── sample-schema.json
```

---

## Inicio Rápido

### 1. Configurar tu API
Edita `karate-config.js` y reemplaza las URLs por las de tu proyecto:
```javascript
config.baseUrl = 'https://tu-api.com/api/v1';
```

### 2. Ejecutar tests

```bash
# Todos los tests
gradle test

# Por ambiente
gradle test -Dkarate.env=dev
gradle test -Dkarate.env=qa
gradle test -Dkarate.env=staging

# Por tipo (tareas personalizadas)
gradle smoke                    # Solo @smoke
gradle regression               # Solo @regression
gradle e2e                      # Solo @e2e
gradle negative                 # Solo @negative

# Por tag específico
gradle test -Dkarate.options="--tags @post"
gradle test -Dkarate.options="--tags @get and @smoke"
gradle test -Dkarate.options="--tags ~@ignore"

# Feature individual
gradle test -Dkarate.options="classpath:features/sample/sample-crud.feature"
```

### 3. Ver reportes
```
build/karate-reports/karate-summary.html
```

---

## Tags disponibles

| Tag             | Propósito                                    |
|-----------------|----------------------------------------------|
| `@smoke`        | Tests mínimos críticos (cada deploy)         |
| `@regression`   | Suite completa de regresión                  |
| `@e2e`          | Flujos end-to-end                            |
| `@negative`     | Manejo de errores y casos límite             |
| `@data-driven`  | Tests parametrizados                         |
| `@csv`          | Tests con datos CSV externos                 |
| `@excel`        | Tests con datos Excel                        |
| `@contract`     | Validación de schema                         |
| `@get` `@post` `@put` `@delete` | Por método HTTP          |
| `@ignore`       | Excluir de ejecución                         |

---

## Cómo cargar datos de prueba

### JSON
```gherkin
* def data = read('classpath:data/json/mi-archivo.json')
* def item = data.miCampo
```

### CSV (en Scenario Outline)
```gherkin
Examples:
  | read('classpath:data/csv/mi-archivo.csv') |
```

### Excel
```gherkin
* def Excel = Java.type('runner.ExcelDataReader')
* def rows = Excel.read('data/excel/mi-archivo.xlsx', 'Sheet1')
# Con filtro:
* def activos = Excel.readFiltered('data/excel/mi-archivo.xlsx', 'Sheet1', 'status', 'active')
```

### Tabla inline
```gherkin
* table datos
  | id   | nombre  | estado      |
  | 1001 | 'Item1' | 'active'    |
  | 1002 | 'Item2' | 'inactive'  |
```

---

## Helpers reutilizables

```gherkin
# Llamar un helper pasando parámetros
* def result = call read('classpath:helpers/create-resource.feature') { payload: '#(miData)' }
* def id = result.response.id
```

---

##Cómo agregar un nuevo módulo

1. Crear carpeta: `features/mi-modulo/`
2. Crear feature: `mi-modulo-crud.feature`
3. Agregar datos: `data/json/mi-modulo-data.json`
4. Agregar schema: `schemas/mi-modulo-schema.json`
5. (Opcional) Agregar helper: `helpers/create-mi-modulo.feature`
6. Etiquetar con `@mi-modulo` para filtrar

---

## Requisitos

- Java 11+
- Gradle 8+ (o usar el wrapper incluido: `./gradlew test`)
