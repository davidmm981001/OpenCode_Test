package runner;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.InputStream;
import java.util.*;

/**
 * ═══════════════════════════════════════════════════════════════
 * ExcelDataReader - Leer datos de prueba desde archivos .xlsx
 * ═══════════════════════════════════════════════════════════════
 *
 * Uso desde Karate:
 *
 *   * def Excel = Java.type('runner.ExcelDataReader')
 *   * def rows  = Excel.read('data/excel/mi-archivo.xlsx', 'Sheet1')
 *   * def filtered = Excel.readFiltered('data/excel/mi-archivo.xlsx', 'Sheet1', 'status', 'active')
 *
 * Retorna: List<Map<String, Object>>
 *   - Cada Map es una fila del Excel
 *   - Los keys son los nombres de la primera fila (header)
 */
public class ExcelDataReader {

    public static List<Map<String, Object>> read(String filePath, String sheetName) {
        List<Map<String, Object>> data = new ArrayList<>();

        try (InputStream is = ExcelDataReader.class.getClassLoader().getResourceAsStream(filePath);
             Workbook workbook = new XSSFWorkbook(is)) {

            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                throw new RuntimeException("Hoja '" + sheetName + "' no encontrada en " + filePath);
            }

            Row headerRow = sheet.getRow(0);
            List<String> headers = new ArrayList<>();
            for (Cell cell : headerRow) {
                headers.add(cell.getStringCellValue().trim());
            }

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                Map<String, Object> rowMap = new LinkedHashMap<>();
                for (int j = 0; j < headers.size(); j++) {
                    Cell cell = row.getCell(j, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                    rowMap.put(headers.get(j), getCellValue(cell));
                }
                data.add(rowMap);
            }

        } catch (Exception e) {
            throw new RuntimeException("Error leyendo Excel [" + filePath + "]: " + e.getMessage(), e);
        }
        return data;
    }

    public static List<Map<String, Object>> readFiltered(
            String filePath, String sheetName, String filterCol, String filterVal) {
        List<Map<String, Object>> allData = read(filePath, sheetName);
        List<Map<String, Object>> filtered = new ArrayList<>();
        for (Map<String, Object> row : allData) {
            Object val = row.get(filterCol);
            if (val != null && val.toString().equals(filterVal)) {
                filtered.add(row);
            }
        }
        return filtered;
    }

    private static Object getCellValue(Cell cell) {
        if (cell == null) return "";
        switch (cell.getCellType()) {
            case STRING:  return cell.getStringCellValue().trim();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) return cell.getDateCellValue().toString();
                double num = cell.getNumericCellValue();
                if (num == Math.floor(num) && !Double.isInfinite(num)) return (long) num;
                return num;
            case BOOLEAN: return cell.getBooleanCellValue();
            case FORMULA:
                try { return cell.getStringCellValue(); }
                catch (Exception e) { return cell.getNumericCellValue(); }
            default: return "";
        }
    }
}
