package runner;

import com.intuit.karate.Results;
import com.intuit.karate.Runner;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

/**
 * ═══════════════════════════════════════════════════════════════
 * RUNNER PRINCIPAL
 * ═══════════════════════════════════════════════════════════════
 *
 * Ejecución:
 *   gradle test                                 → Todos los tests
 *   gradle test -Dkarate.env=qa                 → Ambiente QA
 *   gradle smoke                                → Solo @smoke
 *   gradle regression                           → Solo @regression
 *   gradle test -Dkarate.options="--tags @e2e"  → Solo @e2e
 *
 * Reporte: build/karate-reports/karate-summary.html
 */
class TestRunner {

    @Test
    void runAllTests() {
        Results results = Runner.path("classpath:features")
                .tags("~@ignore")
                .outputCucumberJson(true)
                .parallel(5);

        System.out.println("══════════════════════════════════════════");
        System.out.println("  RESUMEN DE EJECUCIÓN");
        System.out.println("══════════════════════════════════════════");
        System.out.println("  Features  : " + results.getFeaturesTotal());
        System.out.println("  Scenarios : " + results.getScenariosTotal());
        System.out.println("  Pasados   : " + results.getScenariosPassed());
        System.out.println("  Fallidos  : " + results.getScenariosFailed());
        System.out.println("  Tiempo    : " + results.getElapsedTime() + " ms");
        System.out.println("══════════════════════════════════════════");
        System.out.println("  Reporte: build/karate-reports/karate-summary.html");
        System.out.println("══════════════════════════════════════════");

        assertEquals(0, results.getFailCount(), results.getErrorMessages());
    }
}
