@ignore
Feature: Helper - Crear recurso (reutilizable)

  # ═══════════════════════════════════════════════════════════════
  # Uso desde otros features:
  #   * def result = call read('classpath:helpers/create-resource.feature') { payload: '#(myData)' }
  #   * def id = result.response.id
  # ═══════════════════════════════════════════════════════════════

  Scenario: Crear recurso via POST
    Given url baseUrl
    And path '/recurso'
    And request payload
    When method POST
    Then status 201
