/*
 * ═══════════════════════════════════════════════════════════════
 * KARATE-CONFIG.JS - Configuración Global del Framework
 * ═══════════════════════════════════════════════════════════════
 * Se ejecuta ANTES de cada Feature/Scenario.
 * Define variables globales, headers y configuración por ambiente.
 *
 * Ambientes:  dev | qa | staging | prod
 * Uso:        gradle test -Dkarate.env=qa
 * ═══════════════════════════════════════════════════════════════
 */
function fn() {

  var env = karate.env || 'qa';
  karate.log('══════════════════════════════════════');
  karate.log('  Ambiente activo: [' + env + ']');
  karate.log('══════════════════════════════════════');

  // ─── Configuración base (todos los ambientes) ───
  var config = {
    env: env,
    connectTimeout: 10000,
    readTimeout: 15000,
    globalHeaders: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    // Rutas a datos de prueba
    dataPath: 'classpath:data/',
    jsonDataPath: 'classpath:data/json/',
    csvDataPath: 'classpath:data/csv/',
    helpersPath: 'classpath:helpers/',
    schemasPath: 'classpath:schemas/'
  };

  // ─── Configuración por ambiente ───
  // TODO: Reemplazar URLs y credenciales con las de tu proyecto
  if (env === 'dev') {
    config.baseUrl = 'http://localhost:8080/api/v1';
    config.apiKey  = 'dev-key-12345';
  } else if (env === 'qa') {
    config.baseUrl = 'https://qa-api.yourcompany.com/api/v1';
    config.apiKey  = 'qa-key-67890';
  } else if (env === 'staging') {
    config.baseUrl = 'https://staging-api.yourcompany.com/api/v1';
    config.apiKey  = 'staging-key-abcde';
  } else if (env === 'prod') {
    config.baseUrl = 'https://api.yourcompany.com/api/v1';
    config.apiKey  = 'prod-readonly-key';
    config.readTimeout = 30000;
  }

  // ─── Timeouts y headers globales ───
  karate.configure('connectTimeout', config.connectTimeout);
  karate.configure('readTimeout', config.readTimeout);
  karate.configure('headers', config.globalHeaders);
  karate.configure('report', { showLog: true, showAllSteps: false });

  // ─── Helpers globales (disponibles en todos los features) ───

  /** Genera un ID numérico aleatorio de 6 dígitos */
  config.generateId = function() {
    return Math.floor(Math.random() * 900000) + 100000;
  };

  /** Retorna timestamp ISO 8601 actual */
  config.timestamp = function() {
    return new Date().toISOString();
  };

  /** Genera nombre único con prefijo: Test_a1b2c3d4 */
  config.randomName = function(prefix) {
    return (prefix || 'Test') + '_' + java.util.UUID.randomUUID().toString().substring(0, 8);
  };

  /** Genera UUID completo */
  config.uuid = function() {
    return java.util.UUID.randomUUID().toString();
  };

  karate.log('  Base URL: ' + config.baseUrl);
  karate.log('══════════════════════════════════════');

  return config;
}
