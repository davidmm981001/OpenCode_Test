@regression @sample
Feature: [MÓDULO] - Descripción funcional del feature
  Como [rol del usuario]
  Quiero [acción que desea realizar]
  Para [beneficio esperado]

  # ═══════════════════════════════════════════════════════════════
  # BACKGROUND: Se ejecuta antes de CADA Scenario.
  # Usa para: url base, carga de datos, autenticación compartida.
  # ═══════════════════════════════════════════════════════════════
  Background:
    * url baseUrl
    # Cargar datos desde JSON
    * def testData = read('classpath:data/json/sample-data.json')
    # Cargar schema para validación de contrato
    * def schema = read('classpath:schemas/sample-schema.json')

  # ─────────────────────────────────────────────────────────────
  # POST - Crear recurso
  # ─────────────────────────────────────────────────────────────
  @smoke @post
  Scenario: POST - Crear recurso exitosamente
    Given path '/recurso'
    And request testData.validPayload
    When method POST
    Then status 201
    And match response.id == '#notnull'
    # Validación de contrato
    And match response == schema.resourceSchema

  @post @negative
  Scenario: POST - Crear recurso con datos inválidos
    Given path '/recurso'
    And request testData.invalidPayload
    When method POST
    Then status 400
    And match response.message == '#string'

  # ─────────────────────────────────────────────────────────────
  # GET - Consultar recurso
  # ─────────────────────────────────────────────────────────────
  @smoke @get
  Scenario: GET - Consultar recurso por ID
    Given path '/recurso', testData.validPayload.id
    When method GET
    Then status 200
    And match response == schema.resourceSchema

  @get @negative
  Scenario: GET - Consultar recurso inexistente retorna 404
    Given path '/recurso', 999999999
    When method GET
    Then status 404

  # ─────────────────────────────────────────────────────────────
  # PUT - Actualizar recurso
  # ─────────────────────────────────────────────────────────────
  @smoke @put
  Scenario: PUT - Actualizar recurso existente
    * def updated = testData.validPayload
    * set updated.name = 'Nombre Actualizado'
    Given path '/recurso', updated.id
    And request updated
    When method PUT
    Then status 200
    And match response.name == 'Nombre Actualizado'

  # ─────────────────────────────────────────────────────────────
  # DELETE - Eliminar recurso
  # ─────────────────────────────────────────────────────────────
  @smoke @delete
  Scenario: DELETE - Eliminar recurso existente
    Given path '/recurso', testData.validPayload.id
    When method DELETE
    Then status 200

    # Verificar eliminación
    Given path '/recurso', testData.validPayload.id
    When method GET
    Then status 404

  # ─────────────────────────────────────────────────────────────
  # SCENARIO OUTLINE - Data-driven con tabla inline
  # ─────────────────────────────────────────────────────────────
  @data-driven
  Scenario Outline: GET - Buscar recursos por filtro "<filtro>"
    Given path '/recurso'
    And param filter = '<filtro>'
    When method GET
    Then status <expectedStatus>

    Examples:
      | filtro    | expectedStatus | descripcion                 |
      | active    | 200            | Filtro válido               |
      | inactive  | 200            | Filtro válido alternativo   |
      | invalid!  | 400            | Filtro con caracteres inv.  |

  # ─────────────────────────────────────────────────────────────
  # SCENARIO OUTLINE - Data-driven desde CSV externo
  # ─────────────────────────────────────────────────────────────
  @data-driven @csv
  Scenario Outline: POST - Crear recursos desde archivo CSV
    * def payload =
      """
      {
        "id": #(<id>),
        "name": "<name>",
        "status": "<status>"
      }
      """
    Given path '/recurso'
    And request payload
    When method POST
    Then status <expectedStatus>

    # El CSV debe tener columnas: id,name,status,expectedStatus
    Examples:
      | read('classpath:data/csv/sample-data.csv') |

  # ─────────────────────────────────────────────────────────────
  # SCENARIO OUTLINE - Data-driven desde Excel
  # ─────────────────────────────────────────────────────────────
  @data-driven @excel @ignore
  Scenario: POST - Crear recursos desde archivo Excel
    * def Excel = Java.type('runner.ExcelDataReader')
    * def rows = Excel.read('data/excel/sample-data.xlsx', 'Sheet1')
    * def createResource =
      """
      function(row) {
        var result = karate.call('classpath:helpers/create-resource.feature', { payload: row });
        return result.response;
      }
      """
    * def results = karate.map(rows, createResource)
    * match each results == { id: '#notnull' }

  # ─────────────────────────────────────────────────────────────
  # E2E - Flujo completo
  # ─────────────────────────────────────────────────────────────
  @e2e
  Scenario: E2E - Ciclo de vida completo del recurso
    # ── CREAR ──
    * def newResource =
      """
      {
        "id": #(generateId()),
        "name": #(randomName('Res')),
        "status": "active"
      }
      """
    Given path '/recurso'
    And request newResource
    When method POST
    Then status 201
    * def resourceId = response.id

    # ── CONSULTAR ──
    Given path '/recurso', resourceId
    When method GET
    Then status 200
    And match response.name == newResource.name

    # ── ACTUALIZAR ──
    * set newResource.status = 'inactive'
    Given path '/recurso', resourceId
    And request newResource
    When method PUT
    Then status 200
    And match response.status == 'inactive'

    # ── ELIMINAR ──
    Given path '/recurso', resourceId
    When method DELETE
    Then status 200

    # ── VERIFICAR ELIMINACIÓN ──
    Given path '/recurso', resourceId
    When method GET
    Then status 404
    * karate.log('>>> E2E completado. ID:', resourceId)
