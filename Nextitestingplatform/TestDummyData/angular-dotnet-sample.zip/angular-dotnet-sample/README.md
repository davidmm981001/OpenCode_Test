# Angular + .NET sample project

This is a very small full-stack sample with:

- **Frontend:** Angular standalone app
- **Backend:** .NET 8 Minimal API
- **Endpoints:** 4 endpoints total

## Backend endpoints

- `GET /api/health`
- `GET /api/products`
- `GET /api/products/{id}`
- `POST /api/products`
- `DELETE /api/products/{id}`

## Run the backend

```bash
cd backend
dotnet restore
dotnet run
```

The API will usually run at:

```bash
http://localhost:5008
```

## Run the frontend

```bash
cd frontend
npm install
npm start
```

The Angular app will usually run at:

```bash
http://localhost:4200
```

## Notes

- The backend uses an **in-memory list**, so data resets when the API restarts.
- CORS is enabled for `http://localhost:4200`.
- This is meant as a starter project you can extend.
