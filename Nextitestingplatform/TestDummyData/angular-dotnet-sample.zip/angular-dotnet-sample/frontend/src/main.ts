import { bootstrapApplication } from '@angular/platform-browser';
import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, provideHttpClient } from '@angular/common/http';

interface Product {
  id: number;
  name: string;
  price: number;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <main class="page">
      <section class="card">
        <h1>Angular + .NET Sample</h1>
        <p class="subtitle">A minimal frontend consuming a minimal API.</p>

        <form class="form" (ngSubmit)="addProduct()">
          <input
            type="text"
            name="name"
            [(ngModel)]="newName"
            placeholder="Product name"
            required
          />
          <input
            type="number"
            name="price"
            [(ngModel)]="newPrice"
            placeholder="Price"
            min="0"
            step="0.01"
            required
          />
          <button type="submit">Add</button>
        </form>

        <button class="refresh" type="button" (click)="loadProducts()">Refresh</button>

        <p *ngIf="message()" class="message">{{ message() }}</p>

        <ul class="list">
          <li *ngFor="let product of products()" class="item">
            <span>
              <strong>{{ product.name }}</strong>
              <small>
                {{ product.price | currency:'USD' }}
              </small>
            </span>
            <button type="button" (click)="deleteProduct(product.id)">Delete</button>
          </li>
        </ul>
      </section>
    </main>
  `
})
class AppComponent {
  private readonly http = inject(HttpClient);

  readonly apiUrl = 'http://localhost:5008/api/products';
  readonly products = signal<Product[]>([]);
  readonly message = signal('');

  newName = '';
  newPrice: number | null = null;

  constructor() {
    this.loadProducts();
  }

  loadProducts(): void {
    this.http.get<Product[]>(this.apiUrl).subscribe({
      next: (data) => {
        this.products.set(data);
        this.message.set('');
      },
      error: () => this.message.set('Could not load products. Is the backend running?')
    });
  }

  addProduct(): void {
    if (!this.newName.trim() || this.newPrice === null) {
      return;
    }

    this.http.post<Product>(this.apiUrl, {
      name: this.newName.trim(),
      price: this.newPrice
    }).subscribe({
      next: () => {
        this.newName = '';
        this.newPrice = null;
        this.message.set('Product created successfully.');
        this.loadProducts();
      },
      error: () => this.message.set('Could not create the product.')
    });
  }

  deleteProduct(id: number): void {
    this.http.delete(`${this.apiUrl}/${id}`).subscribe({
      next: () => {
        this.message.set('Product deleted successfully.');
        this.loadProducts();
      },
      error: () => this.message.set('Could not delete the product.')
    });
  }
}

bootstrapApplication(AppComponent, {
  providers: [provideHttpClient()]
}).catch((err) => console.error(err));
