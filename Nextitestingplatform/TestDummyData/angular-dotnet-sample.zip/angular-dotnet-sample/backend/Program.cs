using Microsoft.AspNetCore.Http.HttpResults;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options =>
{
    options.AddPolicy("frontend", policy =>
    {
        policy
            .WithOrigins("http://localhost:4200")
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();
app.UseCors("frontend");

var products = new List<Product>
{
    new(1, "Keyboard", 45.99m),
    new(2, "Mouse", 19.50m),
    new(3, "Monitor", 210.00m)
};

app.MapGet("/api/health", () => Results.Ok(new { status = "ok", app = "SampleApi" }));

app.MapGet("/api/products", () => Results.Ok(products));

app.MapGet("/api/products/{id:int}", Results<Ok<Product>, NotFound> (int id) =>
{
    var product = products.FirstOrDefault(p => p.Id == id);
    return product is null ? TypedResults.NotFound() : TypedResults.Ok(product);
});

app.MapPost("/api/products", (CreateProductRequest request) =>
{
    var nextId = products.Count == 0 ? 1 : products.Max(p => p.Id) + 1;
    var product = new Product(nextId, request.Name, request.Price);
    products.Add(product);
    return Results.Created($"/api/products/{product.Id}", product);
});

app.MapDelete("/api/products/{id:int}", Results<NoContent, NotFound> (int id) =>
{
    var product = products.FirstOrDefault(p => p.Id == id);
    if (product is null)
    {
        return TypedResults.NotFound();
    }

    products.Remove(product);
    return TypedResults.NoContent();
});

app.Run();

record Product(int Id, string Name, decimal Price);
record CreateProductRequest(string Name, decimal Price);
