# 🥒 Cucumber Testing Framework — Arquetipo

Arquetipo base para automatización de pruebas **UI + API** con **Cucumber BDD** + **Gradle**.  
Combina Selenium WebDriver para pruebas de interfaz y RestAssured para pruebas de API,  
todo unificado bajo el mismo flujo Gherkin.

---

## 📁 Estructura

```
cucumber-testing-framework/
├── build.gradle                                   # Dependencias y tareas Gradle
├── settings.gradle
│
└── src/test/
    ├── java/
    │   ├── runner/
    │   │   └── TestRunner.java                    # Suite JUnit5 Platform
    │   │
    │   ├── config/
    │   │   ├── ConfigManager.java                 # Carga de propiedades por ambiente
    │   │   ├── DriverFactory.java                 # Gestión de WebDriver (thread-safe)
    │   │   └── Hooks.java                         # Before/After + screenshots en fallos
    │   │
    │   ├── pages/                                 # Page Object Model (Selenium)
    │   │   ├── BasePage.java                      # Clase base con métodos comunes
    │   │   └── LoginPage.java                     # Ejemplo de Page Object
    │   │
    │   ├── steps/                                 # Step Definitions
    │   │   ├── LoginSteps.java                    # Steps para login.feature (UI)
    │   │   └── ApiResourceSteps.java              # Steps para resource-api.feature (API)
    │   │
    │   └── helpers/
    │       ├── DataLoader.java                    # Carga JSON, CSV, Excel
    │       ├── TestHelpers.java                   # IDs, nombres, timestamps
    │       └── ApiHelper.java                     # Wrapper RestAssured
    │
    └── resources/
        ├── cucumber.properties                    # Config de plugins Cucumber
        ├── extent.properties                      # Config de Extent Reports
        │
        ├── config/                                # Propiedades por ambiente
        │   ├── env-dev.properties
        │   ├── env-qa.properties
        │   └── env-staging.properties
        │
        ├── features/                              # Features Gherkin (.feature)
        │   └── sample/
        │       ├── login.feature                  # Template UI: login
        │       └── resource-api.feature           # Template API: CRUD
        │
        ├── data/                                  # Datos de prueba
        │   ├── json/
        │   ├── csv/
        │   └── excel/
        │
        └── schemas/                               # JSON Schemas
            └── resource-schema.json
```

---

## 🚀 Inicio Rápido

### 1. Compilar y descargar dependencias

```bash
gradle build -x test
```

### 2. Configurar tu aplicación

Edita `src/test/resources/config/env-qa.properties`:

```properties
base.url=https://tu-app.com
api.url=https://api.tu-app.com/v1
test.user=tu_usuario@test.com
test.password=TuPassword123
```

### 3. Ejecutar

```bash
gradle test                  # Todos los tests
gradle smoke                 # Solo @smoke
gradle regression            # Solo @regression
gradle api                   # Solo @api (sin browser)
gradle e2e                   # Solo @e2e
```

### 4. Ver reportes

```
reports/cucumber-report.html    → Reporte Cucumber nativo
reports/extent-report.html      → Reporte Extent (más visual)
```

---

## 📋 Comandos Completos

### Por tipo de test

| Comando | Qué ejecuta |
|---------|-------------|
| `gradle test` | Todos (excepto `@ignore`) |
| `gradle smoke` | Solo `@smoke` |
| `gradle regression` | Solo `@regression` |
| `gradle api` | Solo `@api` (sin browser) |
| `gradle e2e` | Solo `@e2e` |

### Por ambiente

```bash
gradle test -Denv=dev          # Desarrollo local
gradle test -Denv=qa           # QA (default)
gradle test -Denv=staging      # Pre-producción
```

### Por browser

```bash
gradle test -Dbrowser=chrome        # Chrome (default)
gradle test -Dbrowser=firefox       # Firefox
gradle test -Dbrowser=edge          # Edge
gradle test -Dheadless=true         # Sin UI visible
```

### Por tags (combinaciones)

```bash
gradle test -Dcucumber.filter.tags="@smoke"
gradle test -Dcucumber.filter.tags="@smoke and @ui"
gradle test -Dcucumber.filter.tags="@regression and not @negative"
gradle test -Dcucumber.filter.tags="@post or @get"
```

### Combinación completa

```bash
gradle test -Denv=staging -Dbrowser=firefox -Dheadless=true -Dcucumber.filter.tags="@smoke"
```

---

## 📊 Reportes

| Reporte | Ubicación |
|---------|-----------|
| Cucumber HTML | `reports/cucumber-report.html` |
| Cucumber JSON | `reports/cucumber-report.json` |
| JUnit XML (CI) | `reports/cucumber-report.xml` |
| Extent Spark | `reports/extent-report.html` |
| Screenshots | Embebidos en el reporte (en fallos) |

---

## 🏗️ Cómo Agregar un Nuevo Módulo

### Paso 1: Crear el Feature (Gherkin)

```gherkin
# src/test/resources/features/mi-modulo/mi-funcionalidad.feature
@ui @regression @mi-modulo
Feature: Mi funcionalidad
  Como usuario
  Quiero hacer algo
  Para obtener un beneficio

  Background:
    Given el usuario está logueado

  @smoke
  Scenario: Caso positivo
    When realiza la acción principal
    Then ve el resultado esperado

  @data-driven
  Scenario Outline: Múltiples combinaciones
    When ingresa "<dato>" en el campo
    Then el resultado es "<esperado>"

    Examples:
      | dato    | esperado |
      | válido  | ok       |
      | vacío   | error    |
```

### Paso 2: Crear el Page Object

```java
// src/test/java/pages/MiPagina.java
public class MiPagina extends BasePage {
    private final By miBoton = By.cssSelector("[data-testid='mi-boton']");
    private final By miTexto = By.id("resultado");

    public void clickAccion() { click(miBoton); }
    public String getResultado() { return getText(miTexto); }
}
```

### Paso 3: Crear los Step Definitions

```java
// src/test/java/steps/MiModuloSteps.java
public class MiModuloSteps {
    private final MiPagina miPagina = new MiPagina();

    @When("realiza la acción principal")
    public void realizaAccion() {
        miPagina.clickAccion();
    }

    @Then("ve el resultado esperado")
    public void veResultado() {
        assertEquals("OK", miPagina.getResultado());
    }
}
```

---

## 📋 Cómo Cargar Datos de Prueba

### JSON

```java
import helpers.DataLoader;

Map<String, Object> data = DataLoader.fromJson("mi-data.json");
String nombre = (String) data.get("name");
```

### CSV

```java
List<Map<String, String>> rows = DataLoader.fromCsv("mi-data.csv");
for (Map<String, String> row : rows) {
    String user = row.get("username");
}
```

### Excel

```java
List<Map<String, Object>> rows = DataLoader.fromExcel("mi-data.xlsx", "Sheet1");

// Con filtro
List<Map<String, Object>> activos = DataLoader.fromExcelFiltered(
    "mi-data.xlsx", "Sheet1", "status", "active");
```

### DataTable de Cucumber (inline en el feature)

```gherkin
When envío datos:
  | campo1 | valor1 |
  | campo2 | valor2 |
```
```java
@When("envío datos:")
public void envioDatos(DataTable table) {
    Map<String, String> data = table.asMap(String.class, String.class);
}
```

---

## 🏷️ Sistema de Tags

### Tags funcionales

| Tag | Propósito |
|-----|-----------|
| `@ui` | Tests que usan browser (Hooks levanta WebDriver) |
| `@api` | Tests de API sin browser (Hooks solo hace log) |
| `@smoke` | Tests críticos mínimos |
| `@regression` | Suite completa |
| `@e2e` | Flujos end-to-end |
| `@negative` | Manejo de errores |
| `@data-driven` | Tests parametrizados |
| `@ignore` | Excluir de ejecución |

### Tags por método HTTP

| Tag | Uso |
|-----|-----|
| `@get` `@post` `@put` `@delete` | Filtrar por verbo HTTP |

### Tags por módulo

Crea tags propios para cada módulo: `@login`, `@dashboard`, `@checkout`, etc.

---

## 🔑 Buenas Prácticas

1. **Separa `@ui` y `@api`**: Los Hooks manejan el browser solo para `@ui`.
2. **Page Object Model**: Toda interacción con la UI va en `pages/`, nunca en steps.
3. **Steps reutilizables**: Escribe steps genéricos que se puedan usar en múltiples features.
4. **Datos externos**: Usa `DataLoader` o DataTables en vez de hardcodear valores.
5. **Un Step = Una acción**: Cada step debe hacer una sola cosa clara.
6. **Background para precondiciones**: Lo que se repite en todos los scenarios va en Background.
7. **Selectores `data-testid`**: Más estables que CSS o XPath frágiles.
8. **API para setup**: Crea datos de prueba via API (rápido) en vez de UI (lento).

---

## ⚙️ Requisitos

- Java 11+
- Gradle 8+ (o usar el wrapper: `./gradlew test`)
- Chrome, Firefox o Edge instalado (WebDriverManager descarga el driver automáticamente)
