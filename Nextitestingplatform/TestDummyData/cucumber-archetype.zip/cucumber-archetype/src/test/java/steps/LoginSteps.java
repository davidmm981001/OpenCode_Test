package steps;

import io.cucumber.java.en.*;
import pages.LoginPage;

import static org.junit.jupiter.api.Assertions.*;

/**
 * ═══════════════════════════════════════════════════════════════
 * LoginSteps - Step definitions para login.feature
 * ═══════════════════════════════════════════════════════════════
 * TODO: Adaptar las validaciones a tu aplicación real.
 */
public class LoginSteps {

    private final LoginPage loginPage = new LoginPage();

    // ─── Given ───

    @Given("el usuario navega a la página de login")
    public void elUsuarioNavegaALaPaginaDeLogin() {
        loginPage.goTo();
    }

    // ─── When ───

    @When("ingresa usuario {string} y contraseña {string}")
    public void ingresaUsuarioYContrasena(String username, String password) {
        loginPage.login(username, password);
    }

    @When("hace clic en el botón de login")
    public void haceClicEnElBotonDeLogin() {
        // El clic ya se hace en loginPage.login()
        // Este step es para el scenario de campos vacíos
    }

    @When("hace clic en el botón de login sin ingresar datos")
    public void haceClicSinIngresarDatos() {
        loginPage.login("", "");
    }

    @When("el usuario hace clic en logout")
    public void elUsuarioHaceClicEnLogout() {
        // TODO: Implementar acción de logout
        // dashboardPage.clickLogout();
    }

    // ─── Then ───

    @Then("debe ser redirigido al dashboard")
    public void debeSerRedirigidoAlDashboard() {
        String url = loginPage.getCurrentUrl();
        assertTrue(url.contains("/dashboard"),
                "Se esperaba URL con /dashboard, pero fue: " + url);
    }

    @Then("debe ver el mensaje de bienvenida")
    public void debeVerMensajeDeBienvenida() {
        // TODO: Validar elemento de bienvenida
        // assertTrue(dashboardPage.isWelcomeVisible());
    }

    @Then("debe ver un mensaje de error")
    public void debeVerMensajeDeError() {
        assertTrue(loginPage.isErrorDisplayed(),
                "Se esperaba un mensaje de error visible");
    }

    @Then("debe ver un mensaje de error de campos requeridos")
    public void debeVerMensajeDeErrorCamposRequeridos() {
        assertTrue(loginPage.isErrorDisplayed(),
                "Se esperaba mensaje de campos requeridos");
    }

    @Then("debe ser redirigido a la página de login")
    public void debeSerRedirigidoALogin() {
        String url = loginPage.getCurrentUrl();
        assertTrue(url.contains("/login"),
                "Se esperaba URL con /login, pero fue: " + url);
    }

    @Then("el resultado esperado es {string}")
    public void elResultadoEsperadoEs(String resultado) {
        if ("exitoso".equals(resultado)) {
            assertTrue(loginPage.getCurrentUrl().contains("/dashboard"),
                    "Login debió ser exitoso");
        } else {
            assertTrue(loginPage.isErrorDisplayed(),
                    "Login debió mostrar error");
        }
    }
}
