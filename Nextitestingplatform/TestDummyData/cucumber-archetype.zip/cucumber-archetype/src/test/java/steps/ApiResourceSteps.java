package steps;

import helpers.ApiHelper;
import helpers.TestHelpers;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import io.restassured.response.Response;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * ═══════════════════════════════════════════════════════════════
 * ApiResourceSteps - Step definitions para resource-api.feature
 * ═══════════════════════════════════════════════════════════════
 * Usa RestAssured via ApiHelper para todas las peticiones HTTP.
 * TODO: Adaptar endpoints y validaciones a tu API real.
 */
public class ApiResourceSteps {

    private final ApiHelper api = new ApiHelper();
    private Response response;
    private String savedId;

    // ─── Given ───

    @Given("la API está disponible")
    public void laApiEstaDisponible() {
        // Health check opcional
        // Response health = api.get("/health");
        // assertEquals(200, health.getStatusCode());
    }

    @Given("existe un recurso creado previamente")
    public void existeUnRecursoCreado() {
        Map<String, Object> payload = new HashMap<>();
        payload.put("id", TestHelpers.generateId());
        payload.put("name", TestHelpers.randomName("Precondition"));
        payload.put("status", "active");

        response = api.post("/resource", payload);
        savedId = response.jsonPath().getString("id");
    }

    // ─── When: POST ───

    @When("envío un POST a {string} con los datos:")
    public void envioPostConDatos(String endpoint, DataTable dataTable) {
        Map<String, String> data = dataTable.asMap(String.class, String.class);
        Map<String, Object> payload = new HashMap<>(data);
        payload.put("id", TestHelpers.generateId());

        response = api.post(endpoint, payload);

        // Guardar ID si fue exitoso
        if (response.getStatusCode() == 201 || response.getStatusCode() == 200) {
            String id = response.jsonPath().getString("id");
            if (id != null) savedId = id;
        }
    }

    // ─── When: GET ───

    @When("envío un GET a {string}")
    public void envioGet(String endpoint) {
        String resolvedEndpoint = resolveEndpoint(endpoint);
        response = api.get(resolvedEndpoint);
    }

    @When("envío un GET a {string} con parámetro {string} igual a {string}")
    public void envioGetConParametro(String endpoint, String param, String value) {
        Map<String, String> params = new HashMap<>();
        params.put(param, value);
        response = api.get(endpoint, params);
    }

    // ─── When: PUT ───

    @When("envío un PUT a {string} con los datos:")
    public void envioPutConDatos(String endpoint, DataTable dataTable) {
        String resolvedEndpoint = resolveEndpoint(endpoint);
        Map<String, String> data = dataTable.asMap(String.class, String.class);
        Map<String, Object> payload = new HashMap<>(data);

        response = api.put(resolvedEndpoint, payload);
    }

    // ─── When: DELETE ───

    @When("envío un DELETE a {string}")
    public void envioDelete(String endpoint) {
        String resolvedEndpoint = resolveEndpoint(endpoint);
        response = api.delete(resolvedEndpoint);
    }

    // ─── Then ───

    @Then("el código de respuesta es {int}")
    public void elCodigoDeRespuestaEs(int expectedStatus) {
        assertEquals(expectedStatus, response.getStatusCode(),
                "Status esperado: " + expectedStatus
                        + ", recibido: " + response.getStatusCode()
                        + "\nBody: " + response.getBody().asString());
    }

    @Then("la respuesta contiene el campo {string}")
    public void laRespuestaContieneElCampo(String field) {
        Object value = response.jsonPath().get(field);
        assertNotNull(value, "El campo '" + field + "' no existe en la respuesta");
    }

    @Then("la respuesta contiene {string} con valor {string}")
    public void laRespuestaContieneConValor(String field, String expectedValue) {
        String actual = response.jsonPath().getString(field);
        assertEquals(expectedValue, actual,
                "Campo '" + field + "': esperado '" + expectedValue + "', recibido '" + actual + "'");
    }

    @Then("guardo el {string} de la respuesta")
    public void guardoElDeLaRespuesta(String field) {
        savedId = response.jsonPath().getString(field);
        assertNotNull(savedId, "No se pudo guardar el campo '" + field + "'");
    }

    @Then("la respuesta cumple el schema {string}")
    public void laRespuestaCumpleElSchema(String schemaFile) {
        // TODO: Implementar validación con json-schema-validator
        // response.then().body(matchesJsonSchemaInClasspath("schemas/" + schemaFile));
        assertNotNull(response.getBody().asString(), "La respuesta no debe ser vacía");
    }

    // ─── Helpers internos ───

    private String resolveEndpoint(String endpoint) {
        if (endpoint.contains("{id}") && savedId != null) {
            return endpoint.replace("{id}", savedId);
        }
        return endpoint;
    }
}
