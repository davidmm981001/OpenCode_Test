package config;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

/**
 * ═══════════════════════════════════════════════════════════════
 * Hooks - Before/After para todos los Scenarios
 * ═══════════════════════════════════════════════════════════════
 * - @ui: Levanta browser antes, lo cierra después
 * - @api: No levanta browser
 * - Screenshot automático en fallos
 */
public class Hooks {

    /**
     * Antes de cada scenario con tag @ui: crear WebDriver.
     */
    @Before("@ui")
    public void beforeUiScenario(Scenario scenario) {
        System.out.println("▶ [UI] Iniciando: " + scenario.getName());
        DriverFactory.getDriver();
    }

    /**
     * Antes de cada scenario con tag @api: solo log.
     */
    @Before("@api")
    public void beforeApiScenario(Scenario scenario) {
        System.out.println("▶ [API] Iniciando: " + scenario.getName());
    }

    /**
     * Después de cada step: si falló y es @ui, tomar screenshot.
     */
    @AfterStep("@ui")
    public void afterStepScreenshot(Scenario scenario) {
        if (scenario.isFailed()) {
            captureScreenshot(scenario);
        }
    }

    /**
     * Después de cada scenario @ui: cerrar browser.
     */
    @After("@ui")
    public void afterUiScenario(Scenario scenario) {
        if (scenario.isFailed()) {
            captureScreenshot(scenario);
        }
        DriverFactory.quitDriver();
        System.out.println("■ [UI] Finalizado: " + scenario.getName()
                + " → " + scenario.getStatus());
    }

    /**
     * Después de cada scenario @api: solo log.
     */
    @After("@api")
    public void afterApiScenario(Scenario scenario) {
        System.out.println("■ [API] Finalizado: " + scenario.getName()
                + " → " + scenario.getStatus());
    }

    private void captureScreenshot(Scenario scenario) {
        try {
            WebDriver driver = DriverFactory.getDriver();
            byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            scenario.attach(screenshot, "image/png", scenario.getName());
        } catch (Exception e) {
            System.err.println("⚠ No se pudo capturar screenshot: " + e.getMessage());
        }
    }
}
