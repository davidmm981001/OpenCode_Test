package config;

import java.io.InputStream;
import java.util.Properties;

/**
 * ═══════════════════════════════════════════════════════════════
 * ConfigManager - Configuración multi-ambiente
 * ═══════════════════════════════════════════════════════════════
 * Carga propiedades desde archivos env-{ambiente}.properties.
 *
 * Uso: gradle test -Denv=qa
 *      ConfigManager.get("base.url")
 */
public class ConfigManager {

    private static final Properties props = new Properties();
    private static String env;

    static {
        env = System.getProperty("env", "qa");
        String fileName = "config/env-" + env + ".properties";
        try (InputStream is = ConfigManager.class.getClassLoader().getResourceAsStream(fileName)) {
            if (is == null) {
                throw new RuntimeException("Archivo de config no encontrado: " + fileName);
            }
            props.load(is);
            System.out.println("══════════════════════════════════════");
            System.out.println("  Ambiente activo: [" + env + "]");
            System.out.println("  Base URL: " + props.getProperty("base.url"));
            System.out.println("  API URL:  " + props.getProperty("api.url"));
            System.out.println("══════════════════════════════════════");
        } catch (Exception e) {
            throw new RuntimeException("Error cargando config: " + e.getMessage(), e);
        }
    }

    public static String get(String key) {
        return props.getProperty(key);
    }

    public static String get(String key, String defaultValue) {
        return props.getProperty(key, defaultValue);
    }

    public static int getInt(String key, int defaultValue) {
        String val = props.getProperty(key);
        return val != null ? Integer.parseInt(val) : defaultValue;
    }

    public static boolean getBool(String key, boolean defaultValue) {
        String val = props.getProperty(key);
        return val != null ? Boolean.parseBoolean(val) : defaultValue;
    }

    public static String getEnv() {
        return env;
    }
}
