package pages;

import org.openqa.selenium.By;

/**
 * ═══════════════════════════════════════════════════════════════
 * LoginPage - Ejemplo de Page Object
 * ═══════════════════════════════════════════════════════════════
 * TODO: Reemplazar selectores con los de tu aplicación.
 */
public class LoginPage extends BasePage {

    // ─── Locators ───
    // TODO: Actualizar con los selectores reales
    private final By usernameInput      = By.id("username");
    private final By passwordInput      = By.id("password");
    private final By loginButton        = By.cssSelector("button[type='submit']");
    private final By errorMessage       = By.cssSelector("[data-testid='error-message']");
    private final By rememberMeCheckbox = By.id("remember-me");
    private final By forgotPasswordLink = By.cssSelector("a[href*='forgot']");

    // ─── Acciones ───

    public LoginPage goTo() {
        navigateToPath("/login");
        return this;
    }

    public void login(String username, String password) {
        type(usernameInput, username);
        type(passwordInput, password);
        click(loginButton);
    }

    public void loginAndWaitForDashboard(String username, String password) {
        login(username, password);
        waitForUrlContains("/dashboard");
    }

    public String getErrorMessage() {
        return getText(errorMessage);
    }

    public boolean isErrorDisplayed() {
        return isDisplayed(errorMessage);
    }

    public void checkRememberMe() {
        click(rememberMeCheckbox);
    }

    // ─── Validaciones ───

    public boolean isLoginFormVisible() {
        return isDisplayed(usernameInput)
                && isDisplayed(passwordInput)
                && isDisplayed(loginButton);
    }
}
