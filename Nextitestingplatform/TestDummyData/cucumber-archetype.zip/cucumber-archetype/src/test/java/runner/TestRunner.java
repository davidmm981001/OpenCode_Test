package runner;

import org.junit.platform.suite.api.ConfigurationParameter;
import org.junit.platform.suite.api.IncludeEngines;
import org.junit.platform.suite.api.SelectClasspathResource;
import org.junit.platform.suite.api.Suite;

import static io.cucumber.junit.platform.engine.Constants.*;

/**
 * ═══════════════════════════════════════════════════════════════
 * RUNNER PRINCIPAL - JUnit5 Platform Suite
 * ═══════════════════════════════════════════════════════════════
 *
 * Ejecución:
 *   gradle test                                  → Todos
 *   gradle test -Denv=qa                         → Ambiente QA
 *   gradle test -Dbrowser=firefox                → Firefox
 *   gradle test -Dheadless=true                  → Sin UI
 *   gradle smoke                                 → Solo @smoke
 *   gradle api                                   → Solo @api
 *   gradle test -Dcucumber.filter.tags="@e2e"    → Solo E2E
 *
 * Reportes: reports/cucumber-report.html
 *           reports/extent-report.html
 */
@Suite
@IncludeEngines("cucumber")
@SelectClasspathResource("features")
@ConfigurationParameter(key = GLUE_PROPERTY_NAME, value = "steps,config")
@ConfigurationParameter(key = PLUGIN_PROPERTY_NAME, value = "pretty, html:reports/cucumber-report.html, json:reports/cucumber-report.json")
@ConfigurationParameter(key = FEATURES_PROPERTY_NAME, value = "src/test/resources/features")
@ConfigurationParameter(key = FILTER_TAGS_PROPERTY_NAME, value = "not @ignore")
public class TestRunner {
}
