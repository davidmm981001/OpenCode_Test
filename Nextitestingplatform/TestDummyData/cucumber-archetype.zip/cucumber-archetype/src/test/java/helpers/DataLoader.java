package helpers;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.*;

/**
 * ═══════════════════════════════════════════════════════════════
 * DataLoader - Carga datos de prueba desde JSON, CSV y Excel
 * ═══════════════════════════════════════════════════════════════
 *
 * Uso en Steps:
 *   Map<String, Object> data = DataLoader.fromJson("sample-data.json");
 *   List<Map<String, String>> rows = DataLoader.fromCsv("sample-data.csv");
 *   List<Map<String, Object>> excel = DataLoader.fromExcel("data.xlsx", "Sheet1");
 */
public class DataLoader {

    private static final ObjectMapper mapper = new ObjectMapper();

    // ─── JSON ───

    @SuppressWarnings("unchecked")
    public static Map<String, Object> fromJson(String filename) {
        try (InputStream is = getResource("data/json/" + filename)) {
            return mapper.readValue(is, Map.class);
        } catch (Exception e) {
            throw new RuntimeException("Error leyendo JSON [" + filename + "]: " + e.getMessage(), e);
        }
    }

    public static <T> T fromJson(String filename, Class<T> type) {
        try (InputStream is = getResource("data/json/" + filename)) {
            return mapper.readValue(is, type);
        } catch (Exception e) {
            throw new RuntimeException("Error leyendo JSON [" + filename + "]: " + e.getMessage(), e);
        }
    }

    // ─── CSV ───

    public static List<Map<String, String>> fromCsv(String filename) {
        List<Map<String, String>> data = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(getResource("data/csv/" + filename)))) {

            String headerLine = br.readLine();
            if (headerLine == null) return data;
            String[] headers = headerLine.split(",");

            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] values = line.split(",", -1);
                Map<String, String> row = new LinkedHashMap<>();
                for (int i = 0; i < headers.length; i++) {
                    row.put(headers[i].trim(), i < values.length ? values[i].trim() : "");
                }
                data.add(row);
            }
        } catch (Exception e) {
            throw new RuntimeException("Error leyendo CSV [" + filename + "]: " + e.getMessage(), e);
        }
        return data;
    }

    // ─── Excel ───

    public static List<Map<String, Object>> fromExcel(String filename, String sheetName) {
        List<Map<String, Object>> data = new ArrayList<>();
        try (InputStream is = getResource("data/excel/" + filename);
             Workbook workbook = new XSSFWorkbook(is)) {

            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) throw new RuntimeException("Hoja '" + sheetName + "' no encontrada");

            Row headerRow = sheet.getRow(0);
            List<String> headers = new ArrayList<>();
            for (Cell cell : headerRow) {
                headers.add(cell.getStringCellValue().trim());
            }

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;
                Map<String, Object> rowMap = new LinkedHashMap<>();
                for (int j = 0; j < headers.size(); j++) {
                    Cell cell = row.getCell(j, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                    rowMap.put(headers.get(j), getCellValue(cell));
                }
                data.add(rowMap);
            }
        } catch (Exception e) {
            throw new RuntimeException("Error leyendo Excel [" + filename + "]: " + e.getMessage(), e);
        }
        return data;
    }

    public static List<Map<String, Object>> fromExcelFiltered(
            String filename, String sheetName, String col, String val) {
        List<Map<String, Object>> all = fromExcel(filename, sheetName);
        List<Map<String, Object>> filtered = new ArrayList<>();
        for (Map<String, Object> row : all) {
            if (val.equals(String.valueOf(row.get(col)))) filtered.add(row);
        }
        return filtered;
    }

    // ─── Internos ───

    private static InputStream getResource(String path) {
        InputStream is = DataLoader.class.getClassLoader().getResourceAsStream(path);
        if (is == null) throw new RuntimeException("Recurso no encontrado: " + path);
        return is;
    }

    private static Object getCellValue(Cell cell) {
        if (cell == null) return "";
        switch (cell.getCellType()) {
            case STRING:  return cell.getStringCellValue().trim();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) return cell.getDateCellValue().toString();
                double num = cell.getNumericCellValue();
                if (num == Math.floor(num) && !Double.isInfinite(num)) return (long) num;
                return num;
            case BOOLEAN: return cell.getBooleanCellValue();
            default:      return "";
        }
    }
}
