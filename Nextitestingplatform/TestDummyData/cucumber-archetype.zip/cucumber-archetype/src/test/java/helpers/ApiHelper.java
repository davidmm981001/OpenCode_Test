package helpers;

import config.ConfigManager;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.util.Map;

/**
 * ═══════════════════════════════════════════════════════════════
 * ApiHelper - Wrapper de RestAssured para Steps de API
 * ═══════════════════════════════════════════════════════════════
 *
 * Uso en Steps:
 *   ApiHelper api = new ApiHelper();
 *   Response res = api.get("/users/1");
 *   Response res = api.post("/users", payload);
 */
public class ApiHelper {

    private final RequestSpecification baseSpec;

    public ApiHelper() {
        String apiUrl = ConfigManager.get("api.url");
        String apiKey = ConfigManager.get("api.key", "");

        this.baseSpec = RestAssured.given()
                .baseUri(apiUrl)
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header("api_key", apiKey)
                .log().ifValidationFails();
    }

    public Response get(String path) {
        return baseSpec.get(path);
    }

    public Response get(String path, Map<String, ?> params) {
        return baseSpec.queryParams(params).get(path);
    }

    public Response post(String path, Object body) {
        return baseSpec.body(body).post(path);
    }

    public Response put(String path, Object body) {
        return baseSpec.body(body).put(path);
    }

    public Response patch(String path, Object body) {
        return baseSpec.body(body).patch(path);
    }

    public Response delete(String path) {
        return baseSpec.delete(path);
    }
}
