@ui @regression
Feature: Login de usuario
  Como usuario del sistema
  Quiero poder iniciar sesión
  Para acceder a las funcionalidades de la aplicación

  # ═══════════════════════════════════════════════════════════════
  # BACKGROUND: Se ejecuta antes de cada Scenario
  # ═══════════════════════════════════════════════════════════════
  Background:
    Given el usuario navega a la página de login

  # ─────────────────────────────────────────────────────────────
  # Scenarios individuales
  # ─────────────────────────────────────────────────────────────
  @smoke
  Scenario: Login exitoso con credenciales válidas
    When ingresa usuario "qa_user@test.com" y contraseña "SecureP@ss123"
    And hace clic en el botón de login
    Then debe ser redirigido al dashboard
    And debe ver el mensaje de bienvenida

  @negative
  Scenario: Login fallido con credenciales inválidas
    When ingresa usuario "fake@test.com" y contraseña "wrongpass"
    And hace clic en el botón de login
    Then debe ver un mensaje de error

  @negative
  Scenario: Login fallido con campos vacíos
    When hace clic en el botón de login sin ingresar datos
    Then debe ver un mensaje de error de campos requeridos

  # ─────────────────────────────────────────────────────────────
  # Scenario Outline - Data-driven con tabla inline
  # ─────────────────────────────────────────────────────────────
  @data-driven
  Scenario Outline: Login con múltiples combinaciones de datos
    When ingresa usuario "<username>" y contraseña "<password>"
    And hace clic en el botón de login
    Then el resultado esperado es "<resultado>"

    Examples: Credenciales válidas e inválidas
      | username           | password      | resultado   |
      | qa_user@test.com   | SecureP@ss123 | exitoso     |
      | fake@test.com      | wrongpass     | error       |
      |                    | SecureP@ss123 | error       |
      | qa_user@test.com   |               | error       |
      | admin@test.com     | Admin123!     | exitoso     |

  # ─────────────────────────────────────────────────────────────
  # Flujo E2E
  # ─────────────────────────────────────────────────────────────
  @e2e
  Scenario: Flujo completo login y logout
    When ingresa usuario "qa_user@test.com" y contraseña "SecureP@ss123"
    And hace clic en el botón de login
    Then debe ser redirigido al dashboard
    When el usuario hace clic en logout
    Then debe ser redirigido a la página de login
