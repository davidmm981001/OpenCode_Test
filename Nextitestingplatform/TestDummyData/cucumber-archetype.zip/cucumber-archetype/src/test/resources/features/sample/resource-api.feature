@api @regression
Feature: API - CRUD de recursos
  Como consumidor de la API
  Quiero poder crear, consultar, actualizar y eliminar recursos
  Para gestionar la información del sistema

  Background:
    Given la API está disponible

  # ─────────────────────────────────────────────────────────────
  # POST - Crear recurso
  # ─────────────────────────────────────────────────────────────
  @smoke @post
  Scenario: POST - Crear recurso exitosamente
    When envío un POST a "/resource" con los datos:
      | name   | Recurso de prueba |
      | status | active            |
    Then el código de respuesta es 201
    And la respuesta contiene el campo "id"
    And la respuesta contiene "name" con valor "Recurso de prueba"

  @negative @post
  Scenario: POST - Crear recurso con datos inválidos
    When envío un POST a "/resource" con los datos:
      | name   |                |
      | status | invalid_status |
    Then el código de respuesta es 400

  # ─────────────────────────────────────────────────────────────
  # GET - Consultar recurso
  # ─────────────────────────────────────────────────────────────
  @smoke @get
  Scenario: GET - Consultar recurso existente
    Given existe un recurso creado previamente
    When envío un GET a "/resource/{id}"
    Then el código de respuesta es 200
    And la respuesta cumple el schema "resource-schema.json"

  @negative @get
  Scenario: GET - Consultar recurso inexistente
    When envío un GET a "/resource/999999999"
    Then el código de respuesta es 404

  # ─────────────────────────────────────────────────────────────
  # GET con filtros - Scenario Outline
  # ─────────────────────────────────────────────────────────────
  @data-driven @get
  Scenario Outline: GET - Listar recursos por filtro
    When envío un GET a "/resource" con parámetro "status" igual a "<filtro>"
    Then el código de respuesta es <statusCode>

    Examples:
      | filtro    | statusCode | descripcion          |
      | active    | 200        | Filtro válido        |
      | inactive  | 200        | Filtro alternativo   |
      | INVALID!! | 400        | Filtro inválido      |

  # ─────────────────────────────────────────────────────────────
  # PUT - Actualizar recurso
  # ─────────────────────────────────────────────────────────────
  @smoke @put
  Scenario: PUT - Actualizar recurso existente
    Given existe un recurso creado previamente
    When envío un PUT a "/resource/{id}" con los datos:
      | name   | Recurso actualizado |
      | status | inactive            |
    Then el código de respuesta es 200
    And la respuesta contiene "name" con valor "Recurso actualizado"

  # ─────────────────────────────────────────────────────────────
  # DELETE - Eliminar recurso
  # ─────────────────────────────────────────────────────────────
  @smoke @delete
  Scenario: DELETE - Eliminar recurso existente
    Given existe un recurso creado previamente
    When envío un DELETE a "/resource/{id}"
    Then el código de respuesta es 200
    When envío un GET a "/resource/{id}"
    Then el código de respuesta es 404

  # ─────────────────────────────────────────────────────────────
  # Flujo E2E
  # ─────────────────────────────────────────────────────────────
  @e2e
  Scenario: E2E - Ciclo completo crear, leer, actualizar, eliminar
    When envío un POST a "/resource" con los datos:
      | name   | Recurso E2E |
      | status | active      |
    Then el código de respuesta es 201
    And guardo el "id" de la respuesta

    When envío un GET a "/resource/{id}"
    Then el código de respuesta es 200
    And la respuesta contiene "name" con valor "Recurso E2E"

    When envío un PUT a "/resource/{id}" con los datos:
      | name   | Recurso E2E Actualizado |
      | status | inactive                |
    Then el código de respuesta es 200

    When envío un DELETE a "/resource/{id}"
    Then el código de respuesta es 200

    When envío un GET a "/resource/{id}"
    Then el código de respuesta es 404
