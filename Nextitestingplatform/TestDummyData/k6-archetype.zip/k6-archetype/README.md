# ⚡ K6 Performance Testing Framework — Arquetipo

Arquetipo base para pruebas de rendimiento con **K6** (Grafana).  
Incluye perfiles de carga predefinidos, data-driven, métricas custom, y reportes.

---

## 📁 Estructura

```
k6-performance-framework/
├── src/
│   ├── config/
│   │   ├── environments.js        # URLs y credenciales por ambiente
│   │   ├── profiles.js            # Perfiles: smoke, load, stress, spike, soak
│   │   └── headers.js             # Headers reutilizables (JSON, auth, bearer)
│   │
│   ├── tests/                     # Scripts de test por tipo
│   │   ├── smoke/
│   │   │   └── api-health.js      # Validación rápida de endpoints
│   │   ├── load/
│   │   │   ├── crud-flow.js       # CRUD completo bajo carga normal
│   │   │   └── csv-driven.js      # Data-driven desde CSV
│   │   ├── stress/
│   │   │   └── breakpoint.js      # Encontrar punto de quiebre
│   │   ├── spike/
│   │   │   └── traffic-burst.js   # Pico súbito de tráfico
│   │   ├── soak/
│   │   │   └── endurance.js       # Resistencia prolongada (1h+)
│   │   └── e2e/
│   │       └── user-journey.js    # Flujo completo de usuario
│   │
│   ├── checks/
│   │   └── http-checks.js         # Validaciones reutilizables
│   │
│   ├── thresholds/
│   │   └── custom.js              # Umbrales: strict, moderate, relaxed
│   │
│   ├── helpers/
│   │   ├── utils.js               # Generadores, think time, wrappers HTTP
│   │   ├── csv-reader.js          # Lector CSV con SharedArray
│   │   └── json-reader.js         # Lector JSON con SharedArray
│   │
│   └── data/
│       ├── json/payloads.json     # Datos JSON
│       └── csv/users.csv          # Datos CSV
│
└── reports/                       # Reportes generados
```

---

## 🚀 Inicio Rápido

### 1. Instalar K6

```bash
# macOS
brew install k6

# Linux (Debian/Ubuntu)
sudo gpg -k
sudo gpg --no-default-keyring --keyring /usr/share/keyrings/k6-archive-keyring.gpg \
  --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys C5AD17C747E3415A3642D57D77C6C491D6AC1D68
echo "deb [signed-by=/usr/share/keyrings/k6-archive-keyring.gpg] https://dl.k6.io/deb stable main" \
  | sudo tee /etc/apt/sources.list.d/k6.list
sudo apt-get update && sudo apt-get install k6

# Windows
choco install k6

# Docker
docker run --rm -i grafana/k6 run - <script.js
```

### 2. Configurar

Edita `src/config/environments.js` con las URLs de tu API:

```javascript
qa: {
    baseUrl: 'https://tu-api.com/api/v1',
    apiKey: 'tu-api-key',
}
```

### 3. Ejecutar

```bash
k6 run -e ENV=qa src/tests/smoke/api-health.js
```

---

## 📋 Comandos por Tipo de Test

### Smoke (validación rápida)
```bash
k6 run -e ENV=qa src/tests/smoke/api-health.js
```
5 VUs, 1.5 min. Verifica que endpoints principales responden.

### Load (carga normal)
```bash
k6 run -e ENV=qa src/tests/load/crud-flow.js
k6 run -e ENV=qa src/tests/load/csv-driven.js
```
50–100 VUs, 16 min. Simula tráfico esperado con CRUD completo.

### Stress (punto de quiebre)
```bash
k6 run -e ENV=qa src/tests/stress/breakpoint.js
```
50→400 VUs progresivos, 16 min. Encuentra dónde el sistema falla.

### Spike (pico súbito)
```bash
k6 run -e ENV=qa src/tests/spike/traffic-burst.js
```
10→500 VUs en 10 seg. Simula tráfico viral o campaña masiva.

### Soak (resistencia)
```bash
k6 run -e ENV=qa src/tests/soak/endurance.js
```
50 VUs, 1h+. Detecta memory leaks y degradación progresiva.

### E2E (flujo completo)
```bash
k6 run -e ENV=qa src/tests/e2e/user-journey.js
```
Registro → login → CRUD → logout con think times realistas.

---

## 📊 Reportes

### Consola (default)
K6 imprime métricas en la terminal al finalizar.

### HTML
```bash
K6_WEB_DASHBOARD=true k6 run -e ENV=qa src/tests/load/crud-flow.js
```

### JSON (para CI/CD)
```bash
k6 run --out json=reports/results.json -e ENV=qa src/tests/smoke/api-health.js
```

### CSV
```bash
k6 run --out csv=reports/results.csv -e ENV=qa src/tests/smoke/api-health.js
```

### Grafana + InfluxDB (dashboard en tiempo real)
```bash
k6 run --out influxdb=http://localhost:8086/k6 -e ENV=qa src/tests/load/crud-flow.js
```

---

## 🏗️ Cómo Agregar un Nuevo Test

### 1. Crear el script

```javascript
// src/tests/load/mi-nuevo-test.js
import { profiles } from '../../config/profiles.js';
import { checks } from '../../checks/http-checks.js';
import { apiGet, thinkTime } from '../../helpers/utils.js';

export const options = {
    ...profiles.load,       // Usa perfil predefinido
    tags: { testType: 'load', module: 'mi-modulo' },
};

export default function () {
    const res = apiGet('/mi-endpoint');
    checks.isStatus200(res);
    checks.responseTimeUnder(res, 1000);
    thinkTime(1, 3);
}
```

### 2. Personalizar thresholds

```javascript
import { profiles } from '../../config/profiles.js';
import { customThresholds } from '../../thresholds/custom.js';

export const options = {
    ...profiles.load,
    thresholds: {
        ...profiles.load.thresholds,
        ...customThresholds.strict,       // Combinar umbrales
        'group_duration{group:::POST}': ['p(95)<500'],  // Por grupo
    },
};
```

### 3. Usar datos CSV

```javascript
import { loadCsv } from '../../helpers/csv-reader.js';

const data = loadCsv('mi-data.csv');

export default function () {
    const row = data[Math.floor(Math.random() * data.length)];
    // usar row.campo1, row.campo2...
}
```

---

## 📋 Checks Reutilizables

```javascript
import { checks } from '../checks/http-checks.js';

checks.isStatus200(response);                         // status == 200
checks.isStatus(response, 201);                       // status == N
checks.isValidJson(response);                         // body es JSON
checks.responseTimeUnder(response, 500);              // duration < 500ms
checks.responseContains(response, 'id');               // body tiene campo
checks.responseFieldEquals(response, 'status', 'ok');  // campo == valor
checks.bodyNotEmpty(response);                         // body no vacío
checks.headerExists(response, 'Content-Type');         // header existe
```

---

## 🎚️ Perfiles Predefinidos

| Perfil | VUs | Duración | Propósito |
|--------|-----|----------|-----------|
| `smoke` | 5 | 1.5 min | Health check rápido |
| `load` | 50→100 | 16 min | Tráfico normal esperado |
| `stress` | 50→400 | 16 min | Encontrar punto de quiebre |
| `spike` | 10→500 | 3.5 min | Pico súbito de tráfico |
| `soak` | 50 | 1h 10m | Resistencia prolongada |

Cada perfil incluye stages y thresholds preconfigurados.

---

## 🔑 Buenas Prácticas

1. **Think time siempre**: Usa `thinkTime(1, 3)` entre requests para simular usuarios reales.
2. **SharedArray para datos**: `loadCsv()` y `loadJson()` usan SharedArray (eficiente en memoria).
3. **Groups para métricas**: Agrupa requests con `group('nombre', () => {...})` para métricas por flujo.
4. **Métricas custom**: Usa `Counter`, `Trend`, `Rate`, `Gauge` para rastrear métricas de negocio.
5. **Perfiles, no hardcode**: Usa `profiles.load` en vez de copiar stages en cada test.
6. **Thresholds combinables**: Mezcla `profiles.*.thresholds` con `customThresholds.strict`.
7. **Ambiente por variable**: Siempre pasa `-e ENV=qa`, nunca hardcodees URLs.
8. **Cleanup**: Si el test crea datos, elimínalos al final para no contaminar el ambiente.

---

## ⚙️ Requisitos

- K6 v0.49+ instalado
- Acceso HTTP al API bajo prueba
