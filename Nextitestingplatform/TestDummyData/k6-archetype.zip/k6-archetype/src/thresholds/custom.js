/**
 * ═══════════════════════════════════════════════════════════════
 * THRESHOLDS - Umbrales personalizados reutilizables
 * ═══════════════════════════════════════════════════════════════
 * Combinables con los del perfil.
 *
 * Uso:
 *   import { customThresholds } from '../thresholds/custom.js';
 *   export const options = {
 *     ...profiles.load,
 *     thresholds: {
 *       ...profiles.load.thresholds,
 *       ...customThresholds.strict,
 *     },
 *   };
 */

export const customThresholds = {

    // Estricto: API de alta prioridad
    strict: {
        http_req_duration:   ['p(90)<300', 'p(95)<500', 'p(99)<1000'],
        http_req_failed:     ['rate<0.01'],
        http_reqs:           ['rate>100'],
        iteration_duration:  ['p(95)<2000'],
    },

    // Moderado: APIs internas
    moderate: {
        http_req_duration:   ['p(95)<1000', 'p(99)<2000'],
        http_req_failed:     ['rate<0.05'],
    },

    // Relajado: Endpoints batch o reportes
    relaxed: {
        http_req_duration:   ['p(95)<3000', 'p(99)<5000'],
        http_req_failed:     ['rate<0.10'],
    },
};
