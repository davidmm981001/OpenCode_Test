import { config } from '../../config/environments.js';
import { profiles } from '../../config/profiles.js';
import { jsonHeaders } from '../../config/headers.js';
import { checks } from '../../checks/http-checks.js';
import { apiGet, apiPost, thinkTime, randomId } from '../../helpers/utils.js';

/**
 * ═══════════════════════════════════════════════════════════════
 * SMOKE TEST - Validación rápida de salud del API
 * ═══════════════════════════════════════════════════════════════
 * Ejecuta con pocos VUs para verificar que los endpoints
 * principales responden correctamente.
 *
 * Ejecución: k6 run -e ENV=qa src/tests/smoke/api-health.js
 */

export const options = {
    ...profiles.smoke,
    tags: { testType: 'smoke' },
};

export default function () {
    // ── GET: Health check / listar ──
    const getRes = apiGet('/resource', { headers: jsonHeaders });
    checks.isStatus200(getRes);
    checks.responseTimeUnder(getRes, 500);

    thinkTime(1, 2);

    // ── POST: Crear recurso ──
    const payload = {
        id: randomId(),
        name: `Smoke_${Date.now()}`,
        status: 'active',
    };
    const postRes = apiPost('/resource', payload);
    checks.isStatus(postRes, 201);
    checks.isValidJson(postRes);
    checks.responseContains(postRes, 'id');

    thinkTime(1, 2);
}
