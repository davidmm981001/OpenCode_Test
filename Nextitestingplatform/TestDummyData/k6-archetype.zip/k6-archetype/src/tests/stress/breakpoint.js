import { group } from 'k6';
import { config } from '../../config/environments.js';
import { profiles } from '../../config/profiles.js';
import { jsonHeaders } from '../../config/headers.js';
import { checks } from '../../checks/http-checks.js';
import { apiGet, apiPost, thinkTime, randomId, randomName } from '../../helpers/utils.js';
import { Counter, Trend } from 'k6/metrics';

/**
 * ═══════════════════════════════════════════════════════════════
 * STRESS TEST - Encontrar punto de quiebre
 * ═══════════════════════════════════════════════════════════════
 * Incrementa VUs progresivamente hasta que el sistema falla.
 * Métricas custom rastrean errores y degradación.
 *
 * Ejecución: k6 run -e ENV=qa src/tests/stress/breakpoint.js
 */

// Métricas custom
const errorCount = new Counter('custom_errors');
const createDuration = new Trend('custom_create_duration');
const readDuration = new Trend('custom_read_duration');

export const options = {
    ...profiles.stress,
    tags: { testType: 'stress' },
};

export default function () {

    group('POST - Crear bajo estrés', () => {
        const payload = {
            id: randomId(),
            name: randomName('Stress'),
            status: 'active',
        };
        const res = apiPost('/resource', payload);
        createDuration.add(res.timings.duration);

        if (!checks.isStatus(res, 201)) {
            errorCount.add(1);
        }
    });

    thinkTime(0.5, 1);

    group('GET - Leer bajo estrés', () => {
        const res = apiGet('/resource', { headers: jsonHeaders });
        readDuration.add(res.timings.duration);

        if (!checks.isStatus200(res)) {
            errorCount.add(1);
        }
    });

    thinkTime(0.5, 1);
}
