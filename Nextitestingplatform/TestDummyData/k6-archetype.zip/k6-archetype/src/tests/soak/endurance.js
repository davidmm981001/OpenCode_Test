import { config } from '../../config/environments.js';
import { profiles } from '../../config/profiles.js';
import { jsonHeaders } from '../../config/headers.js';
import { checks } from '../../checks/http-checks.js';
import { apiGet, apiPost, apiDelete, thinkTime, randomId, randomName } from '../../helpers/utils.js';
import { Trend, Counter } from 'k6/metrics';

/**
 * ═══════════════════════════════════════════════════════════════
 * SOAK TEST - Resistencia prolongada (1h+)
 * ═══════════════════════════════════════════════════════════════
 * Detecta: memory leaks, degradación progresiva, connection pool
 * exhaustion, acumulación de logs.
 *
 * Ejecución: k6 run -e ENV=qa src/tests/soak/endurance.js
 */

const soakDuration = new Trend('soak_req_duration');
const soakErrors = new Counter('soak_errors');

export const options = {
    ...profiles.soak,
    tags: { testType: 'soak' },
};

export default function () {
    // Flujo repetitivo: crear → leer → eliminar
    const payload = { id: randomId(), name: randomName('Soak'), status: 'active' };
    const createRes = apiPost('/resource', payload);
    soakDuration.add(createRes.timings.duration);

    if (!checks.isStatus(createRes, 201)) {
        soakErrors.add(1);
        return;
    }

    const id = JSON.parse(createRes.body).id;

    thinkTime(2, 4);

    const readRes = apiGet(`/resource/${id}`, { headers: jsonHeaders });
    soakDuration.add(readRes.timings.duration);
    checks.isStatus200(readRes);

    thinkTime(1, 3);

    const delRes = apiDelete(`/resource/${id}`);
    soakDuration.add(delRes.timings.duration);
    checks.isStatus200(delRes);

    thinkTime(3, 6);
}
