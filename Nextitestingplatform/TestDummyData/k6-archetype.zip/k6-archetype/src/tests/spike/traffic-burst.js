import { config } from '../../config/environments.js';
import { profiles } from '../../config/profiles.js';
import { jsonHeaders } from '../../config/headers.js';
import { checks } from '../../checks/http-checks.js';
import { apiGet, apiPost, thinkTime, randomId } from '../../helpers/utils.js';
import { Counter } from 'k6/metrics';

/**
 * ═══════════════════════════════════════════════════════════════
 * SPIKE TEST - Pico súbito de tráfico
 * ═══════════════════════════════════════════════════════════════
 * Simula un aumento repentino de usuarios (ej: campaña de marketing,
 * noticia viral) y verifica que el sistema se recupera.
 *
 * Ejecución: k6 run -e ENV=qa src/tests/spike/traffic-burst.js
 */

const spikeErrors = new Counter('spike_errors');

export const options = {
    ...profiles.spike,
    tags: { testType: 'spike' },
};

export default function () {
    const getRes = apiGet('/resource', { headers: jsonHeaders });
    if (!checks.isStatus200(getRes)) {
        spikeErrors.add(1);
    }
    checks.responseTimeUnder(getRes, 5000);

    thinkTime(0.3, 1);

    const payload = { id: randomId(), name: `Spike_${Date.now()}`, status: 'active' };
    const postRes = apiPost('/resource', payload);
    if (!checks.isStatus(postRes, 201)) {
        spikeErrors.add(1);
    }

    thinkTime(0.3, 1);
}
