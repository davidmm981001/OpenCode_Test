import { group } from 'k6';
import { config } from '../../config/environments.js';
import { profiles } from '../../config/profiles.js';
import { jsonHeaders } from '../../config/headers.js';
import { checks } from '../../checks/http-checks.js';
import { apiGet, apiPost, apiPut, apiDelete, thinkTime, randomId, randomName, randomEmail } from '../../helpers/utils.js';

/**
 * ═══════════════════════════════════════════════════════════════
 * E2E TEST - Flujo completo de un usuario real
 * ═══════════════════════════════════════════════════════════════
 * Simula: registrar → login → crear recurso → buscar → actualizar
 * → eliminar → logout. Con think times realistas.
 *
 * Ejecución: k6 run -e ENV=qa src/tests/e2e/user-journey.js
 */

export const options = {
    ...profiles.load,
    tags: { testType: 'e2e' },
};

export default function () {
    let authToken = '';
    let resourceId = '';

    // ── 1. Registrar usuario ──
    group('01 - Registrar usuario', () => {
        const user = {
            username: randomName('user'),
            email: randomEmail(),
            password: 'TestP@ss123',
        };
        const res = apiPost('/auth/register', user);
        checks.isStatus(res, 201);
    });
    thinkTime(2, 4);

    // ── 2. Login ──
    group('02 - Iniciar sesión', () => {
        const res = apiPost('/auth/login', {
            username: config.testUser,
            password: config.testPassword,
        });
        checks.isStatus200(res);
        checks.responseContains(res, 'token');

        if (res.status === 200) {
            authToken = JSON.parse(res.body).token || '';
        }
    });
    thinkTime(1, 3);

    // ── 3. Crear recurso ──
    group('03 - Crear recurso', () => {
        const payload = {
            id: randomId(),
            name: randomName('E2E'),
            status: 'active',
        };
        const res = apiPost('/resource', payload);
        checks.isStatus(res, 201);

        if (res.status === 201) {
            resourceId = JSON.parse(res.body).id;
        }
    });
    thinkTime(2, 4);

    // ── 4. Buscar recursos ──
    group('04 - Buscar recursos', () => {
        const res = apiGet('/resource?status=active', { headers: jsonHeaders });
        checks.isStatus200(res);
        checks.responseTimeUnder(res, 1500);
    });
    thinkTime(1, 3);

    // ── 5. Actualizar recurso ──
    group('05 - Actualizar recurso', () => {
        if (!resourceId) return;
        const payload = { name: randomName('E2E_Updated'), status: 'inactive' };
        const res = apiPut(`/resource/${resourceId}`, payload);
        checks.isStatus200(res);
    });
    thinkTime(1, 2);

    // ── 6. Eliminar recurso ──
    group('06 - Eliminar recurso', () => {
        if (!resourceId) return;
        const res = apiDelete(`/resource/${resourceId}`);
        checks.isStatus200(res);
    });
    thinkTime(1, 2);

    // ── 7. Verificar eliminación ──
    group('07 - Verificar eliminación', () => {
        if (!resourceId) return;
        const res = apiGet(`/resource/${resourceId}`, { headers: jsonHeaders });
        checks.isStatus(res, 404);
    });
    thinkTime(1, 2);
}
