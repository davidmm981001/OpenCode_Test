import { group } from 'k6';
import { config } from '../../config/environments.js';
import { profiles } from '../../config/profiles.js';
import { jsonHeaders } from '../../config/headers.js';
import { checks } from '../../checks/http-checks.js';
import { apiGet, apiPost, apiPut, apiDelete, thinkTime, randomId, randomName } from '../../helpers/utils.js';

/**
 * ═══════════════════════════════════════════════════════════════
 * LOAD TEST - Carga normal esperada (CRUD completo)
 * ═══════════════════════════════════════════════════════════════
 * Simula tráfico real: crea, consulta, actualiza y elimina recursos.
 * Ramp up → steady state → pico → ramp down.
 *
 * Ejecución: k6 run -e ENV=qa src/tests/load/crud-flow.js
 */

export const options = {
    ...profiles.load,
    tags: { testType: 'load' },
};

export default function () {
    let resourceId;

    // ── Crear recurso ──
    group('POST - Crear recurso', () => {
        const payload = {
            id: randomId(),
            name: randomName('Load'),
            status: 'active',
        };
        const res = apiPost('/resource', payload);
        checks.isStatus(res, 201);
        checks.responseContains(res, 'id');

        if (res.status === 201) {
            resourceId = JSON.parse(res.body).id;
        }
    });

    thinkTime(1, 3);

    // ── Consultar recurso ──
    group('GET - Consultar recurso', () => {
        if (!resourceId) return;
        const res = apiGet(`/resource/${resourceId}`, { headers: jsonHeaders });
        checks.isStatus200(res);
        checks.isValidJson(res);
        checks.responseTimeUnder(res, 1000);
    });

    thinkTime(1, 2);

    // ── Actualizar recurso ──
    group('PUT - Actualizar recurso', () => {
        if (!resourceId) return;
        const payload = {
            name: randomName('Updated'),
            status: 'inactive',
        };
        const res = apiPut(`/resource/${resourceId}`, payload);
        checks.isStatus200(res);
    });

    thinkTime(1, 2);

    // ── Eliminar recurso ──
    group('DELETE - Eliminar recurso', () => {
        if (!resourceId) return;
        const res = apiDelete(`/resource/${resourceId}`);
        checks.isStatus200(res);
    });

    thinkTime(2, 4);
}
