import { config } from '../../config/environments.js';
import { profiles } from '../../config/profiles.js';
import { jsonHeaders } from '../../config/headers.js';
import { checks } from '../../checks/http-checks.js';
import { apiPost, thinkTime } from '../../helpers/utils.js';
import { loadCsv } from '../../helpers/csv-reader.js';

/**
 * ═══════════════════════════════════════════════════════════════
 * LOAD TEST - Data-driven desde CSV
 * ═══════════════════════════════════════════════════════════════
 * Cada VU toma un usuario aleatorio del CSV y simula login.
 *
 * Ejecución: k6 run -e ENV=qa src/tests/load/csv-driven.js
 */

const users = loadCsv('users.csv');

export const options = {
    ...profiles.load,
    tags: { testType: 'load', dataSource: 'csv' },
};

export default function () {
    // Seleccionar usuario aleatorio del CSV
    const user = users[Math.floor(Math.random() * users.length)];

    const payload = {
        username: user.username,
        password: user.password,
    };

    const res = apiPost('/auth/login', payload);
    checks.isStatus200(res);
    checks.responseTimeUnder(res, 1500);
    checks.responseContains(res, 'token');

    thinkTime(2, 5);
}
