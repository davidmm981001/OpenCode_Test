import { check } from 'k6';

/**
 * ═══════════════════════════════════════════════════════════════
 * CHECKS - Validaciones reutilizables para respuestas HTTP
 * ═══════════════════════════════════════════════════════════════
 *
 * Uso:
 *   import { checks } from '../checks/http-checks.js';
 *   checks.isStatus200(response);
 *   checks.isValidJson(response);
 *   checks.responseContains(response, 'id');
 */

export const checks = {

    isStatus(response, code) {
        return check(response, {
            [`status es ${code}`]: (r) => r.status === code,
        });
    },

    isStatus200(response) {
        return check(response, {
            'status es 200':       (r) => r.status === 200,
            'sin errores HTTP':    (r) => r.status < 400,
        });
    },

    isStatus201(response) {
        return check(response, {
            'status es 201 (created)': (r) => r.status === 201,
        });
    },

    isValidJson(response) {
        return check(response, {
            'body es JSON válido': (r) => {
                try { JSON.parse(r.body); return true; }
                catch (e) { return false; }
            },
        });
    },

    responseTimeUnder(response, ms) {
        return check(response, {
            [`tiempo < ${ms}ms`]: (r) => r.timings.duration < ms,
        });
    },

    responseContains(response, field) {
        return check(response, {
            [`respuesta contiene '${field}'`]: (r) => {
                const body = JSON.parse(r.body);
                return body[field] !== undefined;
            },
        });
    },

    responseFieldEquals(response, field, expected) {
        return check(response, {
            [`${field} == '${expected}'`]: (r) => {
                const body = JSON.parse(r.body);
                return String(body[field]) === String(expected);
            },
        });
    },

    bodyNotEmpty(response) {
        return check(response, {
            'body no vacío': (r) => r.body && r.body.length > 0,
        });
    },

    headerExists(response, header) {
        return check(response, {
            [`header '${header}' presente`]: (r) => r.headers[header] !== undefined,
        });
    },
};
