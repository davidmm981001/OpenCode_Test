import { sleep } from 'k6';
import http from 'k6/http';
import { config } from '../config/environments.js';
import { jsonHeaders } from '../config/headers.js';

/**
 * ═══════════════════════════════════════════════════════════════
 * HELPERS - Utilidades reutilizables para tests K6
 * ═══════════════════════════════════════════════════════════════
 */

// ─── Generadores de datos ───

export function randomId() {
    return Math.floor(Math.random() * 900000) + 100000;
}

export function randomName(prefix = 'Test') {
    return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 6)}`;
}

export function randomEmail(domain = 'test.com') {
    return `perf_${Date.now().toString(36)}@${domain}`;
}

export function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function randomFromArray(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

// ─── Pausa realista (think time) ───

export function thinkTime(minSec = 1, maxSec = 3) {
    sleep(randomInt(minSec * 1000, maxSec * 1000) / 1000);
}

// ─── Autenticación ───

export function getAuthToken() {
    const loginPayload = JSON.stringify({
        username: config.testUser,
        password: config.testPassword,
    });

    const response = http.post(
        `${config.baseUrl}/auth/login`,
        loginPayload,
        { headers: jsonHeaders }
    );

    if (response.status === 200) {
        const body = JSON.parse(response.body);
        return body.token || body.access_token || '';
    }
    return '';
}

// ─── HTTP Wrappers con base URL ───

export function apiGet(path, params = {}) {
    return http.get(`${config.baseUrl}${path}`, params);
}

export function apiPost(path, body, params = {}) {
    return http.post(
        `${config.baseUrl}${path}`,
        JSON.stringify(body),
        { headers: jsonHeaders, ...params }
    );
}

export function apiPut(path, body, params = {}) {
    return http.put(
        `${config.baseUrl}${path}`,
        JSON.stringify(body),
        { headers: jsonHeaders, ...params }
    );
}

export function apiDelete(path, params = {}) {
    return http.del(`${config.baseUrl}${path}`, null, params);
}
