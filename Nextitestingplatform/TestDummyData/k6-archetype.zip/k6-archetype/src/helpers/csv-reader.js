import papaparse from 'https://jslib.k6.io/papaparse/5.1.1/index.js';
import { SharedArray } from 'k6/data';

/**
 * ═══════════════════════════════════════════════════════════════
 * CSV DATA - Leer datos desde archivos CSV
 * ═══════════════════════════════════════════════════════════════
 * SharedArray se carga UNA vez y se comparte entre VUs (eficiente).
 *
 * Uso:
 *   import { loadCsv } from '../helpers/csv-reader.js';
 *   const users = loadCsv('users.csv');
 *   const row = users[Math.floor(Math.random() * users.length)];
 */

export function loadCsv(filename) {
    return new SharedArray(filename, function () {
        const data = papaparse.parse(open(`../data/csv/${filename}`), {
            header: true,
            skipEmptyLines: true,
        });
        return data.data;
    });
}
