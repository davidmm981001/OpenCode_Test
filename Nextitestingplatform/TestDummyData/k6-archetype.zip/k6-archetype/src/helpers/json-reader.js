import { SharedArray } from 'k6/data';

/**
 * ═══════════════════════════════════════════════════════════════
 * JSON DATA - Leer datos desde archivos JSON
 * ═══════════════════════════════════════════════════════════════
 *
 * Uso:
 *   import { loadJson } from '../helpers/json-reader.js';
 *   const data = loadJson('payloads.json');
 */

export function loadJson(filename) {
    return new SharedArray(filename, function () {
        const raw = open(`../data/json/${filename}`);
        return JSON.parse(raw);
    });
}

export function loadJsonObject(filename) {
    const raw = open(`../data/json/${filename}`);
    return JSON.parse(raw);
}
