/**
 * ═══════════════════════════════════════════════════════════════
 * CONFIG - Configuración centralizada multi-ambiente
 * ═══════════════════════════════════════════════════════════════
 * Uso: k6 run -e ENV=qa src/tests/smoke/api-health.js
 *
 * Ambientes: dev | qa | staging | prod
 */

const environments = {
    dev: {
        baseUrl: 'http://localhost:8080/api/v1',
        webUrl: 'http://localhost:3000',
        apiKey: 'dev-key-local',
        testUser: 'dev@test.com',
        testPassword: 'DevP@ss123',
    },
    qa: {
        baseUrl: 'https://qa-api.yourcompany.com/api/v1',
        webUrl: 'https://qa.yourcompany.com',
        apiKey: 'qa-key-12345',
        testUser: 'qa_user@test.com',
        testPassword: 'SecureP@ss123',
    },
    staging: {
        baseUrl: 'https://staging-api.yourcompany.com/api/v1',
        webUrl: 'https://staging.yourcompany.com',
        apiKey: 'staging-key-67890',
        testUser: 'staging@test.com',
        testPassword: 'StagingP@ss456',
    },
    prod: {
        baseUrl: 'https://api.yourcompany.com/api/v1',
        webUrl: 'https://yourcompany.com',
        apiKey: 'prod-readonly-key',
        testUser: 'monitor@yourcompany.com',
        testPassword: 'MonitorP@ss789',
    },
};

const currentEnv = __ENV.ENV || 'qa';

if (!environments[currentEnv]) {
    throw new Error(`Ambiente '${currentEnv}' no configurado. Usa: dev, qa, staging, prod`);
}

export const config = environments[currentEnv];
export const ENV = currentEnv;
