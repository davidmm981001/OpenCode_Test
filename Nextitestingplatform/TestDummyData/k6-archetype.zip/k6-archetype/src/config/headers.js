/**
 * ═══════════════════════════════════════════════════════════════
 * HEADERS - Headers predefinidos reutilizables
 * ═══════════════════════════════════════════════════════════════
 */
import { config } from './environments.js';

export const jsonHeaders = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
};

export const authHeaders = {
    ...jsonHeaders,
    'Authorization': `Bearer ${config.apiKey}`,
};

export const apiKeyHeaders = {
    ...jsonHeaders,
    'api_key': config.apiKey,
};

export function bearerToken(token) {
    return {
        ...jsonHeaders,
        'Authorization': `Bearer ${token}`,
    };
}
