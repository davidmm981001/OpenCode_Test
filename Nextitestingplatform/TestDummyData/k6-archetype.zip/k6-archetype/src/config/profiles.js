/**
 * ═══════════════════════════════════════════════════════════════
 * PROFILES - Perfiles de carga predefinidos
 * ═══════════════════════════════════════════════════════════════
 * Cada perfil define stages, VUs, y duración para un tipo de test.
 *
 * Uso:
 *   import { profiles } from '../config/profiles.js';
 *   export const options = profiles.smoke;
 */

export const profiles = {

    // ── Smoke: Validación rápida, pocos usuarios ──
    smoke: {
        stages: [
            { duration: '30s', target: 5 },
            { duration: '1m',  target: 5 },
            { duration: '10s', target: 0 },
        ],
        thresholds: {
            http_req_duration: ['p(95)<500'],
            http_req_failed:   ['rate<0.01'],
        },
    },

    // ── Load: Carga normal esperada ──
    load: {
        stages: [
            { duration: '2m',  target: 50 },    // ramp up
            { duration: '5m',  target: 50 },    // steady state
            { duration: '2m',  target: 100 },   // pico
            { duration: '5m',  target: 100 },   // steady pico
            { duration: '2m',  target: 0 },     // ramp down
        ],
        thresholds: {
            http_req_duration: ['p(95)<1000', 'p(99)<2000'],
            http_req_failed:   ['rate<0.05'],
        },
    },

    // ── Stress: Encontrar el punto de quiebre ──
    stress: {
        stages: [
            { duration: '2m',  target: 50 },
            { duration: '3m',  target: 100 },
            { duration: '3m',  target: 200 },
            { duration: '3m',  target: 300 },
            { duration: '3m',  target: 400 },
            { duration: '2m',  target: 0 },
        ],
        thresholds: {
            http_req_duration: ['p(95)<3000'],
            http_req_failed:   ['rate<0.15'],
        },
    },

    // ── Spike: Pico súbito de carga ──
    spike: {
        stages: [
            { duration: '30s', target: 10 },
            { duration: '10s', target: 500 },   // spike!
            { duration: '1m',  target: 500 },
            { duration: '10s', target: 10 },    // baja súbita
            { duration: '1m',  target: 10 },
            { duration: '10s', target: 0 },
        ],
        thresholds: {
            http_req_duration: ['p(95)<5000'],
            http_req_failed:   ['rate<0.20'],
        },
    },

    // ── Soak: Resistencia prolongada ──
    soak: {
        stages: [
            { duration: '5m',  target: 50 },
            { duration: '1h',  target: 50 },    // carga sostenida
            { duration: '5m',  target: 0 },
        ],
        thresholds: {
            http_req_duration: ['p(95)<1500'],
            http_req_failed:   ['rate<0.05'],
        },
    },
};
