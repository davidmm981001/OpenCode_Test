import { defineConfig, devices } from '@playwright/test';
import dotenv from 'dotenv';

// ═══════════════════════════════════════════════════════════════
// Cargar variables de ambiente desde .env.<ENV>
// Uso: ENV=qa npx playwright test
// ═══════════════════════════════════════════════════════════════
const env = process.env.ENV || 'qa';
dotenv.config({ path: `src/config/.env.${env}` });

export default defineConfig({

  // ─── Directorio de tests ───
  testDir: './src/tests',

  // ─── Timeouts ───
  timeout: 30_000,
  expect: { timeout: 5_000 },

  // ─── Ejecución ───
  fullyParallel: true,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  forbidOnly: !!process.env.CI,

  // ─── Reportes ───
  reporter: [
    ['list'],
    ['html', { outputFolder: 'reports/html', open: 'never' }],
    ['json', { outputFile: 'reports/results.json' }],
    ['junit', { outputFile: 'reports/results.xml' }],
  ],

  // ─── Configuración global compartida ───
  use: {
    baseURL: process.env.BASE_URL || 'https://qa.yourcompany.com',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    actionTimeout: 10_000,
    navigationTimeout: 15_000,
    extraHTTPHeaders: {
      'Accept': 'application/json',
    },
  },

  // ─── Proyectos (navegadores y dispositivos) ───
  projects: [
    // ── Setup global (login, seed, etc.) ──
    {
      name: 'setup',
      testMatch: /.*\.setup\.ts/,
    },

    // ── Desktop browsers ──
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
      dependencies: ['setup'],
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
      dependencies: ['setup'],
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
      dependencies: ['setup'],
    },

    // ── Mobile ──
    {
      name: 'mobile-chrome',
      use: { ...devices['Pixel 5'] },
      dependencies: ['setup'],
    },
    {
      name: 'mobile-safari',
      use: { ...devices['iPhone 13'] },
      dependencies: ['setup'],
    },

    // ── API testing (sin navegador) ──
    {
      name: 'api',
      testMatch: /.*\.api\.spec\.ts/,
      use: { baseURL: process.env.API_URL || process.env.BASE_URL },
    },
  ],
});
