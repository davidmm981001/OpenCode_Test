# 🎭 Playwright Testing Framework — Arquetipo

Arquetipo base para automatización de pruebas **UI + API** con **Playwright** + **TypeScript**.  
Listo para clonar, configurar y empezar a escribir tests.

---

## 📁 Estructura

```
playwright-testing-framework/
├── playwright.config.ts                       # Config: browsers, ambientes, reportes
├── package.json                               # Dependencias y scripts npm
├── tsconfig.json                              # Configuración TypeScript
│
└── src/
    ├── config/                                # Variables por ambiente
    │   ├── .env.dev
    │   ├── .env.qa
    │   └── .env.staging
    │
    ├── pages/                                 # Page Object Model
    │   ├── BasePage.ts                        # Clase base (métodos comunes)
    │   ├── LoginPage.ts                       # Ejemplo de Page Object
    │   └── index.ts                           # Barrel export
    │
    ├── tests/                                 # Archivos de test (.spec.ts)
    │   ├── global.setup.ts                    # Setup global (auth, seed)
    │   ├── sample-ui.spec.ts                  # Template tests UI
    │   └── sample-resource.api.spec.ts        # Template tests API
    │
    ├── fixtures/                              # Custom fixtures (Page Objects inyectados)
    │   └── index.ts
    │
    ├── helpers/                               # Utilidades reutilizables
    │   ├── DataLoader.ts                      # Carga JSON, CSV, Excel
    │   ├── TestHelpers.ts                     # IDs, nombres, retry, API calls
    │   └── index.ts
    │
    └── data/                                  # Datos de prueba externos
        ├── json/
        ├── csv/
        └── excel/
```

---

## 🚀 Inicio Rápido

### 1. Instalar

```bash
npm install
npx playwright install --with-deps
```

### 2. Configurar tu aplicación

Edita los archivos `.env.*` en `src/config/`:

```env
BASE_URL=https://tu-app.com
API_URL=https://api.tu-app.com/v1
TEST_USER=tu_usuario@test.com
TEST_PASSWORD=TuPassword123
```

### 3. Ejecutar

```bash
npm test                    # Todos los tests
npm run test:smoke          # Solo @smoke
npm run test:regression     # Solo @regression
npm run test:e2e            # Solo @e2e
npm run test:api            # Solo API (sin browser)
npm run report              # Abrir reporte HTML
```

---

## 📋 Comandos Completos

### Por tipo de test

| Comando | Qué ejecuta |
|---------|-------------|
| `npm test` | Todos los tests en todos los browsers |
| `npm run test:smoke` | Solo tests con tag `@smoke` |
| `npm run test:regression` | Solo tests con tag `@regression` |
| `npm run test:e2e` | Solo flujos end-to-end |
| `npm run test:api` | Solo tests API (sin browser) |

### Por navegador

| Comando | Navegador |
|---------|-----------|
| `npm run test:chromium` | Chrome |
| `npm run test:firefox` | Firefox |
| `npm run test:webkit` | Safari |
| `npm run test:mobile` | Chrome mobile (Pixel 5) |

### Por ambiente

```bash
ENV=dev npm test            # Desarrollo local
ENV=qa npm test             # QA (default)
ENV=staging npm test        # Pre-producción
```

### Modo interactivo y debug

```bash
npm run test:ui             # UI interactiva de Playwright
npm run test:headed         # Ver el browser en pantalla
npm run test:debug          # Modo debug paso a paso
npm run codegen             # Grabar interacciones → generar código
```

### Filtros avanzados (directo con npx)

```bash
# Por archivo
npx playwright test src/tests/sample-ui.spec.ts

# Por nombre del test
npx playwright test --grep "login exitoso"

# Combinación de tags
npx playwright test --grep "@smoke|@e2e"

# Excluir tag
npx playwright test --grep-invert "@negative"

# Un solo browser + tag
npx playwright test --project=chromium --grep "@smoke"
```

---

## 📊 Reportes

Después de cada ejecución se generan automáticamente:

| Reporte | Ubicación | Comando |
|---------|-----------|---------|
| HTML interactivo | `reports/html/index.html` | `npm run report` |
| JSON (CI/CD) | `reports/results.json` | — |
| JUnit XML (CI/CD) | `reports/results.xml` | — |
| Screenshots | Adjuntos al reporte HTML | Automático en fallos |
| Videos | Adjuntos al reporte HTML | Automático en fallos |
| Traces | Descargable desde reporte | En primer reintento |

---

## 🏗️ Cómo Agregar un Nuevo Módulo

### Paso 1: Crear el Page Object

```typescript
// src/pages/DashboardPage.ts
import { Page, Locator } from '@playwright/test';
import { BasePage } from './BasePage';

export class DashboardPage extends BasePage {
  readonly welcomeText: Locator;
  readonly createButton: Locator;

  constructor(page: Page) {
    super(page);
    this.welcomeText = page.locator('[data-testid="welcome"]');
    this.createButton = page.locator('button:has-text("Crear")');
  }

  async goto(): Promise<void> {
    await this.navigate('/dashboard');
  }

  async clickCreate(): Promise<void> {
    await this.click(this.createButton);
  }
}
```

### Paso 2: Exportar en el barrel

```typescript
// src/pages/index.ts
export { DashboardPage } from './DashboardPage';
```

### Paso 3: Registrar el fixture

```typescript
// src/fixtures/index.ts
import { DashboardPage } from '../pages';

type CustomFixtures = {
  loginPage: LoginPage;
  dashboardPage: DashboardPage;  // ← agregar
};

export const test = base.extend<CustomFixtures>({
  loginPage: async ({ page }, use) => { await use(new LoginPage(page)); },
  dashboardPage: async ({ page }, use) => { await use(new DashboardPage(page)); },
});
```

### Paso 4: Escribir los tests

```typescript
// src/tests/dashboard.spec.ts
import { test, expect } from '../fixtures';

test.describe('Dashboard @regression', () => {
  test('muestra mensaje de bienvenida @smoke', async ({ dashboardPage }) => {
    await dashboardPage.goto();
    await dashboardPage.expectVisible(dashboardPage.welcomeText);
  });
});
```

---

## 📋 Cómo Cargar Datos de Prueba

### JSON

```typescript
import { DataLoader } from '../helpers';

interface User { username: string; password: string; }
const users = DataLoader.fromJson<User[]>('users.json');
```

### CSV (data-driven)

```typescript
const rows = DataLoader.fromCsv('login-data.csv');

for (const row of rows) {
  test(`login: ${row.description}`, async ({ loginPage }) => {
    await loginPage.login(row.username, row.password);
  });
}
```

### Excel

```typescript
const data = DataLoader.fromExcel('test-data.xlsx', 'Sheet1');

// Con filtro
const activos = DataLoader.fromExcelFiltered(
  'test-data.xlsx', 'Sheet1', 'status', 'active'
);
```

---

## 🏷️ Sistema de Tags

Usa `@tag` dentro del nombre del `test.describe` o `test()`:

```typescript
test.describe('Login @smoke @regression', () => {
  test('caso positivo @smoke', async () => { ... });
  test('caso negativo @negative', async () => { ... });
});
```

Ejecutar por tag:

```bash
npx playwright test --grep "@smoke"
npx playwright test --grep "@smoke|@e2e"
npx playwright test --grep-invert "@negative"
```

| Tag | Propósito |
|-----|-----------|
| `@smoke` | Tests críticos mínimos |
| `@regression` | Suite completa |
| `@e2e` | Flujos end-to-end |
| `@negative` | Manejo de errores |
| `@data-driven` | Tests parametrizados |
| `@api` | Tests de API sin browser |

---

## 🔑 Buenas Prácticas del Arquetipo

1. **Page Object Model**: Toda interacción con la UI va en `pages/`, nunca en el test directo.
2. **Fixtures**: Inyecta Page Objects via fixtures, no los instancies manualmente en cada test.
3. **Data externa**: Los datos de prueba van en `data/`, no hardcodeados en los tests.
4. **Tags consistentes**: Siempre etiquetar con al menos `@smoke` o `@regression`.
5. **Ambientes vía .env**: Nunca hardcodear URLs ni credenciales en el código.
6. **API para setup/cleanup**: Usar `TestHelpers.apiCreate()` para preparar datos, no la UI.
7. **Tests independientes**: Cada test debe funcionar solo, sin depender del orden de ejecución.
8. **Selectores robustos**: Preferir `data-testid` sobre selectores CSS frágiles.

---

## ⚙️ Requisitos

- Node.js 18+
- npm 9+
