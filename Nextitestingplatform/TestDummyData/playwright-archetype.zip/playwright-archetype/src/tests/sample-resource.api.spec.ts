import { test, expect } from '@playwright/test';
import { DataLoader, TestHelpers } from '../helpers';

/**
 * ═══════════════════════════════════════════════════════════════
 * TEMPLATE: Tests de API (sin navegador)
 * ═══════════════════════════════════════════════════════════════
 * Archivo con sufijo .api.spec.ts → ejecuta en proyecto 'api'
 * sin levantar navegador.
 *
 * Ejecución: npm run test:api
 *
 * TODO: Reemplazar endpoints y payloads con los de tu API.
 */

// const testData = DataLoader.fromJson<any>('sample-data.json');

test.describe('API - CRUD de recursos @api @regression', () => {

  const API = '/api/v1/resource';
  let createdId: number;

  // ─── POST ───
  test('POST - Crear recurso @smoke', async ({ request }) => {
    const payload = {
      id: TestHelpers.generateId(),
      name: TestHelpers.randomName('Resource'),
      status: 'active',
    };

    const response = await request.post(API, { data: payload });
    expect(response.ok()).toBeTruthy();
    expect(response.status()).toBe(201);

    const body = await response.json();
    expect(body.id).toBeDefined();
    expect(body.name).toBe(payload.name);
    createdId = body.id;
  });

  test('POST - Datos inválidos retorna 400 @negative', async ({ request }) => {
    const response = await request.post(API, {
      data: { name: '', status: 'invalid' },
    });
    expect(response.status()).toBe(400);
  });

  // ─── GET ───
  test('GET - Consultar recurso por ID @smoke', async ({ request }) => {
    const response = await request.get(`${API}/${createdId}`);
    expect(response.ok()).toBeTruthy();

    const body = await response.json();
    expect(body.id).toBe(createdId);
    expect(body).toHaveProperty('name');
    expect(body).toHaveProperty('status');
  });

  test('GET - Recurso inexistente retorna 404 @negative', async ({ request }) => {
    const response = await request.get(`${API}/999999999`);
    expect(response.status()).toBe(404);
  });

  // ─── GET con filtros (data-driven) ───
  const filters = [
    { status: 'active',  expectedCode: 200, desc: 'filtro válido' },
    { status: 'inactive', expectedCode: 200, desc: 'filtro alternativo' },
    { status: 'INVALID', expectedCode: 400, desc: 'filtro inválido' },
  ];

  for (const { status, expectedCode, desc } of filters) {
    test(`GET - Listar con ${desc} @data-driven`, async ({ request }) => {
      const response = await request.get(API, {
        params: { status },
      });
      expect(response.status()).toBe(expectedCode);
    });
  }

  // ─── PUT ───
  test('PUT - Actualizar recurso existente @smoke', async ({ request }) => {
    const response = await request.put(`${API}/${createdId}`, {
      data: { name: 'Updated Name', status: 'inactive' },
    });
    expect(response.ok()).toBeTruthy();

    const body = await response.json();
    expect(body.name).toBe('Updated Name');
    expect(body.status).toBe('inactive');
  });

  // ─── DELETE ───
  test('DELETE - Eliminar recurso @smoke', async ({ request }) => {
    const response = await request.delete(`${API}/${createdId}`);
    expect(response.ok()).toBeTruthy();

    // Verificar eliminación
    const verify = await request.get(`${API}/${createdId}`);
    expect(verify.status()).toBe(404);
  });

  test('DELETE - Recurso inexistente retorna 404 @negative', async ({ request }) => {
    const response = await request.delete(`${API}/999999999`);
    expect(response.status()).toBe(404);
  });
});

test.describe('API - Flujo E2E @api @e2e', () => {

  test('ciclo completo: crear → leer → actualizar → eliminar', async ({ request }) => {
    const API = '/api/v1/resource';
    const payload = {
      id: TestHelpers.generateId(),
      name: TestHelpers.randomName('E2E'),
      status: 'active',
    };

    // Crear
    const createRes = await request.post(API, { data: payload });
    expect(createRes.status()).toBe(201);
    const { id } = await createRes.json();

    // Leer
    const readRes = await request.get(`${API}/${id}`);
    expect(readRes.ok()).toBeTruthy();
    const readBody = await readRes.json();
    expect(readBody.name).toBe(payload.name);

    // Actualizar
    const updateRes = await request.put(`${API}/${id}`, {
      data: { ...payload, name: 'E2E_Updated', status: 'inactive' },
    });
    expect(updateRes.ok()).toBeTruthy();

    // Verificar actualización
    const verifyRes = await request.get(`${API}/${id}`);
    const verifyBody = await verifyRes.json();
    expect(verifyBody.name).toBe('E2E_Updated');

    // Eliminar
    const deleteRes = await request.delete(`${API}/${id}`);
    expect(deleteRes.ok()).toBeTruthy();

    // Verificar eliminación
    const gone = await request.get(`${API}/${id}`);
    expect(gone.status()).toBe(404);
  });
});
