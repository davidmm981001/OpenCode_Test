import { test as setup } from '@playwright/test';

/**
 * ═══════════════════════════════════════════════════════════════
 * Global Setup - Se ejecuta ANTES de todos los tests
 * ═══════════════════════════════════════════════════════════════
 * Ideal para: autenticación, seed de datos, preparar estado.
 * Los demás proyectos dependen de 'setup' (ver playwright.config).
 *
 * TODO: Implementar según las necesidades de tu aplicación.
 */

setup('autenticación global', async ({ page }) => {
  // Ejemplo: Login y guardar estado de autenticación
  //
  // await page.goto('/login');
  // await page.locator('#username').fill(process.env.TEST_USER!);
  // await page.locator('#password').fill(process.env.TEST_PASSWORD!);
  // await page.locator('button[type="submit"]').click();
  // await page.waitForURL('**/dashboard**');
  //
  // // Guardar cookies/storage para reutilizar en otros tests
  // await page.context().storageState({ path: '.auth/user.json' });

  console.log('⚙️  Setup global ejecutado');
});
