import { test, expect } from '../fixtures';
import { DataLoader, TestHelpers } from '../helpers';

/**
 * ═══════════════════════════════════════════════════════════════
 * TEMPLATE: Tests UI con Page Objects y datos externos
 * ═══════════════════════════════════════════════════════════════
 * TODO: Reemplazar con los tests reales de tu aplicación.
 */

// ─── Datos de prueba ───
// const testData = DataLoader.fromJson<any>('sample-data.json');
// const csvData  = DataLoader.fromCsv('sample-data.csv');

test.describe('Login @smoke @regression', () => {

  test.beforeEach(async ({ loginPage }) => {
    await loginPage.goto();
  });

  test('debe mostrar la página de login', async ({ loginPage }) => {
    await loginPage.expectVisible(loginPage.usernameInput);
    await loginPage.expectVisible(loginPage.passwordInput);
    await loginPage.expectVisible(loginPage.loginButton);
  });

  test('login exitoso redirige al dashboard', async ({ loginPage, page }) => {
    const user = process.env.TEST_USER || 'testuser';
    const pass = process.env.TEST_PASSWORD || 'testpass';

    await loginPage.login(user, pass);
    await expect(page).toHaveURL(/.*dashboard.*/);
  });

  test('login fallido muestra mensaje de error @negative', async ({ loginPage }) => {
    await loginPage.login('usuario_invalido', 'clave_incorrecta');
    await loginPage.expectVisible(loginPage.errorMessage);
  });
});

test.describe('Login data-driven @data-driven', () => {

  // ── Scenario Outline equivalente con tabla inline ──
  const credentials = [
    { user: '',             pass: 'pass123',  expected: 'error', desc: 'usuario vacío' },
    { user: 'valid@test.com', pass: '',        expected: 'error', desc: 'contraseña vacía' },
    { user: 'valid@test.com', pass: 'Pass123', expected: 'ok',    desc: 'credenciales válidas' },
  ];

  for (const { user, pass, expected, desc } of credentials) {
    test(`login con ${desc} → ${expected}`, async ({ loginPage, page }) => {
      await loginPage.goto();
      await loginPage.login(user, pass);

      if (expected === 'ok') {
        await expect(page).toHaveURL(/.*dashboard.*/);
      } else {
        await loginPage.expectVisible(loginPage.errorMessage);
      }
    });
  }

  // ── Data-driven desde CSV ──
  // const csvRows = DataLoader.fromCsv('login-data.csv');
  // for (const row of csvRows) {
  //   test(`login CSV: ${row.description}`, async ({ loginPage }) => {
  //     await loginPage.goto();
  //     await loginPage.login(row.username, row.password);
  //     // validar según row.expectedResult
  //   });
  // }
});

test.describe('Navegación general @e2e', () => {

  test('flujo completo: login → acción → logout', async ({ loginPage, page }) => {
    // ── Login ──
    await loginPage.goto();
    await loginPage.login(
      process.env.TEST_USER || 'testuser',
      process.env.TEST_PASSWORD || 'testpass'
    );
    await expect(page).toHaveURL(/.*dashboard.*/);

    // ── Acción en la app ──
    // TODO: Interactuar con la aplicación
    // await dashboardPage.clickCreateButton();
    // await formPage.fillAndSubmit(testData);

    // ── Logout ──
    // await page.locator('[data-testid="logout"]').click();
    // await expect(page).toHaveURL(/.*login.*/);
  });
});
