import * as fs from 'fs';
import * as path from 'path';
import { parse } from 'csv-parse/sync';
import * as XLSX from 'xlsx';

/**
 * ═══════════════════════════════════════════════════════════════
 * DataLoader - Carga datos de prueba desde JSON, CSV y Excel
 * ═══════════════════════════════════════════════════════════════
 *
 * Uso:
 *   import { DataLoader } from '../helpers/DataLoader';
 *
 *   const users = DataLoader.fromJson<User[]>('users.json');
 *   const rows  = DataLoader.fromCsv('test-data.csv');
 *   const excel = DataLoader.fromExcel('data.xlsx', 'Sheet1');
 */
export class DataLoader {

  private static readonly DATA_DIR = path.resolve(__dirname, '../data');

  // ─── JSON ───

  static fromJson<T>(filename: string): T {
    const filePath = path.join(this.DATA_DIR, 'json', filename);
    const raw = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(raw) as T;
  }

  // ─── CSV ───

  static fromCsv(filename: string): Record<string, string>[] {
    const filePath = path.join(this.DATA_DIR, 'csv', filename);
    const raw = fs.readFileSync(filePath, 'utf-8');
    return parse(raw, {
      columns: true,
      skip_empty_lines: true,
      trim: true,
    });
  }

  // ─── Excel ───

  static fromExcel(filename: string, sheetName?: string): Record<string, unknown>[] {
    const filePath = path.join(this.DATA_DIR, 'excel', filename);
    const workbook = XLSX.readFile(filePath);
    const sheet = sheetName
      ? workbook.Sheets[sheetName]
      : workbook.Sheets[workbook.SheetNames[0]];

    if (!sheet) {
      throw new Error(`Hoja '${sheetName}' no encontrada en ${filename}`);
    }
    return XLSX.utils.sheet_to_json(sheet);
  }

  // ─── Excel con filtro ───

  static fromExcelFiltered(
    filename: string,
    sheetName: string,
    filterCol: string,
    filterVal: string
  ): Record<string, unknown>[] {
    const data = this.fromExcel(filename, sheetName);
    return data.filter(row => String(row[filterCol]) === filterVal);
  }
}
