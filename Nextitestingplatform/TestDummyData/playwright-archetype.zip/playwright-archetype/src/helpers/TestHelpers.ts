import { Page, APIRequestContext } from '@playwright/test';

/**
 * ═══════════════════════════════════════════════════════════════
 * TestHelpers - Utilidades comunes para tests
 * ═══════════════════════════════════════════════════════════════
 */
export class TestHelpers {

  /** Genera un ID numérico aleatorio de 6 dígitos */
  static generateId(): number {
    return Math.floor(Math.random() * 900000) + 100000;
  }

  /** Genera nombre único con prefijo */
  static randomName(prefix = 'Test'): string {
    return `${prefix}_${Date.now().toString(36)}`;
  }

  /** Genera email único para pruebas */
  static randomEmail(domain = 'test.com'): string {
    return `test_${Date.now().toString(36)}@${domain}`;
  }

  /** Timestamp ISO 8601 */
  static timestamp(): string {
    return new Date().toISOString();
  }

  /** Esperar milisegundos (usar con moderación) */
  static async sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /** Reintentar una acción N veces */
  static async retry<T>(
    fn: () => Promise<T>,
    retries = 3,
    delay = 1000
  ): Promise<T> {
    for (let i = 0; i < retries; i++) {
      try {
        return await fn();
      } catch (error) {
        if (i === retries - 1) throw error;
        await this.sleep(delay);
      }
    }
    throw new Error('Retry failed');
  }

  /** Crear recurso via API (setup de datos) */
  static async apiCreate(
    request: APIRequestContext,
    endpoint: string,
    data: Record<string, unknown>
  ) {
    const response = await request.post(endpoint, { data });
    return response.json();
  }

  /** Eliminar recurso via API (cleanup) */
  static async apiDelete(
    request: APIRequestContext,
    endpoint: string
  ) {
    await request.delete(endpoint);
  }
}
