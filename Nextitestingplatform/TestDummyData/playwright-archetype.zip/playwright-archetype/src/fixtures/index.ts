import { test as base } from '@playwright/test';
import { LoginPage } from '../pages';

/**
 * ═══════════════════════════════════════════════════════════════
 * Custom Fixtures - Inyección de Page Objects en tests
 * ═══════════════════════════════════════════════════════════════
 *
 * Extiende el `test` de Playwright con Page Objects listos para usar.
 * Cada fixture se inicializa automáticamente con la página actual.
 *
 * Uso en tests:
 *   import { test, expect } from '../fixtures';
 *
 *   test('mi test', async ({ loginPage }) => {
 *     await loginPage.goto();
 *     await loginPage.login('user', 'pass');
 *   });
 *
 * TODO: Agregar más Page Objects según crezca tu aplicación.
 */

type CustomFixtures = {
  loginPage: LoginPage;
  // TODO: Agregar aquí más Page Objects
  // dashboardPage: DashboardPage;
  // profilePage: ProfilePage;
};

export const test = base.extend<CustomFixtures>({
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },
  // TODO: Agregar más fixtures
  // dashboardPage: async ({ page }, use) => {
  //   await use(new DashboardPage(page));
  // },
});

export { expect } from '@playwright/test';
