/**
 * Barrel export de todos los Page Objects.
 * Permite importar así: import { LoginPage } from '../pages';
 */
export { BasePage } from './BasePage';
export { LoginPage } from './LoginPage';
