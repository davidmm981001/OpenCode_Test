import { Page, Locator } from '@playwright/test';
import { BasePage } from './BasePage';

/**
 * ═══════════════════════════════════════════════════════════════
 * LoginPage - Ejemplo de Page Object
 * ═══════════════════════════════════════════════════════════════
 * TODO: Reemplazar selectores con los de tu aplicación.
 *
 * Convenciones:
 *   - Declarar locators como propiedades readonly
 *   - Métodos de acción devuelven la página destino
 *   - Nombres descriptivos: loginWithValidCredentials()
 */
export class LoginPage extends BasePage {

  // ─── Locators ───
  readonly usernameInput: Locator;
  readonly passwordInput: Locator;
  readonly loginButton: Locator;
  readonly errorMessage: Locator;
  readonly rememberMeCheckbox: Locator;
  readonly forgotPasswordLink: Locator;

  constructor(page: Page) {
    super(page);
    // TODO: Reemplazar con los selectores reales de tu app
    this.usernameInput      = page.locator('#username');
    this.passwordInput      = page.locator('#password');
    this.loginButton        = page.locator('button[type="submit"]');
    this.errorMessage       = page.locator('[data-testid="error-message"]');
    this.rememberMeCheckbox = page.locator('#remember-me');
    this.forgotPasswordLink = page.locator('a[href*="forgot"]');
  }

  // ─── Acciones ───

  async goto(): Promise<void> {
    await this.navigate('/login');
  }

  async login(username: string, password: string): Promise<void> {
    await this.fill(this.usernameInput, username);
    await this.fill(this.passwordInput, password);
    await this.click(this.loginButton);
  }

  async loginAndWaitForDashboard(username: string, password: string): Promise<void> {
    await this.login(username, password);
    await this.page.waitForURL('**/dashboard**');
  }

  async getErrorText(): Promise<string> {
    return this.getText(this.errorMessage);
  }

  async checkRememberMe(): Promise<void> {
    await this.rememberMeCheckbox.check();
  }
}
